/* Siymon AI character: a small white soft-cube with a green antenna, drawn in SVG (no emoji, no bitmap).
   States: idle | greeting | listening | thinking | typing | success | error | offline  (set via data-state, animated in CSS). */
(function () {
  "use strict";
  var uid = 0;
  var STATES = ["idle", "greeting", "listening", "thinking", "typing", "success", "error", "offline"];
  function svg(id) {
    return '<svg class="sai-char" viewBox="0 0 64 64" data-state="idle" aria-hidden="true" focusable="false">' +
      '<defs>' +
      '<radialGradient id="saiB' + id + '" cx="34%" cy="22%" r="88%"><stop offset="0" stop-color="#ffffff"/><stop offset=".62" stop-color="#eef2ee"/><stop offset="1" stop-color="#c9d3c9"/></radialGradient>' +
      '<radialGradient id="saiG' + id + '" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#5DD62C" stop-opacity=".55"/><stop offset="1" stop-color="#5DD62C" stop-opacity="0"/></radialGradient>' +
      '</defs>' +
      '<ellipse class="sai-glow" cx="32" cy="34" rx="31" ry="28" fill="url(#saiG' + id + ')"/>' +
      '<ellipse class="sai-shadow" cx="32" cy="58.5" rx="15" ry="2.8"/>' +
      '<g class="sai-body">' +
        '<g class="sai-antenna"><path d="M32 10V5" stroke="#8fa08f" stroke-width="2" stroke-linecap="round"/><circle class="sai-ant" cx="32" cy="3.8" r="2.6"/></g>' +
        '<rect x="6" y="9" width="52" height="45" rx="19" fill="url(#saiB' + id + ')"/>' +
        '<rect class="sai-rim" x="6" y="9" width="52" height="45" rx="19" fill="none" stroke-width="1.3"/>' +
        '<path d="M13.5 20.5c3.6-5.6 12.4-8 21-6.6" stroke="#fff" stroke-opacity=".95" stroke-width="2.6" stroke-linecap="round" fill="none"/>' +
        '<path class="sai-belly" d="M16 50c9 2.4 23 2.4 32 0" stroke="#b9c5b9" stroke-opacity=".7" stroke-width="1.6" stroke-linecap="round" fill="none"/>' +
        '<g class="sai-eyes sai-eyes-open"><ellipse class="sai-eye" cx="23.5" cy="31" rx="3.3" ry="4.7"/><ellipse class="sai-eye" cx="40.5" cy="31" rx="3.3" ry="4.7"/>' +
          '<circle cx="24.6" cy="29.2" r="1.15" fill="#fff"/><circle cx="41.6" cy="29.2" r="1.15" fill="#fff"/></g>' +
        '<g class="sai-eyes sai-eyes-happy"><path d="M19.5 32.5q4-6 8 0M36.5 32.5q4-6 8 0"/></g>' +
        '<g class="sai-eyes sai-eyes-flat"><path d="M19.8 32h7.4M36.8 32h7.4"/></g>' +
        '<g class="sai-brows"><path d="M19.5 24.5l7 2.2M44.5 24.5l-7 2.2"/></g>' +
        '<path class="sai-mouth sai-mouth-smile" d="M27 40.5q5 4.8 10 0"/>' +
        '<path class="sai-mouth sai-mouth-flat" d="M28.5 41.5h7"/>' +
        '<path class="sai-mouth sai-mouth-wave" d="M25.5 42q2.1-2.6 4.2 0t4.2 0t4.2 0"/>' +
        '<g class="sai-dots"><circle cx="26" cy="42" r="1.7"/><circle cx="32" cy="42" r="1.7"/><circle cx="38" cy="42" r="1.7"/></g>' +
        '<g class="sai-blush"><ellipse cx="17.5" cy="38" rx="3.2" ry="2"/><ellipse cx="46.5" cy="38" rx="3.2" ry="2"/></g>' +
      '</g></svg>';
  }
  function create(state) {
    var wrap = document.createElement("span");
    wrap.className = "sai-char-wrap";
    wrap.innerHTML = svg(++uid);
    var el = wrap.firstChild;
    var api = {
      el: wrap,
      set: function (s) { if (STATES.indexOf(s) < 0) s = "idle"; el.setAttribute("data-state", s); return api; },
      get: function () { return el.getAttribute("data-state"); },
    };
    api.set(state || "idle");
    return api;
  }
  window.SiymonAIChar = { create: create, STATES: STATES };
})();
