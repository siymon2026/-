/* Siymon AI: network layer. Talks ONLY to this site's backend (/api/ai/*); the AI provider key never reaches the browser.
   Identity is the customer's normal session token; this file never sends a customer id. */
(function () {
  "use strict";
  var TOKEN_KEYS = ["siymon_customer_token_v1", "siymon_customer_token"];
  var GUEST_KEY = "siymon_ai_guest_v1";

  function token() {
    try { for (var i = 0; i < TOKEN_KEYS.length; i++) { var t = localStorage.getItem(TOKEN_KEYS[i]); if (t) return t; } } catch (e) {}
    return "";
  }
  function guestKey() {
    try {
      var k = localStorage.getItem(GUEST_KEY);
      if (!k || !/^[a-f0-9]{16,48}$/.test(k)) {
        var a = new Uint8Array(16); (window.crypto || window.msCrypto).getRandomValues(a);
        k = Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join("");
        localStorage.setItem(GUEST_KEY, k);
      }
      return k;
    } catch (e) { return ""; }
  }
  function headers(json) {
    var h = { "X-AI-Session": guestKey() };
    var t = token(); if (t) h.Authorization = "Bearer " + t;
    if (json) h["Content-Type"] = "application/json";
    return h;
  }
  function jget(url) { return fetch(url, { headers: headers(false), cache: "no-store" }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { j._status = r.status; return j; }); }); }
  function jsend(method, url, body) { return fetch(url, { method: method, headers: headers(true), body: body ? JSON.stringify(body) : undefined }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { j._status = r.status; return j; }); }); }

  /** POST /api/ai/chat and call onEvent(obj) for each server-sent event. Resolves when the stream ends. */
  function stream(payload, onEvent, signal) {
    return fetch("/api/ai/chat", { method: "POST", headers: headers(true), body: JSON.stringify(payload), signal: signal }).then(function (res) {
      if (!res.ok || !res.body) {
        return res.json().catch(function () { return {}; }).then(function (j) { onEvent({ type: "error", code: j.code || (res.status === 429 ? "RATE_IP" : "NETWORK") }); });
      }
      var reader = res.body.getReader(), dec = new TextDecoder("utf-8"), buf = "";
      function pump() {
        return reader.read().then(function (r) {
          if (r.done) return;
          buf += dec.decode(r.value, { stream: true });
          var i;
          while ((i = buf.search(/\r?\n\r?\n/)) >= 0) {
            var block = buf.slice(0, i); buf = buf.slice(i).replace(/^\r?\n\r?\n/, "");
            var line = block.split(/\r?\n/).filter(function (l) { return l.indexOf("data:") === 0; }).map(function (l) { return l.slice(5).replace(/^ /, ""); }).join("\n");
            if (line) { try { onEvent(JSON.parse(line)); } catch (e) {} }
          }
          return pump();
        });
      }
      return pump();
    });
  }

  var TERMINAL = { done: 1, delivered: 1, canceled: 1, cancelled: 1, rejected: 1, failed: 1, refunded: 1 };
  /** Does the signed-in customer have an order in progress? (drives the contextual quick replies) */
  function hasActiveOrder() {
    if (!token()) return Promise.resolve(false);
    return fetch("/api/customer/orders", { headers: headers(false), cache: "no-store" }).then(function (r) { return r.ok ? r.json() : {}; })
      .then(function (j) { var l = (j && (j.orders || j.items)) || []; return l.some(function (o) { return !TERMINAL[String(o.status)]; }); }).catch(function () { return false; });
  }

  window.SiymonAICore = {
    token: token, guestKey: guestKey, stream: stream, hasActiveOrder: hasActiveOrder,
    config: function () { return jget("/api/ai/config"); },
    current: function () { return jget("/api/ai/current"); },
    history: function () { return jget("/api/ai/history"); },
    open: function (id) { return jget("/api/ai/history/" + encodeURIComponent(id)); },
    removeAll: function () { return jsend("DELETE", "/api/ai/history"); },
    removeOne: function (id) { return jsend("DELETE", "/api/ai/history/" + encodeURIComponent(id)); },
    startNew: function () { return jsend("POST", "/api/ai/new"); },
    support: function (summary, orderId, conversationId) { return jsend("POST", "/api/ai/support", { summary: summary, orderId: orderId || "", conversationId: conversationId || "" }); },
  };
})();
