/* Siymon AI: floating assistant UI. Depends on siymon-ai-character.js, siymon-ai-core.js, siymon-ai-i18n.js. */
(function () {
  "use strict";
  if (window.__siymonAiLoaded) return;
  window.__siymonAiLoaded = true;
  var Core = window.SiymonAICore, Char = window.SiymonAIChar, I18N = window.SiymonAII18n;
  if (!Core || !Char || !I18N) return;
  var doc = document;

  var ICON = {
    send: '<svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    stop: '<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    more: '<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><circle cx="12" cy="19" r="1.2" fill="currentColor"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
    clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12h10l1-12M9 7V4h6v3"/></svg>',
    copy: '<svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>',
    retry: '<svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 1 0 3-6.2M4 4v4h4"/></svg>',
    eyeoff: '<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10.6 6.2A9 9 0 0 1 21 12a13 13 0 0 1-3 3.8M6.5 7.6A13 13 0 0 0 3 12c1.8 3.4 5 6 9 6 1.2 0 2.3-.2 3.3-.6"/></svg>',
    expand: '<svg viewBox="0 0 24 24"><path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/></svg>',
    arrow: '<svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  };
  function h(tag, attrs, html) { var e = doc.createElement(tag); if (attrs) for (var k in attrs) { if (k === "class") e.className = attrs[k]; else e.setAttribute(k, attrs[k]); } if (html != null) e.innerHTML = html; return e; }
  function txt(tag, cls, text) { var e = h(tag, cls ? { class: cls } : null); e.textContent = text; return e; }

  var lang = "ar", T = I18N.ar, cfg = null, root, fab, tab, scrim, panel, scroll, sugg, offlineNote, input, sendBtn, menu, headChar, fabChar, statusEl, titleEl;
  var open = false, streaming = false, ctl = null, convId = "", lastUser = "", hydrated = false, charTimer = 0, activeOrder = false, wide = false;
  var GUEST_STORE = "siymon_ai_guest_msgs_v1", HIDE_KEY = "siymon_ai_hidden_v1";

  function getLang() { var l = "ar"; try { l = localStorage.getItem("siymon_lang_v1") || "ar"; } catch (e) {} return I18N[l] ? l : "ar"; }
  function pageKey() {
    var p = location.pathname.replace(/\/+$/, "/");
    if (p === "/" || p === "/index.html") return "home";
    var m = p.match(/^\/([a-z]+)\//); return m ? m[1] : "home";
  }
  function firstName() { try { var p = JSON.parse(localStorage.getItem("siymon_customer_profile_v1") || "null"); return p && p.firstName ? String(p.firstName).slice(0, 30) : ""; } catch (e) { return ""; } }

  /* ----------------------------- character states ----------------------------- */
  function setChar(s, hold) {
    headChar.set(s); fabChar.set(s);
    clearTimeout(charTimer);
    if (hold) charTimer = setTimeout(function () { var next = navigator.onLine === false ? "offline" : (document.activeElement === input && input.value ? "listening" : "idle"); headChar.set(next); fabChar.set(next); }, hold);
  }
  function setStatus() {
    var on = navigator.onLine !== false;
    root.setAttribute("data-online", String(on));
    statusEl.lastChild.textContent = streaming ? (headChar.get() === "typing" ? T.typing : T.thinking) : (on ? T.online : T.offline);
    if (!on) setChar("offline"); else if (headChar.get() === "offline") setChar("idle");
    offlineNote.hidden = on; sendBtn.disabled = !streaming && (!on);
  }

  /* ----------------------------- messages ----------------------------- */
  function scrollDown(force) { var near = scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 140; if (force || near) scroll.scrollTop = scroll.scrollHeight; }
  function avatar() { var a = h("span", { class: "sai-av" }); a.appendChild(Char.create("idle").el); return a; }
  function addUser(text) {
    var m = h("div", { class: "sai-msg user" }); var c = h("div", { class: "sai-col" }); c.appendChild(txt("div", "sai-bubble", text)); m.appendChild(c); scroll.appendChild(m); scrollDown(true); return m;
  }
  function addBot(text, isErr) {
    var m = h("div", { class: "sai-msg bot" + (isErr ? " err" : "") }); m.appendChild(avatar());
    var c = h("div", { class: "sai-col" }); var b = txt("div", "sai-bubble", text || ""); c.appendChild(b); m.appendChild(c); scroll.appendChild(m);
    return { el: m, col: c, bubble: b };
  }
  function actions(bot, canRetry) {
    var row = h("div", { class: "sai-acts" });
    var cp = h("button", { class: "sai-act", type: "button", "aria-label": T.copy }, ICON.copy + "<span>" + T.copy + "</span>");
    cp.onclick = function () { copyText(bot.bubble.textContent).then(function () { cp.lastChild.textContent = T.copied; setTimeout(function () { cp.lastChild.textContent = T.copy; }, 1400); }); };
    row.appendChild(cp);
    if (canRetry) { var rt = h("button", { class: "sai-act", type: "button", "aria-label": T.retry }, ICON.retry + "<span>" + T.retry + "</span>"); rt.onclick = function () { if (!streaming && lastUser) { bot.el.remove(); send(lastUser, true); } }; row.appendChild(rt); }
    bot.col.appendChild(row);
  }
  function copyText(t) {
    if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(t).catch(function () {});
    return new Promise(function (res) { try { var ta = h("textarea"); ta.value = t; ta.style.cssText = "position:fixed;opacity:0"; doc.body.appendChild(ta); ta.select(); doc.execCommand("copy"); ta.remove(); } catch (e) {} res(); });
  }

  function money(n, cur) { var v = Number(n); if (!isFinite(v)) return ""; return v.toFixed(2).replace(/\.00$/, "") + " " + (cur || "MAD"); }
  function renderCards(col, cards) {
    var wrap = h("div", { class: "sai-cards", role: "list" });
    cards.forEach(function (c) {
      var card = h("div", { class: "sai-card", role: "listitem" });
      if (c.img && /^(\/uploads\/|\/[^/]|https:\/\/)/.test(c.img)) {
        var im = h("div", { class: "sai-card-img" });
        var img = h("img", { alt: c.name || "", loading: "lazy" }); img.src = c.img; img.addEventListener("error", function () { im.remove(); }); im.appendChild(img); card.appendChild(im);
      }
      var b = h("div", { class: "sai-card-b" });
      b.appendChild(txt("div", "sai-card-n", c.name));
      b.appendChild(txt("div", "sai-card-s", c.storeName));
      var p = h("div", { class: "sai-card-p" }); var pb = doc.createElement("bdi"); pb.textContent = money(c.unitPrice, c.currency); p.appendChild(pb);
      if (c.onSale) { var s = doc.createElement("s"), sb = doc.createElement("bdi"); sb.textContent = money(c.price, c.currency); s.appendChild(sb); p.appendChild(s); }
      b.appendChild(p);
      var ok = c.available && c.storeOpen;
      b.appendChild(txt("span", "sai-badge" + (ok ? "" : " off"), !c.available ? T.unavailable : (!c.storeOpen ? T.closed : (c.lowStock ? T.low : T.available))));
      var a = h("div", { class: "sai-card-a" });
      var v = txt("button", "sai-pill", T.view); v.type = "button"; v.onclick = function () { openProduct(c.id); };
      var ad = txt("button", "sai-pill primary", T.add); ad.type = "button"; ad.disabled = !ok; ad.onclick = function () { addProduct(c.id, ad); };
      a.appendChild(v); a.appendChild(ad); b.appendChild(a); card.appendChild(b); wrap.appendChild(card);
    });
    col.appendChild(wrap);
  }
  function openProduct(id) {
    if (window.__siymonCart && window.__siymonCart.open(id)) { closePanel(); return; }
    location.href = "/?ai_item=" + encodeURIComponent(id);
  }
  function addProduct(id, btn) {
    if (window.__siymonCart && window.__siymonCart.add(id, 1)) { btn.textContent = T.added; btn.disabled = true; setChar("success", 1400); return; }
    location.href = "/?ai_add=" + encodeURIComponent(id);
  }
  function renderNav(col, nav) {
    var w = h("div", { class: "sai-nav" });
    var a = h("a", { class: "sai-link", href: nav.href }, "<span></span>" + ICON.arrow); a.firstChild.textContent = nav.label;
    w.appendChild(a); col.appendChild(w);
  }
  function renderSupport(col, sp) {
    var w = h("div", { class: "sai-support" });
    w.appendChild(txt("p", "", T.supportTitle)); w.appendChild(txt("p", "", sp.summary));
    var b = txt("button", "sai-pill primary", Core.token() ? T.supportBtn : T.supportLogin); b.type = "button";
    b.onclick = function () {
      if (!Core.token()) { location.href = "/account/"; return; }
      b.disabled = true;
      Core.support(sp.summary, sp.orderId, convId).then(function (r) {
        if (r && r.ok) { w.innerHTML = ""; w.appendChild(txt("p", "", T.supportDone)); var a = h("a", { class: "sai-link", href: "/support/" }, "<span></span>" + ICON.arrow); a.firstChild.textContent = T.supportOpen; w.appendChild(a); setChar("success", 1500); }
        else { b.disabled = false; w.appendChild(txt("p", "", T.supportFail)); setChar("error", 1800); }
      }).catch(function () { b.disabled = false; setChar("error", 1800); });
    };
    w.appendChild(b); col.appendChild(w);
  }
  function renderStored(m) {
    if (m.role === "user") { addUser(m.text); return; }
    var bot = addBot(m.text, false);
    if (m.cards && m.cards.length) renderCards(bot.col, m.cards);
    if (m.nav) renderNav(bot.col, m.nav);
    if (m.support) renderSupport(bot.col, m.support);
    actions(bot, false);
  }

  /* ----------------------------- guest transcript (session only) ----------------------------- */
  function guestLoad() { try { return JSON.parse(sessionStorage.getItem(GUEST_STORE) || "[]"); } catch (e) { return []; } }
  function guestSave(msg) { try { var a = guestLoad(); a.push(msg); sessionStorage.setItem(GUEST_STORE, JSON.stringify(a.slice(-40))); } catch (e) {} }

  /* ----------------------------- sending ----------------------------- */
  var ERR = {
    NOT_CONFIGURED: "unavailableAI", DISABLED: "unavailableAI", PROVIDER_AUTH: "unavailableAI", PROVIDER_NOT_CONFIGURED: "unavailableAI", PROVIDER_QUOTA: "providerBusy", PROVIDER_DOWN: "providerBusy", PROVIDER_TIMEOUT: "providerBusy",
    PROVIDER_BLOCKED: "genericErr", LOGIN_REQUIRED: "loginNeeded", RATE_DAY: "dayLimit", RATE_IP: "ipLimit", BUDGET: "providerBusy", NETWORK: "netErr", PROVIDER_NETWORK: "providerBusy",
  };
  function errMessage(ev) {
    if (ev.code === "RATE_MINUTE") return T.reachedLimit(ev.retryAfter || 30);
    if (ev.code === "TOO_LONG") return T.tooLong(ev.max || 600);
    var k = ERR[ev.code]; return T[k || "genericErr"];
  }
  function setBusy(b) {
    streaming = b; sendBtn.className = "sai-send" + (b ? " stop" : ""); sendBtn.innerHTML = b ? ICON.stop : ICON.send; sendBtn.setAttribute("aria-label", b ? T.stop : T.send);
    input.disabled = false; setStatus();
  }
  function send(text, isRetry) {
    text = String(text || "").trim(); if (!text || streaming) return;
    if (navigator.onLine === false) { setChar("offline"); return; }
    lastUser = text;
    if (!isRetry) { addUser(text); if (!Core.token()) guestSave({ role: "user", text: text }); }
    input.value = ""; autosize(); sugg.hidden = true;
    var bot = addBot("", false); bot.bubble.classList.add("sai-caret"); var acc = "", cards = null, nav = null, support = null, failed = null;
    ctl = new AbortController(); setBusy(true); setChar("thinking");
    Core.stream({ message: text, conversationId: convId, page: pageKey(), lang: lang }, function (ev) {
      if (ev.type === "meta") convId = ev.convId || convId;
      else if (ev.type === "state") setChar(ev.state === "working" ? "thinking" : "thinking");
      else if (ev.type === "delta") { if (!acc) setChar("typing"); acc += ev.text; bot.bubble.textContent = acc; scrollDown(); }
      else if (ev.type === "cards") { cards = ev.cards; if (!bot.col.querySelector(".sai-cards")) renderCards(bot.col, cards); scrollDown(true); }
      else if (ev.type === "nav") { nav = ev.nav; }
      else if (ev.type === "support") { support = ev.support; }
      else if (ev.type === "login") { nav = nav || { href: "/account/", label: T.signIn }; }
      else if (ev.type === "final") { acc = ev.text || acc; bot.bubble.textContent = acc; }
      else if (ev.type === "error") failed = ev;
    }, ctl.signal).catch(function (e) { if (!(e && e.name === "AbortError")) failed = failed || { code: "NETWORK" }; }).then(function () {
      bot.bubble.classList.remove("sai-caret"); setBusy(false);
      if (failed && !acc) {
        bot.el.classList.add("err"); bot.bubble.textContent = errMessage(failed); setChar("error", 2000);
        var ai = ["NOT_CONFIGURED", "DISABLED", "PROVIDER_AUTH", "PROVIDER_NOT_CONFIGURED"].indexOf(failed.code) >= 0;
        if (ai) renderNav(bot.col, { href: "/support/", label: T.sugg.human });
        else if (failed.code !== "RATE_DAY" && failed.code !== "TOO_LONG" && failed.code !== "LOGIN_REQUIRED") actions(bot, true);
        else if (failed.code === "LOGIN_REQUIRED") renderNav(bot.col, { href: "/account/", label: T.signIn });
        return;
      }
      if (!acc) { bot.el.remove(); setChar("idle"); return; }
      if (nav) renderNav(bot.col, nav);
      if (support) renderSupport(bot.col, support);
      actions(bot, false);
      if (!Core.token()) guestSave({ role: "assistant", text: acc, cards: cards || undefined, nav: nav || undefined, support: undefined });
      setChar("success", 1100); scrollDown(true);
    });
  }
  function stop() { if (ctl) { try { ctl.abort(); } catch (e) {} } }

  /* ----------------------------- suggestions (depend on customer state + page) ----------------------------- */
  function renderSugg() {
    var logged = !!Core.token(), p = pageKey(), keys;
    if (!logged) keys = ["howOrder", "meal", "pay", "login"];
    else if (activeOrder) keys = ["track", "eta", "meal", "wallet"];
    else keys = ["meal", "orders", "wallet", "points"];
    if (p === "grid") keys = logged ? ["gameRules", "gameRank", "gameStats", "gameTips"] : ["gameRules", "gameRank", "gameTips", "login"];
    var byPage = { wallet: logged ? "topup" : null, orders: logged ? "where" : null, rewards: logged ? "redeem" : null, account: logged ? "profile" : null, support: "human" };
    if (byPage[p]) { keys = keys.filter(function (k) { return k !== byPage[p]; }); keys.unshift(byPage[p]); }
    keys = keys.slice(0, 5);
    sugg.innerHTML = "";
    keys.forEach(function (k) { var c = txt("button", "sai-chip", T.sugg[k]); c.type = "button"; c.onclick = function () { send(T.q[k]); }; sugg.appendChild(c); });
    sugg.hidden = false;
  }

  /* ----------------------------- panel open / close ----------------------------- */
  function welcome() {
    var w = (cfg && cfg.welcome && cfg.welcome[lang]) || "";
    var n = Core.token() ? firstName() : "";
    var bot = addBot((n ? T.hello(n) + "\n" : "") + w, false); void bot;
    setChar("greeting", 2400);
  }
  function hydrate() {
    if (hydrated) return; hydrated = true;
    scroll.innerHTML = "";
    var done = function () { if (!scroll.children.length) welcome(); renderSugg(); scrollDown(true); };
    if (Core.token()) {
      Core.current().then(function (r) { var c = r && r.conversation; if (c && c.messages && c.messages.length) { convId = c.id; c.messages.forEach(renderStored); } done(); }).catch(done);
    } else { var g = guestLoad(); g.forEach(renderStored); done(); }
    Core.hasActiveOrder().then(function (a) { activeOrder = a; if (!streaming) renderSugg(); });
  }
  function openPanel() {
    if (open) return; open = true; hydrate();
    panel.setAttribute("data-open", "true"); scrim.setAttribute("data-open", "true"); fab.setAttribute("aria-expanded", "true"); fab.setAttribute("data-away", "true");
    try { history.pushState({ sai: 1 }, ""); } catch (e) {}
    setTimeout(function () { try { input.focus({ preventScroll: true }); } catch (e) {} }, 320);
    setStatus();
  }
  function closePanel(fromPop) {
    if (!open) return; open = false; hideMenu();
    panel.setAttribute("data-open", "false"); scrim.setAttribute("data-open", "false"); fab.setAttribute("aria-expanded", "false"); fab.removeAttribute("data-away");
    if (!fromPop && history.state && history.state.sai) { try { history.back(); } catch (e) {} }
    try { fab.focus({ preventScroll: true }); } catch (e) {}
  }
  function autosize() { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 120) + "px"; }

  /* ----------------------------- menu: history, new chat, clear, hide ----------------------------- */
  function hideMenu() { if (menu) { menu.remove(); menu = null; } }
  function showMenu(anchor) {
    if (menu) { hideMenu(); return; }
    menu = h("div", { class: "sai-menu", role: "menu" });
    function item(icon, label, fn) { var b = h("button", { type: "button", role: "menuitem" }, icon + "<span></span>"); b.lastChild.textContent = label; b.onclick = function () { hideMenu(); fn(); }; menu.appendChild(b); }
    item(ICON.plus, T.newChat, newChat);
    if (Core.token()) item(ICON.clock, T.history, showHistory);
    item(ICON.trash, T.clear, askClear);
    menu.appendChild(h("hr"));
    item(ICON.eyeoff, T.hide, hideAssistant);
    panel.appendChild(menu);
  }
  function newChat() {
    if (streaming) stop();
    Core.startNew().then(function (r) { convId = (r && r.conversationId) || ""; }).catch(function () { convId = ""; });
    try { sessionStorage.removeItem(GUEST_STORE); } catch (e) {}
    scroll.innerHTML = ""; hydrated = true; welcome(); renderSugg();
  }
  function showHistory() {
    Core.history().then(function (r) {
      scroll.innerHTML = ""; var box = h("div", { class: "sai-hist" });
      var list = (r && r.conversations) || [];
      if (!list.length) box.appendChild(txt("div", "sai-empty", T.noHistory));
      list.forEach(function (c) {
        var b = h("button", { class: "sai-hist-item", type: "button" }); b.appendChild(txt("span", "", c.title || "-")); b.appendChild(txt("small", "", new Date(c.updatedAt).toLocaleDateString(lang === "ar" ? "ar-MA" : lang)));
        b.onclick = function () { Core.open(c.id).then(function (x) { var cv = x && x.conversation; if (!cv) return; convId = cv.id; scroll.innerHTML = ""; cv.messages.forEach(renderStored); scrollDown(true); }); };
        box.appendChild(b);
      });
      var back = txt("button", "sai-pill", T.back); back.type = "button"; back.onclick = function () { hydrated = false; hydrate(); };
      box.appendChild(back); scroll.appendChild(box); sugg.hidden = true;
    });
  }
  function askClear() {
    var o = h("div", { class: "sai-confirm" }), b = h("div", { class: "sai-confirm-box", role: "alertdialog" });
    b.appendChild(txt("p", "", T.clearAsk)); var row = h("div");
    var no = txt("button", "sai-pill", T.cancel); no.type = "button"; no.onclick = function () { o.remove(); };
    var yes = txt("button", "sai-pill primary", T.yes); yes.type = "button"; yes.onclick = function () { o.remove(); Core.removeAll().then(function () { convId = ""; try { sessionStorage.removeItem(GUEST_STORE); } catch (e) {} scroll.innerHTML = ""; hydrated = false; hydrate(); }); };
    row.appendChild(no); row.appendChild(yes); b.appendChild(row); o.appendChild(b); panel.appendChild(o);
  }
  function hideAssistant() { try { localStorage.setItem(HIDE_KEY, "1"); } catch (e) {} closePanel(); applyHidden(); }
  function applyHidden() { var hid = false; try { hid = localStorage.getItem(HIDE_KEY) === "1"; } catch (e) {} fab.hidden = hid; tab.hidden = !hid; }

  /* ----------------------------- layout: bottom navigation, keyboard, safe areas ----------------------------- */
  function layout() {
    var hgt = 0;
    // keep clear of every bar docked at the bottom of the screen (navigation pill, cart bar...)
    doc.querySelectorAll(".sub-nav,.cart-bar,.bottom-nav,.tabbar").forEach(function (n) {
      var cs = window.getComputedStyle(n); if (cs.display === "none" || cs.visibility === "hidden") return;
      var r = n.getBoundingClientRect();
      if (r.height > 0 && r.top > window.innerHeight * 0.5 && r.top < window.innerHeight) hgt = Math.max(hgt, Math.round(window.innerHeight - r.top));
    });
    root.style.setProperty("--sai-nav", (hgt || 0) + "px");
    var vv = window.visualViewport;
    if (vv) {
      var kb = window.innerHeight - vv.height - vv.offsetTop > 120;
      fab.setAttribute("data-kb", String(kb)); if (kb && !open) fab.style.visibility = "hidden"; else fab.style.visibility = "";
      if (open && window.innerWidth < 768) { panel.style.setProperty("--sai-h", Math.round(Math.min(vv.height, window.innerHeight * 0.92)) + "px"); panel.style.bottom = Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop)) + "px"; }
      else { panel.style.removeProperty("--sai-h"); panel.style.bottom = ""; }
    }
  }

  /* ----------------------------- boot ----------------------------- */
  function applyLang() {
    lang = getLang(); T = I18N[lang]; root.setAttribute("dir", T.dir); root.setAttribute("lang", lang);
    fab.setAttribute("aria-label", T.open); tab.setAttribute("aria-label", T.show); offlineNote.textContent = T.offline; input.placeholder = T.placeholder; input.setAttribute("aria-label", T.placeholder);
    titleEl.textContent = (cfg && cfg.name) || T.name; setBusy(streaming); setStatus();
    root.querySelectorAll("[data-t]").forEach(function (e) { e.setAttribute("aria-label", T[e.getAttribute("data-t")]); e.title = T[e.getAttribute("data-t")]; });
  }
  function build() {
    root = h("div", { class: "sai-root", "data-online": "true" });
    fabChar = Char.create("idle"); headChar = Char.create("idle");
    fab = h("button", { class: "sai-fab", type: "button", "aria-haspopup": "dialog", "aria-expanded": "false" }); fab.appendChild(fabChar.el);
    tab = h("button", { class: "sai-tab", type: "button" }); tab.appendChild(Char.create("idle").el);
    scrim = h("div", { class: "sai-scrim" });
    panel = h("section", { class: "sai-panel", role: "dialog", "aria-modal": "false" });
    var head = h("div", { class: "sai-head" });
    var hc = h("span", { class: "sai-head-char" }); hc.appendChild(headChar.el);
    var tt = h("div", { class: "sai-title" }); titleEl = h("b"); statusEl = h("div", { class: "sai-status" }, '<span class="sai-dot"></span><span></span>'); tt.appendChild(titleEl); tt.appendChild(statusEl);
    var mb = h("button", { class: "sai-btn", type: "button", "data-t": "menu", "aria-haspopup": "menu" }, ICON.more);
    var xb = h("button", { class: "sai-btn sai-expand", type: "button", "data-t": "expand" }, ICON.expand);
    var cb = h("button", { class: "sai-btn", type: "button", "data-t": "close" }, ICON.close);
    head.appendChild(hc); head.appendChild(tt); head.appendChild(xb); head.appendChild(mb); head.appendChild(cb);
    scroll = h("div", { class: "sai-scroll", role: "log", "aria-live": "polite", "aria-relevant": "additions text" });
    sugg = h("div", { class: "sai-sugg", role: "group" });
    offlineNote = h("div", { class: "sai-offline", role: "status" }); offlineNote.hidden = true;
    var form = h("form", { class: "sai-form", autocomplete: "off" });
    input = h("textarea", { class: "sai-input", rows: "1", enterkeyhint: "send" }); input.maxLength = (cfg && cfg.maxMessageChars) || 600;
    sendBtn = h("button", { class: "sai-send", type: "submit" }, ICON.send);
    form.appendChild(input); form.appendChild(sendBtn);
    panel.appendChild(head); panel.appendChild(scroll); panel.appendChild(offlineNote); panel.appendChild(sugg); panel.appendChild(form);
    root.appendChild(fab); root.appendChild(tab); root.appendChild(scrim); root.appendChild(panel); doc.body.appendChild(root);

    fab.onclick = openPanel; tab.onclick = function () { try { localStorage.removeItem(HIDE_KEY); } catch (e) {} applyHidden(); };
    cb.onclick = function () { closePanel(); }; scrim.onclick = function () { closePanel(); };
    mb.onclick = function (e) { e.stopPropagation(); showMenu(mb); };
    xb.onclick = function () { wide = !wide; panel.setAttribute("data-wide", String(wide)); xb.setAttribute("aria-label", wide ? T.shrink : T.expand); };
    panel.addEventListener("click", function (e) { if (menu && !menu.contains(e.target)) hideMenu(); });
    form.onsubmit = function (e) { e.preventDefault(); if (streaming) { stop(); return; } send(input.value); };
    sendBtn.addEventListener("click", function (e) { if (streaming) { e.preventDefault(); stop(); } });
    input.addEventListener("input", function () { autosize(); if (!streaming) setChar(input.value ? "listening" : "idle"); });
    input.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey && window.innerWidth >= 768 && !e.isComposing) { e.preventDefault(); if (!streaming) send(input.value); } });
    doc.addEventListener("keydown", function (e) { if (e.key === "Escape" && open) closePanel(); });
    window.addEventListener("popstate", function () { if (open) closePanel(true); });
    window.addEventListener("online", setStatus); window.addEventListener("offline", setStatus);
    window.addEventListener("resize", layout); window.addEventListener("orientationchange", layout); window.addEventListener("storage", function (e) { if (e.key === "siymon_lang_v1") applyLang(); });
    if (window.visualViewport) { window.visualViewport.addEventListener("resize", layout); window.visualViewport.addEventListener("scroll", layout); }
    applyLang(); applyHidden(); layout(); setTimeout(layout, 600); setTimeout(layout, 1800); window.addEventListener("load", layout);
    if (window.ResizeObserver) { doc.querySelectorAll(".sub-nav,.cart-bar").forEach(function (nb) { new ResizeObserver(layout).observe(nb); }); }
  }

  Core.config().then(function (c) {
    if (!c || !c.ok || !c.available) return; // disabled / no key / guests not allowed: the page stays exactly as it was
    if (pageKey() === "grid" && !(c.game && c.game.inGame)) return; // the team switched the assistant off inside the game
    cfg = c; try { build(); } catch (e) { try { console.error("Siymon AI failed to start", e); } catch (x) {} }
  }).catch(function () {});
})();
