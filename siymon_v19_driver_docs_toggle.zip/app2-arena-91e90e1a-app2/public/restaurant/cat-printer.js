/* Cat / mini thermal printer (Fun Print, MX05/MX06/MX10, GB01...) over Web Bluetooth.
   These printers do NOT speak ESC/POS: they use a proprietary 0x51 0x78 packet
   protocol and print 1-bit bitmaps, 384 px wide (48 bytes per line).
   Receipt is drawn on a canvas, so Arabic / French / English all print correctly. */
(function () {
  "use strict";

  var SERVICES = [
    "0000ae30-0000-1000-8000-00805f9b34fb",
    "0000af30-0000-1000-8000-00805f9b34fb",
  ];
  var CHAR_WRITE = "0000ae01-0000-1000-8000-00805f9b34fb";
  var WIDTH = 384;
  var LINE_BYTES = WIDTH / 8;

  // ---- CRC8 (poly 0x07) ----
  var CRC_TABLE = (function () {
    var t = new Uint8Array(256);
    for (var i = 0; i < 256; i++) {
      var c = i;
      for (var j = 0; j < 8; j++) c = c & 0x80 ? ((c << 1) ^ 0x07) & 0xff : (c << 1) & 0xff;
      t[i] = c;
    }
    return t;
  })();
  function crc8(data) {
    var c = 0;
    for (var i = 0; i < data.length; i++) c = CRC_TABLE[c ^ data[i]];
    return c;
  }
  function packet(cmd, data) {
    data = Uint8Array.from(data || []);
    var out = new Uint8Array(8 + data.length);
    out.set([0x51, 0x78, cmd, 0x00, data.length & 0xff, (data.length >> 8) & 0xff]);
    out.set(data, 6);
    out[6 + data.length] = crc8(data);
    out[7 + data.length] = 0xff;
    return out;
  }
  var sleep = function (ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  };

  // ---- connection ----
  var UUID = function (n) { return "0000" + n + "-0000-1000-8000-00805f9b34fb"; };
  var state = { char: null, ctrl: null, data: null, notify: null, type: "cat", waiters: [] };

  function detach() {
    state.char = state.ctrl = state.data = state.notify = null;
    state.waiters = [];
  }

  async function attach(server, name) {
    detach();
    var isMxw = /^MXW/i.test(String(name || ""));
    for (var i = 0; i < SERVICES.length; i++) {
      try {
        var svc = await server.getPrimaryService(SERVICES[i]);
        if (isMxw) {
          state.type = "mxw";
          state.ctrl = await svc.getCharacteristic(UUID("ae01"));
          state.data = await svc.getCharacteristic(UUID("ae03"));
          try {
            state.notify = await svc.getCharacteristic(UUID("ae02"));
            await state.notify.startNotifications();
            state.notify.addEventListener("characteristicvaluechanged", onNotify);
          } catch (_n) { state.notify = null; }
          state.char = state.ctrl;
          return true;
        }
        state.type = "cat";
        var ch = null;
        try {
          ch = await svc.getCharacteristic(CHAR_WRITE);
        } catch (_e) {
          var all = await svc.getCharacteristics();
          for (var k = 0; k < all.length; k++) {
            var p = all[k].properties;
            if (p.write || p.writeWithoutResponse) { ch = all[k]; break; }
          }
        }
        if (ch) { state.char = ch; return true; }
      } catch (_e2) { /* try next */ }
    }
    return false;
  }
  function isAttached() { return !!state.char; }

  async function writeTo(ch, bytes) {
    if (!ch) throw new Error("Printer not ready");
    if (ch.properties.writeWithoutResponse) await ch.writeValueWithoutResponse(bytes);
    else await ch.writeValue(bytes);
  }
  function send(bytes) { return writeTo(state.char, bytes); }

  // ---- MXW01 protocol (header 22 21 ... AA) ----
  function onNotify(ev) {
    var v = new Uint8Array(ev.target.value.buffer);
    if (v.length >= 3 && v[0] === 0x22 && v[1] === 0x21) {
      var cmd = v[2];
      state.waiters = state.waiters.filter(function (w) {
        if (w.cmd === cmd) { w.resolve(v); return false; }
        return true;
      });
    }
  }
  function waitFor(cmd, ms) {
    return new Promise(function (resolve) {
      var w = { cmd: cmd, resolve: resolve };
      state.waiters.push(w);
      setTimeout(function () {
        var i = state.waiters.indexOf(w);
        if (i >= 0) { state.waiters.splice(i, 1); resolve(null); }
      }, ms);
    });
  }
  function mxwPacket(cmd, data) {
    data = Uint8Array.from(data || []);
    var out = new Uint8Array(8 + data.length);
    out.set([0x22, 0x21, cmd, 0x00, data.length & 0xff, (data.length >> 8) & 0xff]);
    out.set(data, 6);
    out[6 + data.length] = crc8(data);
    out[7 + data.length] = 0xaa;
    return out;
  }
  async function printMxw(lines) {
    var inten = parseInt(localStorage.getItem("catPrinterIntensity") || "", 10);
    if (!(inten > 0 && inten <= 100)) inten = 0x5d;
    var n = lines.length;
    await writeTo(state.ctrl, mxwPacket(0xa2, [inten]));
    await sleep(80);
    var req = waitFor(0xa9, 4000);
    await writeTo(state.ctrl, mxwPacket(0xa9, [n & 0xff, (n >> 8) & 0xff, 0x30, 0x00]));
    await req;
    var all = new Uint8Array(n * LINE_BYTES);
    for (var i = 0; i < n; i++) all.set(lines[i], i * LINE_BYTES);
    var CH = 96;
    for (var o = 0; o < all.length; o += CH) {
      await writeTo(state.data, all.slice(o, o + CH));
      await sleep(8);
    }
    var done = waitFor(0xaa, 30000);
    await writeTo(state.ctrl, mxwPacket(0xad, [0x00]));
    await done;
    await sleep(200);
  }

  // ---- canvas -> 1-bit lines ----
  function canvasToLines(canvas) {
    var ctx = canvas.getContext("2d");
    var img = ctx.getImageData(0, 0, WIDTH, canvas.height).data;
    var lines = [];
    for (var y = 0; y < canvas.height; y++) {
      var row = new Uint8Array(LINE_BYTES);
      for (var x = 0; x < WIDTH; x++) {
        var i = (y * WIDTH + x) * 4;
        var lum = 0.299 * img[i] + 0.587 * img[i + 1] + 0.114 * img[i + 2];
        if (img[i + 3] > 20 && lum < 150) row[x >> 3] |= 1 << (x & 7); // LSB = leftmost pixel
      }
      lines.push(row);
    }
    return lines;
  }

  function getEnergy() {
    var v = parseInt(localStorage.getItem("catPrinterEnergy") || "", 10);
    return v > 0 && v <= 0xffff ? v : 0x5dc0;
  }

  async function printCanvas(canvas) {
    var lines = canvasToLines(canvas);
    if (state.type === "mxw") return printMxw(lines);
    var e = getEnergy();
    await send(packet(0xa3, [0x00])); // device state
    await send(packet(0xa4, [0x32])); // quality
    await send(packet(0xa6, [0xaa, 0x55, 0x17, 0x38, 0x44, 0x5f, 0x5f, 0x5f, 0x44, 0x38, 0x2c])); // lattice start
    await send(packet(0xaf, [e & 0xff, (e >> 8) & 0xff])); // darkness
    await send(packet(0xbe, [0x01])); // apply
    await sleep(50);
    for (var i = 0; i < lines.length; i++) {
      await send(packet(0xa2, lines[i]));
      if (i % 8 === 7) await sleep(25);
      else await sleep(6);
    }
    await send(packet(0xa6, [0xaa, 0x55, 0x17, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17])); // lattice end
    await send(packet(0xa1, [0x50, 0x00])); // feed paper
    await sleep(300);
  }

  // ---- receipt drawing ----
  var AR = /[\u0600-\u06FF]/;
  var FONT = '"Noto Naskh Arabic","Segoe UI",Tahoma,Arial,sans-serif';

  function wrap(ctx, text, maxW) {
    var words = String(text || "").split(/\s+/);
    var out = [];
    var cur = "";
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      while (ctx.measureText(w).width > maxW && w.length > 1) {
        var k = w.length - 1;
        while (k > 1 && ctx.measureText(w.slice(0, k)).width > maxW) k--;
        if (cur) { out.push(cur); cur = ""; }
        out.push(w.slice(0, k));
        w = w.slice(k);
      }
      var test = cur ? cur + " " + w : w;
      if (ctx.measureText(test).width > maxW && cur) { out.push(cur); cur = w; }
      else cur = test;
    }
    if (cur) out.push(cur);
    return out.length ? out : [""];
  }

  /* rows: [{t:"text", size:22, bold:true, align:"center"|"auto", sep:true}] or {pair:[left,right]} */
  function renderRows(rows) {
    var PAD = 8;
    var tmp = document.createElement("canvas");
    tmp.width = WIDTH;
    tmp.height = 10;
    var m = tmp.getContext("2d");
    var layout = [];
    var total = PAD;
    rows.forEach(function (r) {
      if (r.sep) { layout.push({ sep: true, y: total + 6 }); total += 14; return; }
      var size = r.size || 22;
      var lh = Math.round(size * 1.35);
      m.font = (r.bold ? "bold " : "") + size + "px " + FONT;
      if (r.pair) {
        layout.push({ r: r, size: size, y: total, lines: null });
        total += lh;
        return;
      }
      var ls = wrap(m, r.t, WIDTH - PAD * 2);
      layout.push({ r: r, size: size, y: total, lines: ls, lh: lh });
      total += lh * ls.length;
    });
    total += PAD + 40;

    var c = document.createElement("canvas");
    c.width = WIDTH;
    c.height = total;
    var ctx = c.getContext("2d");
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, WIDTH, total);
    ctx.fillStyle = "#000";
    ctx.textBaseline = "top";

    layout.forEach(function (L) {
      if (L.sep) {
        ctx.fillRect(PAD, L.y, WIDTH - PAD * 2, 2);
        return;
      }
      var r = L.r;
      ctx.font = (r.bold ? "bold " : "") + L.size + "px " + FONT;
      var lh = Math.round(L.size * 1.35);
      if (r.pair) {
        var a = String(r.pair[0] || ""), b = String(r.pair[1] || "");
        var rtl = AR.test(a);
        ctx.direction = rtl ? "rtl" : "ltr";
        ctx.textAlign = rtl ? "right" : "left";
        ctx.fillText(a, rtl ? WIDTH - PAD : PAD, L.y);
        ctx.direction = "ltr";
        ctx.textAlign = rtl ? "left" : "right";
        ctx.fillText(b, rtl ? PAD : WIDTH - PAD, L.y);
        return;
      }
      L.lines.forEach(function (ln, i) {
        var rtl = AR.test(ln);
        ctx.direction = rtl ? "rtl" : "ltr";
        var al = r.align === "center" ? "center" : rtl ? "right" : "left";
        ctx.textAlign = al;
        var x = al === "center" ? WIDTH / 2 : al === "right" ? WIDTH - PAD : PAD;
        ctx.fillText(ln, x, L.y + i * lh);
      });
    });
    return c;
  }

  async function printRows(rows) {
    if (document.fonts && document.fonts.ready) { try { await document.fonts.ready; } catch (_e) {} }
    await printCanvas(renderRows(rows));
  }

  window.CatPrinter = {
    SERVICES: SERVICES,
    attach: attach,
    detach: detach,
    type: function () { return state.type; },
    isAttached: isAttached,
    printRows: printRows,
    printCanvas: printCanvas,
    renderRows: renderRows,
  };
})();
