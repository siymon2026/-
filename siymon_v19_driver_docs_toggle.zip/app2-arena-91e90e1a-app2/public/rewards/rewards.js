/* SIYMON — Rewards (نقاط الوفاء), app-style screen.
 * Every number comes from GET /api/customer/wallet (server ledger + loyalty.app view model).
 * The page never computes a balance or a tier; it only draws what the server says
 * and sends "convert N points" to the existing, idempotent redeem endpoint. */
(function () {
  "use strict";

  var TOKEN_KEY = "siymon_customer_token_v1";
  var LANG_KEY = "siymon_lang_v1";
  var CACHE_KEY = "siymon_rewards_cache_v1";
  var PAGE = 12;

  /* ------------------------------------------------------------------ i18n */
  var T = {
    ar: {
      title: "نقاط الوفاء", pts: "نقطة", points: "نقاطك", worth: "تساوي",
      tier_bronze: "عضو برونزي", tier_silver: "عضو فضي", tier_gold: "عضو ذهبي",
      toNext: "{n} نقطة لتصل إلى {t}", topTier: "وصلت لأعلى مستوى 🎉", keep: "يتجدد مستواك بما تكسبه خلال آخر 12 شهراً",
      tn_bronze: "البرونزي", tn_silver: "الفضي", tn_gold: "الذهبي", earned12: "مكتسب خلال 12 شهراً",
      convert: "حوّل إلى رصيد", convertSub: "استعمله في طلبك القادم", how: "كيف تعمل؟",
      expSoon: "تنتهي <b>{n}</b> نقطة في {d}", expUse: "استعملها", pendingNote: "{n} نقطة قيد الانتظار — تتوفر في {d}",
      nextReward: "المكافأة القادمة", rewardLadder: "سلّم المكافآت", missing: "تنقصك {n} نقطة", unlocked: "جاهز", locked: "مقفل", nextTag: "التالي",
      allDone: "يمكنك تحويل كل المكافآت المتاحة", ladderSub: "{p} نقطة = {v} {c}",
      waysEarn: "اكسب نقاطاً أكثر", wayOrder: "اطلب واكسب", wayOrderTxt: "كل طلب مكتمل يمنحك نقاطاً تلقائياً بعد التسليم.",
      per100: "عن كل 100 {c} تطلبها", wayPromo: "عرض خاص", wayConvert: "حوّلها متى شئت", wayConvertTxt: "كل {p} نقطة = 1 {c} تضاف إلى محفظتك.",
      activity: "النشاط", fAll: "الكل", fIn: "مكتسب", fOut: "مستعمل", empty: "لا يوجد نشاط بعد. اطلب وجبتك الأولى وابدأ بجمع النقاط!", more: "عرض المزيد",
      today: "اليوم", yesterday: "أمس",
      k_earn: "نقاط من طلب", k_campaign: "مكافأة عرض", k_adjust_in: "إضافة من الإدارة", k_redeem: "تحويل إلى المحفظة", k_expire: "نقاط منتهية", k_reverse: "استرجاع — طلب ملغى", k_adjust_out: "خصم من الإدارة",
      order: "طلب", pending: "قيد الانتظار", availAt: "تتوفر {d}", expiresAt: "تنتهي {d}",
      rTitle: "حوّل نقاطك إلى رصيد", rLead: "يُضاف المبلغ فوراً إلى محفظتك ويُستعمل لدفع طلباتك.", ptsUnit: "نقطة",
      youGet: "ستحصل على", rMin: "الحد الأدنى {n} نقطة", rMax: "الحد الأقصى {n} نقطة للعملية", rAll: "الكل",
      rConfirm: "تحويل {n} نقطة", rWorking: "جارٍ التحويل…", rFine: "التحويل نهائي ولا يمكن التراجع عنه.",
      rNone: "لا تملك نقاطاً كافية للتحويل بعد.", rNoneMin: "تحتاج {n} نقطة على الأقل للتحويل.", rOff: "تحويل النقاط متوقف حالياً.",
      doneTitle: "تم التحويل!", doneTxt: "أُضيف إلى محفظتك. رصيدك الآن {b}", close: "تم", wallet: "عرض المحفظة",
      errNet: "تعذّر الاتصال. تحقق من الشبكة وحاول مجدداً.", errAuth: "انتهت الجلسة. سجّل الدخول من جديد.",
      errGeneric: "تعذّر التحويل. حاول مجدداً.", errInsufficient: "نقاطك المتاحة الآن {n} فقط.", errDaily: "بلغت الحد اليومي للتحويل.", errMin: "الحد الأدنى {n} نقطة.", errMax: "الحد الأقصى {n} نقطة.",
      howTitle: "كيف تعمل نقاط الوفاء؟", h1: "اطلب: تكسب نقاطاً بعد تسليم كل طلب.", h2: "اجمع: تظهر نقاطك هنا مع تاريخ توفرها وانتهائها.", h3: "حوّل: بدّل نقاطك برصيد في المحفظة وادفع به طلبك.",
      levels: "المستويات", levelsTxt: "يتحدد مستواك بالنقاط التي كسبتها خلال آخر 12 شهراً.", terms: "الشروط",
      offTitle: "البرنامج متوقف مؤقتاً", offTxt: "رصيدك ونقاطك محفوظة كما هي وستعود الأرباح عند استئناف البرنامج.",
      loginT: "سجّل الدخول لترى نقاطك", loginTxt: "اجمع نقاطاً مع كل طلب وحوّلها إلى رصيد تدفع به.", loginBtn: "تسجيل الدخول",
      offline: "أنت غير متصل — تُعرض آخر بيانات محفوظة.", refreshed: "تم التحديث", retry: "إعادة المحاولة", loadErr: "تعذّر تحميل نقاطك.",
    },
    fr: {
      title: "Points fidélité", pts: "pts", points: "Vos points", worth: "Valeur",
      tier_bronze: "Membre Bronze", tier_silver: "Membre Argent", tier_gold: "Membre Or",
      toNext: "{n} pts pour atteindre {t}", topTier: "Niveau maximum atteint 🎉", keep: "Votre niveau dépend de vos gains des 12 derniers mois",
      tn_bronze: "Bronze", tn_silver: "Argent", tn_gold: "Or", earned12: "gagnés sur 12 mois",
      convert: "Convertir en solde", convertSub: "Utilisez-le à la prochaine commande", how: "Comment ça marche ?",
      expSoon: "<b>{n}</b> pts expirent le {d}", expUse: "Utiliser", pendingNote: "{n} pts en attente — disponibles le {d}",
      nextReward: "Prochaine récompense", rewardLadder: "Échelle de récompenses", missing: "Il vous manque {n} pts", unlocked: "Prêt", locked: "Verrouillé", nextTag: "Suivant",
      allDone: "Vous pouvez convertir toutes les récompenses", ladderSub: "{p} pts = {v} {c}",
      waysEarn: "Gagnez plus de points", wayOrder: "Commandez et gagnez", wayOrderTxt: "Chaque commande livrée vous rapporte des points automatiquement.",
      per100: "pour 100 {c} dépensés", wayPromo: "Offre spéciale", wayConvert: "Convertissez quand vous voulez", wayConvertTxt: "{p} pts = 1 {c} ajouté à votre portefeuille.",
      activity: "Activité", fAll: "Tout", fIn: "Gagnés", fOut: "Utilisés", empty: "Aucune activité. Passez votre première commande !", more: "Voir plus",
      today: "Aujourd'hui", yesterday: "Hier",
      k_earn: "Points de commande", k_campaign: "Bonus offre", k_adjust_in: "Ajout par l'équipe", k_redeem: "Converti en solde", k_expire: "Points expirés", k_reverse: "Annulé — commande annulée", k_adjust_out: "Retrait par l'équipe",
      order: "Commande", pending: "En attente", availAt: "Dispo. {d}", expiresAt: "Expire {d}",
      rTitle: "Convertir vos points", rLead: "Le montant est ajouté tout de suite à votre portefeuille.", ptsUnit: "pts",
      youGet: "Vous recevez", rMin: "Minimum {n} pts", rMax: "Maximum {n} pts par opération", rAll: "Tout",
      rConfirm: "Convertir {n} pts", rWorking: "Conversion…", rFine: "La conversion est définitive.",
      rNone: "Pas encore assez de points à convertir.", rNoneMin: "Il faut au moins {n} pts pour convertir.", rOff: "La conversion est suspendue.",
      doneTitle: "Converti !", doneTxt: "Ajouté à votre portefeuille. Solde : {b}", close: "OK", wallet: "Voir le portefeuille",
      errNet: "Connexion impossible. Vérifiez le réseau.", errAuth: "Session expirée. Reconnectez-vous.",
      errGeneric: "Conversion impossible. Réessayez.", errInsufficient: "Vous n'avez que {n} pts disponibles.", errDaily: "Limite journalière atteinte.", errMin: "Minimum {n} pts.", errMax: "Maximum {n} pts.",
      howTitle: "Comment fonctionnent les points ?", h1: "Commandez : gagnez des points à chaque livraison.", h2: "Cumulez : suivez dates de disponibilité et d'expiration ici.", h3: "Convertissez : payez vos commandes avec votre solde.",
      levels: "Niveaux", levelsTxt: "Votre niveau dépend des points gagnés sur les 12 derniers mois.", terms: "Conditions",
      offTitle: "Programme en pause", offTxt: "Votre solde et vos points sont conservés. Les gains reprendront avec le programme.",
      loginT: "Connectez-vous pour voir vos points", loginTxt: "Gagnez des points à chaque commande et convertissez-les en solde.", loginBtn: "Se connecter",
      offline: "Hors ligne — dernières données enregistrées.", refreshed: "Actualisé", retry: "Réessayer", loadErr: "Impossible de charger vos points.",
    },
    en: {
      title: "Rewards", pts: "pts", points: "Your points", worth: "Worth",
      tier_bronze: "Bronze member", tier_silver: "Silver member", tier_gold: "Gold member",
      toNext: "{n} pts to reach {t}", topTier: "Top level reached 🎉", keep: "Your level follows what you earned in the last 12 months",
      tn_bronze: "Bronze", tn_silver: "Silver", tn_gold: "Gold", earned12: "earned in 12 months",
      convert: "Convert to balance", convertSub: "Use it on your next order", how: "How it works",
      expSoon: "<b>{n}</b> pts expire on {d}", expUse: "Use them", pendingNote: "{n} pts pending — available {d}",
      nextReward: "Next reward", rewardLadder: "Reward ladder", missing: "{n} pts to go", unlocked: "Ready", locked: "Locked", nextTag: "Next",
      allDone: "You can convert every reward on the ladder", ladderSub: "{p} pts = {v} {c}",
      waysEarn: "Earn more points", wayOrder: "Order & earn", wayOrderTxt: "Every completed order earns points automatically after delivery.",
      per100: "per 100 {c} spent", wayPromo: "Special offer", wayConvert: "Convert any time", wayConvertTxt: "{p} pts = 1 {c} added to your wallet.",
      activity: "Activity", fAll: "All", fIn: "Earned", fOut: "Used", empty: "No activity yet. Place your first order to start earning!", more: "Show more",
      today: "Today", yesterday: "Yesterday",
      k_earn: "Points from order", k_campaign: "Offer bonus", k_adjust_in: "Added by team", k_redeem: "Converted to wallet", k_expire: "Points expired", k_reverse: "Reversed — order canceled", k_adjust_out: "Removed by team",
      order: "Order", pending: "Pending", availAt: "Available {d}", expiresAt: "Expires {d}",
      rTitle: "Convert your points", rLead: "The amount is added to your wallet right away and pays for your orders.", ptsUnit: "pts",
      youGet: "You get", rMin: "Minimum {n} pts", rMax: "Maximum {n} pts per conversion", rAll: "All",
      rConfirm: "Convert {n} pts", rWorking: "Converting…", rFine: "Conversion is final and cannot be undone.",
      rNone: "Not enough points to convert yet.", rNoneMin: "You need at least {n} pts to convert.", rOff: "Conversion is paused right now.",
      doneTitle: "Converted!", doneTxt: "Added to your wallet. Balance: {b}", close: "Done", wallet: "View wallet",
      errNet: "Can't connect. Check your network.", errAuth: "Session expired. Please sign in again.",
      errGeneric: "Couldn't convert. Try again.", errInsufficient: "You only have {n} pts available.", errDaily: "Daily conversion limit reached.", errMin: "Minimum {n} pts.", errMax: "Maximum {n} pts.",
      howTitle: "How do points work?", h1: "Order: earn points after every delivery.", h2: "Collect: see availability and expiry dates right here.", h3: "Convert: swap points for wallet balance and pay with it.",
      levels: "Levels", levelsTxt: "Your level follows the points you earned in the last 12 months.", terms: "Terms",
      offTitle: "Programme paused", offTxt: "Your balance and points are kept. Earning resumes with the programme.",
      loginT: "Sign in to see your points", loginTxt: "Earn points with every order and convert them into balance.", loginBtn: "Sign in",
      offline: "You're offline — showing last saved data.", refreshed: "Updated", retry: "Retry", loadErr: "Couldn't load your points.",
    },
  };

  var ICON = {
    star: '<path d="M12 2.6l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.6l1.2-6.5L2.5 9.5l6.6-.9z"/>',
    swap: '<path d="M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    bag: '<path d="M5 9h14l-1.4 9.2a1.5 1.5 0 0 1-1.5 1.3H7.9a1.5 1.5 0 0 1-1.5-1.3L5 9Z"/><path d="M8.5 9 11 4.5M15.5 9 13 4.5"/>',
    gift: '<rect x="3.5" y="8.5" width="17" height="4" rx="1"/><path d="M5 12.5V20h14v-7.5M12 8.5V20M12 8.5c-2.5 0-4-1-4-2.5S9 3.5 10.5 4.5 12 8.5 12 8.5zm0 0c2.5 0 4-1 4-2.5s-1-2.5-2.5-1.5S12 8.5 12 8.5z"/>',
    wallet: '<path d="M3.5 7.5A2 2 0 0 1 5.5 5.5H17v3"/><path d="M3.5 7.5v9a2 2 0 0 0 2 2h13a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1h-13a2 2 0 0 1-2-1Z"/><circle cx="16" cy="13" r="1.1"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
    fire: '<path d="M12 3c1 3.5 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 .3 1.2 1 2 2 2 0-3-1-5 1-8z"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    check: '<path d="M5 12.5l4.2 4.2L19 7"/>',
  };
  function svg(name) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICON[name] + "</svg>"; }

  /* ----------------------------------------------------------------- state */
  var state = { shop: null, reward: null, lang: "ar", token: "", data: null, filter: "all", shown: PAGE, loading: false, offline: false, redeem: null };
  try { state.lang = localStorage.getItem(LANG_KEY) || "ar"; } catch (e) {}
  if (!T[state.lang]) state.lang = "ar";
  try { state.token = localStorage.getItem(TOKEN_KEY) || ""; } catch (e) {}


  /* reward products (redeem points for a product) */
  Object.assign(T.ar, {
    shopT: "استبدل نقاطك بمنتجات", shopSub: "اختر مكافأتك وسنسلّمها لك", rwBtn: "استبدل", rwMissing: "ينقصك {n} نقطة", rwSold: "نفدت الكمية", rwLeft: "متبقي {n} فقط",
    rwConfirmT: "تأكيد الاستبدال", rwConfirmTxt: "سيتم خصم {n} نقطة مقابل «{name}». سنُبلغك عند تسليمها.", rwGo: "تأكيد الاستبدال", rwDone: "تم الاستبدال 🎁", rwDoneTxt: "سنبلغك عندما تصبح مكافأتك جاهزة للتسليم.",
    rwMine: "مكافآتي", rwPending: "بانتظار التسليم", rwFulfilled: "تم التسليم", rwCancelled: "ملغي (أُعيدت النقاط)", rwBal: "رصيدك بعد الاستبدال",
    rwErrPts: "رصيدك لا يكفي لهذه المكافأة", rwErrStock: "نفدت كمية هذه المكافأة", rwErrGone: "هذه المكافأة لم تعد متاحة", rwErr: "تعذّر الاستبدال، حاول مرة أخرى",
  });
  Object.assign(T.fr, {
    shopT: "Échangez vos points", shopSub: "Choisissez votre récompense, nous vous la remettons", rwBtn: "Échanger", rwMissing: "Il vous manque {n} points", rwSold: "Épuisé", rwLeft: "Plus que {n}",
    rwConfirmT: "Confirmer l'échange", rwConfirmTxt: "{n} points seront déduits pour « {name} ». Nous vous préviendrons à la remise.", rwGo: "Confirmer l'échange", rwDone: "Échange effectué 🎁", rwDoneTxt: "Nous vous préviendrons quand votre récompense sera prête.",
    rwMine: "Mes récompenses", rwPending: "À remettre", rwFulfilled: "Remis", rwCancelled: "Annulé (points restitués)", rwBal: "Solde après échange",
    rwErrPts: "Solde insuffisant pour cette récompense", rwErrStock: "Cette récompense est épuisée", rwErrGone: "Cette récompense n'est plus disponible", rwErr: "Échange impossible, réessayez",
  });
  Object.assign(T.en, {
    shopT: "Redeem your points", shopSub: "Pick a reward and we'll hand it over", rwBtn: "Redeem", rwMissing: "{n} more points needed", rwSold: "Sold out", rwLeft: "Only {n} left",
    rwConfirmT: "Confirm redemption", rwConfirmTxt: "{n} points will be deducted for “{name}”. We'll notify you on delivery.", rwGo: "Confirm redemption", rwDone: "Redeemed 🎁", rwDoneTxt: "We'll let you know when your reward is ready.",
    rwMine: "My rewards", rwPending: "Awaiting delivery", rwFulfilled: "Delivered", rwCancelled: "Cancelled (points refunded)", rwBal: "Balance after redeeming",
    rwErrPts: "Not enough points for this reward", rwErrStock: "This reward is sold out", rwErrGone: "This reward is no longer available", rwErr: "Could not redeem, please try again",
  });

  function t(k) { return (T[state.lang] && T[state.lang][k]) || T.ar[k] || k; }
  /* tier names come from the supervisor's settings; the built-in translations are only a fallback */
  function tname(x) { return (x && x.names && (x.names[state.lang] || x.names.ar)) || (x ? t("tn_" + x.id) : "") || ""; }
  function tbadge(x) {
    var n = tname(x);
    return state.lang === "ar" ? "عضو " + n : state.lang === "fr" ? "Membre " + n : n + " member";
  }
  function monthsTxt(m) {
    m = int(m) || 12;
    if (state.lang === "ar") return m === 1 ? "الشهر الأخير" : m === 2 ? "آخر شهرين" : (m <= 10 ? "آخر " + m + " أشهر" : "آخر " + m + " شهراً");
    if (state.lang === "fr") return m === 1 ? "dernier mois" : m + " derniers mois";
    return m === 1 ? "last month" : "last " + m + " months";
  }
  function fmt(k, v) { var s = t(k); Object.keys(v || {}).forEach(function (x) { s = s.split("{" + x + "}").join(v[x]); }); return s; }
  function $(id) { return document.getElementById(id); }
  function esc(v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function num(v) { var n = Number(v); return isFinite(n) ? n : 0; }
  function mad(v) { return num(v).toFixed(2); }
  function int(v) { return Math.round(num(v)).toLocaleString("en-US").replace(/,/g, "\u202f"); }
  function reduced() { try { return window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) { return false; } }
  function buzz(ms) { try { if (navigator.vibrate) navigator.vibrate(ms || 12); } catch (e) {} }
  function cur() { return (state.data && state.data.currency) || "MAD"; }
  function dayKey(iso) { return String(iso || "").slice(0, 10); }
  function fmtDay(iso) {
    if (!iso) return "";
    try { return new Date(iso).toLocaleDateString(state.lang === "ar" ? "ar-MA-u-nu-latn" : state.lang, { day: "numeric", month: "short" }); }
    catch (e) { return dayKey(iso); }
  }
  function fmtDayLong(iso) {
    try { return new Date(iso).toLocaleDateString(state.lang === "ar" ? "ar-MA-u-nu-latn" : state.lang, { weekday: "long", day: "numeric", month: "long" }); }
    catch (e) { return dayKey(iso); }
  }
  function groupLabel(iso) {
    var d = dayKey(iso), today = new Date(), y = new Date(Date.now() - 86400000);
    function k(x) { return x.getFullYear() + "-" + String(x.getMonth() + 1).padStart(2, "0") + "-" + String(x.getDate()).padStart(2, "0"); }
    var local = ""; try { local = k(new Date(iso)); } catch (e) { local = d; }
    if (local === k(today)) return t("today");
    if (local === k(y)) return t("yesterday");
    return fmtDayLong(iso);
  }

  /* -------------------------------------------------------------- network */
  function api(path, opts) {
    opts = opts || {};
    var headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
    if (state.token) headers["X-Customer-Token"] = state.token;
    return fetch(path, Object.assign({}, opts, { headers: headers, cache: "no-store" })).then(function (res) {
      return res.text().then(function (text) {
        var body = {}; try { body = text ? JSON.parse(text) : {}; } catch (e) {}
        if (!res.ok) { var err = new Error(body.error || "HTTP " + res.status); err.status = res.status; err.code = body.code || ""; err.body = body; throw err; }
        return body;
      });
    });
  }
  function saveCache(d) { try { localStorage.setItem(CACHE_KEY, JSON.stringify({ at: Date.now(), t: state.token.slice(-8), d: d })); } catch (e) {} }
  function readCache() {
    try { var c = JSON.parse(localStorage.getItem(CACHE_KEY) || "null"); return c && c.t === state.token.slice(-8) ? c.d : null; } catch (e) { return null; }
  }
  function clearCache() { try { localStorage.removeItem(CACHE_KEY); } catch (e) {} }

  /* ------------------------------------------------------------- toast */
  var toastTimer = 0;
  function toast(msg) {
    var el = $("rToast"); el.textContent = msg; el.classList.add("is-on");
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.classList.remove("is-on"); }, 2200);
  }

  /* ----------------------------------------------------------- static text */
  function applyStatic() {
    var h = document.documentElement; h.lang = state.lang; h.dir = state.lang === "ar" ? "rtl" : "ltr";
    document.title = "siymon | " + t("title");
    $("rLarge").textContent = t("title"); $("rBarTitle").textContent = t("title");
    var NAVL = { ar: ["الرئيسية", "الإشعارات", "المتاجر", "السلة", "حسابي"], en: ["Home", "Notifications", "Stores", "Cart", "Profile"], fr: ["Accueil", "Notifications", "Magasins", "Panier", "Profil"] }[state.lang];
    ["home", "bell", "store", "cart", "user"].forEach(function (k, i) {
      var a = document.getElementById("nav_" + k); if (!a) return;
      var lb = a.querySelector(".lb"); if (lb) lb.textContent = NAVL[i]; a.setAttribute("aria-label", NAVL[i]);
    });
    Array.prototype.forEach.call(document.querySelectorAll("[data-lang]"), function (b) {
      var on = b.getAttribute("data-lang") === state.lang; b.classList.toggle("is-on", on); b.setAttribute("aria-pressed", String(on));
    });
  }

  /* ------------------------------------------------------------ rendering */
  function loy() { return (state.data && state.data.loyalty) || null; }
  function appv() { var l = loy(); return (l && l.app) || null; }

  function countUp(el, to) {
    if (reduced() || to === 0) { el.textContent = int(to); return; }
    var from = num(el.getAttribute("data-v")), start = performance.now(), dur = 800;
    el.setAttribute("data-v", to);
    function tick(now) {
      var p = Math.min(1, (now - start) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = int(from + (to - from) * e);
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  function renderPass() {
    var l = loy(), a = appv(), box = $("rPass");
    if (!l) return;
    var b = l.balances || {}, p = l.program || {};
    var tier = (a && a.tier) || { id: "bronze", progress: 0, next: null, toNext: 0, earnedInWindow: 0, tiers: [] };
    box.setAttribute("data-tier", tier.id || "none");
    var avail = num(b.available);
    var off = !p.enabled;
    var noTiers = tier.enabled === false;
    var ring = tier.next ? tier.progress : 1;
    var nextName = tier.next ? tname(tier.next) : "";
    var tiers = tier.tiers || [];
    var curIdx = Math.max(0, tiers.map(function (x) { return x.id; }).indexOf(tier.id));
    var segs = tiers.map(function (x, i) { return "<i" + (i <= curIdx ? ' class="on"' : "") + "></i>"; }).join("");
    var labels = tiers.map(function (x) { return "<span>" + esc(tname(x) || x.id) + "</span>"; }).join("");
    box.innerHTML =
      '<div class="r-pass-top"><span class="r-tier"><svg viewBox="0 0 24 24" aria-hidden="true">' + ICON.star + "</svg>" + esc(tier.enabled === false ? t("points") : tbadge(tier)) + '</span><span class="r-brand">SIYMON</span></div>' +
      '<div class="r-pass-mid"><div class="r-pts"><div class="r-pts-label">' + esc(t("points")) + "</div>" +
      '<div class="r-pts-val"><b id="rPtsNum" data-v="0">0</b><small>' + esc(t("pts")) + "</small></div>" +
      '<div class="r-worth">' + esc(t("worth")) + " <b>" + esc(mad(l.valueMAD)) + " " + esc(cur()) + "</b></div></div>" +
      (noTiers ? "" : '<div class="r-ring" role="img" aria-label="' + esc(tier.next ? fmt("toNext", { n: int(tier.toNext), t: nextName }) : t("topTier")) + '">' +
      '<svg viewBox="0 0 86 86"><circle class="bg" cx="43" cy="43" r="36"/><circle class="fg" id="rRing" cx="43" cy="43" r="36"/></svg>' +
      '<div class="r-ring-in"><div><b>' + Math.round(ring * 100) + "%</b><small>" + esc(tier.next ? nextName : "★") + "</small></div></div></div>") + "</div>" +
      (tiers.length ? '<div class="r-steps">' + segs + '</div><div class="r-steps-lb">' + labels + "</div>" : "") +
      '<div class="r-pass-foot"></div>';
    var foot = box.querySelector(".r-pass-foot"), s = document.createElement("span");
    if (off) { s.textContent = t("offTitle") + " — " + t("offTxt"); }
    else if (noTiers) { s.textContent = ""; }
    else if (tier.next) {
      var parts = t("toNext").split("{n}"), bb = document.createElement("b");
      bb.textContent = int(tier.toNext);
      s.appendChild(document.createTextNode(parts[0])); s.appendChild(bb);
      s.appendChild(document.createTextNode((parts[1] || "").replace("{t}", nextName)));
    } else { s.textContent = t("topTier"); }
    foot.appendChild(s);
    countUp($("rPtsNum"), avail);
    var fg = $("rRing"), C = 226.2;
    if (fg) requestAnimationFrame(function () { requestAnimationFrame(function () { fg.style.strokeDashoffset = String(C * (1 - Math.min(1, Math.max(0, ring)))); }); });
  }

  function renderActions() {
    var l = loy(); if (!l) return;
    var can = !!l.canRedeem;
    $("rActions").innerHTML =
      '<button class="r-btn r-press" id="rBtnConvert" type="button"' + (can ? "" : " disabled") + ">" + svg("swap") + "<span>" + esc(t("convert")) + "</span></button>" +
      '<button class="r-btn ghost r-press" id="rBtnHow" type="button">' + svg("info") + "<span>" + esc(t("how")) + "</span></button>";
  }

  function renderExpire() {
    var a = appv(), l = loy(), box = $("rExpire"); if (!a || !l) { box.classList.add("hidden"); return; }
    var exp = a.expiring || {};
    var pend = num((l.balances || {}).pending);
    if (num(exp.total) > 0 && exp.next) {
      box.classList.remove("hidden");
      box.innerHTML = '<span class="ic">' + svg("clock") + "</span><p>" + fmt("expSoon", { n: int(exp.total), d: esc(fmtDay(exp.next.date)) }) + "</p>" +
        (l.canRedeem ? '<button type="button" id="rExpUse" class="r-press">' + esc(t("expUse")) + "</button>" : "");
    } else if (pend > 0 && a.pendingReleaseAt) {
      box.classList.remove("hidden");
      box.innerHTML = '<span class="ic">' + svg("clock") + "</span><p>" + esc(fmt("pendingNote", { n: int(pend), d: fmtDay(a.pendingReleaseAt) })) + "</p>";
    } else { box.classList.add("hidden"); box.innerHTML = ""; }
  }

  function renderNext() {
    var l = loy(), a = appv(), box = $("rNext"); if (!l || !a || !a.ladder || !(a.ladder.steps || []).length) { box.innerHTML = ""; return; }
    var lad = a.ladder, avail = num((l.balances || {}).available), c = cur();
    var head = "";
    if (lad.next) {
      head = '<div class="r-next"><div class="r-next-top"><b>' + esc(t("nextReward")) + ' · <em>' + esc(lad.next.value) + " " + esc(c) + "</em></b><span>" + esc(fmt("missing", { n: int(lad.next.missing) })) + "</span></div>" +
        '<div class="r-bar-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.round(lad.progress * 100) + '"><div class="r-bar-fill" id="rNextFill"></div></div>' +
        '<div class="r-bar-txt"><span>' + int(avail) + "</span><span>" + int(lad.next.points) + "</span></div></div>";
    } else {
      head = '<div class="r-next"><div class="r-next-top"><b>' + esc(t("allDone")) + "</b></div></div>";
    }
    var rungs = lad.steps.map(function (s) {
      var cls = s.unlocked ? "is-open" : (lad.next && lad.next.points === s.points ? "is-next" : "");
      return '<div class="r-rung ' + cls + '">' + (s.unlocked ? "" : '<svg class="lock" viewBox="0 0 24 24" aria-hidden="true">' + ICON.lock + "</svg>") +
        '<div class="v">' + esc(s.value) + "<small>" + esc(c) + '</small></div><div class="p">' + int(s.points) + " " + esc(t("pts")) + "</div>" +
        '<span class="s">' + esc(s.unlocked ? t("unlocked") : cls === "is-next" ? t("nextTag") : t("locked")) + "</span></div>";
    }).join("");
    box.innerHTML = '<div class="r-h"><h2>' + esc(t("rewardLadder")) + "</h2></div>" + head + '<div class="r-ladder" id="rLadder">' + rungs + "</div>";
    var fill = $("rNextFill");
    if (fill) requestAnimationFrame(function () { requestAnimationFrame(function () { fill.style.width = Math.round(lad.progress * 100) + "%"; }); });
    var ld = $("rLadder");
    if (ld) {
      var target = ld.querySelector(".is-next") || ld.querySelector(".is-open:last-of-type");
      if (target && target.scrollIntoView) { try { target.scrollIntoView({ inline: "center", block: "nearest", behavior: "auto" }); } catch (e) {} }
    }
  }

  function renderEarn() {
    var l = loy(), a = appv(), box = $("rEarn"); if (!l || !a) { box.innerHTML = ""; return; }
    var p = l.program || {}, c = cur(), cards = [];
    if (p.enabled && p.earn && p.earn.enabled && num(a.earnPer100) > 0) {
      cards.push('<article class="r-ecard"><span class="ic">' + svg("bag") + "</span><b>" + esc(t("wayOrder")) + '</b><span class="big">+' + esc(int(a.earnPer100)) + " " + esc(t("pts")) + "</span><p class=\"sub\">" + esc(fmt("per100", { c: c })) + "</p><p>" + esc(t("wayOrderTxt")) + "</p></article>");
    }
    (p.campaigns || []).forEach(function (cp) {
      var name = cp && (cp.name || cp.title); if (!name) return;
      cards.push('<article class="r-ecard promo"><span class="ic">' + svg("fire") + "</span><b>" + esc(name) + '</b>' + (num(cp.points || cp.bonusPoints) ? '<span class="big">+' + esc(int(cp.points || cp.bonusPoints)) + " " + esc(t("pts")) + "</span>" : "") + "<p>" + esc(cp.note || t("wayPromo")) + "</p></article>");
    });
    if (p.redeem && p.redeem.enabled) {
      cards.push('<article class="r-ecard"><span class="ic">' + svg("wallet") + "</span><b>" + esc(t("wayConvert")) + "</b><p>" + esc(fmt("wayConvertTxt", { p: int(l.pointsPerCurrencyUnit), c: c })) + "</p></article>");
    }
    box.innerHTML = cards.length ? '<div class="r-h"><h2>' + esc(t("waysEarn")) + '</h2></div><div class="r-earn">' + cards.join("") + "</div>" : "";
  }

  function entryView(e) {
    var credit = e.direction === "credit", k = e.kind, key;
    if (k === "adjust") key = credit ? "k_adjust_in" : "k_adjust_out"; else key = "k_" + k;
    var title = t(key); if (title === key) title = credit ? t("fIn") : t("fOut");
    var sub = [];
    if (e.orderId) sub.push(t("order") + " #" + e.orderId);
    if (credit && e.status === "pending") sub.push(fmt("availAt", { d: fmtDay(e.availableAt || e.expiresAt) }));
    else if (credit && e.expiresAt && num(e.remaining) > 0) sub.push(fmt("expiresAt", { d: fmtDay(e.expiresAt) }));
    var icon = k === "redeem" ? "swap" : k === "expire" ? "clock" : k === "reverse" ? "undo" : k === "campaign" ? "gift" : k === "earn" ? "bag" : credit ? "plus" : "minus";
    return { credit: credit, title: title, sub: sub.join(" · "), icon: icon, warn: k === "expire" || k === "reverse", pending: credit && e.status === "pending" };
  }

  function renderActivity() {
    var l = loy(), box = $("rActivity"); if (!l) return;
    var all = (l.entries || []).filter(function (e) { return e.status !== "void"; });
    var rows = all.filter(function (e) { return state.filter === "all" || (state.filter === "in" ? e.direction === "credit" : e.direction === "debit"); });
    var seg = ["all", "in", "out"].map(function (f) {
      return '<button type="button" data-f="' + f + '" class="' + (state.filter === f ? "is-on" : "") + '" role="tab" aria-selected="' + (state.filter === f) + '">' + esc(t({ all: "fAll", in: "fIn", out: "fOut" }[f])) + "</button>";
    }).join("");
    var html = '<div class="r-h"><h2>' + esc(t("activity")) + '</h2></div><div class="r-seg" role="tablist">' + seg + "</div>";
    if (!rows.length) { box.innerHTML = html + '<div class="r-list"><div class="r-empty">' + esc(t("empty")) + "</div></div>"; return; }
    var visible = rows.slice(0, state.shown), lastGroup = "", open = false;
    visible.forEach(function (e) {
      var g = groupLabel(e.at), v = entryView(e);
      if (g !== lastGroup) { if (open) html += "</div>"; html += '<div class="r-day">' + esc(g) + '</div><div class="r-list">'; open = true; lastGroup = g; }
      html += '<div class="r-row ' + (v.credit ? "in" : "") + (v.warn ? " warn" : "") + '"><span class="ic">' + svg(v.icon) + '</span><div class="tx"><b>' + esc(v.title) + "</b>" + (v.sub ? "<small>" + esc(v.sub) + "</small>" : "") +
        '</div><div class="am"><b>' + (v.credit ? "+" : "−") + int(e.points) + "</b>" + (v.pending ? '<small class="pend">' + esc(t("pending")) + "</small>" : "<small>" + esc(t("pts")) + "</small>") + "</div></div>";
    });
    if (open) html += "</div>";
    if (rows.length > state.shown) html += '<button type="button" class="r-more r-press" id="rMore">' + esc(t("more")) + "</button>";
    box.innerHTML = html;
  }

  function renderAll() {
    $("rSkel").classList.add("hidden");
    $("rAuth").classList.add("hidden");
    $("rHome").classList.remove("hidden");
    renderPass(); renderActions(); renderExpire(); renderNext(); renderEarn(); renderActivity();
    var off = $("rOffline");
    if (state.offline) { off.textContent = t("offline"); off.classList.remove("hidden"); } else off.classList.add("hidden");
  }

  function showAuth() {
    $("rSkel").classList.add("hidden"); $("rHome").classList.add("hidden");
    var box = $("rAuth");
    box.innerHTML = '<span class="big"><svg viewBox="0 0 24 24" aria-hidden="true">' + ICON.star + "</svg></span><h2>" + esc(t("loginT")) + "</h2><p>" + esc(t("loginTxt")) +
      '</p><a class="r-btn r-press" href="/orders/?next=' + encodeURIComponent("/rewards/") + '">' + esc(t("loginBtn")) + "</a>";
    box.classList.remove("hidden");
  }

  /* ------------------------------------------------------------------ load */
  function load(opts) {
    opts = opts || {};
    if (!state.token) { showAuth(); return Promise.resolve(); }
    if (state.loading) return Promise.resolve();
    state.loading = true;
    return api("/api/customer/wallet?limit=100&lang=" + encodeURIComponent(state.lang)).then(function (d) {
      state.data = d; state.offline = false; state.shown = Math.max(PAGE, state.shown);
      saveCache(d); renderAll(); loadShop();
      if (opts.toast) toast(t("refreshed"));
    }).catch(function (err) {
      if (err.status === 401) { clearCache(); state.token = ""; showAuth(); return; }
      var cached = state.data || readCache();
      if (cached) { state.data = cached; state.offline = true; renderAll(); if (opts.toast) toast(t("errNet")); return; }
      $("rSkel").classList.add("hidden");
      var box = $("rAuth");
      box.innerHTML = '<h2>' + esc(t("loadErr")) + "</h2><p>" + esc(err.status === undefined || err.message === "Failed to fetch" ? t("errNet") : err.message) + '</p><button class="r-btn r-press" type="button" id="rRetry">' + esc(t("retry")) + "</button>";
      box.classList.remove("hidden");
    }).then(function () { state.loading = false; });
  }

  /* ---------------------------------------------------------------- sheets */
  var openSheet = null, sheetEls = { redeem: "rRedeem", how: "rHow", reward: "rReward" };
  function showSheet(name, pushHistory) {
    var el = $(sheetEls[name]), sc = $("rScrim");
    if (openSheet) hideSheet(true);
    openSheet = name;
    el.hidden = false; sc.classList.remove("hidden");
    document.body.classList.add("sheet-open");
    requestAnimationFrame(function () { requestAnimationFrame(function () { el.classList.add("is-on"); sc.classList.add("is-on"); }); });
    if (pushHistory !== false) { try { history.pushState({ rSheet: name }, ""); } catch (e) {} }
    var f = el.querySelector("input,button"); if (f && !reduced()) setTimeout(function () { try { f.focus({ preventScroll: true }); } catch (e) {} }, 350);
  }
  function hideSheet(immediate) {
    if (!openSheet) return;
    var el = $(sheetEls[openSheet]), sc = $("rScrim"); openSheet = null;
    el.classList.remove("is-on"); sc.classList.remove("is-on"); el.style.transform = "";
    document.body.classList.remove("sheet-open");
    var done = function () { if (!openSheet) { el.hidden = true; sc.classList.add("hidden"); } };
    if (immediate) { el.hidden = true; sc.classList.add("hidden"); } else setTimeout(done, 360);
  }
  function closeSheet() {
    if (!openSheet) return;
    // go through history so the phone's back gesture and our close button behave the same
    if (history.state && history.state.rSheet) history.back(); else hideSheet();
  }
  window.addEventListener("popstate", function () { if (openSheet) hideSheet(); });

  // drag the grabber (or the sheet top) down to dismiss
  (function () {
    var startY = 0, dy = 0, el = null, dragging = false;
    document.addEventListener("touchstart", function (e) {
      var g = e.target.closest && e.target.closest("[data-grab]"); if (!g) return;
      el = g.closest(".r-sheet"); startY = e.touches[0].clientY; dy = 0; dragging = true; el.classList.add("is-drag");
    }, { passive: true });
    document.addEventListener("touchmove", function (e) {
      if (!dragging) return; dy = Math.max(0, e.touches[0].clientY - startY); el.style.transform = "translateY(" + dy + "px)";
    }, { passive: true });
    document.addEventListener("touchend", function () {
      if (!dragging) return; dragging = false; el.classList.remove("is-drag");
      if (dy > 110) { closeSheet(); } else { el.style.transform = ""; }
    });
  })();

  /* ---- redeem ---- */
  function newRequestId() {
    try { if (window.crypto && crypto.randomUUID) return "rd-" + crypto.randomUUID(); } catch (e) {}
    return "rd-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
  }
  function redeemLimits() {
    var l = loy(), b = l.balances || {};
    var avail = num(b.available), min = Math.max(1, num(l.minPoints)), maxTx = num(l.maxPointsPerTx);
    var max = maxTx > 0 ? Math.min(avail, maxTx) : avail;
    return { avail: avail, min: min, max: Math.floor(max), per: Math.max(1, num(l.pointsPerCurrencyUnit)), maxTx: maxTx };
  }
  function openRedeem(preset) {
    var l = loy(); if (!l) return;
    var lim = redeemLimits(), body = $("rRedeemBody");
    var enabled = !!(l.program && l.program.enabled && l.program.redeem && l.program.redeem.enabled);
    if (!enabled || lim.max < lim.min) {
      var msg = !enabled ? t("rOff") : lim.avail <= 0 ? t("rNone") : fmt("rNoneMin", { n: int(lim.min) });
      body.innerHTML = '<h2 id="rRedeemTitle">' + esc(t("rTitle")) + '</h2><p class="lead">' + esc(msg) + '</p><button class="r-btn r-press" type="button" data-close>' + esc(t("close")) + "</button>";
      showSheet("redeem"); return;
    }
    state.redeem = { id: newRequestId(), pts: Math.min(lim.max, Math.max(lim.min, preset || lim.min)), busy: false, lim: lim };
    var chips = [{ k: "min", v: lim.min }, { k: "25", v: Math.floor(lim.max * 0.25) }, { k: "50", v: Math.floor(lim.max * 0.5) }, { k: "75", v: Math.floor(lim.max * 0.75) }, { k: "max", v: lim.max }]
      .filter(function (c, i, arr) { return c.v >= lim.min && c.v <= lim.max && arr.findIndex(function (x) { return x.v === c.v; }) === i; });
    body.innerHTML =
      '<h2 id="rRedeemTitle">' + esc(t("rTitle")) + '</h2><p class="lead">' + esc(t("rLead")) + "</p>" +
      '<div class="r-dial"><button class="r-step r-press" type="button" id="rMinus" aria-label="-">−</button>' +
      '<div class="r-dial-val"><input id="rPts" type="number" inputmode="numeric" min="' + lim.min + '" max="' + lim.max + '" step="1" value="' + state.redeem.pts + '" aria-label="' + esc(t("ptsUnit")) + '" /><small>' + esc(t("ptsUnit")) + "</small></div>" +
      '<button class="r-step r-press" type="button" id="rPlus" aria-label="+">+</button></div>' +
      '<div class="r-worth-big" id="rWorthBig"></div>' +
      '<input class="r-range" id="rRange" type="range" min="' + lim.min + '" max="' + lim.max + '" step="1" value="' + state.redeem.pts + '" aria-hidden="true" tabindex="-1" />' +
      '<div class="r-chips" id="rChips">' + chips.map(function (c) { return '<button type="button" class="r-chip" data-pts="' + c.v + '">' + (c.k === "max" ? esc(t("rAll")) + " · " : "") + int(c.v) + "</button>"; }).join("") + "</div>" +
      '<div class="r-err" id="rErr" role="alert"></div>' +
      '<button class="r-btn r-press" type="button" id="rGo"></button>' +
      '<p class="r-fine">' + esc(lim.maxTx > 0 ? fmt("rMax", { n: int(lim.maxTx) }) + " · " : "") + esc(fmt("rMin", { n: int(lim.min) })) + " · " + esc(t("rFine")) + "</p>";
    showSheet("redeem");
    syncRedeem();
  }
  function setRedeemPts(v, from) {
    var r = state.redeem; if (!r || r.busy) return;
    var n = Math.floor(num(v)); if (!isFinite(n)) n = r.lim.min;
    r.pts = Math.min(r.lim.max, Math.max(1, n));
    syncRedeem(from);
  }
  function syncRedeem(from) {
    var r = state.redeem; if (!r) return;
    var inp = $("rPts"), rng = $("rRange"), lim = r.lim;
    if (!inp) return;
    if (from !== "input") inp.value = r.pts;
    if (from !== "range") rng.value = Math.max(lim.min, r.pts);
    var amount = Math.floor(r.pts / lim.per * 100 + 1e-9) / 100;
    $("rWorthBig").innerHTML = esc(t("youGet")) + " <b>" + esc(mad(amount)) + " " + esc(cur()) + "</b>";
    var bad = r.pts < lim.min || r.pts > lim.max;
    $("rMinus").disabled = r.busy || r.pts <= lim.min; $("rPlus").disabled = r.busy || r.pts >= lim.max;
    var go = $("rGo"); go.disabled = r.busy || bad;
    go.textContent = r.busy ? t("rWorking") : fmt("rConfirm", { n: int(r.pts) });
    Array.prototype.forEach.call(document.querySelectorAll("#rChips .r-chip"), function (c) { c.classList.toggle("is-on", num(c.getAttribute("data-pts")) === r.pts); });
    var err = $("rErr"); err.textContent = bad && r.pts > 0 ? (r.pts < lim.min ? fmt("errMin", { n: int(lim.min) }) : fmt("errMax", { n: int(lim.max) })) : "";
  }
  function redeemError(err) {
    var c = err.code || "", b = err.body || {};
    if (c === "INSUFFICIENT_POINTS") return fmt("errInsufficient", { n: int(b.available) });
    if (c === "BELOW_MIN_POINTS") return fmt("errMin", { n: int(b.minPoints) });
    if (c === "ABOVE_MAX_POINTS") return fmt("errMax", { n: int(b.maxPointsPerTx) });
    if (c === "DAILY_LIMIT") return t("errDaily");
    if (c === "REDEEM_DISABLED" || c === "PROGRAM_DISABLED") return t("rOff");
    if (err.status === 401) return t("errAuth");
    if (err.status === undefined || err.message === "Failed to fetch" || err.name === "TypeError") return t("errNet");
    return t("errGeneric");
  }
  function submitRedeem() {
    var r = state.redeem; if (!r || r.busy) return;
    if (r.pts < r.lim.min || r.pts > r.lim.max) return;
    r.busy = true; buzz(10); syncRedeem();
    // same requestId on a retry after a network drop => the server never debits twice
    api("/api/customer/wallet/loyalty/redeem", { method: "POST", body: JSON.stringify({ points: r.pts, requestId: r.id }) }).then(function (res) {
      buzz([18, 40, 18]);
      try { window.dispatchEvent(new Event("siymon:wallet-changed")); } catch (e) {}
      showDone(res);
      load();
    }).catch(function (err) {
      r.busy = false;
      var net = err.status === undefined || err.name === "TypeError";
      if (!net) r.id = newRequestId(); // a definitive answer: next try is a new operation
      syncRedeem(); $("rErr").textContent = redeemError(err);
      if (err.status === 401) { clearCache(); }
    });
  }
  function showDone(res) {
    var body = $("rRedeemBody"), bal = mad(res.walletBalance != null ? res.walletBalance : res.balanceAfter);
    var colors = ["#5DD62C", "#FFC857", "#6BB8FF", "#FF6B6B", "#F8F8F8"], conf = "";
    if (!reduced()) for (var i = 0; i < 22; i++) {
      conf += '<i style="--x:' + Math.round((Math.random() - 0.5) * 300) + "px;--rot:" + Math.round(Math.random() * 540) + "deg;--d:" + (Math.random() * 0.25).toFixed(2) + "s;background:" + colors[i % colors.length] + '"></i>';
    }
    body.innerHTML = '<div class="r-done"><div class="r-conf" aria-hidden="true">' + conf + '</div><div class="r-check"><svg viewBox="0 0 24 24" aria-hidden="true">' + ICON.check + "</svg></div>" +
      '<h2 id="rRedeemTitle">' + esc(t("doneTitle")) + '</h2><div class="amt">+' + esc(mad(res.amount)) + " " + esc(res.currency || cur()) + "</div><p>" + esc(fmt("doneTxt", { b: "\u2066" + bal + " " + (res.currency || cur()) + "\u2069" })) + "</p></div>" +
      '<a class="r-btn ghost r-press" style="text-decoration:none" href="/wallet/">' + svg("wallet") + "<span>" + esc(t("wallet")) + '</span></a><button class="r-btn r-press" type="button" data-close>' + esc(t("close")) + "</button>";
    state.redeem = null;
  }

  /* ---- how it works ---- */
  function openHow() {
    var l = loy(), p = (l && l.program) || {}, a = appv(), tier = a && a.tier;
    var tiers = ((tier && tier.tiers) || []).map(function (x) {
      return '<div class="r-trow' + (tier && x.id === tier.id ? " is-me" : "") + '" data-t="' + esc(x.id) + '"><svg viewBox="0 0 24 24" aria-hidden="true">' + ICON.star + "</svg><b>" + esc(tname(x) || x.id) + "</b><span>" + (x.from ? int(x.from) + "+ " + esc(t("pts")) : "0 " + esc(t("pts"))) + "</span></div>";
    }).join("");
    var rule = (p.earn && p.earn.rule) ? "<p class=\"lead\">" + esc(p.earn.rule) + "</p>" : "";
    $("rHowBody").innerHTML = '<h2 id="rHowTitle">' + esc(t("howTitle")) + "</h2>" + rule +
      '<ul class="r-how"><li><span class="n">1</span><span>' + esc(t("h1")) + '</span></li><li><span class="n">2</span><span>' + esc(t("h2")) + '</span></li><li><span class="n">3</span><span>' + esc(t("h3")) + "</span></li></ul>" +
      (tiers ? "<h2 style=\"font-size:16px\">" + esc(t("levels")) + '</h2><p class="lead">' + esc(t("levelsTxt").replace(/(آخر 12 شهراً|12 derniers mois|last 12 months)/, monthsTxt(tier && tier.windowMonths))) + '</p><div class="r-tiers">' + tiers + "</div>" : "") +
      (p.terms ? '<h2 style="font-size:16px">' + esc(t("terms")) + '</h2><div class="r-terms">' + esc(p.terms) + "</div>" : "") +
      '<button class="r-btn r-press" type="button" data-close style="margin-top:14px">' + esc(t("close")) + "</button>";
    showSheet("how");
  }


  /* ---------------------------------------------------------- reward products */
  function loadShop() {
    if (!state.token) return Promise.resolve();
    return api("/api/customer/loyalty/rewards?lang=" + encodeURIComponent(state.lang)).then(function (d) { state.shop = d; renderShop(); }).catch(function () { /* optional section: stay silent offline */ });
  }
  function renderShop() {
    var box = $("rShop"), d = state.shop;
    if (!d || !d.enabled || (!(d.products || []).length && !(d.redemptions || []).length)) { box.classList.add("hidden"); box.innerHTML = ""; return; }
    var cards = (d.products || []).map(function (p) {
      var hint = p.soldOut ? t("rwSold") : p.affordable ? (p.lowStock ? fmt("rwLeft", { n: p.lowStock }) : "") : fmt("rwMissing", { n: int(p.missing) });
      var img = p.image ? '<img src="' + esc(p.image) + '" alt="" loading="lazy" />' : '<span class="r-prod-ph" aria-hidden="true">🎁</span>';
      return '<button class="r-prod r-press' + (p.affordable ? "" : " is-locked") + '" type="button" data-prod="' + esc(p.id) + '"' + (p.soldOut ? " disabled" : "") + ">" +
        '<span class="r-prod-img">' + img + "</span>" +
        '<b class="r-prod-name">' + esc(p.name) + "</b>" +
        '<span class="r-prod-pts">' + int(p.points) + " " + esc(t("pts")) + "</span>" +
        '<small class="r-prod-hint' + (p.affordable ? " ok" : "") + '">' + esc(hint || t("rwBtn")) + "</small></button>";
    }).join("");
    var mine = (d.redemptions || []).slice(0, 5).map(function (r) {
      var st = r.status === "fulfilled" ? t("rwFulfilled") : r.status === "cancelled" ? t("rwCancelled") : t("rwPending");
      return '<li class="r-rd ' + esc(r.status) + '"><span><b>' + esc(r.name) + "</b><small>" + int(r.points) + " " + esc(t("pts")) + "</small></span><em>" + esc(st) + "</em></li>";
    }).join("");
    box.innerHTML = '<div class="r-h"><h2>' + esc(t("shopT")) + '</h2></div><p class="r-shop-sub">' + esc(t("shopSub")) + "</p>" +
      (cards ? '<div class="r-prods">' + cards + "</div>" : "") +
      (mine ? '<div class="r-h" style="margin-top:18px"><h2>' + esc(t("rwMine")) + '</h2></div><ul class="r-rds">' + mine + "</ul>" : "");
    box.classList.remove("hidden");
  }
  function newRewardId() { return newRequestId().replace(/^rd-/, "rw-"); }
  function openReward(id) {
    var d = state.shop; if (!d) return;
    var p = (d.products || []).filter(function (x) { return x.id === id; })[0]; if (!p || p.soldOut) return;
    var body = $("rRewardBody");
    state.reward = { product: p, id: newRewardId(), busy: false };
    if (!p.affordable) {
      body.innerHTML = '<h2 id="rRewardTitle">' + esc(p.name) + '</h2><p class="lead">' + esc(fmt("rwMissing", { n: int(p.missing) })) + '</p><button class="r-btn r-press" type="button" data-close>' + esc(t("close")) + "</button>";
      showSheet("reward"); return;
    }
    var img = p.image ? '<div class="r-rw-img"><img src="' + esc(p.image) + '" alt="" /></div>' : "";
    body.innerHTML = img + '<h2 id="rRewardTitle">' + esc(t("rwConfirmT")) + '</h2><p class="lead">' + esc(fmt("rwConfirmTxt", { n: int(p.points), name: p.name })) + "</p>" +
      '<p class="r-rw-bal">' + esc(t("rwBal")) + ": <b>" + int(num(d.available) - p.points) + " " + esc(t("pts")) + '</b></p><p class="r-err" id="rRwErr" role="alert"></p>' +
      '<button class="r-btn r-press" type="button" id="rRwGo">' + esc(t("rwGo")) + '</button><button class="r-btn ghost r-press" type="button" data-close>' + esc(t("close")) + "</button>";
    showSheet("reward");
  }
  function rewardError(err) {
    var c = err && err.code;
    return c === "INSUFFICIENT_POINTS" ? t("rwErrPts") : c === "OUT_OF_STOCK" ? t("rwErrStock") : (c === "PRODUCT_UNAVAILABLE" || c === "PROGRAM_OFF") ? t("rwErrGone") : t("rwErr");
  }
  function submitReward() {
    var r = state.reward; if (!r || r.busy) return;
    r.busy = true; buzz(10);
    var go = $("rRwGo"); if (go) go.disabled = true;
    // same requestId on a retry after a network drop => the server never debits twice
    api("/api/customer/loyalty/rewards/" + encodeURIComponent(r.product.id) + "/redeem", { method: "POST", body: JSON.stringify({ requestId: r.id }) }).then(function () {
      buzz([18, 40, 18]);
      try { window.dispatchEvent(new Event("siymon:wallet-changed")); } catch (e) {}
      $("rRewardBody").innerHTML = '<div class="r-done"><span class="r-done-ic" aria-hidden="true">🎁</span><h2 id="rRewardTitle">' + esc(t("rwDone")) + '</h2><p class="lead">' + esc(t("rwDoneTxt")) + '</p></div><button class="r-btn r-press" type="button" data-close>' + esc(t("close")) + "</button>";
      load(); loadShop();
    }).catch(function (err) {
      r.busy = false; if (go) go.disabled = false;
      var net = err.status === undefined || err.name === "TypeError";
      if (!net) r.id = newRewardId();
      var e = $("rRwErr"); if (e) e.textContent = net ? t("errNet") : rewardError(err);
      if (!net) loadShop();
    });
  }

  /* ---------------------------------------------------------------- events */
  document.addEventListener("click", function (e) {
    var tg = e.target, hit = function (s) { return tg.closest && tg.closest(s); };
    var lang = hit("[data-lang]");
    if (lang) { state.lang = lang.getAttribute("data-lang"); try { localStorage.setItem(LANG_KEY, state.lang); } catch (er) {} applyStatic(); if (openSheet) hideSheet(true); if (state.data) renderAll(); else if (!state.token) showAuth(); load(); loadShop(); buzz(8); return; }
    var prod = hit("[data-prod]"); if (prod) { openReward(prod.getAttribute("data-prod")); return; }
    if (hit("#rRwGo")) { submitReward(); return; }
    if (hit("#rBtnConvert")) { openRedeem(); return; }
    if (hit("#rExpUse")) { var ex = appv() && appv().expiring; openRedeem(ex ? ex.total : 0); return; }
    if (hit("#rBtnHow")) { openHow(); return; }
    if (hit("#rScrim") || hit("[data-close]")) { closeSheet(); return; }
    var f = hit(".r-seg [data-f]"); if (f) { state.filter = f.getAttribute("data-f"); state.shown = PAGE; renderActivity(); buzz(6); return; }
    if (hit("#rMore")) { state.shown += PAGE; renderActivity(); return; }
    if (hit("#rRetry")) { $("rAuth").classList.add("hidden"); $("rSkel").classList.remove("hidden"); load(); return; }
    var chip = hit("#rChips .r-chip"); if (chip) { setRedeemPts(chip.getAttribute("data-pts")); buzz(8); return; }
    if (hit("#rMinus")) { var r = state.redeem; if (r) setRedeemPts(r.pts - Math.max(1, Math.round(r.lim.per / 2))); buzz(6); return; }
    if (hit("#rPlus")) { var r2 = state.redeem; if (r2) setRedeemPts(r2.pts + Math.max(1, Math.round(r2.lim.per / 2))); buzz(6); return; }
    if (hit("#rGo")) { submitRedeem(); return; }
  });
  document.addEventListener("input", function (e) {
    if (e.target.id === "rPts") { var r = state.redeem; if (r && !r.busy) { r.pts = Math.floor(num(e.target.value)); syncRedeem("input"); } }
    else if (e.target.id === "rRange") setRedeemPts(e.target.value, "range");
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeSheet(); });
  $("rBack").addEventListener("click", function (e) {
    try { if (document.referrer && new URL(document.referrer).origin === location.origin && history.length > 1) { e.preventDefault(); history.back(); } } catch (er) {}
  });

  /* compact bar shows when the large title is gone */
  (function () {
    var bar = $("rBar"), ticking = false;
    function upd() { bar.classList.toggle("is-solid", window.scrollY > 28); ticking = false; }
    window.addEventListener("scroll", function () { if (!ticking) { ticking = true; requestAnimationFrame(upd); } }, { passive: true });
    upd();
  })();

  /* pull to refresh (only when scrolled to the very top and no sheet is open) */
  (function () {
    var ptr = $("rPtr"), startY = 0, pull = 0, active = false, TH = 78;
    document.addEventListener("touchstart", function (e) {
      if (openSheet || window.scrollY > 0 || e.touches.length !== 1 || (e.target.closest && e.target.closest(".r-ladder,.r-earn,input,.r-sheet"))) { active = false; return; }
      startY = e.touches[0].clientY; pull = 0; active = true;
    }, { passive: true });
    document.addEventListener("touchmove", function (e) {
      if (!active) return;
      pull = Math.max(0, (e.touches[0].clientY - startY) * 0.5);
      if (pull > 0 && window.scrollY <= 0) {
        ptr.style.opacity = String(Math.min(1, pull / TH));
        ptr.style.transform = "translateY(" + Math.min(pull, TH) * 0.6 + "px) scale(" + (0.7 + Math.min(1, pull / TH) * 0.3) + ") rotate(" + pull * 4 + "deg)";
      }
    }, { passive: true });
    document.addEventListener("touchend", function () {
      if (!active) return; active = false;
      if (pull >= TH) {
        buzz(14); ptr.classList.add("is-spin"); ptr.style.opacity = "1"; ptr.style.transform = "translateY(" + TH * 0.6 + "px) scale(1)";
        load({ toast: true }).then(function () { setTimeout(function () { ptr.classList.remove("is-spin"); ptr.style.opacity = "0"; ptr.style.transform = ""; }, 250); });
      } else { ptr.style.opacity = "0"; ptr.style.transform = ""; }
      pull = 0;
    });
  })();

  /* come back to the app => fresh numbers */
  document.addEventListener("visibilitychange", function () { if (!document.hidden && state.token && state.data) load(); });
  window.addEventListener("pageshow", function (e) { if (e.persisted && state.token) load(); });
  window.addEventListener("online", function () { if (state.offline) load(); });

  /* ------------------------------------------------------------------ boot */
  applyStatic();
  window.addEventListener("load", applyStatic); // the shared bottom bar is built after this script
  if (!state.token) { showAuth(); }
  else {
    var cached = readCache();
    if (cached) { state.data = cached; state.offline = false; renderAll(); }
    load();
  }
})();
