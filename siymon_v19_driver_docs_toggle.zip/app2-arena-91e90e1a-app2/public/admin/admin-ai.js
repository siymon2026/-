/* global api, toast */
/* "Siymon AI" admin section: enable/disable, provider & model, welcome text, instructions, limits, knowledge base, stats, conversations.
   API keys are NEVER entered here: they live in server environment variables (GEMINI_API_KEY / AI_API_KEY). */
(function () {
  "use strict";
  var doc = document;
  var L = window.adminPageElements.L, h = window.adminPageElements.h;
  var say = function (m) { try { toast(m); } catch (e) {} };
  var S = null, stats = null, busy = false;

  function errText(e) { var b = e && e.body; return (b && (b.error || b.code)) || (e && e.message) || "Error"; }
  function box(title) {
    return h("div", { class: "modal-card sen-box", role: "region" },
      h("div", { class: "sen-head" }, h("h3", {}, title),
        h("button", { class: "sen-x", type: "button", "aria-label": L("إغلاق", "Close", "Fermer"), onclick: function () { window.showAI(false); if (location.hash.indexOf("ai") > -1) location.hash = "#/"; } }, "✕")));
  }
  function section(title, hint) { return h("section", { style: "margin:14px 0;padding:12px;border:1px solid var(--color-border,#2a2a2a);border-radius:14px" }, h("h4", { style: "margin:0 0 6px" }, title), hint ? h("small", { class: "sen-muted", style: "display:block;margin-bottom:8px" }, hint) : null); }
  function row(label, ctl, hint) { return h("label", { style: "display:block;margin:8px 0" }, h("span", { style: "display:block;font-size:13px;margin-bottom:3px" }, label), ctl, hint ? h("small", { class: "sen-muted", style: "display:block;margin-top:2px" }, hint) : null); }
  function inp(type, val, set, extra) {
    var e = h("input", Object.assign({ class: "input", type: type, style: "width:100%" }, extra || {}));
    e.value = val == null ? "" : val; e.addEventListener("input", function () { set(type === "number" ? Number(e.value) : e.value); }); return e;
  }
  function area(val, set, rows, max) { var e = h("textarea", { class: "input", rows: rows || 3, maxlength: max || 1000, style: "width:100%;resize:vertical" }); e.value = val || ""; e.addEventListener("input", function () { set(e.value); }); return e; }
  function check(label, val, set) { var c = h("input", { type: "checkbox" }); c.checked = !!val; c.addEventListener("change", function () { set(c.checked); }); return h("label", { style: "display:inline-flex;gap:6px;align-items:center;margin-inline-end:14px" }, c, h("span", {}, label)); }
  function btn(label, fn, ghost) { return h("button", { class: "lx-btn" + (ghost ? " ghost" : ""), type: "button", onclick: fn }, label); }

  function render() {
    var root = box(L("مساعد Siymon AI", "Siymon AI assistant", "Assistant Siymon AI"));
    var k = S.key || {};
    // --- status
    var st = section(L("الحالة والاتصال", "Status and connection", "État et connexion"));
    st.appendChild(h("div", { style: "display:flex;gap:12px;align-items:center;flex-wrap:wrap" },
      check(L("تفعيل المساعد للزبائن", "Enable the assistant for customers", "Activer l’assistant"), S.enabled, function (v) { S.enabled = v; }),
      h("b", {}, (k.configured ? "OK " : "-- ") + L("مفتاح المزود: ", "Provider key: ", "Clé du fournisseur : ") + (k.configured ? L("مضبوط (", "set (", "définie (") + k.hint + ")" : L("غير مضبوط", "not set", "non définie")))));
    st.appendChild(h("small", { class: "sen-muted", style: "display:block;margin:6px 0" }, L(
      "لا يُدخل المفتاح هنا ولا يظهر أبداً. ضعه في متغيرات البيئة على السيرفر: GEMINI_API_KEY لمزود Gemini أو AI_API_KEY لأي مزود متوافق مع OpenAI، ثم أعد تشغيل السيرفر.",
      "The key is never typed or shown here. Set it as a server environment variable: GEMINI_API_KEY for Gemini or AI_API_KEY for any OpenAI-compatible provider, then restart the server.",
      "La clé n’est jamais saisie ni affichée ici. Définissez-la dans les variables d’environnement : GEMINI_API_KEY ou AI_API_KEY, puis redémarrez le serveur.")));
    var testOut = h("span", { class: "sen-muted" });
    st.appendChild(h("div", { style: "display:flex;gap:10px;align-items:center;flex-wrap:wrap" }, btn(L("اختبار الاتصال بالمزود", "Test provider connection", "Tester la connexion"), function () {
      testOut.textContent = "…";
      api("/api/admin/ai/test", { method: "POST" }).then(function (r) { testOut.textContent = r.ok ? L("نجح الاتصال (", "Connected (", "Connecté (") + r.ms + " ms)" : L("فشل: ", "Failed: ", "Échec : ") + (r.code || ""); }).catch(function (e) { testOut.textContent = errText(e); });
    }, true), testOut));
    root.appendChild(st);

    // --- identity & behaviour
    var id = section(L("الهوية والسلوك", "Identity and behaviour", "Identité et comportement"));
    id.appendChild(row(L("اسم المساعد", "Assistant name", "Nom"), inp("text", S.name, function (v) { S.name = v; }, { maxlength: 40 })));
    id.appendChild(row(L("رسالة الترحيب (العربية)", "Welcome (Arabic)", "Accueil (arabe)"), area(S.welcome.ar, function (v) { S.welcome.ar = v; }, 2, 400)));
    id.appendChild(row(L("رسالة الترحيب (الفرنسية)", "Welcome (French)", "Accueil (français)"), area(S.welcome.fr, function (v) { S.welcome.fr = v; }, 2, 400)));
    id.appendChild(row(L("رسالة الترحيب (الإنجليزية)", "Welcome (English)", "Accueil (anglais)"), area(S.welcome.en, function (v) { S.welcome.en = v; }, 2, 400)));
    id.appendChild(row(L("تعليمات إضافية للمساعد", "Extra instructions", "Instructions supplémentaires"), area(S.instructions, function (v) { S.instructions = v; }, 5, 3000),
      L("تُضاف إلى التعليمات الأساسية ولا تلغي قواعد الأمان.", "Added to the core instructions; they cannot remove the safety rules.", "S’ajoutent aux consignes de base ; les règles de sécurité restent actives.")));
    id.appendChild(h("div", {}, check("العربية / الدارجة", S.languages.ar, function (v) { S.languages.ar = v; }), check("Français", S.languages.fr, function (v) { S.languages.fr = v; }), check("English", S.languages.en, function (v) { S.languages.en = v; }), check(L("السماح للزوار غير المسجلين", "Allow guests", "Autoriser les visiteurs"), S.allowGuests, function (v) { S.allowGuests = v; })));
    root.appendChild(id);

    // --- model
    var md = section(L("المزود والنموذج", "Provider and model", "Fournisseur et modèle"));
    var sel = h("select", { class: "input", style: "width:100%" }, h("option", { value: "gemini" }, "Gemini (Google)"), h("option", { value: "openai" }, L("متوافق مع OpenAI (OpenAI, Groq, OpenRouter...)", "OpenAI-compatible (OpenAI, Groq, OpenRouter...)", "Compatible OpenAI")));
    sel.value = S.provider; sel.addEventListener("change", function () { S.provider = sel.value; });
    md.appendChild(row(L("المزود", "Provider", "Fournisseur"), sel));
    md.appendChild(row(L("النموذج", "Model", "Modèle"), inp("text", S.model, function (v) { S.model = v; }, { maxlength: 80, dir: "ltr" })));
    md.appendChild(row(L("نماذج احتياطية (تبديل تلقائي)", "Fallback models (auto-switch)", "Modèles de secours (bascule auto)"), inp("text", (S.fallbackModels || []).join(", "), function (v) { S.fallbackModels = String(v || "").split(/[\n,;]+/).map(function (x) { return x.trim(); }).filter(Boolean).slice(0, 6); }, { maxlength: 300, dir: "ltr", placeholder: "gemini-2.5-flash, gemini-2.5-flash-lite" })));
    var fbHint = document.createElement("div"); fbHint.className = "hint"; fbHint.textContent = L("عند فشل النموذج أو انتهاء حصته (توكن) ينتقل المساعد تلقائياً إلى النموذج التالي في القائمة بالترتيب.", "If the model fails or its quota runs out, the assistant switches to the next model in this list.", "Si le modèle échoue ou son quota est épuisé, l'assistant passe au modèle suivant de la liste."); md.appendChild(fbHint);
    md.appendChild(row(L("عنوان API مخصص (اختياري، https فقط)", "Custom API base URL (optional, https only)", "URL de l’API (facultatif, https)"), inp("text", S.baseUrl, function (v) { S.baseUrl = v; }, { maxlength: 200, dir: "ltr", placeholder: "https://api.groq.com/openai/v1" })));
    md.appendChild(h("div", { style: "display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px" },
      row(L("الإبداع (0-1.5)", "Temperature", "Température"), inp("number", S.temperature, function (v) { S.temperature = v; }, { step: "0.1", min: 0, max: 1.5 })),
      row(L("أقصى طول للرد (توكن)", "Max output tokens", "Tokens max"), inp("number", S.maxOutputTokens, function (v) { S.maxOutputTokens = v; }, { min: 100, max: 2000 })),
      row(L("مهلة الطلب (مللي ثانية)", "Timeout (ms)", "Délai (ms)"), inp("number", S.timeoutMs, function (v) { S.timeoutMs = v; }, { min: 5000, max: 60000 }))));
    root.appendChild(md);

    // --- limits
    var lm = section(L("الحدود والاستهلاك والخصوصية", "Limits, usage and privacy", "Limites, usage et confidentialité"));
    var g = h("div", { style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px" });
    [["perMinute", "رسائل/دقيقة لكل مستخدم", "Messages per minute", 1, 60], ["perDay", "رسائل/يوم للمسجلين", "Messages per day (signed in)", 1, 1000], ["guestPerDay", "رسائل/يوم للزوار (0 = ممنوع)", "Messages per day (guests, 0 = off)", 0, 500],
      ["maxMessageChars", "أقصى طول للرسالة", "Max message length", 50, 2000], ["historyMessages", "رسائل السياق المرسلة للنموذج", "Context messages sent", 2, 40], ["maxToolRounds", "أقصى جولات الأدوات", "Max tool rounds", 1, 6], ["dailyTokenBudget", "ميزانية التوكن اليومية (0 = بلا حد)", "Daily token budget (0 = none)", 0, 1000000000]
    ].forEach(function (f) { g.appendChild(row(L(f[1], f[2], f[2]), inp("number", S.limits[f[0]], function (v) { S.limits[f[0]] = v; }, { min: f[3], max: f[4] }))); });
    g.appendChild(row(L("مدة حفظ المحادثات (أيام)", "Chat retention (days)", "Conservation (jours)"), inp("number", S.retentionDays, function (v) { S.retentionDays = v; }, { min: 1, max: 365 })));
    g.appendChild(row(L("سعر مليون توكن إدخال", "Price per 1M input tokens", "Prix / 1M tokens entrée"), inp("number", S.pricing.inPerMillion, function (v) { S.pricing.inPerMillion = v; }, { step: "0.01", min: 0 })));
    g.appendChild(row(L("سعر مليون توكن إخراج", "Price per 1M output tokens", "Prix / 1M tokens sortie"), inp("number", S.pricing.outPerMillion, function (v) { S.pricing.outPerMillion = v; }, { step: "0.01", min: 0 })));
    lm.appendChild(g); root.appendChild(lm);

    // --- Grid Battle (game) integration
    S.game = S.game || { enabled: true, stats: true, leaderboard: true, tips: true, inGame: true };
    var gm = section(L("لعبة Grid Battle", "Grid Battle game", "Jeu Grid Battle"), L(
      "تحكم في ما يعرفه المساعد عن اللعبة. المساعد للقراءة فقط: لا يغيّر تصنيفاً ولا نقاطاً ولا نتيجة، ولا يمنح مكافآت.",
      "Control what the assistant knows about the game. It is read-only: it cannot change a rating, points or a result, and cannot grant rewards.",
      "Contrôlez ce que l’assistant sait du jeu. Lecture seule : il ne modifie ni classement, ni points, ni résultat, et n’accorde aucune récompense."));
    gm.appendChild(h("div", { style: "display:flex;flex-direction:column;gap:8px;margin-top:6px" },
      check(L("ربط المساعد باللعبة (القواعد والرتب والنصائح)", "Connect the assistant to the game (rules, ranks, tips)", "Connecter l’assistant au jeu (règles, rangs, conseils)"), S.game.enabled, function (v) { S.game.enabled = v; }),
      check(L("إظهار المساعد داخل صفحة اللعبة (يُخفى أثناء المباراة)", "Show the assistant inside the game page (hidden during a match)", "Afficher l’assistant dans la page du jeu (masqué pendant un match)"), S.game.inGame, function (v) { S.game.inGame = v; }),
      check(L("السماح بقراءة إحصاءات اللاعب نفسه (تصنيفه ونتائجه)", "Let it read the player’s own stats (rating, results)", "Lui permettre de lire les statistiques du joueur (classement, résultats)"), S.game.stats, function (v) { S.game.stats = v; }),
      check(L("السماح بعرض لوحة الترتيب العامة (أسماء مختصرة)", "Let it show the public leaderboard (shortened names)", "Lui permettre d’afficher le classement public (noms abrégés)"), S.game.leaderboard, function (v) { S.game.leaderboard = v; }),
      check(L("السماح بنصائح اللعب", "Allow gameplay tips", "Autoriser les conseils de jeu"), S.game.tips, function (v) { S.game.tips = v; })));
    root.appendChild(gm);

    // --- knowledge base
    var kb = section(L("قاعدة المعرفة", "Knowledge base", "Base de connaissances"), L("معلومات موثقة يعتمد عليها المساعد (أوقات العمل، سياسات، شروط...). لا تضع أسراراً.", "Verified facts the assistant relies on (hours, policies, terms). Never put secrets here.", "Faits vérifiés (horaires, politiques). Aucun secret."));
    (S.knowledge || []).forEach(function (e, i) {
      var r = h("div", { style: "border-top:1px solid var(--color-border,#2a2a2a);padding:8px 0" });
      r.appendChild(inp("text", e.title, function (v) { e.title = v; }, { maxlength: 80, placeholder: L("العنوان", "Title", "Titre") }));
      r.appendChild(area(e.text, function (v) { e.text = v; }, 3, 1500));
      r.appendChild(h("div", { style: "display:flex;gap:10px;align-items:center;margin-top:4px" }, check(L("مفعّل", "Enabled", "Actif"), e.enabled !== false, function (v) { e.enabled = v; }), btn(L("حذف", "Delete", "Supprimer"), function () { S.knowledge.splice(i, 1); render(); open2(); }, true)));
      kb.appendChild(r);
    });
    kb.appendChild(btn(L("إضافة معلومة", "Add entry", "Ajouter"), function () { if ((S.knowledge || []).length >= 30) return say("30 max"); S.knowledge = S.knowledge || []; S.knowledge.push({ title: "", text: "", enabled: true }); render(); open2(); }, true));
    root.appendChild(kb);

    root.appendChild(h("div", { style: "display:flex;gap:10px;margin:10px 0" }, btn(L("حفظ الإعدادات", "Save settings", "Enregistrer"), save)));

    // --- stats
    var sx = section(L("الإحصاءات", "Statistics", "Statistiques"));
    if (stats) {
      var t = stats.totals;
      var cards = [[L("المحادثات", "Conversations", "Conversations"), t.conversations], [L("الرسائل", "Messages", "Messages"), t.messages], [L("المستخدمون", "Users", "Utilisateurs"), stats.users], [L("نسبة الأخطاء %", "Error rate %", "Taux d’erreur %"), stats.errorRate],
        [L("توكن إدخال", "Input tokens", "Tokens entrée"), t.tokensIn], [L("توكن إخراج", "Output tokens", "Tokens sortie"), t.tokensOut], [L("استدعاءات الأدوات", "Tool calls", "Appels d’outils"), t.toolCalls], [L("التحويل للدعم", "Support hand-offs", "Transferts support"), t.handoffs],
        [L("محاولات تجاوز القواعد", "Injection attempts", "Tentatives d’injection"), t.injections], [L("محظور بالحدود", "Rate limited", "Limités"), t.limited], [L("التكلفة التقديرية", "Estimated cost", "Coût estimé"), stats.estimatedCost == null ? "-" : stats.estimatedCost + " " + stats.currency]];
      var gr = h("div", { style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px" });
      cards.forEach(function (c) { gr.appendChild(h("div", { style: "border:1px solid var(--color-border,#2a2a2a);border-radius:12px;padding:8px 10px" }, h("div", { class: "sen-muted", style: "font-size:12px" }, c[0]), h("b", { style: "font-size:18px" }, String(c[1])))); });
      sx.appendChild(gr);
    }
    root.appendChild(sx);

    // --- conversations
    var cv = section(L("مراجعة المحادثات", "Conversation review", "Revue des conversations"), L("للمشرف الرئيسي فقط، وكل فتح لمحادثة يُسجَّل في سجل التدقيق. احترم سياسة الخصوصية.", "Main admin only; every view is written to the audit log. Respect the privacy policy.", "Administrateur principal uniquement ; chaque consultation est journalisée."));
    var list = h("div"), view = h("div", { style: "margin-top:8px" });
    cv.appendChild(btn(L("تحميل آخر المحادثات", "Load latest conversations", "Charger"), function () {
      api("/api/admin/ai/conversations").then(function (r) {
        list.replaceChildren();
        (r.conversations || []).forEach(function (c) {
          list.appendChild(h("button", { class: "lx-btn ghost", type: "button", style: "display:block;width:100%;text-align:start;margin:4px 0", onclick: function () {
            api("/api/admin/ai/conversations/" + encodeURIComponent(c.id)).then(function (x) {
              view.replaceChildren();
              x.conversation.messages.forEach(function (m) { view.appendChild(h("div", { style: "margin:4px 0;padding:6px 8px;border-radius:10px;background:" + (m.role === "user" ? "rgba(93,214,44,.12)" : "rgba(128,128,128,.12)") }, h("small", { class: "sen-muted" }, (m.role === "user" ? L("الزبون", "Customer", "Client") : "AI") + " - " + new Date(m.at).toLocaleString()), h("div", { style: "white-space:pre-wrap" }, m.text))); });
            }).catch(function (e) { say(errText(e)); });
          } }, (c.owner === "guest" ? L("زائر", "Guest", "Visiteur") : String(c.owner).slice(-6)) + " - " + (c.title || "-") + " (" + c.count + ")"));
        });
      }).catch(function (e) { say(errText(e)); });
    }, true));
    cv.appendChild(list); cv.appendChild(view); root.appendChild(cv);
    doc.getElementById("aiModal").replaceChildren(root);
  }
  var scrollTop = 0;
  function open2() { /* keep scroll position after structural re-render */ }

  function save() {
    if (busy) return; busy = true;
    api("/api/admin/ai/settings", { method: "PUT", body: JSON.stringify(S) }).then(function (r) { busy = false; S = r.settings; render(); say("OK " + L("تم الحفظ", "Saved", "Enregistré")); }).catch(function (e) { busy = false; say(errText(e)); });
  }
  function open() {
    var m = doc.getElementById("aiModal");
    m.replaceChildren(box(L("مساعد Siymon AI", "Siymon AI assistant", "Assistant Siymon AI")));
    Promise.all([api("/api/admin/ai/settings"), api("/api/admin/ai/stats").catch(function () { return {}; })]).then(function (r) { S = r[0].settings; stats = r[1].stats || null; render(); window.showAI(true); })
      .catch(function (e) { m.firstChild.appendChild(h("p", { class: "sen-muted" }, errText(e))); window.showAI(true); });
  }
  window.showAI = function (show) { var m = doc.getElementById("aiModal"); m.classList.toggle("show", !!show); if (!show) m.replaceChildren(); };
  var b = doc.getElementById("aiBtn");
  if (b) b.addEventListener("click", function () { if (window.adminPerms && !window.adminPerms.canNav("ai")) return; open(); });
})();
