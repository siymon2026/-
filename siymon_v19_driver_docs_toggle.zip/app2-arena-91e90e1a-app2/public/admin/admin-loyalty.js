/* global api, toast */
/* "إدارة نقاط الوفاء" — loyalty programme + customer points/wallet administration.
 *
 * The server is the only authority:
 *   - reading needs loyalty.read,
 *   - adjusting points needs loyalty.adjust,
 *   - changing the rules needs loyalty.settings (never granted by default),
 *   - adjusting wallet balance needs wallet.adjust.
 * This page only *hides* what a role cannot do; every endpoint re-checks the role,
 * and every change is written to the audit log (actor, time, before/after, reason). */
(function () {
  "use strict";
  var doc = document;
  var L = window.adminPageElements.L, h = window.adminPageElements.h;
  var say = function (m) { try { toast(m); } catch (e) {} };
  function lang() { return (doc.documentElement.lang || "ar").slice(0, 2); }
  function can(p) { return !!(window.adminPerms && window.adminPerms.can(p)); }
  function money(v) { return (Math.round((Number(v) || 0) * 100) / 100).toFixed(2); }
  function input(type, value, extra) {
    var e = h("input", Object.assign({ class: "sen-search", type: type, autocomplete: "off" }, extra || {}));
    if (type === "checkbox") e.checked = !!value; else e.value = value == null ? "" : value;
    return e;
  }
  function row(label, el) { return h("div", { class: "sen-field" }, h("label", { class: "sen-muted" }, label), el); }
  function errText(e) {
    var c = e && e.body && e.body.code;
    var M = {
      VERSION_CONFLICT: L("تم التعديل من مستخدم آخر — أعد التحميل", "Changed by someone else — reload", "Modifié par quelqu'un d'autre — rechargez"),
      UNKNOWN_SETTING: L("إعداد غير معروف", "Unknown setting", "Paramètre inconnu"),
      INVALID_SETTING: L("قيمة غير صالحة", "Invalid value", "Valeur invalide"),
      REASON_REQUIRED: L("السبب إلزامي", "A reason is required", "Motif obligatoire"),
      BAD_POINTS: L("عدد نقاط غير صالح", "Invalid points", "Points invalides"),
      INSUFFICIENT_POINTS: L("النقاط المتاحة لا تكفي (لن يُنشأ رصيد سالب)", "Not enough points (no negative balance allowed)", "Points insuffisants (solde négatif interdit)"),
      NOT_FOUND: L("غير موجود", "Not found", "Introuvable"),
    };
    return (M[c] || (e && e.message) || "Error") + (e && e.body && e.body.error && c !== "VERSION_CONFLICT" ? " (" + e.body.error + ")" : "") + (e && e.body && e.body.available != null ? " — " + L("المتاح", "available", "disponible") + ": " + e.body.available : "");
  }

  /* ------------------------------------------------------------------ sink */
  var root = null;
  function box(title, close) {
    var b = h("div", { class: "modal-card sen-box", role: "region" });
    b.appendChild(h("div", { class: "sen-head" }, h("h3", {}, title),
      h("button", { class: "sen-x", type: "button", "aria-label": L("إغلاق", "Close", "Fermer"), onclick: function () { if (close) close(); } }, "✕")));
    return b;
  }

  /* -------------------------------------------------------------- settings */
  var CUR = L("درهم", "MAD", "MAD");
  function toggle(checked) {
    var i = h("input", { type: "checkbox", role: "switch" });
    i.checked = !!checked;
    var w = h("span", { class: "lx-sw" }, i, h("span", { class: "lx-track", "aria-hidden": "true" }));
    w.input = i;
    return w;
  }
  function numIn(value, extra) {
    var e = h("input", Object.assign({ class: "lx-input", type: "number", inputmode: "decimal", autocomplete: "off" }, extra || {}));
    e.value = value == null ? "" : value;
    return e;
  }
  function withUnit(el, unit) { return h("span", { class: "lx-in" }, el, unit ? h("em", {}, unit) : null); }
  function fld(label, control, hint) {
    return h("div", { class: "lx-field" }, h("label", {}, label), control, hint ? h("small", {}, hint) : null);
  }
  function sw(label, hint, toggleEl) {
    return h("label", { class: "lx-switch-row" }, h("span", { class: "lx-switch-txt" }, h("b", {}, label), hint ? h("small", {}, hint) : null), toggleEl);
  }
  function card(title, sub) {
    var kids = Array.prototype.slice.call(arguments, 2);
    return h("section", { class: "lx-card" }, h("div", { class: "lx-card-head" }, h("h4", {}, title), sub ? h("p", {}, sub) : null), h("div", { class: "lx-card-body" }, kids));
  }
  function intOrNull(el) { var v = String(el.value).trim(); return v === "" ? null : Number(v); }

  /* -------------------------------------------------------------- reward products */
  function fileToJpeg(file, max) { // kept name; now WebP via the shared helper
    if (window.SiymonImg) return window.SiymonImg.toWebpDataUrl(file, { max: max });
    return new Promise(function (resolve, reject) {
      var r = new FileReader(); r.onload = function () { resolve(String(r.result || "")); }; r.onerror = function () { reject(new Error("bad image")); }; r.readAsDataURL(file);
    });
  }
  var RD_STATUS = {
    pending: L("بانتظار التسليم", "Awaiting delivery", "À remettre"),
    fulfilled: L("تم التسليم", "Delivered", "Remis"),
    cancelled: L("ملغي", "Cancelled", "Annulé"),
  };

  function rewardsPanel(canEdit, canFulfil) {
    var wrap = h("div", { class: "lx-shop" });
    var listBox = h("div", { class: "lx-prods" });
    var formBox = h("div", { class: "lx-prodform-host" });
    var redBox = h("div", { class: "lx-reds" });
    var filter = "pending";
    var data = { products: [], redemptions: [], pending: 0 };

    function load() {
      return api("/api/admin/loyalty/rewards").then(function (r) { data = r; render(); })
        .catch(function (e) { listBox.replaceChildren(h("p", { class: "lx-err" }, "❌ " + errText(e))); });
    }

    function productForm(p) {
      var isNew = !p;
      p = p || { names: { ar: "", fr: "", en: "" }, points: 100, stock: null, active: true, image: "" };
      var ar = h("input", { class: "lx-input", type: "text", maxlength: "80", value: p.names.ar, placeholder: L("اسم المنتج", "Product name", "Nom du produit") });
      var fr = h("input", { class: "lx-input", type: "text", maxlength: "80", value: p.names.fr === p.names.ar ? "" : p.names.fr, placeholder: "Français" });
      var en = h("input", { class: "lx-input", type: "text", maxlength: "80", value: p.names.en === p.names.ar ? "" : p.names.en, placeholder: "English" });
      var pts = numIn(p.points, { min: "1", step: "1" });
      var stock = numIn(p.stock, { min: "0", step: "1", placeholder: L("غير محدود", "Unlimited", "Illimité") });
      var act = toggle(p.active);
      var img = { url: p.image || "" };
      var preview = h("div", { class: "lx-img" });
      function paintImg() {
        preview.replaceChildren();
        if (img.url) preview.appendChild(h("img", { src: img.url, alt: "", loading: "lazy" }));
        else preview.appendChild(h("span", {}, "🎁"));
      }
      paintImg();
      var file = h("input", { type: "file", accept: "image/*", hidden: true });
      var pick = h("button", { class: "lx-btn ghost", type: "button", onclick: function () { file.click(); } }, L("رفع صورة", "Upload photo", "Téléverser une photo"));
      var clear = h("button", { class: "lx-btn ghost", type: "button", onclick: function () { img.url = ""; paintImg(); } }, L("إزالة", "Remove", "Retirer"));
      file.addEventListener("change", function () {
        var f = file.files && file.files[0]; if (!f) return;
        pick.disabled = true;
        fileToJpeg(f, 900).then(function (dataUrl) {
          return api("/api/admin/upload/menu-image", { method: "POST", body: JSON.stringify({ image: dataUrl }) });
        }).then(function (r) { img.url = r.url; paintImg(); })
          .catch(function (e) { say("❌ " + errText(e)); })
          .then(function () { pick.disabled = false; file.value = ""; });
      });
      var save = h("button", { class: "lx-btn primary", type: "button" }, isNew ? L("إضافة المنتج", "Add product", "Ajouter") : L("حفظ", "Save", "Enregistrer"));
      var cancel = h("button", { class: "lx-btn ghost", type: "button", onclick: function () { formBox.replaceChildren(); } }, L("إلغاء", "Cancel", "Annuler"));
      save.addEventListener("click", function () {
        var body = {
          names: { ar: ar.value.trim(), fr: fr.value.trim(), en: en.value.trim() },
          points: Number(pts.value), stock: intOrNull(stock), active: act.input.checked, image: img.url,
        };
        if (!body.names.ar) { say("❌ " + L("اكتب اسم المنتج بالعربية", "Enter the Arabic name", "Nom arabe requis")); return; }
        if (!(body.points >= 1) || body.points % 1) { say("❌ " + L("النقاط عدد صحيح من 1 فأكثر", "Points must be a whole number ≥ 1", "Points: entier ≥ 1")); return; }
        save.disabled = true;
        api(isNew ? "/api/admin/loyalty/rewards/products" : "/api/admin/loyalty/rewards/products/" + encodeURIComponent(p.id), { method: isNew ? "POST" : "PUT", body: JSON.stringify(body) })
          .then(function () { say("✅ " + L("تم الحفظ", "Saved", "Enregistré")); formBox.replaceChildren(); return load(); })
          .catch(function (e) { save.disabled = false; say("❌ " + errText(e)); });
      });
      return h("section", { class: "lx-card lx-prodform" },
        h("div", { class: "lx-card-head" }, h("h4", {}, isNew ? L("منتج جديد", "New product", "Nouveau produit") : L("تعديل المنتج", "Edit product", "Modifier le produit"))),
        h("div", { class: "lx-card-body" },
          h("div", { class: "lx-prodform-top" }, preview, h("div", { class: "lx-prodform-img" }, pick, clear, file)),
          h("div", { class: "lx-grid" },
            fld(L("الاسم بالعربية", "Arabic name", "Nom arabe"), ar), fld("Français", fr), fld("English", en)),
          h("div", { class: "lx-grid" },
            fld(L("السعر بالنقاط", "Price in points", "Prix en points"), withUnit(pts, L("نقطة", "pts", "pts"))),
            fld(L("الكمية المتوفرة", "Stock", "Stock"), withUnit(stock, L("قطعة", "pcs", "pcs")), L("اتركه فارغاً لكمية غير محدودة", "Leave empty for unlimited", "Vide = illimité"))),
          sw(L("المنتج ظاهر للزبائن", "Visible to customers", "Visible pour les clients"), null, act),
          h("div", { class: "lx-form-acts" }, cancel, save)));
    }

    function render() {
      listBox.replaceChildren();
      if (!data.products.length) listBox.appendChild(h("p", { class: "lx-empty" }, L("لا توجد منتجات بعد. أضف أول منتج مكافأة ليستبدله الزبائن بنقاطهم.", "No products yet. Add the first reward customers can redeem.", "Aucun produit. Ajoutez la première récompense.")));
      data.products.forEach(function (p) {
        var toggleAct = toggle(p.active); if (!canEdit) toggleAct.input.disabled = true;
        toggleAct.input.addEventListener("change", function () {
          api("/api/admin/loyalty/rewards/products/" + encodeURIComponent(p.id), { method: "PUT", body: JSON.stringify({ active: toggleAct.input.checked }) })
            .then(load).catch(function (e) { toggleAct.input.checked = !toggleAct.input.checked; say("❌ " + errText(e)); });
        });
        var edit = h("button", { class: "lx-btn ghost sm", type: "button", onclick: function () { formBox.replaceChildren(productForm(p)); formBox.scrollIntoView({ block: "nearest", behavior: "smooth" }); } }, L("تعديل", "Edit", "Modifier"));
        var del = h("button", { class: "lx-btn ghost sm danger", type: "button", onclick: function () {
          if (!confirm(L("حذف هذا المنتج نهائياً؟", "Delete this product permanently?", "Supprimer ce produit définitivement ?"))) return;
          api("/api/admin/loyalty/rewards/products/" + encodeURIComponent(p.id), { method: "DELETE" }).then(function () { say("✅"); load(); }).catch(function (e) { say("❌ " + errText(e)); });
        } }, L("حذف", "Delete", "Supprimer"));
        if (!canEdit) { edit.disabled = true; del.disabled = true; }
        var stockTxt = p.stock == null ? L("غير محدود", "Unlimited", "Illimité") : (p.stock <= 0 ? L("نفدت الكمية", "Sold out", "Épuisé") : p.stock + " " + L("متبقي", "left", "restant"));
        listBox.appendChild(h("article", { class: "lx-prod" + (p.active ? "" : " off") },
          h("div", { class: "lx-img" }, p.image ? h("img", { src: p.image, alt: "", loading: "lazy" }) : h("span", {}, "🎁")),
          h("div", { class: "lx-prod-main" }, h("b", {}, p.names.ar), h("span", { class: "lx-pts" }, p.points + " " + L("نقطة", "pts", "pts")), h("small", { class: p.stock != null && p.stock <= 0 ? "warn" : "" }, stockTxt)),
          h("div", { class: "lx-prod-acts" }, toggleAct, edit, del)));
      });
      renderReds();
    }

    function renderReds() {
      redBox.replaceChildren();
      var rows = data.redemptions.filter(function (r) { return filter === "all" || r.status === filter; });
      if (!rows.length) redBox.appendChild(h("p", { class: "lx-empty" }, filter === "pending" ? L("لا توجد طلبات بانتظار التسليم.", "Nothing waiting for delivery.", "Rien à remettre.") : L("لا توجد طلبات.", "No requests.", "Aucune demande.")));
      rows.forEach(function (r) {
        var acts = h("div", { class: "lx-red-acts" });
        if (r.status === "pending" && canFulfil) {
          acts.appendChild(h("button", { class: "lx-btn primary sm", type: "button", onclick: function () { act(r, "fulfil"); } }, L("تم التسليم", "Mark delivered", "Marquer remis")));
          acts.appendChild(h("button", { class: "lx-btn ghost sm danger", type: "button", onclick: function () {
            var reason = prompt(L("سبب الإلغاء (اختياري). ستُعاد النقاط للزبون.", "Reason (optional). The points go back to the customer.", "Motif (facultatif). Les points sont restitués."), "");
            if (reason === null) return;
            act(r, "cancel", reason);
          } }, L("إلغاء واسترجاع النقاط", "Cancel & refund", "Annuler et rembourser")));
        }
        redBox.appendChild(h("article", { class: "lx-red" },
          h("div", { class: "lx-red-main" }, h("b", {}, r.names.ar), h("span", {}, (r.customerName || "—") + " · " + r.points + " " + L("نقطة", "pts", "pts")), h("small", {}, new Date(r.createdAt).toLocaleString())),
          h("span", { class: "lx-chipst " + r.status }, RD_STATUS[r.status] || r.status), acts));
      });
    }
    function act(r, kind, reason) {
      api("/api/admin/loyalty/redemptions/" + encodeURIComponent(r.id) + "/" + kind, { method: "POST", body: JSON.stringify(kind === "cancel" ? { reason: reason || "" } : {}) })
        .then(function () { say("✅"); return load(); }).catch(function (e) { say("❌ " + errText(e)); });
    }

    var add = h("button", { class: "lx-btn primary", type: "button", onclick: function () { formBox.replaceChildren(productForm(null)); formBox.scrollIntoView({ block: "nearest", behavior: "smooth" }); } }, L("+ منتج جديد", "+ New product", "+ Nouveau produit"));
    if (!canEdit) add.disabled = true;
    var tabs = h("div", { class: "lx-seg", role: "tablist" });
    [["pending", L("بانتظار التسليم", "Pending", "En attente")], ["all", L("الكل", "All", "Tout")]].forEach(function (f) {
      tabs.appendChild(h("button", { class: "lx-seg-b" + (filter === f[0] ? " on" : ""), type: "button", "data-f": f[0], onclick: function () {
        filter = f[0]; tabs.querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-f") === filter); }); renderReds();
      } }, f[1]));
    });
    wrap.appendChild(card(L("منتجات المكافآت", "Reward products", "Produits récompense"), L("منتجات يستبدلها الزبون بنقاطه من صفحة نقاط الوفاء.", "Products customers redeem with their points.", "Produits que les clients échangent contre des points."),
      h("div", {}, add), formBox, listBox));
    wrap.appendChild(card(L("طلبات الاستبدال", "Redemption requests", "Demandes d'échange"), L("سلّم المنتج للزبون ثم اضغط «تم التسليم». الإلغاء يعيد النقاط والكمية تلقائياً.", "Hand the product over, then mark it delivered. Cancelling refunds the points and the stock.", "Remettez le produit puis marquez-le. L'annulation restitue points et stock."), tabs, redBox));
    wrap.refresh = load;
    load();
    return wrap;
  }

  function settingsPanel(settings, canEdit, reload, overview) {
    var wrap = h("div", { class: "lx" });
    var dirty = false;
    var canEditShop = canEdit, canFulfilShop = can("loyalty.adjust");
    var dis = function (el) { if (!canEdit) (el.input || el).disabled = true; return el; };

    /* ---- master switch + summary ---- */
    var on = toggle(settings.enabled);
    var o = overview || {};
    var head = h("div", { class: "lx-hero" },
      h("div", { class: "lx-hero-main" },
        h("h3", {}, L("نقاط الوفاء", "Loyalty points", "Points de fidélité")),
        h("p", {}, L("تحكّم في كسب النقاط واستبدالها والرتب والمكافآت. التغييرات لا تصل للزبائن إلا بعد الحفظ.",
          "Control how points are earned, redeemed, and how levels and rewards work. Changes reach customers only after saving.",
          "Gérez le gain, l'utilisation des points, les niveaux et les récompenses. Les changements ne sont visibles qu'après enregistrement.")),
        sw(L("البرنامج مفعّل", "Programme enabled", "Programme activé"), L("عند الإيقاف يتوقف كسب النقاط فقط، وتبقى الأرصدة محفوظة.", "Turning it off only stops earning; balances are kept.", "La désactivation arrête seulement le gain; les soldes sont conservés."), dis(on))),
      h("div", { class: "lx-kpis" },
        [[L("حسابات", "Accounts", "Comptes"), o.accounts], [L("نقاط متاحة", "Available", "Disponibles"), o.availablePoints],
         [L("قيد التأكيد", "Pending", "En attente"), o.pendingPoints], [L("مستخدمة", "Used", "Utilisés"), o.usedPoints]].map(function (k) {
          return h("div", { class: "lx-kpi" }, h("b", {}, String(k[1] || 0)), h("span", {}, k[0]));
        })));
    wrap.appendChild(head);
    on.input.addEventListener("change", function () { on.closest(".lx-switch-row").classList.toggle("is-off", !on.input.checked); });
    on.closest(".lx-switch-row") && on.closest(".lx-switch-row").classList.toggle("is-off", !settings.enabled);

    /* ---- earn ---- */
    var earnOn = toggle(settings.earn.enabled);
    var unit = numIn(settings.earn.unitAmount, { min: "1", step: "any" });
    var perUnit = numIn(settings.earn.pointsPerUnit, { min: "1", step: "1" });
    var base = h("select", { class: "lx-input" });
    [["paid", L("المبلغ المدفوع فعليًا", "Amount actually paid", "Montant réellement payé")],
     ["subtotal", L("قيمة المنتجات قبل الخصم", "Items value before discount", "Articles avant remise")],
     ["total", L("إجمالي الطلب", "Order total", "Total de la commande")]].forEach(function (x) { base.appendChild(h("option", { value: x[0] }, x[1])); });
    base.value = settings.earn.base;
    var withDelivery = toggle(settings.earn.includeDeliveryFee);
    var afterDiscount = toggle(!settings.earn.includeDiscount);
    var minOrder = numIn(settings.earn.minOrderAmount, { min: "0", step: "any" });
    var capOrder = numIn(settings.earn.maxPointsPerOrder, { min: "1", step: "1", placeholder: L("بدون سقف", "No cap", "Sans plafond") });
    var capDay = numIn(settings.earn.maxPointsPerDay, { min: "1", step: "1", placeholder: L("بدون سقف", "No cap", "Sans plafond") });
    var holdDays = numIn(settings.earn.pendingDays, { min: "0", step: "1" });
    var earnPane = h("div", { class: "lx-pane" },
      card(L("قاعدة الكسب", "Earning rule", "Règle de gain"), L("كم نقطة يحصل عليها الزبون بعد تسليم الطلب.", "How many points a customer gets after delivery.", "Points gagnés après la livraison."),
        sw(L("احتساب النقاط مفعّل", "Earning enabled", "Gain activé"), null, dis(earnOn)),
        h("div", { class: "lx-grid" },
          fld(L("لكل مبلغ قدره", "For every", "Pour chaque"), withUnit(dis(unit), CUR)),
          fld(L("يحصل على", "Earns", "Gagne"), withUnit(dis(perUnit), L("نقطة", "points", "points"))),
          fld(L("أساس الاحتساب", "Calculated on", "Calculé sur"), dis(base)))),
      card(L("ما يدخل في الحساب", "What counts", "Ce qui compte"), null,
        sw(L("إضافة رسوم التوصيل", "Include delivery fee", "Inclure la livraison"), null, dis(withDelivery)),
        sw(L("احتساب المبلغ بعد الخصومات", "Use the amount after discounts", "Utiliser le montant après remises"), null, dis(afterDiscount))),
      card(L("حدود الأمان", "Safety limits", "Limites"), L("اترك الحقل فارغاً لإلغاء السقف.", "Leave a field empty for no cap.", "Laissez vide pour aucun plafond."),
        h("div", { class: "lx-grid" },
          fld(L("أدنى مبلغ للطلب", "Minimum order", "Commande minimum"), withUnit(dis(minOrder), CUR)),
          fld(L("سقف النقاط لكل طلب", "Max points per order", "Points max par commande"), withUnit(dis(capOrder), L("نقطة", "pts", "pts"))),
          fld(L("سقف النقاط اليومي", "Max points per day", "Points max par jour"), withUnit(dis(capDay), L("نقطة", "pts", "pts"))),
          fld(L("تعليق النقاط قبل إتاحتها", "Hold before usable", "Délai avant utilisation"), withUnit(dis(holdDays), L("يوم", "days", "jours")), L("0 = تُتاح فوراً", "0 = usable immediately", "0 = immédiat")))));

    /* ---- redeem + expiry ---- */
    var redeemOn = toggle(settings.redeem.enabled);
    var minPoints = numIn(settings.redeem.minPoints, { min: "1", step: "1" });
    var perCurrency = numIn(settings.redeem.pointsPerCurrencyUnit, { min: "1", step: "1" });
    var maxTx = numIn(settings.redeem.maxPointsPerTx, { min: "1", step: "1", placeholder: L("بدون سقف", "No cap", "Sans plafond") });
    var maxDay = numIn(settings.redeem.maxPointsPerDay, { min: "1", step: "1", placeholder: L("بدون سقف", "No cap", "Sans plafond") });
    var expiryOn = toggle(settings.expiry.enabled);
    var expiryDays = numIn(settings.expiry.days, { min: "1", step: "1" });
    var alertDays = numIn(settings.expiry.alertDays, { min: "1", step: "1" });
    var redeemPane = h("div", { class: "lx-pane" },
      card(L("تحويل النقاط إلى رصيد", "Converting points to balance", "Conversion en solde"), L("يحوّل الزبون نقاطه إلى رصيد في محفظته.", "Customers turn points into wallet balance.", "Les clients convertissent leurs points en solde."),
        sw(L("التحويل مفعّل", "Conversion enabled", "Conversion activée"), null, dis(redeemOn)),
        h("div", { class: "lx-grid" },
          fld(L("قيمة الدرهم الواحد", "Value of 1 MAD", "Valeur de 1 MAD"), withUnit(dis(perCurrency), L("نقطة", "points", "points"))),
          fld(L("أدنى تحويل", "Minimum conversion", "Conversion minimum"), withUnit(dis(minPoints), L("نقطة", "pts", "pts"))),
          fld(L("سقف العملية الواحدة", "Max per conversion", "Max par conversion"), withUnit(dis(maxTx), L("نقطة", "pts", "pts"))),
          fld(L("سقف التحويل اليومي", "Daily conversion cap", "Plafond journalier"), withUnit(dis(maxDay), L("نقطة", "pts", "pts"))))),
      card(L("صلاحية النقاط", "Points validity", "Validité des points"), L("متى تنتهي النقاط ومتى يُنبَّه الزبون.", "When points expire and when customers are warned.", "Quand les points expirent et quand prévenir."),
        sw(L("تفعيل انتهاء الصلاحية", "Enable expiry", "Activer l'expiration"), null, dis(expiryOn)),
        h("div", { class: "lx-grid" },
          fld(L("مدة الصلاحية", "Validity", "Validité"), withUnit(dis(expiryDays), L("يوم", "days", "jours"))),
          fld(L("التنبيه قبل الانتهاء بـ", "Warn before expiry", "Prévenir avant l'expiration"), withUnit(dis(alertDays), L("يوم", "days", "jours")), L("يجب ألا يتجاوز مدة الصلاحية", "Must not exceed the validity", "Ne doit pas dépasser la validité")))));

    /* ---- levels (tiers) + ladder ---- */
    var tiersOn = toggle(settings.tiers.enabled);
    var windowMonths = numIn(settings.tiers.windowMonths, { min: "1", max: "60", step: "1" });
    var rows = settings.tiers.list.map(function (t) { return { id: t.id, from: t.from, names: { ar: t.names.ar || "", fr: t.names.fr || "", en: t.names.en || "" } }; });
    var rail = h("div", { class: "lx-rail", "aria-hidden": "true" });
    var tierBox = h("div", { class: "lx-tiers" });
    function touch() { markDirty(); }
    function renderRail() {
      rail.replaceChildren();
      var top = Math.max(1, (rows[rows.length - 1] || {}).from || 1) * 1.2;
      rail.appendChild(h("i", { class: "lx-rail-line" }));
      rows.forEach(function (r, i) {
        var pos = Math.min(100, ((Number(r.from) || 0) / top) * 100);
        rail.appendChild(h("span", { class: "lx-mark", style: "inset-inline-start:" + pos + "%", "data-i": String(i) }, h("b", {}, r.names.ar || "—"), h("small", {}, String(Number(r.from) || 0))));
      });
    }
    function renderTiers() {
      tierBox.replaceChildren();
      rows.forEach(function (r, i) {
        var nm = h("input", { class: "lx-input", type: "text", maxlength: "30", placeholder: L("اسم الرتبة", "Level name", "Nom du niveau"), value: r.names.ar });
        var from = numIn(r.from, { min: "0", step: "1" });
        var fr = h("input", { class: "lx-input", type: "text", maxlength: "30", placeholder: "Français", value: r.names.fr });
        var en = h("input", { class: "lx-input", type: "text", maxlength: "30", placeholder: "English", value: r.names.en });
        if (i === 0) from.disabled = true;
        nm.addEventListener("input", function () { r.names.ar = nm.value; renderRail(); touch(); });
        fr.addEventListener("input", function () { r.names.fr = fr.value; touch(); });
        en.addEventListener("input", function () { r.names.en = en.value; touch(); });
        from.addEventListener("input", function () { r.from = from.value === "" ? "" : Number(from.value); renderRail(); touch(); });
        from.addEventListener("change", function () { rows.sort(function (a, b) { return (Number(a.from) || 0) - (Number(b.from) || 0); }); setTimeout(function () { renderTiers(); renderRail(); }, 0); });
        var del = h("button", { class: "lx-icon-btn", type: "button", "aria-label": L("حذف الرتبة", "Remove level", "Supprimer le niveau"), onclick: function () { rows.splice(i, 1); renderTiers(); renderRail(); touch(); } }, "✕");
        if (i === 0 || rows.length <= 2) del.disabled = true;
        [nm, from, fr, en, del].forEach(dis);
        tierBox.appendChild(h("div", { class: "lx-tier" },
          h("div", { class: "lx-tier-main" }, nm, withUnit(from, L("نقطة فأكثر", "pts +", "pts +"))),
          h("details", {}, h("summary", {}, L("الترجمات", "Translations", "Traductions")), h("div", { class: "lx-tier-tr" }, fr, en)),
          del));
      });
      var add = h("button", { class: "lx-btn ghost", type: "button", onclick: function () {
        var last = rows[rows.length - 1];
        rows.push({ id: "t" + Date.now().toString(36), from: (Number(last.from) || 0) + 500, names: { ar: "", fr: "", en: "" } });
        renderTiers(); renderRail(); touch();
      } }, L("+ إضافة رتبة", "+ Add level", "+ Ajouter un niveau"));
      dis(add);
      if (rows.length >= 6) add.disabled = true;
      tierBox.appendChild(add);
    }
    renderTiers(); renderRail();

    var steps = settings.ladder.steps.slice();
    var stepBox = h("div", { class: "lx-chips" });
    var stepNew = numIn("", { min: "1", step: "any", placeholder: L("مبلغ جديد", "New amount", "Nouveau montant") });
    function ptsFor(money) { return Math.max(Number(minPoints.value) || 1, Math.ceil(money * (Number(perCurrency.value) || 1))); }
    function renderSteps() {
      stepBox.replaceChildren();
      steps.forEach(function (m, i) {
        var x = h("button", { class: "lx-icon-btn", type: "button", "aria-label": L("حذف", "Remove", "Supprimer"), onclick: function () { steps.splice(i, 1); renderSteps(); touch(); } }, "✕");
        if (steps.length <= 1) x.disabled = true;
        dis(x);
        stepBox.appendChild(h("span", { class: "lx-chip" }, h("b", {}, m + " "), CUR, h("small", {}, ptsFor(m) + " " + L("نقطة", "pts", "pts")), x));
      });
    }
    renderSteps();
    [perCurrency, minPoints].forEach(function (e) { e.addEventListener("input", renderSteps); });
    var stepAdd = h("button", { class: "lx-btn ghost", type: "button", onclick: function () {
      var v = Number(stepNew.value);
      if (!(v >= 1)) { say("❌ " + L("أدخل مبلغاً صحيحاً", "Enter a valid amount", "Montant invalide")); return; }
      if (steps.indexOf(v) >= 0) { say("❌ " + L("المبلغ موجود مسبقاً", "Already in the list", "Déjà présent")); return; }
      if (steps.length >= 8) { say("❌ " + L("الحد الأقصى 8 درجات", "Maximum 8 steps", "8 paliers maximum")); return; }
      steps.push(v); steps.sort(function (a, b) { return a - b; }); stepNew.value = ""; renderSteps(); touch();
    } }, L("إضافة", "Add", "Ajouter"));
    dis(stepNew); dis(stepAdd);

    var levelsPane = h("div", { class: "lx-pane" },
      card(L("رتب الزبائن", "Customer levels", "Niveaux clients"), L("يرتقي الزبون برتبته بحسب النقاط التي كسبها خلال المدة المحددة.", "Customers move up by the points they earned during the window.", "Les clients montent selon les points gagnés sur la période."),
        sw(L("تفعيل الرتب", "Enable levels", "Activer les niveaux"), null, dis(tiersOn)),
        h("div", { class: "lx-grid one" }, fld(L("مدة احتساب الرتبة", "Level window", "Période de calcul"), withUnit(dis(windowMonths), L("شهراً", "months", "mois")), L("النقاط المكتسبة خلال هذه المدة فقط تحدد الرتبة", "Only points earned in this window count", "Seuls les points gagnés sur cette période comptent"))),
        rail, tierBox),
      card(L("سلّم المكافآت", "Reward ladder", "Paliers de récompense"), L("المبالغ التي تظهر للزبون كمكافآت قابلة للتحويل.", "The money steps shown to customers as rewards.", "Les montants affichés comme récompenses."),
        stepBox, h("div", { class: "lx-addrow" }, withUnit(stepNew, CUR), stepAdd)));

    /* ---- campaigns + terms ---- */
    var camps = (settings.campaigns || []).slice();
    var campBox = h("div", { class: "lx-camps" });
    function renderCamps() {
      campBox.replaceChildren();
      camps.forEach(function (c, i) {
        if (!c.id) c.id = "camp_" + (i + 1);
        var name = h("input", { class: "lx-input", type: "text", maxlength: "80", placeholder: L("اسم الحملة", "Campaign name", "Nom de la campagne"), value: c.name || "" });
        var bonus = numIn(c.points != null ? c.points : 0, { min: "1", step: "1" });
        var act = toggle(c.active !== false);
        name.addEventListener("input", function () { camps[i].name = name.value; });
        bonus.addEventListener("input", function () { camps[i].points = Number(bonus.value) || 0; });
        act.input.addEventListener("change", function () { camps[i].active = act.input.checked; });
        var del = h("button", { class: "lx-icon-btn", type: "button", "aria-label": L("حذف", "Remove", "Supprimer"), onclick: function () { camps.splice(i, 1); renderCamps(); touch(); } }, "✕");
        [name, bonus, act.input, del].forEach(dis);
        campBox.appendChild(h("div", { class: "lx-camp" }, name, withUnit(bonus, L("نقطة إضافية", "bonus pts", "pts bonus")), act, del));
      });
      var add = h("button", { class: "lx-btn ghost", type: "button", onclick: function () { camps.push({ id: "camp_" + Date.now().toString(36), name: "", points: 10, active: true }); renderCamps(); touch(); } }, L("+ حملة جديدة", "+ New campaign", "+ Nouvelle campagne"));
      dis(add); campBox.appendChild(add);
    }
    renderCamps();
    var terms = {};
    var termsBox = h("div", { class: "lx-terms" });
    [["ar", "العربية"], ["fr", "Français"], ["en", "English"]].forEach(function (p) {
      var ta = h("textarea", { class: "lx-input", rows: "3", maxlength: "2000", placeholder: p[1] });
      ta.value = (settings.terms && settings.terms[p[0]]) || "";
      dis(ta); terms[p[0]] = ta; termsBox.appendChild(ta);
    });
    var campPane = h("div", { class: "lx-pane" },
      card(L("الحملات والمكافآت", "Campaigns and bonuses", "Campagnes et bonus"), L("تظهر الحملات المفعّلة للزبائن في صفحة المحفظة.", "Active campaigns are announced on the wallet page.", "Les campagnes actives s'affichent dans le portefeuille."), campBox),
      card(L("شروط إضافية", "Extra terms", "Conditions supplémentaires"), L("نص يظهر للزبون بعد الشروط الأساسية.", "Shown to customers after the standard terms.", "Affiché après les conditions standard."), termsBox));

    /* ---- customer preview ---- */
    var previewBox = h("div", { class: "lx-preview" });
    var previewBtn = h("button", { class: "lx-btn ghost", type: "button" }, L("تحديث المعاينة", "Refresh preview", "Actualiser"));
    var previewPane = h("div", { class: "lx-pane" },
      card(L("ما يراه الزبون", "What customers see", "Ce que voient les clients"), L("نصوص حقيقية مولّدة من المسودة الحالية دون حفظها.", "Real texts generated from the current draft, without saving.", "Textes réels générés depuis le brouillon, sans enregistrer."), previewBox, previewBtn));

    /* ---- customers ---- */
    var custHost = h("div", { class: "lx-pane" });
    var custLoaded = false;
    var shopHost = h("div", { class: "lx-pane" });
    var shopLoaded = false;

    /* ---- tabs ---- */
    var panes = { earn: earnPane, redeem: redeemPane, levels: levelsPane, shop: shopHost, camps: campPane, preview: previewPane, cust: custHost };
    var tabDefs = [["earn", L("كسب النقاط", "Earning", "Gain")], ["redeem", L("الاستبدال والصلاحية", "Redeem & expiry", "Utilisation")],
      ["levels", L("الرتب والمكافآت", "Levels & rewards", "Niveaux")], ["shop", L("منتجات المكافآت", "Reward products", "Produits récompense")], ["camps", L("الحملات والشروط", "Campaigns & terms", "Campagnes")],
      ["preview", L("معاينة الزبون", "Customer preview", "Aperçu")], ["cust", L("الزبائن", "Customers", "Clients")]];
    var tabBar = h("div", { class: "lx-tabs", role: "tablist" });
    var paneHost = h("div", { class: "lx-panes" });
    function show(key) {
      tabBar.querySelectorAll("button").forEach(function (b) { var a = b.getAttribute("data-k") === key; b.setAttribute("aria-selected", a ? "true" : "false"); b.classList.toggle("on", a); });
      Object.keys(panes).forEach(function (k) { panes[k].hidden = k !== key; });
      if (key === "preview") preview();
      if (key === "cust" && !custLoaded) { custLoaded = true; custHost.appendChild(customersPanel()); }
      if (key === "shop") { if (!shopLoaded) { shopLoaded = true; shopHost.appendChild(rewardsPanel(canEditShop, canFulfilShop)); } else if (shopHost.firstChild && shopHost.firstChild.refresh) shopHost.firstChild.refresh(); }
      bar.classList.toggle("hide-bar", key === "cust" || key === "shop");
    }
    tabDefs.forEach(function (d) {
      tabBar.appendChild(h("button", { class: "lx-tab", type: "button", role: "tab", "data-k": d[0], onclick: function () { show(d[0]); } }, d[1]));
      paneHost.appendChild(panes[d[0]]);
    });
    wrap.appendChild(tabBar);
    wrap.appendChild(paneHost);

    /* ---- body / validation ---- */
    function body() {
      return {
        expectedVersion: settings.version,
        enabled: on.input.checked,
        earn: {
          enabled: earnOn.input.checked, unitAmount: Number(unit.value), pointsPerUnit: Number(perUnit.value),
          base: base.value, includeDeliveryFee: withDelivery.input.checked, includeDiscount: !afterDiscount.input.checked,
          minOrderAmount: Number(minOrder.value) || 0, maxPointsPerOrder: intOrNull(capOrder),
          maxPointsPerDay: intOrNull(capDay), pendingDays: Number(holdDays.value) || 0,
        },
        redeem: {
          enabled: redeemOn.input.checked, minPoints: Number(minPoints.value), pointsPerCurrencyUnit: Number(perCurrency.value),
          maxPointsPerTx: intOrNull(maxTx), maxPointsPerDay: intOrNull(maxDay),
        },
        expiry: { enabled: expiryOn.input.checked, days: Number(expiryDays.value), alertDays: Number(alertDays.value) },
        tiers: {
          enabled: tiersOn.input.checked, windowMonths: Number(windowMonths.value),
          list: rows.map(function (r) { return { id: r.id, from: Number(r.from), names: { ar: String(r.names.ar || "").trim(), fr: String(r.names.fr || "").trim(), en: String(r.names.en || "").trim() } }; }),
        },
        ladder: { steps: steps.slice() },
        campaigns: camps
          .filter(function (c) { return String(c.name || "").trim() && Number(c.points) > 0; })
          .map(function (c) { return { id: c.id, name: String(c.name).trim(), points: Number(c.points), active: c.active !== false }; }),
        terms: { ar: terms.ar.value, fr: terms.fr.value, en: terms.en.value },
      };
    }
    function problems() {
      var p = [], b = body();
      rows.forEach(function (r, i) {
        if (!String(r.names.ar || "").trim()) p.push(L("لكل رتبة اسم عربي", "Every level needs an Arabic name", "Chaque niveau a besoin d'un nom arabe"));
        if (r.from === "" || !(Number(r.from) >= 0) || Number(r.from) % 1) p.push(L("عتبة الرتبة يجب أن تكون عدداً صحيحاً", "Level thresholds must be whole numbers", "Les seuils doivent être entiers"));
        if (i > 0 && Number(r.from) <= Number(rows[i - 1].from)) p.push(L("عتبات الرتب يجب أن تتزايد", "Level thresholds must increase", "Les seuils doivent croître"));
      });
      if (b.expiry.alertDays > b.expiry.days) p.push(L("أيام التنبيه أكبر من مدة الصلاحية", "Warning days exceed the validity", "Le délai d'alerte dépasse la validité"));
      return p.filter(function (x, i) { return p.map(String).indexOf(String(x)) === i; });
    }

    /* ---- preview ---- */
    function preview() {
      api("/api/admin/loyalty/preview", { method: "POST", body: JSON.stringify(body()) }).then(function (r) {
        previewBox.replaceChildren();
        ["ar", "fr", "en"].forEach(function (l) {
          var p = r.preview[l];
          var lv = ((p.tiers && p.tiers.list) || []).map(function (t) { return t.name + " " + t.from + "+"; }).join(" · ");
          previewBox.appendChild(h("div", { class: "lx-pv" },
            h("b", {}, l.toUpperCase()),
            h("p", {}, p.earn.rule),
            h("p", { class: "m" }, p.terms),
            p.tiers && p.tiers.enabled ? h("p", { class: "m" }, lv) : null,
            h("p", { class: "m" }, (p.ladder.steps || []).join(" · ") + " " + (l === "ar" ? "درهم" : "MAD") + " · " + (p.expiry.enabled ? p.expiry.days + " j / " + p.expiry.alertDays + " j" : "—"))));
        });
      }).catch(function (e) { previewBox.replaceChildren(h("p", { class: "lx-err" }, "❌ " + errText(e))); });
    }
    previewBtn.addEventListener("click", preview);

    /* ---- sticky save bar ---- */
    var status = h("span", { class: "lx-status" }, L("كل التغييرات محفوظة", "All changes saved", "Tout est enregistré"));
    var issues = h("span", { class: "lx-issues" });
    var save = h("button", { class: "lx-btn primary", type: "button", disabled: true }, L("حفظ ونشر", "Save and publish", "Enregistrer et publier"));
    var undo = h("button", { class: "lx-btn ghost", type: "button", disabled: true, onclick: function () { reload(); } }, L("تراجع", "Discard", "Annuler"));
    var bar = h("div", { class: "lx-bar" + (canEdit ? "" : " ro") }, h("div", { class: "lx-bar-txt" }, status, issues), h("div", { class: "lx-bar-acts" }, undo, save));
    function markDirty() {
      if (!canEdit) return;
      dirty = true;
      bar.classList.add("dirty");
      status.textContent = String(L("تغييرات غير محفوظة", "Unsaved changes", "Modifications non enregistrées"));
      var p = problems();
      issues.textContent = p.length ? "⚠ " + p[0] : "";
      save.disabled = p.length > 0;
      undo.disabled = false;
    }
    wrap.addEventListener("input", function (e) { if (paneHost.contains(e.target) || head.contains(e.target)) { if (!e.target.closest(".lx-addrow") && !e.target.closest(".lx-customers") && !e.target.closest(".lx-shop")) markDirty(); } });
    wrap.addEventListener("change", function (e) { if ((paneHost.contains(e.target) || head.contains(e.target)) && !e.target.closest(".lx-customers") && !e.target.closest(".lx-shop") && !e.target.closest(".lx-addrow")) markDirty(); });
    save.addEventListener("click", function () {
      if (!canEdit || !dirty) return;
      var p = problems();
      if (p.length) { say("❌ " + p[0]); return; }
      if (settings.enabled && !on.input.checked && !confirm(L("إيقاف البرنامج يوقف كسب النقاط فقط؛ أرصدة الزبائن وسجلاتهم تبقى محفوظة. تأكيد؟",
        "Turning the programme off only stops earning; customer balances and history are kept. Confirm?",
        "Désactiver le programme arrête uniquement le gain ; les soldes et l'historique sont conservés. Confirmer ?"))) return;
      save.disabled = true;
      api("/api/admin/loyalty/settings", { method: "PUT", body: JSON.stringify(body()) })
        .then(function () { say("✅ " + L("تم الحفظ", "Saved", "Enregistré")); reload(); })
        .catch(function (e) { save.disabled = false; say("❌ " + errText(e)); });
    });
    wrap.appendChild(bar);
    if (!canEdit) {
      status.textContent = String(L("عرض فقط — لا تملك صلاحية تعديل القواعد", "Read-only — you cannot change the rules", "Lecture seule — modification non autorisée"));
    }
    show("earn");
    return wrap;
  }

  /* -------------------------------------------------------------- customer */
  function detailPanel(customerId, back) {
    var wrap = h("div", { class: "loy-detail" }, h("p", { class: "sen-muted" }, "…"));
    function load() {
      api("/api/admin/loyalty/customers/" + encodeURIComponent(customerId)).then(function (r) {
        wrap.replaceChildren();
        wrap.appendChild(h("div", { class: "sen-head" },
          h("h3", {}, r.customer.name || r.customer.id),
          h("button", { class: "sen-x", type: "button", "aria-label": L("رجوع", "Back", "Retour"), onclick: back }, "✕")));
        wrap.appendChild(h("p", { class: "sen-muted" }, [r.customer.id, r.customer.phone, r.customer.email].filter(Boolean).join(" · ")));

        var b = r.loyalty.balances;
        wrap.appendChild(h("div", { class: "loy-stat-row" },
          h("div", { class: "loy-stat" }, h("span", {}, L("النقاط المتاحة", "Available points", "Points disponibles")), h("b", {}, String(b.available))),
          h("div", { class: "loy-stat" }, h("span", {}, L("قيد التأكيد", "Pending", "En attente")), h("b", {}, String(b.pending))),
          h("div", { class: "loy-stat" }, h("span", {}, L("المستخدمة", "Used", "Utilisés")), h("b", {}, String(b.used))),
          h("div", { class: "loy-stat" }, h("span", {}, L("المنتهية", "Expired", "Expirés")), h("b", {}, String(b.expired))),
          h("div", { class: "loy-stat" }, h("span", {}, L("رصيد المحفظة", "Wallet balance", "Solde portefeuille")), h("b", {}, money(r.wallet.balance) + " " + r.wallet.currency))));
        if (r.reconcile && r.reconcile.diff) {
          wrap.appendChild(h("p", { class: "sen-muted", style: "color:#b45309" },
            "⚠ " + L("عدم تطابق بين الرصيد والسجل", "Balance/ledger mismatch", "Écart solde/journal") + ": " + money(r.reconcile.diff)));
        }

        /* adjust points */
        if (r.canAdjustPoints) {
          var dir = h("select", { class: "sen-search" },
            h("option", { value: "credit" }, L("إضافة نقاط", "Add points", "Ajouter des points")),
            h("option", { value: "debit" }, L("خصم نقاط", "Deduct points", "Déduire des points")));
          var pts = input("number", "", { min: "1", step: "1", placeholder: L("عدد النقاط", "Points", "Points") });
          var reason = input("text", "", { placeholder: L("السبب (إلزامي)", "Reason (required)", "Motif (obligatoire)"), maxlength: "160" });
          var refInput = input("text", "", { placeholder: L("مرجع اختياري", "Optional reference", "Référence (optionnel)"), maxlength: "60" });
          var go = h("button", { class: "sen-btn primary", type: "button" }, L("تنفيذ التعديل", "Apply adjustment", "Appliquer"));
          go.addEventListener("click", function () {
            var body = { direction: dir.value, points: Number(pts.value), reason: reason.value.trim(), reference: refInput.value.trim() || undefined };
            if (!body.reason) { say("❌ " + L("السبب إلزامي", "A reason is required", "Motif obligatoire")); return; }
            if (!(body.points > 0)) { say("❌ " + L("أدخل عدد نقاط صحيح", "Enter valid points", "Points invalides")); return; }
            var verb = dir.value === "credit" ? L("إضافة", "add", "ajouter") : L("خصم", "deduct", "déduire");
            if (!confirm(verb + " " + body.points + " " + L("نقطة", "points", "points") + " — " + body.reason + "؟")) return;
            go.disabled = true;
            api("/api/admin/loyalty/customers/" + encodeURIComponent(customerId) + "/adjust", { method: "POST", body: JSON.stringify(body) })
              .then(function (res) { say("✅ " + L("تم التعديل", "Adjusted", "Ajusté") + (res.duplicate ? " (" + L("مكرر", "duplicate", "doublon") + ")" : "")); load(); })
              .catch(function (e) { go.disabled = false; say("❌ " + errText(e)); });
          });
          wrap.appendChild(h("h4", {}, L("تعديل يدوي للنقاط", "Manual points adjustment", "Ajustement manuel des points")));
          wrap.appendChild(h("div", { class: "loy-grid" }, row(L("الاتجاه", "Direction", "Sens"), dir), row(L("النقاط", "Points", "Points"), pts),
            row(L("السبب", "Reason", "Motif"), reason), row(L("المرجع", "Reference", "Référence"), refInput)));
          wrap.appendChild(go);
        }

        /* adjust wallet */
        if (r.canAdjustWallet) {
          var wdir = h("select", { class: "sen-search" },
            h("option", { value: "credit" }, L("إضافة رصيد", "Add balance", "Ajouter du solde")),
            h("option", { value: "debit" }, L("خصم رصيد", "Deduct balance", "Déduire du solde")));
          var amt = input("number", "", { min: "0.01", step: "any", placeholder: "MAD" });
          var wreason = input("text", "", { placeholder: L("السبب (إلزامي)", "Reason (required)", "Motif (obligatoire)"), maxlength: "160" });
          var wgo = h("button", { class: "sen-btn primary", type: "button" }, L("تنفيذ", "Apply", "Appliquer"));
          wgo.addEventListener("click", function () {
            var body = { direction: wdir.value, amount: Number(amt.value), reason: wreason.value.trim() };
            if (!body.reason) { say("❌ " + L("السبب إلزامي", "A reason is required", "Motif obligatoire")); return; }
            if (!(body.amount > 0)) { say("❌ " + L("أدخل مبلغًا صحيحًا", "Enter a valid amount", "Montant invalide")); return; }
            if (!confirm(body.direction + " " + money(body.amount) + " — " + body.reason + "؟")) return;
            wgo.disabled = true;
            api("/api/admin/customers/" + encodeURIComponent(customerId) + "/wallet-adjust", { method: "POST", body: JSON.stringify(body) })
              .then(function () { say("✅"); load(); })
              .catch(function (e) { wgo.disabled = false; say("❌ " + errText(e)); });
          });
          wrap.appendChild(h("h4", {}, L("تعديل رصيد المحفظة", "Wallet balance adjustment", "Ajustement du solde")));
          wrap.appendChild(h("div", { class: "loy-grid" }, row(L("الاتجاه", "Direction", "Sens"), wdir), row(L("المبلغ", "Amount", "Montant"), amt),
            row(L("السبب", "Reason", "Motif"), wreason)));
          wrap.appendChild(wgo);
        }

        /* points ledger */
        wrap.appendChild(h("h4", {}, L("سجل النقاط", "Points ledger", "Journal des points")));
        var pl = h("div", { class: "sen-list" });
        (r.loyalty.entries || []).slice(0, 60).forEach(function (e) {
          pl.appendChild(h("div", { class: "sen-row" },
            h("div", { class: "sen-name" }, h("b", {}, (e.direction === "credit" ? "+" : "−") + e.points + " " + L("نقطة", "pts", "pts") + " · " + e.kind),
              h("small", {}, [e.reason, e.orderId ? "#" + e.orderId : "", e.at ? String(e.at).slice(0, 16).replace("T", " ") : ""].filter(Boolean).join(" · "))),
            h("div", { class: "sen-acts" }, h("span", { class: "sen-muted" }, e.status || ""))));
        });
        if (!(r.loyalty.entries || []).length) pl.appendChild(h("p", { class: "sen-muted" }, L("لا يوجد سجل بعد", "No history yet", "Aucun historique")));
        wrap.appendChild(pl);

        /* wallet ledger */
        wrap.appendChild(h("h4", {}, L("حركات المحفظة", "Wallet transactions", "Mouvements du portefeuille")));
        var wl = h("div", { class: "sen-list" });
        (r.transactions || []).slice(0, 60).forEach(function (tx) {
          wl.appendChild(h("div", { class: "sen-row" },
            h("div", { class: "sen-name" }, h("b", {}, (tx.direction === "credit" ? "+" : "−") + money(tx.amount) + " " + (tx.currency || "MAD") + " · " + tx.type),
              h("small", {}, [tx.at ? String(tx.at).slice(0, 16).replace("T", " ") : "", tx.reference, tx.orderId ? "#" + tx.orderId : "", tx.note].filter(Boolean).join(" · "))),
            h("div", { class: "sen-acts" }, h("span", { class: "sen-muted" }, tx.status))));
        });
        if (!(r.transactions || []).length) wl.appendChild(h("p", { class: "sen-muted" }, L("لا توجد حركات", "No transactions", "Aucun mouvement")));
        wrap.appendChild(wl);
      }).catch(function (e) { wrap.replaceChildren(h("p", { class: "sen-muted" }, "❌ " + errText(e))); });
    }
    load();
    return wrap;
  }

  /* ---------------------------------------------------------------- search */
  function customersPanel() {
    var wrap = h("div", { class: "loy-customers lx-customers" });
    var q = input("search", "", { placeholder: L("ابحث بالمعرّف أو الهاتف أو البريد", "Search by id, phone or email", "Rechercher par id, téléphone ou email") });
    var out = h("div", { class: "sen-list" });
    var host = h("div", {});
    wrap.appendChild(h("h4", {}, L("إدارة أرصدة الزبائن", "Customer balances", "Soldes clients")));
    wrap.appendChild(q);
    wrap.appendChild(out);
    wrap.appendChild(host);

    var timer = null;
    function search() {
      api("/api/admin/loyalty/customers?q=" + encodeURIComponent(q.value.trim())).then(function (r) {
        out.replaceChildren();
        (r.customers || []).forEach(function (c) {
          out.appendChild(h("div", { class: "sen-row" },
            h("div", { class: "sen-name" }, h("b", {}, c.name || c.id),
              h("small", {}, [c.phone, c.email, L("نقاط", "pts", "pts") + ": " + c.points.available + " · " + L("محفظة", "wallet", "portefeuille") + ": " + money(c.walletBalance)].filter(Boolean).join(" · "))),
            h("div", { class: "sen-acts" }, h("button", {
              class: "sen-btn", type: "button",
              onclick: function () { out.classList.add("hidden"); var d = detailPanel(c.id, function () { d.remove(); out.classList.remove("hidden"); }); host.replaceChildren(d); },
            }, L("فتح", "Open", "Ouvrir")))));
        });
        if (!(r.customers || []).length) out.appendChild(h("p", { class: "sen-muted" }, L("لا نتائج", "No results", "Aucun résultat")));
      }).catch(function (e) { out.replaceChildren(h("p", { class: "sen-muted" }, "❌ " + errText(e))); });
    }
    q.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(search, 350); });
    search();
    return wrap;
  }

  /* ------------------------------------------------------------------ open */
  function open() {
    var ov = doc.getElementById("loyaltyModal");
    root = h("div", { class: "modal-card sen-box lx-root", role: "region" });
    ov.replaceChildren(root);
    var body = h("div", {}, h("p", { class: "sen-muted" }, "…"));
    root.appendChild(body);

    api("/api/admin/loyalty/settings").then(function (r) {
      body.replaceChildren();
      body.appendChild(settingsPanel(r.settings, r.canEdit, open, r.overview));
      if (can("loyalty.adjust")) {
        var sweep = h("button", { class: "lx-btn ghost lx-sweep", type: "button" }, L("تسوية النقاط المستحقة والمنتهية", "Settle pending / expire due points", "Régler les points en attente / expirés"));
        sweep.addEventListener("click", function () {
          sweep.disabled = true;
          api("/api/admin/loyalty/sweep", { method: "POST", body: "{}" })
            .then(function (res) { say("✅ " + JSON.stringify(res.result || {})); open(); })
            .catch(function (e) { sweep.disabled = false; say("❌ " + errText(e)); });
        });
        body.appendChild(sweep);
      }
      window.showLoyalty(true);
    }).catch(function (e) {
      body.replaceChildren(h("p", { class: "sen-muted" }, "❌ " + errText(e)));
      window.showLoyalty(true);
    });
  }

  function showLoyalty(show) {
    var m = doc.getElementById("loyaltyModal");
    m.classList.toggle("show", !!show);
    if (!show) m.replaceChildren();
    else if (!root || !m.contains(root)) root = m.firstChild;
  }
  window.showLoyalty = showLoyalty;

  var btn = doc.getElementById("loyaltyBtn");
  if (btn) btn.addEventListener("click", function () {
    if (window.adminPerms && !window.adminPerms.canNav("loyalty")) return;
    open();
  });
})();
