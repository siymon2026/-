/* global api, toast */
/* "وضع الديمو" — fake customers / drivers / stores for testing the new features.
 * ON  : the server generates demo accounts (+ a few demo orders) and this page lists their logins.
 * OFF : the server deletes everything demo mode created; real data is never touched.
 * Server-side permission: system_admin only (the endpoints are not granted to any other role). */
(function () {
  "use strict";
  var doc = document;
  var L = window.adminPageElements.L, h = window.adminPageElements.h;
  var say = function (m) { try { toast(m); } catch (e) {} };
  var root = null, busy = false;

  function errText(e) {
    var b = e && e.body;
    return (b && (b.error || b.code)) || (e && e.message) || "Error";
  }
  function copy(text) {
    function done(ok) { say(ok ? L("تم النسخ", "Copied", "Copié") : L("تعذّر النسخ", "Copy failed", "Copie impossible")); }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(false); }); return; }
    try { var ta = h("textarea", { style: "position:fixed;opacity:0" }); ta.value = text; doc.body.appendChild(ta); ta.select(); var ok = doc.execCommand("copy"); ta.remove(); done(ok); } catch (e) { done(false); }
  }
  function box(title) {
    return h("div", { class: "modal-card sen-box", role: "region" },
      h("div", { class: "sen-head" }, h("h3", {}, title),
        h("button", { class: "sen-x", type: "button", "aria-label": L("إغلاق", "Close", "Fermer"), onclick: function () { window.showDemo(false); if (location.hash.indexOf("demo") > -1) location.hash = "#/"; } }, "✕")));
  }
  function accountsTable(title, rows, cols) {
    var t = h("table", { class: "sen-table", style: "width:100%;border-collapse:collapse;font-size:13px" });
    t.appendChild(h("thead", {}, h("tr", {}, cols.map(function (c) { return h("th", { style: "text-align:start;padding:4px 6px" }, c[0]); }))));
    var tb = h("tbody", {});
    rows.forEach(function (r) { tb.appendChild(h("tr", {}, cols.map(function (c) { return h("td", { dir: "auto", style: "padding:4px 6px;user-select:text;-webkit-user-select:text" }, String(r[c[1]] == null ? "" : r[c[1]])); }))); });
    t.appendChild(tb);
    return h("div", { style: "margin:10px 0;overflow:auto" }, h("b", {}, title), t);
  }

  function render(d) {
    root = box(L("وضع الديمو", "Demo mode", "Mode démo"));
    var on = !!d.enabled, c = d.counts || {};
    root.appendChild(h("p", { class: "sen-muted" }, L(
      "عند التشغيل يُنشأ تلقائياً زبائن وسائقون ومتاجر افتراضيون (مع طلبات تجريبية) لاختبار المزايا. عند الإيقاف يُحذف كل ما أنشأه الديمو فقط ويعود النظام لوضعه الحقيقي.",
      "Turning it on automatically creates fake customers, drivers and stores (with sample orders) to test features. Turning it off deletes only what demo mode created and the system returns to its real state.",
      "L’activation crée automatiquement de faux clients, livreurs et boutiques (avec des commandes d’exemple). La désactivation supprime uniquement ce que le mode démo a créé.")));
    root.appendChild(h("div", { class: "sen-field", style: "display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:8px 0" },
      h("b", { style: "font-size:16px" }, on ? "🟢 " + L("الديمو يعمل", "Demo is ON", "Démo ACTIVÉ") : "⚪ " + L("الديمو متوقف", "Demo is OFF", "Démo désactivé")),
      h("button", { class: "lx-btn" + (on ? " ghost" : ""), id: "demoToggle", type: "button", onclick: function () { toggle(!on); } },
        on ? L("إيقاف الديمو وحذف بياناته", "Turn off & delete demo data", "Désactiver et supprimer") : L("تشغيل الديمو", "Turn on demo", "Activer la démo"))));
    root.appendChild(h("p", { class: "sen-muted" }, L("الموجود حالياً: ", "Currently: ", "Actuellement : ") +
      [L("زبائن", "customers", "clients") + " " + (c.customers || 0), L("سائقون", "drivers", "livreurs") + " " + (c.drivers || 0), L("متاجر", "stores", "boutiques") + " " + (c.stores || 0), L("طلبات", "orders", "commandes") + " " + (c.orders || 0)].join(" · ")));
    if (on && d.accounts) {
      var a = d.accounts;
      root.appendChild(h("div", { class: "sen-field", style: "display:flex;gap:8px;align-items:center;flex-wrap:wrap" },
        h("b", {}, L("كلمة المرور لكل الحسابات: ", "Password for all accounts: ", "Mot de passe de tous les comptes : ")),
        h("code", { dir: "ltr", style: "user-select:text" }, a.password),
        h("button", { class: "lx-btn ghost", type: "button", onclick: function () { copy(a.password); } }, L("نسخ", "Copy", "Copier"))));
      root.appendChild(accountsTable(L("الزبائن (الدخول بالبريد أو الهاتف)", "Customers (log in with email or phone)", "Clients (e-mail ou téléphone)"), a.customers, [[L("الاسم", "Name", "Nom"), "name"], [L("البريد", "Email", "E-mail"), "email"], [L("الهاتف", "Phone", "Tél"), "phone"]]));
      root.appendChild(accountsTable(L("السائقون (الدخول بالهاتف)", "Drivers (log in with phone)", "Livreurs (téléphone)"), a.drivers, [[L("الاسم", "Name", "Nom"), "name"], [L("الهاتف", "Phone", "Tél"), "phone"]]));
      root.appendChild(accountsTable(L("المتاجر (الدخول بالهاتف) — أو استعمل «دخول متجر»", "Stores (log in with phone) — or use “Enter store”", "Boutiques (téléphone) — ou « Entrer en boutique »"), a.stores, [[L("المتجر", "Store", "Boutique"), "name"], [L("النوع", "Type", "Type"), "type"], [L("الهاتف", "Phone", "Tél"), "phone"]]));
      root.appendChild(h("p", { class: "sen-muted" }, L(
        "تنبيه: متاجر الديمو ظاهرة في التطبيق مؤقتاً (بوسم DEMO) ليتمكن زبون الديمو من الطلب. أي طلب يضعه حساب ديمو يُحذف عند الإيقاف.",
        "Note: demo stores are temporarily visible in the app (labelled DEMO) so a demo customer can order. Any order placed by a demo account is deleted when you turn demo off.",
        "Note : les boutiques démo sont visibles temporairement (étiquette DEMO). Toute commande passée par un compte démo est supprimée à la désactivation.")));
    }
    var m = doc.getElementById("demoModal");
    m.replaceChildren(root);
  }

  function toggle(want) {
    if (busy) return;
    if (!want && !window.confirm(L("سيتم حذف كل بيانات الديمو (الزبائن والسائقين والمتاجر والطلبات التجريبية). متابعة؟", "All demo data (customers, drivers, stores and demo orders) will be deleted. Continue?", "Toutes les données démo seront supprimées. Continuer ?"))) return;
    busy = true;
    var btn = doc.getElementById("demoToggle"); if (btn) btn.disabled = true;
    api("/api/admin/demo-mode", { method: "POST", body: JSON.stringify({ enabled: !!want }) })
      .then(function (r) {
        busy = false; render(r.demo);
        if (want) say("✅ " + L("تم تشغيل الديمو", "Demo is on", "Démo activé"));
        else say("✅ " + L("تم الإيقاف وحذف بيانات الديمو", "Demo off, data removed", "Démo désactivé, données supprimées"));
      })
      .catch(function (e) { busy = false; if (btn) btn.disabled = false; say("❌ " + errText(e)); });
  }

  function open() {
    var m = doc.getElementById("demoModal");
    m.replaceChildren(box(L("وضع الديمو", "Demo mode", "Mode démo")));
    m.firstChild.appendChild(h("p", { class: "sen-muted" }, "…"));
    api("/api/admin/demo-mode").then(function (r) { render(r.demo); window.showDemo(true); })
      .catch(function (e) { m.firstChild.appendChild(h("p", { class: "sen-muted" }, "❌ " + errText(e))); window.showDemo(true); });
  }

  window.showDemo = function (show) {
    var m = doc.getElementById("demoModal");
    m.classList.toggle("show", !!show);
    if (!show) m.replaceChildren();
  };

  var btn = doc.getElementById("demoBtn");
  if (btn) btn.addEventListener("click", function () {
    if (window.adminPerms && !window.adminPerms.canNav("demo")) return;
    open();
  });
})();
