/* global api, lang, toast, TOPUPS_CACHE, loadTopups, viewTopupReceipt */
/* Wallet top-up review (customers + drivers). Replaces the plain table/prompt() flow of admin.js with:
 *  filters (status, wallet, method, date, search), a clear table, and a confirmation summary BEFORE approving.
 * The SERVER is the authority: PATCH /api/admin/topups/:id needs topups.review, a pending request, a reason for
 * reject/fail, and never credits twice. Nothing here credits anything; success is shown only after the server answers. */
(function () {
  "use strict";
  var doc = document;
  var L = window.adminPageElements.L, h = window.adminPageElements.h;
  var say = function (m) { try { toast(m); } catch (e) {} };
  var canReview = function () { return !window.adminPerms || window.adminPerms.can("topups.review"); };
  var F = { status: "pending", wallet: "all", method: "all", from: "", to: "", q: "" };
  var busy = false, bar = null;
  var ST = { pending: ["قيد المراجعة", "Pending", "En attente", "warn"], approved: ["مقبولة", "Approved", "Approuvée", "ok"], rejected: ["مرفوضة", "Rejected", "Rejetée", "bad"], failed: ["فاشلة / تعذر التحقق", "Failed", "Échec", "bad"] };
  function M(n) { return (Math.round((Number(n) || 0) * 100) / 100).toFixed(2); }
  function list() { return Array.isArray(TOPUPS_CACHE) ? TOPUPS_CACHE : []; }
  function ownerLabel(t) { return t.ownerName || t.driverName || t.customerName || t.ownerId || ""; }
  function wlabel(t) { return t.walletType === "customer" ? L("محفظة زبون", "Customer wallet", "Portefeuille client") : L("محفظة سائق", "Driver wallet", "Portefeuille livreur"); }
  function chip(s) { var x = ST[s] || [s, s, s, ""]; return h("span", { class: "pay-chip " + x[3] }, L(x[0], x[1], x[2])); }
  function day(iso) { return String(iso || "").slice(0, 10); }

  function filtered() {
    var q = F.q.trim().toLowerCase();
    return list().filter(function (t) {
      if (F.status !== "all" && String(t.status) !== F.status) return false;
      if (F.wallet !== "all" && String(t.walletType) !== F.wallet) return false;
      if (F.method !== "all" && String(t.methodId) !== F.method) return false;
      if (F.from && day(t.createdAt) < F.from) return false;
      if (F.to && day(t.createdAt) > F.to) return false;
      if (q) { var hay = [t.id, t.reference, t.confirmedReference, ownerLabel(t), t.driverPhone, t.methodName].join(" ").toLowerCase(); if (hay.indexOf(q) < 0) return false; }
      return true;
    });
  }

  /* ---------- card-based review screen (mobile first) ---------- */
  var root = null, moreOpen = false;
  function amountOf(t) { return Number(t.creditAmount != null ? t.creditAmount : t.amount) || 0; }
  function initial(t) { return (String(ownerLabel(t) || "?").trim().charAt(0) || "?").toUpperCase(); }
  function when(iso) { if (!iso) return ""; var d = new Date(iso); return isNaN(d.getTime()) ? "" : d.toLocaleString(); }
  function tab(key, label, n) {
    return h("button", { type: "button", class: "tp2-tab" + (F.status === key ? " on" : ""), "data-tab": key, role: "tab", "aria-selected": F.status === key ? "true" : "false" },
      h("span", {}, label), h("em", {}, String(n)));
  }
  function pill(key, label, n) {
    return h("button", { type: "button", class: "tp2-pill" + (F.wallet === key ? " on" : ""), "data-wallet": key }, label, n != null ? h("em", {}, String(n)) : null);
  }

  function ensureRoot() {
    var body = doc.getElementById("topupsBody");
    var tbl = body && body.closest("table");
    if (!tbl) return false;
    var scroller = tbl.parentElement; // the old scrolling table box is replaced by the cards
    if (scroller) scroller.style.display = "none";
    var old = doc.getElementById("topupsFilter");
    if (old && old.parentElement) old.parentElement.style.display = "none";
    if (!root || !root.isConnected) {
      root = h("div", { class: "tp2", id: "tpRoot" });
      scroller.parentElement.insertBefore(root, scroller);
      root.addEventListener("click", onClick);
      root.addEventListener("input", function (e) {
        var t = e.target;
        if (t && t.id === "tpQ") { F.q = t.value; drawList(); }
      });
      root.addEventListener("change", function (e) {
        var t = e.target; if (!t) return;
        if (t.id === "tpMethod") { F.method = t.value; drawList(); }
        if (t.id === "tpFrom") { F.from = t.value; drawList(); }
        if (t.id === "tpTo") { F.to = t.value; drawList(); }
      });
    }
    return true;
  }

  function drawTop() {
    var all = list();
    var pend = all.filter(function (t) { return t.status === "pending"; });
    var cnt = function (st) { return all.filter(function (t) { return st === "all" || t.status === st; }).length; };
    var pc = pend.filter(function (t) { return t.walletType === "customer"; }), pd = pend.filter(function (t) { return t.walletType !== "customer"; });
    var sum = function (a) { return M(a.reduce(function (x, t) { return x + amountOf(t); }, 0)); };
    var seen = {}; all.forEach(function (t) { if (t.methodId) seen[t.methodId] = t.methodName || t.methodId; });
    var msel = h("select", { class: "pay-in", id: "tpMethod", "aria-label": L("طريقة الدفع", "Method", "Méthode") }, h("option", { value: "all" }, L("كل طرق الدفع", "All methods", "Toutes méthodes")));
    Object.keys(seen).sort().forEach(function (k) { msel.appendChild(h("option", { value: k }, seen[k])); });
    msel.value = F.method;
    var from = h("input", { class: "pay-in", id: "tpFrom", type: "date", "aria-label": L("من تاريخ", "From", "Du") }); from.value = F.from;
    var to = h("input", { class: "pay-in", id: "tpTo", type: "date", "aria-label": L("إلى تاريخ", "To", "Au") }); to.value = F.to;
    var q = h("input", { class: "pay-in", id: "tpQ", type: "search", placeholder: L("ابحث بالاسم أو المرجع أو رقم الطلب…", "Search name, reference or request #…", "Nom, référence ou n°…") }); q.value = F.q;
    var more = h("div", { class: "tp2-more" + (moreOpen ? " open" : "") }, msel, from, to);

    var top = h("div", { class: "tp2-top", id: "tpTop" },
      h("div", { class: "tp2-stats" },
        h("div", { class: "tp2-stat warn" }, h("span", {}, L("بانتظار المراجعة", "Awaiting review", "En attente")), h("b", {}, String(pend.length)), h("small", {}, sum(pend) + " MAD")),
        h("div", { class: "tp2-stat" }, h("span", {}, L("شحن الزبائن", "Customers", "Clients")), h("b", {}, String(pc.length)), h("small", {}, sum(pc) + " MAD")),
        h("div", { class: "tp2-stat" }, h("span", {}, L("شحن السائقين", "Drivers", "Livreurs")), h("b", {}, String(pd.length)), h("small", {}, sum(pd) + " MAD"))),
      h("div", { class: "tp2-tabs", role: "tablist" },
        tab("pending", L("قيد المراجعة", "Pending", "En attente"), cnt("pending")),
        tab("approved", L("مقبولة", "Approved", "Approuvées"), cnt("approved")),
        tab("rejected", L("مرفوضة", "Rejected", "Rejetées"), cnt("rejected")),
        tab("failed", L("فاشلة", "Failed", "Échecs"), cnt("failed")),
        tab("all", L("الكل", "All", "Toutes"), cnt("all"))),
      h("div", { class: "tp2-pills" },
        pill("all", L("الكل", "Everyone", "Tous")),
        pill("customer", L("الزبائن", "Customers", "Clients")),
        pill("driver", L("السائقون", "Drivers", "Livreurs"))),
      h("div", { class: "tp2-search" }, q,
        h("button", { type: "button", class: "tp2-filterbtn" + (moreOpen ? " on" : ""), "data-act": "more", "aria-expanded": moreOpen ? "true" : "false" }, L("تصفية", "Filters", "Filtres"))),
      more,
      h("div", { class: "tp2-count", id: "tpCount" }));
    var oldTop = root.querySelector("#tpTop");
    var focused = doc.activeElement && doc.activeElement.id === "tpQ";
    if (oldTop) oldTop.replaceWith(top); else root.insertBefore(top, root.firstChild);
    if (focused) { var nq = doc.getElementById("tpQ"); if (nq) { nq.focus(); try { nq.setSelectionRange(nq.value.length, nq.value.length); } catch (e) {} } }
  }

  function card(t) {
    var pending = t.status === "pending";
    var acts = h("div", { class: "tp2-acts" });
    if (pending && canReview()) {
      acts.appendChild(h("button", { class: "tp2-btn ok", type: "button", "data-act": "approve", "data-id": t.id }, "✓ " + L("قبول الشحن", "Approve", "Approuver")));
      acts.appendChild(h("button", { class: "tp2-btn no", type: "button", "data-act": "reject", "data-id": t.id }, L("رفض", "Reject", "Rejeter")));
      acts.appendChild(h("button", { class: "tp2-btn ghost", type: "button", "data-act": "fail", "data-id": t.id }, L("تعذر التحقق", "Can't verify", "Non vérifiable")));
    } else if (pending) acts.appendChild(h("span", { class: "tp-sub" }, L("لا تملك صلاحية المراجعة", "No review permission", "Pas de droit de revue")));
    var isCust = t.walletType === "customer";
    var meta = h("dl", { class: "tp2-meta" },
      h("div", {}, h("dt", {}, L("طريقة الدفع", "Method", "Méthode")), h("dd", {}, t.methodName || t.methodId || "—")),
      h("div", {}, h("dt", {}, L("المرجع", "Reference", "Référence")), h("dd", { class: "ref" }, t.reference || "—",
        t.reference ? h("button", { type: "button", class: "tp2-copy", "data-act": "copy", "data-v": t.reference, title: L("نسخ", "Copy", "Copier"), "aria-label": L("نسخ المرجع", "Copy reference", "Copier la référence") }, "⧉") : null)),
      h("div", {}, h("dt", {}, L("التاريخ", "Date", "Date")), h("dd", {}, when(t.createdAt) || "—")),
      h("div", {}, h("dt", {}, L("رقم الطلب", "Request", "Demande")), h("dd", { class: "ref" }, "#" + String(t.id).slice(-8))));
    var decided = null;
    if (!pending) {
      decided = h("div", { class: "tp2-decided" },
        h("span", {}, (t.decidedAt ? when(t.decidedAt) : "") + (t.reviewerName ? " · " + t.reviewerName : "")),
        t.decisionNote ? h("span", {}, t.decisionNote) : null,
        t.confirmedReference ? h("span", { class: "ref" }, "✓ " + t.confirmedReference) : null);
    }
    return h("article", { class: "tp2-card st-" + t.status },
      h("header", { class: "tp2-h" },
        h("span", { class: "tp2-av " + (isCust ? "cust" : "drv"), "aria-hidden": "true" }, initial(t)),
        h("div", { class: "tp2-who" }, h("b", {}, ownerLabel(t) || "—"),
          h("span", {}, h("i", { class: "tp2-wt " + (isCust ? "cust" : "drv") }, wlabel(t)), t.driverPhone ? " · " + t.driverPhone : "")),
        chip(t.status)),
      h("div", { class: "tp2-amt" },
        h("div", {}, h("small", {}, pending ? L("سيُضاف للمحفظة", "To be credited", "À créditer") : L("المبلغ المضاف", "Credit amount", "Montant crédité")), h("b", {}, M(amountOf(t)), h("em", {}, " MAD"))),
        h("div", { class: "tp2-amt-s" }, h("span", {}, L("المحوَّل ", "Sent ", "Viré "), M(t.amount)), h("span", {}, L("الرسوم ", "Fee ", "Frais "), M(t.fee)))),
      meta, decided,
      t.receiptUrl ? h("button", { class: "tp2-receipt", type: "button", "data-act": "view", "data-id": t.id }, "🧾 " + L("عرض وصل التحويل", "View transfer receipt", "Voir le reçu")) : null,
      acts.childNodes.length ? acts : null);
  }

  function drawList() {
    if (!root) return;
    var rows = filtered().sort(function (a, b) { return String(b.createdAt || "").localeCompare(String(a.createdAt || "")); });
    var cn = doc.getElementById("tpCount");
    if (cn) cn.textContent = L("المعروض: ", "Shown: ", "Affichés : ") + rows.length + " / " + list().length;
    var box = root.querySelector("#tpList");
    if (!box) { box = h("div", { class: "tp2-list", id: "tpList" }); root.appendChild(box); }
    box.replaceChildren();
    if (!rows.length) {
      box.appendChild(h("div", { class: "tp2-empty" }, h("b", {}, "✓"), h("span", {}, F.status === "pending" ? L("لا توجد طلبات شحن بانتظار المراجعة", "No top-up requests waiting for review", "Aucune demande en attente") : L("لا توجد طلبات مطابقة", "No matching requests", "Aucune demande"))));
      return;
    }
    rows.forEach(function (t) { box.appendChild(card(t)); });
  }

  function onClick(e) {
    var t = e.target.closest && e.target.closest("button");
    if (!t || !root.contains(t)) return;
    var tabKey = t.getAttribute("data-tab"), wl = t.getAttribute("data-wallet"), act = t.getAttribute("data-act"), id = t.getAttribute("data-id");
    if (tabKey) { F.status = tabKey; drawTop(); drawList(); return; }
    if (wl) { F.wallet = wl; drawTop(); drawList(); return; }
    if (act === "more") { moreOpen = !moreOpen; drawTop(); return; }
    if (act === "approve") return decide(id, "approved");
    if (act === "reject") return decide(id, "rejected");
    if (act === "fail") return decide(id, "failed");
    if (act === "copy") {
      var v = t.getAttribute("data-v") || "";
      try { navigator.clipboard.writeText(v).then(function () { say("✅ " + L("تم النسخ", "Copied", "Copié")); }); } catch (er) {}
      return;
    }
    if (act === "view") {
      var tp = list().find(function (x) { return String(x.id) === String(id); });
      if (tp && tp.receiptUrl) viewTopupReceipt(tp.receiptUrl).catch(function (er) { say("❌ " + ((er && er.message) || "Error")); });
    }
  }

  function render() {
    if (!ensureRoot()) return;
    drawTop();
    drawList();
  }

  /* ---------- confirmation dialogs ---------- */
  function row(k, v, cls) { return h("div", { class: cls || "" }, h("span", {}, k), h("b", {}, v)); }
  function decide(id, to) {
    if (busy) return;
    var t = list().find(function (x) { return String(x.id) === String(id); });
    if (!t || t.status !== "pending") { say("❌ " + L("الطلب لم يعد قيد المراجعة", "This request is no longer pending", "Demande déjà traitée")); return; }
    var approve = to === "approved", ov, go, reason, ref, chk;
    var box = h("div", {}, h("div", { class: "tp-sumbox" },
      row(L("رقم الطلب", "Request", "Demande"), "#" + String(t.id).slice(-8)),
      row(L("المحفظة", "Wallet", "Portefeuille"), wlabel(t)),
      row(L("صاحب المحفظة", "Owner", "Titulaire"), ownerLabel(t) + " (ID " + (t.ownerId || "") + ")"),
      row(L("طريقة الدفع", "Method", "Méthode"), t.methodName || t.methodId || "—"),
      row(L("مرجع التحويل", "Reference", "Référence"), t.reference || "—"),
      row(L("المبلغ المحوَّل", "Transferred", "Viré"), M(t.amount) + " MAD"),
      row(L("الرسوم", "Fee", "Frais"), M(t.fee) + " MAD"),
      approve ? row(L("سيُضاف إلى المحفظة", "Will be credited", "Sera crédité"), M(t.creditAmount != null ? t.creditAmount : t.amount) + " MAD", "big") : null));
    function valid() { go.disabled = approve ? !chk.checked : String(reason.value).trim().length < 3; }
    if (approve) {
      ref = h("input", { class: "pay-in", dir: "ltr", maxlength: "60", placeholder: L("مرجع العملية كما يظهر في كشف البنك (اختياري)", "Reference as shown on the bank statement (optional)", "Référence du relevé (optionnel)") });
      chk = h("input", { type: "checkbox" }); chk.addEventListener("change", valid);
      box.appendChild(ref);
      box.appendChild(h("label", { class: "tp-chk" }, chk, h("span", {}, L("تحققت من وصول هذا المبلغ فعلياً إلى حسابنا. سيُضاف الرصيد فوراً ولا يمكن التراجع.", "I verified that this amount actually reached our account. The wallet is credited immediately and this cannot be undone.", "J'ai vérifié que ce montant est arrivé. Le crédit est immédiat et irréversible."))));
    } else {
      reason = h("textarea", { class: "pay-in", rows: "3", maxlength: "300", placeholder: L("سبب الرفض (إجباري، 3 أحرف على الأقل) — يظهر لصاحب المحفظة", "Reason (required, min 3 characters) — shown to the wallet owner", "Motif (obligatoire) — visible par le titulaire") });
      reason.addEventListener("input", valid); box.appendChild(reason);
    }
    var title = approve ? L("تأكيد قبول الشحن", "Confirm approval", "Confirmer l'approbation") : to === "failed" ? L("تعذر التحقق من العملية", "Mark as failed", "Marquer en échec") : L("رفض طلب الشحن", "Reject top-up", "Rejeter la demande");
    go = h("button", { class: "pay-btn " + (approve ? "primary" : "danger"), type: "button", disabled: true, onclick: function () {
      if (busy) return; busy = true; go.disabled = true;
      api("/api/admin/topups/" + encodeURIComponent(id), { method: "PATCH", body: JSON.stringify({ status: to, reason: approve ? "" : reason.value.trim(), confirmedReference: approve ? ref.value.trim() : "" }) })
        .then(function () { ov.remove(); say("✅ " + (approve ? L("تمت الموافقة وإضافة الرصيد", "Approved and wallet credited", "Approuvé et crédité") : L("تم تسجيل القرار", "Decision recorded", "Décision enregistrée"))); })
        .catch(function (e) {
          var c = e && e.body && e.body.code;
          say("❌ " + (c === "ALREADY_DECIDED" ? L("تم البت في هذا الطلب مسبقاً", "Already decided", "Déjà traitée") : c === "REASON_REQUIRED" ? L("السبب إجباري", "A reason is required", "Motif requis") : c === "SELF_REVIEW" ? L("لا يمكنك مراجعة طلبك", "You cannot review your own request", "Revue de sa propre demande interdite") : (e && e.message) || "Error"));
          ov.remove();
        })
        .then(function () { busy = false; return loadTopups(); }).catch(function () { busy = false; });
    } }, approve ? L("قبول وإضافة الرصيد", "Approve & credit", "Approuver et créditer") : L("تأكيد", "Confirm", "Confirmer"));
    var cancel = h("button", { class: "pay-btn", type: "button", onclick: function () { ov.remove(); } }, L("إلغاء", "Cancel", "Annuler"));
    ov = h("div", { class: "pay-ov" }, h("div", { class: "pay-dlg sm", role: "dialog", "aria-modal": "true" },
      h("div", { class: "pay-dlg-h" }, h("h3", {}, title), h("button", { class: "pay-x", type: "button", onclick: function () { ov.remove(); } }, "✕")),
      h("div", { class: "pay-dlg-b" }, box), h("div", { class: "pay-dlg-f" }, cancel, go)));
    ov.addEventListener("mousedown", function (e) { if (e.target === ov) ov.remove(); });
    doc.body.appendChild(ov);
  }

  // Replace the legacy renderer / prompt() flow of admin.js (global functions, resolved at call time).
  window.renderTopups = render;
  window.decideTopup = function (id, status) { decide(id, status); return Promise.resolve(); };
})();
