/* global api, lang, toast, token */
/* ORDER payments by manual transfer (supervisor review). Lives inside the existing "Topups" page, separate from wallet top-ups.
 * The SERVER decides (PATCH /api/admin/order-payments/:id needs topups.review; refunds need finance.write). Nothing here marks an
 * order paid by itself: success is shown only after the server answers. All values go through textContent. */
(function () {
  "use strict";
  var L = window.adminPageElements.L, h = window.adminPageElements.h;
  var say = function (m) { try { toast(m); } catch (e) {} };
  var canReview = function () { return !window.adminPerms || window.adminPerms.can("topups.review"); };
  var canRefund = function () { return !window.adminPerms || window.adminPerms.can("finance.write"); };
  var ST = { UNPAID: ["بانتظار الإثبات", "Awaiting proof", "En attente"], PAYMENT_PENDING: ["قيد المراجعة", "Pending", "À vérifier"], PAYMENT_APPROVED: ["مؤكد", "Approved", "Confirmé"], PAYMENT_REJECTED: ["مرفوض", "Rejected", "Refusé"] };
  var F = { status: "PAYMENT_PENDING" }, root, body, busy = false;
  function M(n) { return (Math.round((Number(n) || 0) * 100) / 100).toFixed(2); }
  var ERR = { NOT_PENDING: L("لا يوجد إثبات بانتظار المراجعة", "No proof is pending", "Aucune preuve en attente"), ORDER_CLOSED: L("الطلب ملغى", "Order is canceled", "Commande annulée"), REASON_REQUIRED: L("السبب مطلوب", "Reason required", "Motif requis") };
  function errText(e) { var c = e && e.body && e.body.code; return "❌ " + (ERR[c] || (e && e.message) || "Error"); }

  function viewReceipt(url) {
    fetch(url, { headers: { "X-Admin-Token": token || "" } }).then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.blob(); })
      .then(function (b) { var u = URL.createObjectURL(b); window.open(u, "_blank"); setTimeout(function () { URL.revokeObjectURL(u); }, 60000); })
      .catch(function (e) { say("❌ " + e.message); });
  }
  function decide(p, status) {
    if (busy) return; var reason = "", ref = "";
    if (status === "approved") {
      if (!confirm(L("تأكيد أنك تحققت فعلياً من وصول ", "Confirm you verified the arrival of ", "Confirmez avoir vérifié la réception de ") + M(p.amount) + " " + p.currency + " (#" + p.orderId + ")؟")) return;
      ref = prompt(L("مرجع العملية في كشف الحساب (اختياري)", "Bank statement reference (optional)", "Référence du relevé (optionnel)"), p.reference || "") || "";
    } else {
      reason = prompt(L("سبب الرفض (إلزامي)", "Reason for rejection (required)", "Motif du refus (obligatoire)"), "");
      if (reason === null) return;
      if (String(reason).trim().length < 3) { say(ERR.REASON_REQUIRED); return; }
    }
    busy = true;
    api("/api/admin/order-payments/" + encodeURIComponent(p.orderId), { method: "PATCH", body: JSON.stringify({ status: status, reason: reason, confirmedReference: ref }) })
      .then(function () { say("✅"); }).catch(function (e) { say(errText(e)); }).then(function () { busy = false; load(); });
  }
  function refunded(p) {
    var ref = prompt(L("مرجع الاسترجاع (إلزامي)", "Refund reference (required)", "Référence du remboursement"), "");
    if (!ref) return;
    api("/api/admin/order-payments/" + encodeURIComponent(p.orderId) + "/refunded", { method: "POST", body: JSON.stringify({ reference: ref }) })
      .then(function () { say("✅"); load(); }).catch(function (e) { say(errText(e)); });
  }
  function row(p) {
    var st = ST[p.status] || [p.status, p.status, p.status];
    var acts = h("div", { class: "row", style: "gap:6px;flex-wrap:wrap" });
    if (p.hasReceipt) acts.appendChild(h("button", { class: "btn ghost small", type: "button", onclick: function () { viewReceipt(p.receiptUrl); } }, L("الوصل", "Receipt", "Reçu")));
    if (p.status === "PAYMENT_PENDING" && p.orderStatus !== "canceled" && canReview()) {
      acts.appendChild(h("button", { class: "btn good small", type: "button", onclick: function () { decide(p, "approved"); } }, L("تأكيد", "Approve", "Confirmer")));
      acts.appendChild(h("button", { class: "btn bad small", type: "button", onclick: function () { decide(p, "rejected"); } }, L("رفض", "Reject", "Refuser")));
    }
    if (p.refund && p.refund.state === "required" && canRefund()) acts.appendChild(h("button", { class: "btn small", type: "button", onclick: function () { refunded(p); } }, L("تم الاسترجاع", "Mark refunded", "Remboursé")));
    var note = p.refund && p.refund.state === "required" ? " ⚠ " + L("طلب ملغى: استرجاع مطلوب", "Canceled: refund due", "Annulée : remboursement dû") : "";
    return h("tr", {},
      h("td", {}, "#" + p.orderId), h("td", {}, p.customerName + (p.customerPhone ? " · " + p.customerPhone : "")),
      h("td", {}, p.methodName), h("td", {}, M(p.amount) + " " + p.currency), h("td", { dir: "ltr" }, p.reference || "—"),
      h("td", {}, L(st[0], st[1], st[2]) + note + (p.decisionNote ? " — " + p.decisionNote : "")),
      h("td", {}, p.submittedAt ? new Date(p.submittedAt).toLocaleString() : "—"), h("td", {}, acts));
  }
  function load() {
    var q = F.status === "REFUND" ? "?refund=1" : F.status === "all" ? "" : "?status=" + F.status;
    api("/api/admin/order-payments" + q).then(function (d) {
      body.replaceChildren();
      var rows = d.payments || [];
      if (!rows.length) { body.appendChild(h("tr", {}, h("td", { colspan: "8", class: "hint" }, L("لا توجد مدفوعات", "Nothing here", "Rien à afficher")))); return; }
      rows.forEach(function (p) { body.appendChild(row(p)); });
    }).catch(function (e) { body.replaceChildren(h("tr", {}, h("td", { colspan: "8", class: "hint" }, errText(e)))); });
  }
  function build() {
    var card = document.querySelector("#topupsModal .modal-card");
    if (!card || document.getElementById("orderPaymentsPanel")) return;
    var sel = h("select", { id: "opFilter", onchange: function () { F.status = sel.value; load(); } });
    [["PAYMENT_PENDING", L("قيد المراجعة", "Pending", "À vérifier")], ["PAYMENT_APPROVED", L("مؤكدة", "Approved", "Confirmés")], ["PAYMENT_REJECTED", L("مرفوضة", "Rejected", "Refusés")], ["UNPAID", L("بانتظار الإثبات", "Awaiting proof", "En attente")], ["REFUND", L("استرجاعات مطلوبة", "Refunds due", "Remboursements")], ["all", L("الكل", "All", "Tous")]].forEach(function (o) { sel.appendChild(h("option", { value: o[0] }, o[1])); });
    body = h("tbody", {});
    root = h("div", { class: "panel-like", id: "orderPaymentsPanel", style: "margin-top:14px" },
      h("div", { class: "row", style: "justify-content:space-between;align-items:center;gap:8px" }, h("b", {}, L("مدفوعات الطلبات بالتحويل (غير شحن المحفظة)", "Order payments by transfer (not wallet top-ups)", "Paiements de commandes par virement")), h("div", { class: "row", style: "gap:6px" }, sel, h("button", { class: "btn ghost small", type: "button", onclick: load }, "↻"))),
      h("div", { style: "overflow:auto;margin-top:8px" }, h("table", { class: "table" }, h("thead", {}, h("tr", {}, ["#", L("الزبون", "Customer", "Client"), L("الطريقة", "Method", "Méthode"), L("المبلغ", "Amount", "Montant"), L("المرجع", "Reference", "Référence"), L("الحالة", "Status", "Statut"), L("التاريخ", "Date", "Date"), ""].map(function (t) { return h("th", {}, t); }))), body)));
    card.appendChild(root);
    load();
  }
  document.addEventListener("click", function (e) { if (e.target.closest && e.target.closest("#topupsBtn,[data-key=topups]")) setTimeout(function () { build(); load(); }, 50); });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", build); else build();
})();
