/* global api, toast */
/* "أيقونة التطبيق": seasonal icons for the customer app and the driver app.
 * The browser builds the 192 / 512 / 180 px PNGs from one picture; the server serves the live one at the
 * standard icon URLs (header logo, favicon, PWA manifest, push notification icon) so a WebView / installed PWA
 * picks it up too. The launcher icon of an installed app changes when the OS refreshes the installed app. */
(function () {
  "use strict";
  var doc = document;
  var L = window.adminPageElements.L, h = window.adminPageElements.h;
  var say = function (m) { try { toast(m); } catch (e) {} };
  var state = null, busy = false;
  var APPS = [["customer", ["تطبيق الزبائن", "Customer app", "Application clients"]], ["driver", ["تطبيق السائقين", "Driver app", "Application livreurs"]]];

  function errText(e) { var b = e && e.body; return (b && (b.error || b.code)) || (e && e.message) || "Error"; }
  function call(url, method, body) {
    if (busy) return Promise.reject(new Error("busy"));
    busy = true;
    return api(url, { method: method, body: body ? JSON.stringify(body) : undefined })
      .then(function (r) { busy = false; if (r && r.icons) { state = r.icons; render(); } return r; })
      .catch(function (e) { busy = false; say("❌ " + errText(e)); throw e; });
  }
  function box(title) {
    return h("div", { class: "modal-card sen-box", role: "region" },
      h("div", { class: "sen-head" }, h("h3", {}, title),
        h("button", { class: "sen-x", type: "button", "aria-label": L("إغلاق", "Close", "Fermer"), onclick: function () { window.showAppIcons(false); if (location.hash.indexOf("appicons") > -1) location.hash = "#/"; } }, "✕")));
  }
  function mdLabel(v) { return v ? v.slice(3) + "/" + v.slice(0, 2) : ""; } // MM-DD -> DD/MM
  function toMd(dateStr) { return dateStr ? String(dateStr).slice(5) : ""; }

  // picture -> square PNG of a given size (centre crop, no distortion)
  function renderPng(img, size, bg) {
    var c = doc.createElement("canvas"); c.width = c.height = size;
    var x = c.getContext("2d");
    if (bg) { x.fillStyle = bg; x.fillRect(0, 0, size, size); }
    var s = Math.min(img.width, img.height), sx = (img.width - s) / 2, sy = (img.height - s) / 2;
    x.drawImage(img, sx, sy, s, s, 0, 0, size, size);
    return c.toDataURL("image/png");
  }
  function loadImage(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onerror = function () { reject(new Error("read")); };
      fr.onload = function () { var im = new Image(); im.onerror = function () { reject(new Error(L("ملف صورة غير صالح", "Invalid image", "Image invalide"))); }; im.onload = function () { resolve(im); }; im.src = String(fr.result); };
      fr.readAsDataURL(file);
    });
  }

  function uploader(target) {
    var name = h("input", { class: "input", type: "text", maxlength: 60, placeholder: L("اسم الأيقونة (مثلاً: رمضان)", "Icon name (e.g. Ramadan)", "Nom (ex. Ramadan)"), style: "width:100%;margin:4px 0" });
    var from = h("input", { class: "input", type: "date" }), to = h("input", { class: "input", type: "date" });
    var file = h("input", { type: "file", accept: "image/png,image/jpeg,image/webp,image/svg+xml", style: "display:none" });
    var prev = h("img", { alt: "", style: "width:72px;height:72px;border-radius:16px;object-fit:cover;background:#222;display:none" });
    var picked = null, status = h("small", {}, "");
    file.addEventListener("change", function () {
      var f = file.files && file.files[0]; if (!f) return;
      loadImage(f).then(function (im) { picked = im; prev.src = renderPng(im, 144); prev.style.display = ""; status.textContent = (im.width < 512 || im.height < 512) ? L("تنبيه: الصورة أصغر من 512px وقد تبدو غير حادة", "Note: image is smaller than 512px and may look soft", "Image < 512px : peut paraître floue") : ""; })
        .catch(function (e) { say("❌ " + errText(e)); });
    });
    var pick = h("button", { class: "lx-btn ghost", type: "button", onclick: function () { file.click(); } }, L("اختيار صورة", "Choose picture", "Choisir une image"));
    var save = h("button", { class: "lx-btn", type: "button", onclick: function () {
      if (!picked) return say(L("اختر صورة أولاً", "Choose a picture first", "Choisissez une image"));
      if (!name.value.trim()) return say(L("أدخل اسم الأيقونة", "Enter a name", "Entrez un nom"));
      if (!!from.value !== !!to.value) return say(L("أدخل تاريخ البداية والنهاية معاً أو اتركهما فارغين", "Enter both dates or none", "Les deux dates ou aucune"));
      call("/api/admin/app-icons/" + target, "POST", { name: name.value.trim(), from: toMd(from.value), to: toMd(to.value), icons: { "192": renderPng(picked, 192), "512": renderPng(picked, 512), "180": renderPng(picked, 180, "#0F0F0F") } })
        .then(function () { say("✅ " + L("تمت إضافة الأيقونة", "Icon added", "Icône ajoutée")); }).catch(function () {});
    } }, L("رفع وحفظ", "Upload & save", "Téléverser"));
    return h("details", { style: "margin:10px 0" }, h("summary", { style: "cursor:pointer;font-weight:700" }, "➕ " + L("إضافة أيقونة جديدة", "Add a new icon", "Ajouter une icône")),
      h("div", { style: "padding:8px 0" }, name,
        h("div", { style: "display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:4px 0" }, h("span", {}, L("من", "From", "Du")), from, h("span", {}, L("إلى", "to", "au")), to),
        h("small", { class: "sen-muted" }, L("التواريخ اختيارية وتتكرر كل سنة (يُستعمل اليوم والشهر فقط). اتركها فارغة إن أردت التفعيل اليدوي.", "Dates are optional and repeat every year (only day and month are used). Leave empty for manual activation.", "Dates facultatives, répétées chaque année.")),
        h("div", { style: "display:flex;gap:10px;align-items:center;margin:8px 0;flex-wrap:wrap" }, pick, prev, file, save), status));
  }

  function card(target, cfg, it) {
    var isDefault = !it, id = isDefault ? "default" : it.id;
    var live = cfg.effectiveId === id;
    var src = isDefault ? (target === "driver" ? "/icons-driver/icon-192.png" : "/icons/icon-192.png") : it.url;
    var img = h("img", { alt: "", src: isDefault ? src + "?default=1" : src, style: "width:56px;height:56px;border-radius:14px;object-fit:cover;background:#222" });
    var title = isDefault ? L("الأيقونة الأصلية", "Default icon", "Icône par défaut") : it.name;
    var sub = isDefault ? "" : (it.from ? L("تلقائياً: ", "Auto: ", "Auto : ") + mdLabel(it.from) + " → " + mdLabel(it.to) : L("بدون تواريخ", "No dates", "Sans dates"));
    var acts = h("div", { style: "display:flex;gap:6px;flex-wrap:wrap" });
    if (cfg.mode === "manual" && cfg.activeId !== id) acts.appendChild(h("button", { class: "lx-btn", type: "button", onclick: function () { call("/api/admin/app-icons/" + target + "/settings", "PUT", { activeId: id }).then(function () { say("✅"); }).catch(function () {}); } }, L("تفعيل", "Activate", "Activer")));
    if (!isDefault) {
      acts.appendChild(h("button", { class: "lx-btn ghost", type: "button", onclick: function () {
        var f = window.prompt(L("من (DD/MM) — فارغ لإزالة التواريخ", "From (DD/MM) — empty to clear", "Du (JJ/MM)"), mdLabel(it.from));
        if (f === null) return;
        var t = f ? window.prompt(L("إلى (DD/MM)", "To (DD/MM)", "Au (JJ/MM)"), mdLabel(it.to)) : "";
        if (t === null) return;
        function md(v) { var m = String(v || "").trim().match(/^(\d{1,2})\/(\d{1,2})$/); return m ? ("0" + m[2]).slice(-2) + "-" + ("0" + m[1]).slice(-2) : ""; }
        if ((f && !md(f)) || (t && !md(t))) return say(L("صيغة غير صحيحة، استعمل DD/MM", "Bad format, use DD/MM", "Format invalide (JJ/MM)"));
        call("/api/admin/app-icons/" + target + "/" + it.id, "PUT", { from: md(f), to: md(t) }).then(function () { say("✅"); }).catch(function () {});
      } }, L("التواريخ", "Dates", "Dates")));
      acts.appendChild(h("button", { class: "lx-btn ghost", type: "button", onclick: function () {
        if (!window.confirm(L("حذف هذه الأيقونة؟", "Delete this icon?", "Supprimer cette icône ?"))) return;
        call("/api/admin/app-icons/" + target + "/" + it.id, "DELETE").then(function () { say("✅"); }).catch(function () {});
      } }, L("حذف", "Delete", "Supprimer")));
    }
    return h("div", { style: "display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:8px 0;border-top:1px solid var(--color-border,#2a2a2a)" },
      h("div", { style: "display:flex;gap:10px;align-items:center" }, img, h("div", {}, h("b", {}, title + (live ? " 🟢" : "")), sub ? h("div", { class: "sen-muted", style: "font-size:12px" }, sub) : null, live ? h("div", { style: "font-size:12px" }, L("الأيقونة المعروضة الآن", "Live now", "Active maintenant")) : null)),
      acts);
  }

  function section(target, title) {
    var cfg = state[target];
    var modeSel = h("select", { class: "input", onchange: function (e) { call("/api/admin/app-icons/" + target + "/settings", "PUT", { mode: e.target.value }).then(function () { say("✅"); }).catch(function () {}); } },
      h("option", { value: "manual", selected: cfg.mode === "manual" }, L("يدوي: أختار الأيقونة بنفسي", "Manual: I pick the icon", "Manuel")),
      h("option", { value: "auto", selected: cfg.mode === "auto" }, L("تلقائي حسب تواريخ المواسم", "Automatic by season dates", "Automatique selon les dates")));
    var wrap = h("section", { style: "margin:14px 0;padding:12px;border:1px solid var(--color-border,#2a2a2a);border-radius:14px" },
      h("h4", { style: "margin:0 0 8px" }, title), h("div", { style: "margin-bottom:6px" }, modeSel));
    if (cfg.mode === "auto") wrap.appendChild(h("small", { class: "sen-muted" }, L("توقيت: ", "Timezone: ", "Fuseau : ") + cfg.timezone + " — " + L("خارج كل المواسم تُستعمل الأيقونة الأصلية.", "outside every season the default icon is used.", "hors saison : icône par défaut.")));
    wrap.appendChild(card(target, cfg, null));
    cfg.items.forEach(function (it) { wrap.appendChild(card(target, cfg, it)); });
    wrap.appendChild(uploader(target));
    return wrap;
  }

  function render() {
    var root = box(L("أيقونة التطبيق (المواسم)", "App icon (seasons)", "Icône de l’app (saisons)"));
    root.appendChild(h("p", { class: "sen-muted" }, L(
      "ارفع أيقونات للمواسم (رمضان، العيد، الشتاء…) وفعّلها يدوياً أو اتركها تتبدل تلقائياً حسب التواريخ. تتغير الأيقونة في الموقع والتطبيق داخل WebView وشعار الإشعارات وأيقونة PWA. أما أيقونة الشاشة الرئيسية في الهاتف فيحدّثها النظام بنفسه لاحقاً (قد يحتاج إعادة تثبيت التطبيق).",
      "Upload seasonal icons (Ramadan, Eid, winter…) and activate them manually or let them switch automatically by date. The icon changes on the site, inside the WebView app, notification icon and PWA. The phone home-screen icon is refreshed by the OS later (may need a reinstall).",
      "Téléversez des icônes saisonnières, activation manuelle ou automatique. L’icône de l’écran d’accueil est rafraîchie par le système (réinstallation parfois nécessaire).")));
    APPS.forEach(function (a) { root.appendChild(section(a[0], L.apply(null, a[1]))); });
    doc.getElementById("appiconsModal").replaceChildren(root);
  }

  function open() {
    var m = doc.getElementById("appiconsModal");
    m.replaceChildren(box(L("أيقونة التطبيق (المواسم)", "App icon (seasons)", "Icône de l’app (saisons)")));
    api("/api/admin/app-icons").then(function (r) { state = r.icons; render(); window.showAppIcons(true); })
      .catch(function (e) { m.firstChild.appendChild(h("p", { class: "sen-muted" }, "❌ " + errText(e))); window.showAppIcons(true); });
  }
  window.showAppIcons = function (show) {
    var m = doc.getElementById("appiconsModal");
    m.classList.toggle("show", !!show);
    if (!show) m.replaceChildren();
  };
  var btn = doc.getElementById("appiconsBtn");
  if (btn) btn.addEventListener("click", function () { if (window.adminPerms && !window.adminPerms.canNav("appicons")) return; open(); });
})();
