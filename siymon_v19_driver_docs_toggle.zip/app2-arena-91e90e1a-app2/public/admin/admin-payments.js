/* global api, lang, toast */
/* "Payment settings" page: payment-method registry + the shared wallet top-up policy.
 * The SERVER is the authority (payments.read / payments.manage / wallet.settings are enforced there);
 * this page only mirrors it: without payments.manage everything is read-only.
 * All values are inserted with textContent / .value (never innerHTML). Account numbers are shown only to the
 * authorised admin; the audit log stores them masked. */
(function () {
  "use strict";
  var doc = document;
  var L = window.adminPageElements.L, h = window.adminPageElements.h;
  var say = function (m) { try { toast(m); } catch (e) {} };
  var canManage = function () { return !window.adminPerms || window.adminPerms.can("payments.manage"); };
  var canPolicy = function () { return !window.adminPerms || window.adminPerms.can("wallet.settings"); };
  var KIND = { stripe: ["بطاقة بنكية (Stripe)", "Card (Stripe)", "Carte (Stripe)"], cod: ["دفع عند الاستلام", "Cash on delivery", "À la livraison"], tpe: ["TPE عند التسليم", "TPE on delivery", "TPE à la livraison"], transfer: ["تحويل يدوي", "Manual transfer", "Virement manuel"] };
  var CTX = {
    checkout: { t: ["الدفع عند الطلب", "Checkout", "Paiement commande"], d: ["يظهر عند إتمام الطلب (للطرق التي تدعم الطلبات فقط)", "Shown when placing an order (order-capable methods only)", "Affiché à la commande (méthodes compatibles)"] },
    customerTopup: { t: ["شحن محفظة الزبون", "Customer wallet top-up", "Recharge portefeuille client"], d: ["يختارها الزبون لشحن محفظته", "Customers can pick it to top up their wallet", "Les clients peuvent la choisir"] },
    driverTopup: { t: ["شحن محفظة السائق", "Driver wallet top-up", "Recharge portefeuille livreur"], d: ["يختارها السائق لشحن محفظته", "Drivers can pick it to top up their wallet", "Les livreurs peuvent la choisir"] },
  };
  var DET = [["holderName", "اسم صاحب الحساب", "Account holder", "Titulaire"], ["bankName", "اسم البنك / الخدمة", "Bank / service", "Banque / service"], ["rib", "RIB (24 رقماً)", "RIB (24 digits)", "RIB (24 chiffres)"], ["iban", "IBAN", "IBAN", "IBAN"], ["accountNumber", "رقم الحساب", "Account number", "N° de compte"], ["paymentIdentifier", "معرّف الدفع (هاتف / رمز)", "Payment identifier (phone / code)", "Identifiant de paiement"], ["branch", "الوكالة / الفرع", "Branch / agency", "Agence"], ["referenceFormat", "شكل مرجع التحويل", "Reference format", "Format de référence"]];
  var AUD = { "default": ["الحساب الافتراضي", "Default account", "Compte par défaut"], customer: ["خاص بالزبائن", "Customers only", "Clients"], driver: ["خاص بالسائقين", "Drivers only", "Livreurs"], order: ["خاص بدفع الطلبات", "Order payments only", "Paiement des commandes"] };
  var S = { methods: [], policy: null, policyEditable: false, stripeLabel: "غير متوفر حاليا", tab: "methods", root: null, err: null };

  function M(n) { return (Math.round((Number(n) || 0) * 100) / 100).toFixed(2); }
  function nm(rec) { return (rec.name && (rec.name[lang] || rec.name.ar)) || rec.id; }
  function ico(rec) {
    var box = h("span", { class: "pay-av" });
    if (rec.logo) { var im = h("img", { alt: "", loading: "lazy", referrerpolicy: "no-referrer" }); im.src = rec.logo; im.onerror = function () { im.remove(); box.textContent = initials(rec); }; box.appendChild(im); }
    else box.textContent = initials(rec);
    return box;
  }
  function initials(rec) { var s = String((rec.name && (rec.name.en || rec.name.fr)) || rec.id).replace(/[^A-Za-z0-9 ]/g, " ").trim().split(/\s+/); return ((s[0] || "?")[0] + ((s[1] || "")[0] || "")).toUpperCase(); }
  function accountOk(rec, aud) {
    var d = (rec.details && rec.details[aud]) || {}, base = (rec.details && rec.details["default"]) || {};
    var x = Object.assign({}, base, d);
    return !!(x.holderName && (x.rib || x.iban || x.accountNumber || x.paymentIdentifier));
  }
  function state(rec) {
    if (rec.kind === "stripe") return { c: "bad", t: S.stripeLabel };
    if (!rec.enabled) return { c: "", t: L("معطّلة", "Disabled", "Désactivée") };
    if (rec.kind === "transfer") {
      var need = ["checkout", "customerTopup", "driverTopup"].some(function (c) { return rec.contexts && rec.contexts[c] && !accountOk(rec, c === "customerTopup" ? "customer" : c === "driverTopup" ? "driver" : "order"); });
      if (need) return { c: "warn", t: L("تحتاج إعداد الحساب", "Needs account setup", "Compte à configurer") };
    }
    return { c: "ok", t: L("مفعّلة", "Enabled", "Activée") };
  }
  function quote(amount, m) {
    var p = S.policy || { feeFixed: 0, feePercent: 0 };
    var fx = m && m.feeFixed != null ? Number(m.feeFixed) : Number(p.feeFixed || 0);
    var pc = m && m.feePercent != null ? Number(m.feePercent) : Number(p.feePercent || 0);
    var fee = Math.min(amount, Math.max(0, fx) + amount * Math.max(0, pc) / 100);
    fee = Math.round(fee * 100) / 100;
    return { fee: fee, net: Math.round((amount - fee) * 100) / 100 };
  }
  function errText(e) {
    var c = e && e.body && e.body.code;
    var map = {
      ACCOUNT_REQUIRED: L("أدخل اسم صاحب الحساب ورقم RIB / حساب / معرّف قبل التفعيل", "Enter the account holder and an RIB / account / identifier before enabling", "Saisissez le titulaire et un RIB / compte / identifiant avant l'activation"),
      VERSION_CONFLICT: L("تم التعديل من مستخدم آخر، أعد التحميل", "Changed by someone else, reload", "Modifié par un autre utilisateur, rechargez"),
      BAD_RIB: L("RIB يجب أن يتكون من 24 رقماً", "RIB must be 24 digits", "Le RIB doit comporter 24 chiffres"),
      BAD_IBAN: L("صيغة IBAN غير صحيحة", "IBAN format is invalid", "Format IBAN invalide"),
      BAD_RANGE: L("الحد الأقصى يجب أن يكون ≥ الحد الأدنى", "Maximum must be ≥ minimum", "Le maximum doit être ≥ au minimum"),
      BAD_FEE: L("قيمة الرسوم غير صالحة", "Fee value is invalid", "Frais invalides"),
      BAD_IMAGE: L("رابط الصورة يجب أن يبدأ بـ /uploads/ أو https", "Image URL must start with /uploads/ or https", "L'URL doit commencer par /uploads/ ou https"),
      BAD_AMOUNT: L("مبلغ غير صالح", "Invalid amount", "Montant invalide"),
      OUT_OF_RANGE: L("قيمة خارج المجال المسموح", "Value out of range", "Valeur hors limites"),
      BAD_PRESETS: L("المبالغ الجاهزة يجب أن تقع بين الحدين", "Presets must be between min and max", "Les montants doivent être entre min et max"),
    };
    return "❌ " + (map[c] || (e && e.message) || "Error");
  }

  /* ---------- small form helpers ---------- */
  function sw(checked, onchange, label, disabled) {
    var i = h("input", { type: "checkbox" }); i.checked = !!checked; i.disabled = !!disabled;
    i.addEventListener("change", function () { onchange(i.checked, i); });
    return h("label", { class: "pay-sw" }, i, h("i", {}), label ? h("span", {}, label) : null);
  }
  // Image field: text link + "upload" button (external links are blocked by the site's CSP, so uploading is the reliable way).
  function imgField(label, get, set, ro) {
    var inp = tin(get, set, { ltr: true, max: 300, ro: ro });
    var prev = h("img", { alt: "", style: "max-height:64px;max-width:160px;border-radius:8px;background:#fff;display:none;margin-top:6px;object-fit:contain" });
    var msg = h("small", {}, "");
    function show() { var u = get(); if (u) { prev.src = u; prev.style.display = ""; } else prev.style.display = "none"; }
    prev.addEventListener("error", function () { prev.style.display = "none"; });
    function toDataUrl(file) {
      return new Promise(function (resolve, reject) {
        var fr = new FileReader();
        fr.onerror = function () { reject(new Error("read")); };
        fr.onload = function () {
          var raw = String(fr.result || "");
          var im = new Image();
          im.onerror = function () { resolve(raw); };
          im.onload = function () {
            try {
              var k = Math.min(1, 600 / Math.max(im.width || 1, im.height || 1)), c = doc.createElement("canvas");
              c.width = Math.max(1, Math.round((im.width || 1) * k)); c.height = Math.max(1, Math.round((im.height || 1) * k));
              c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
              resolve(c.toDataURL("image/png"));
            } catch (e) { resolve(raw); }
          };
          im.src = raw;
        };
        fr.readAsDataURL(file);
      });
    }
    var file = h("input", { type: "file", accept: "image/png,image/jpeg,image/webp,image/svg+xml", style: "display:none" });
    file.addEventListener("change", function () {
      var f = file.files && file.files[0]; if (!f) return;
      msg.textContent = L("جارٍ الرفع…", "Uploading…", "Envoi…");
      toDataUrl(f).then(function (d) { return api("/api/admin/upload/payment-image", { method: "POST", body: JSON.stringify({ image: d }) }); })
        .then(function (r) { set(r.url); inp.value = r.url; show(); msg.textContent = L("تم الرفع ✅ — اضغط حفظ", "Uploaded ✅ — press Save", "Envoyé ✅ — cliquez Enregistrer"); })
        .catch(function (e) { msg.textContent = "❌ " + ((e && e.message) || L("فشل الرفع", "Upload failed", "Échec")); })
        .then(function () { file.value = ""; });
    });
    var btn = h("button", { class: "pay-btn", type: "button", disabled: !!ro, onclick: function () { file.click(); } }, L("رفع صورة", "Upload image", "Téléverser"));
    var clear = h("button", { class: "pay-btn", type: "button", disabled: !!ro, onclick: function () { set(""); inp.value = ""; show(); } }, L("إزالة", "Remove", "Retirer"));
    inp.addEventListener("input", show); show();
    return h("div", { class: "pay-fl" }, h("span", {}, label), inp, h("div", { style: "display:flex;gap:8px;margin-top:6px;flex-wrap:wrap" }, btn, clear, file), prev, msg);
  }
  function fl(label, control, hint) { return h("label", { class: "pay-fl" }, h("span", {}, label), control, hint ? h("small", {}, hint) : null); }
  function tin(get, set, o) {
    o = o || {};
    var e = h(o.rows ? "textarea" : "input", { class: "pay-in", autocomplete: "off", placeholder: o.ph || "", maxlength: o.max || 200, dir: o.ltr ? "ltr" : null, rows: o.rows || null });
    if (!o.rows) e.type = o.type || "text";
    if (o.step) e.step = o.step; if (o.min != null) e.min = o.min;
    e.value = get() == null ? "" : get(); e.disabled = !!o.ro;
    e.addEventListener("input", function () { set(o.type === "number" ? (e.value === "" ? null : Number(e.value)) : e.value); });
    return e;
  }
  function tri(label, obj, o) {
    var wrap = h("div", { class: "pay-fl" }, h("span", {}, label));
    [["ar", "AR"], ["fr", "FR"], ["en", "EN"]].forEach(function (p) {
      wrap.appendChild(h("div", { class: "pay-lang" }, h("em", {}, p[1]), tin(function () { return obj[p[0]]; }, function (v) { obj[p[0]] = v; }, { rows: o && o.rows, max: o && o.max, ro: o && o.ro })));
    });
    return wrap;
  }
  function dialog(title, body, foot, small) {
    var ov = h("div", { class: "pay-ov", "data-payment-editor": "" });
    var dlg = h("div", { class: "pay-dlg" + (small ? " sm" : ""), role: "dialog", "aria-modal": "true" },
      h("div", { class: "pay-dlg-h" }, h("h3", {}, title), h("button", { class: "pay-x", type: "button", "aria-label": L("إغلاق", "Close", "Fermer"), onclick: function () { ov.remove(); } }, "✕")),
      h("div", { class: "pay-dlg-b" }, body), foot ? h("div", { class: "pay-dlg-f" }, foot) : null);
    ov.appendChild(dlg);
    ov.addEventListener("mousedown", function (e) { if (e.target === ov) ov.remove(); });
    doc.body.appendChild(ov);
    return ov;
  }

  /* ---------- method editor ---------- */
  function editor(rec) {
    var ro = !canManage();
    var st = JSON.parse(JSON.stringify(rec));
    st.name = st.name || { ar: "", fr: "", en: "" }; st.statusMessage = st.statusMessage || { ar: "", fr: "", en: "" };
    st.details = st.details || {}; st.contexts = st.contexts || {};
    var empty = function () { return { holderName: "", bankName: "", rib: "", iban: "", accountNumber: "", paymentIdentifier: "", branch: "", referenceFormat: "", instructions: { ar: "", fr: "", en: "" } }; };
    ["default", "customer", "driver", "order"].forEach(function (a) { if (a === "default" && !st.details[a]) st.details[a] = empty(); if (st.details[a]) st.details[a].instructions = st.details[a].instructions || { ar: "", fr: "", en: "" }; });
    var tab = "general", aud = "default", pvAud = "customer";
    var tabs = [["general", L("عام", "General", "Général")]];
    if (rec.kind === "transfer") tabs.push(["account", L("الحساب", "Account", "Compte")]);
    tabs.push(["rules", L("الظهور والحدود", "Visibility & limits", "Visibilité & limites")]);
    if (rec.kind === "transfer") tabs.push(["preview", L("معاينة", "Preview", "Aperçu")]);
    var body = h("div", {}), tabsEl = h("div", { class: "pay-tabs" }), saveBtn = null, ov;

    function render() {
      tabsEl.replaceChildren();
      tabs.forEach(function (t) { tabsEl.appendChild(h("button", { class: "pay-tab" + (tab === t[0] ? " on" : ""), type: "button", onclick: function () { tab = t[0]; render(); } }, t[1])); });
      body.replaceChildren();
      if (rec.kind === "stripe") body.appendChild(h("div", { class: "pay-note warn" }, "⚠ ", L("لا يوجد تكامل Stripe حقيقي في النظام: تبقى «غير متوفر حاليا» مهما فُعّلت حتى يُنجز تكامل مختبر.", "There is no real Stripe integration: it stays «unavailable» whatever you toggle until a tested integration exists.", "Aucune intégration Stripe réelle : la méthode reste indisponible.")));
      if (tab === "general") {
        body.appendChild(tri(L("الاسم المعروض", "Display name", "Nom affiché"), st.name, { max: 120, ro: ro }));
        body.appendChild(imgField(L("شعار البنك", "Bank logo", "Logo de la banque"), function () { return st.logo; }, function (v) { st.logo = v; }, ro));
        body.appendChild(h("div", { class: "pay-vis" }, h("div", {}, h("b", {}, L("تفعيل الطريقة", "Enable this method", "Activer la méthode")), h("small", {}, L("التعطيل يخفيها فوراً ولا يحذف أي سجل سابق", "Disabling hides it at once and never deletes past records", "La désactivation la masque sans supprimer l'historique"))), sw(st.enabled, function (v) { st.enabled = v; }, null, ro || rec.kind === "stripe")));
        body.appendChild(tri(L("رسالة حالة تظهر للمستخدم (اختياري)", "Status message shown to users (optional)", "Message de statut (optionnel)"), st.statusMessage, { max: 300, ro: ro }));
      } else if (tab === "account") {
        body.appendChild(h("div", { class: "pay-note" }, L("تحويل يدوي: لا يوجد ربط API مع البنك. لا يُضاف الرصيد إلا بعد أن يتحقق مشرف مخوّل من وصول المبلغ. أدخل بيانات حسابكم الحقيقية فقط.", "Manual transfer: no bank API. Balance is credited only after an authorised supervisor verifies the money arrived. Enter real account details only.", "Virement manuel : aucune API bancaire. Crédit uniquement après vérification d'un superviseur. Saisissez vos vraies coordonnées.")));
        var seg = h("div", { class: "pay-seg", role: "tablist" });
        ["default", "customer", "driver", "order"].forEach(function (a) { seg.appendChild(h("button", { type: "button", class: aud === a ? "on" : "", onclick: function () { aud = a; render(); } }, L.apply(null, AUD[a]))); });
        body.appendChild(seg);
        if (aud !== "default" && !st.details[aud]) {
          body.appendChild(h("p", { class: "pay-sub" }, L("لا يوجد حساب مخصص: يُستعمل الحساب الافتراضي. يمكنك إنشاء حساب مختلف لهذه الفئة.", "No dedicated account: the default one is used. You can create a different one for this audience.", "Aucun compte dédié : le compte par défaut est utilisé.")));
          if (!ro) body.appendChild(h("button", { class: "pay-btn", type: "button", onclick: function () { st.details[aud] = empty(); render(); } }, L("إنشاء حساب مخصص", "Create dedicated account", "Créer un compte dédié")));
        } else {
          var d = st.details[aud], g = h("div", { class: "pay-row2" });
          DET.forEach(function (f) { g.appendChild(fl(L(f[1], f[2], f[3]), tin(function () { return d[f[0]]; }, function (v) { d[f[0]] = v; }, { max: 120, ltr: f[0] !== "holderName" && f[0] !== "bankName", ro: ro }))); });
          body.appendChild(g);
          body.appendChild(tri(L("تعليمات التحويل", "Transfer instructions", "Instructions de virement"), d.instructions, { rows: 3, max: 1500, ro: ro }));
          if (aud !== "default" && !ro) body.appendChild(h("button", { class: "pay-btn danger", type: "button", onclick: function () { st.details[aud] = null; render(); } }, L("حذف الحساب المخصص (العودة للافتراضي)", "Remove dedicated account (use default)", "Supprimer le compte dédié")));
        }
        body.appendChild(imgField(L("صورة QR", "QR image", "Image QR"), function () { return st.qrImage; }, function (v) { st.qrImage = v; }, ro));
      } else if (tab === "rules") {
        body.appendChild(h("p", { class: "pay-sub", style: "margin-bottom:8px" }, L("أماكن ظهور الطريقة (إعداد مستقل لكل مكان)", "Where this method appears (independent per place)", "Où la méthode apparaît")));
        ["checkout", "customerTopup", "driverTopup"].forEach(function (c) {
          if ((rec.kind === "cod" || rec.kind === "tpe") && c !== "checkout") return;
          var forced = false;
          body.appendChild(h("div", { class: "pay-vis" }, h("div", {}, h("b", {}, L.apply(null, CTX[c].t)), h("small", {}, forced ? L("التحويل اليدوي غير متاح للطلبات حالياً", "Manual transfer is not available for orders yet", "Virement manuel indisponible pour les commandes") : L.apply(null, CTX[c].d))), sw(st.contexts[c], function (v) { st.contexts[c] = v; }, null, ro || forced)));
        });
        if (rec.kind === "transfer") {
          body.appendChild(h("div", { class: "pay-row3", style: "margin-top:12px" },
            fl(L("الحد الأدنى (MAD)", "Minimum (MAD)", "Minimum (MAD)"), tin(function () { return st.minAmount; }, function (v) { st.minAmount = v; }, { type: "number", min: 0, step: "any", ro: ro }), L("فارغ = سياسة المحفظة", "Empty = wallet policy", "Vide = politique")),
            fl(L("الحد الأقصى (MAD)", "Maximum (MAD)", "Maximum (MAD)"), tin(function () { return st.maxAmount; }, function (v) { st.maxAmount = v; }, { type: "number", min: 0, step: "any", ro: ro })),
            fl(L("ترتيب الظهور", "Display order", "Ordre"), tin(function () { return st.sortOrder; }, function (v) { st.sortOrder = v == null ? 0 : v; }, { type: "number", min: 0, step: "1", ro: ro }))));
          body.appendChild(h("div", { class: "pay-row2" },
            fl(L("رسوم ثابتة خاصة (MAD)", "Fixed fee override (MAD)", "Frais fixes (MAD)"), tin(function () { return st.feeFixed; }, function (v) { st.feeFixed = v; }, { type: "number", min: 0, step: "any", ro: ro }), L("فارغ = رسوم السياسة العامة (الافتراضي 0)", "Empty = shared policy fee (default 0)", "Vide = politique commune (0 par défaut)")),
            fl(L("رسوم نسبية خاصة (%)", "Percent fee override (%)", "Frais en % "), tin(function () { return st.feePercent; }, function (v) { st.feePercent = v; }, { type: "number", min: 0, step: "any", ro: ro }))));
          body.appendChild(h("div", { class: "pay-vis" }, h("div", {}, h("b", {}, L("صورة الوصل مطلوبة", "Receipt required", "Reçu obligatoire")), h("small", {}, L("التحقق من المشرف إلزامي دائماً في التحويلات اليدوية", "Supervisor verification is always required for manual transfers", "Vérification superviseur toujours requise"))), sw(st.requireReceipt, function (v) { st.requireReceipt = v; }, null, ro)));
        } else {
          body.appendChild(fl(L("ترتيب الظهور", "Display order", "Ordre"), tin(function () { return st.sortOrder; }, function (v) { st.sortOrder = v == null ? 0 : v; }, { type: "number", min: 0, step: "1", ro: ro })));
        }
      } else if (tab === "preview") {
        var seg2 = h("div", { class: "pay-seg" });
        ["customer", "driver"].forEach(function (a) { seg2.appendChild(h("button", { type: "button", class: pvAud === a ? "on" : "", onclick: function () { pvAud = a; render(); } }, a === "customer" ? L("كما يراها الزبون", "As a customer sees it", "Vue client") : L("كما يراها السائق", "As a driver sees it", "Vue livreur"))); });
        body.appendChild(seg2);
        var ctx = pvAud === "customer" ? "customerTopup" : "driverTopup";
        var base = st.details["default"] || empty(), over = st.details[pvAud] || {}, x = Object.assign({}, base, {});
        Object.keys(over).forEach(function (k) { if (k !== "instructions" && over[k]) x[k] = over[k]; });
        var ins = Object.assign({}, base.instructions); if (over.instructions) ["ar", "fr", "en"].forEach(function (l) { if (over.instructions[l]) ins[l] = over.instructions[l]; });
        var hidden = !st.contexts[ctx];
        var card = h("div", { class: "pay-pv" }, h("div", { class: "pay-card-h" }, ico(st), h("div", { class: "pay-card-t" }, h("b", {}, nm(st)), h("small", {}, x.bankName || ""))));
        if (hidden) card.appendChild(h("div", { class: "pay-note warn" }, L("هذه الطريقة غير ظاهرة لهذه الفئة حالياً.", "This method is currently hidden for this audience.", "Méthode masquée pour cette audience.")));
        var dl = h("dl", {});
        [["holderName", L("صاحب الحساب", "Holder", "Titulaire")], ["rib", "RIB"], ["iban", "IBAN"], ["accountNumber", L("رقم الحساب", "Account", "Compte")], ["paymentIdentifier", L("المعرّف", "Identifier", "Identifiant")]].forEach(function (p) { if (x[p[0]]) { dl.appendChild(h("dt", {}, p[1])); dl.appendChild(h("dd", {}, x[p[0]])); } });
        card.appendChild(dl);
        if (!accountOk(Object.assign({}, st, { details: { "default": base, customer: st.details.customer, driver: st.details.driver } }), pvAud)) card.appendChild(h("div", { class: "pay-note warn" }, L("بيانات الحساب ناقصة: لن تُفعَّل الطريقة.", "Account details are incomplete: the method cannot be enabled.", "Coordonnées incomplètes : activation impossible.")));
        if (ins[lang] || ins.ar) card.appendChild(h("p", { class: "pay-sub" }, ins[lang] || ins.ar));
        if (st.qrImage) { var q = h("img", { class: "qr", alt: "QR", referrerpolicy: "no-referrer" }); q.src = st.qrImage; q.onerror = function () { q.remove(); }; card.appendChild(q); }
        var qt = quote(100, st);
        card.appendChild(h("div", { class: "pay-calc" },
          h("div", {}, h("span", {}, L("مثال: مبلغ التحويل", "Example: transferred", "Exemple : virement")), h("b", {}, "100.00 MAD")),
          h("div", {}, h("span", {}, L("الرسوم", "Fee", "Frais")), h("b", {}, M(qt.fee) + " MAD")),
          h("div", { class: "net" }, h("span", {}, L("يُضاف إلى المحفظة", "Credited to wallet", "Crédité")), h("b", {}, M(qt.net) + " MAD")),
          h("div", {}, h("span", {}, L("الحدود", "Limits", "Limites")), h("b", {}, M(st.minAmount != null ? st.minAmount : (S.policy && S.policy.minTopup)) + " – " + M(st.maxAmount != null ? st.maxAmount : (S.policy && S.policy.maxTopup)))),
          h("div", {}, h("span", {}, L("الوصل", "Receipt", "Reçu")), h("b", {}, st.requireReceipt ? L("مطلوب", "Required", "Requis") : L("اختياري", "Optional", "Optionnel")))));
        body.appendChild(card);
      }
    }

    function payload() {
      var b = { expectedVersion: rec.version || 1, name: st.name, statusMessage: st.statusMessage, enabled: !!st.enabled, contexts: {}, sortOrder: Number(st.sortOrder) || 0, logo: st.logo || "" };
      ["checkout", "customerTopup", "driverTopup"].forEach(function (c) { if ((rec.kind === "cod" || rec.kind === "tpe") && c !== "checkout") return; b.contexts[c] = !!st.contexts[c]; });
      if (rec.kind === "transfer") {
        b.minAmount = st.minAmount == null || st.minAmount === "" ? null : Number(st.minAmount);
        b.maxAmount = st.maxAmount == null || st.maxAmount === "" ? null : Number(st.maxAmount);
        b.feeFixed = st.feeFixed == null || st.feeFixed === "" ? null : Number(st.feeFixed);
        b.feePercent = st.feePercent == null || st.feePercent === "" ? null : Number(st.feePercent);
        b.qrImage = st.qrImage || ""; b.requireReceipt = !!st.requireReceipt; b.details = {};
        ["default", "customer", "driver", "order"].forEach(function (a) {
          var d = st.details[a];
          if (!d) { if (a !== "default") b.details[a] = null; return; }
          var o = { instructions: d.instructions }, any = false;
          DET.forEach(function (f) { o[f[0]] = d[f[0]] || ""; if (o[f[0]]) any = true; });
          if (any || a === "default" || (o.instructions.ar || o.instructions.fr || o.instructions.en)) b.details[a] = o; else if (a !== "default") b.details[a] = null;
        });
      }
      return b;
    }

    var foot = [h("button", { class: "pay-btn", type: "button", onclick: function () { ov.remove(); } }, ro ? L("إغلاق", "Close", "Fermer") : L("إلغاء", "Cancel", "Annuler"))];
    if (!ro) {
      saveBtn = h("button", { class: "pay-btn primary", type: "button", onclick: function () {
        if (rec.enabled && !st.enabled && !confirm(L("تعطيل هذه الطريقة سيخفيها عن المستخدمين فوراً. تأكيد؟ (السجلات السابقة تبقى محفوظة)", "Disabling hides this method from users immediately. Confirm? (Past records are kept.)", "La désactiver la masque immédiatement. Confirmer ?"))) return;
        saveBtn.disabled = true;
        api("/api/admin/payment-methods/" + encodeURIComponent(rec.id), { method: "PUT", body: JSON.stringify(payload()) })
          .then(function () { say("✅ " + L("تم الحفظ", "Saved", "Enregistré")); ov.remove(); load(); })
          .catch(function (e) { saveBtn.disabled = false; say(errText(e)); });
      } }, L("حفظ التغييرات", "Save changes", "Enregistrer"));
      foot.push(saveBtn);
    }
    var wrap = h("div", {}, tabsEl, body);
    ov = dialog(nm(rec), wrap, foot);
    render();
  }

  /* ---------- page ---------- */
  function quickToggle(m, v, inp) {
    api("/api/admin/payment-methods/" + encodeURIComponent(m.id), { method: "PUT", body: JSON.stringify({ enabled: v, expectedVersion: m.version || 1 }) })
      .then(function () { say("✅"); load(); })
      .catch(function (e) { inp.checked = !v; say(errText(e)); });
  }
  function card(m) {
    var s = state(m), ro = !canManage();
    var ctxChips = h("div", { class: "pay-chips" });
    ["checkout", "customerTopup", "driverTopup"].forEach(function (c) {
      if ((m.kind === "cod" || m.kind === "tpe") && c !== "checkout") return;
      var on = !!(m.contexts && m.contexts[c]);
      ctxChips.appendChild(h("span", { class: "pay-chip" + (on ? " ok" : " dim") }, L.apply(null, CTX[c].t)));
    });
    var lim = m.kind === "transfer" ? (m.minAmount != null || m.maxAmount != null ? M(m.minAmount != null ? m.minAmount : (S.policy ? S.policy.minTopup : 0)) + " – " + M(m.maxAmount != null ? m.maxAmount : (S.policy ? S.policy.maxTopup : 0)) : L("حسب السياسة العامة", "Shared policy", "Politique commune")) : "—";
    var fee = m.feeFixed != null || m.feePercent != null ? M(m.feeFixed || 0) + " + " + (m.feePercent || 0) + "%" : L("حسب السياسة العامة", "Shared policy", "Politique commune");
    var meta = m.kind === "transfer" ? h("div", { class: "pay-meta" },
      h("div", {}, L("الحدود", "Limits", "Limites"), h("b", {}, lim)), h("div", {}, L("الرسوم", "Fees", "Frais"), h("b", {}, fee)),
      h("div", {}, L("الوصل", "Receipt", "Reçu"), h("b", {}, m.requireReceipt ? L("مطلوب", "Required", "Requis") : L("اختياري", "Optional", "Optionnel"))),
      h("div", {}, L("الترتيب", "Order", "Ordre"), h("b", {}, String(m.sortOrder)))) : null;
    return h("div", { class: "pay-card" + (m.enabled ? "" : " off"), "data-method": m.id },
      h("div", { class: "pay-card-h" }, ico(m), h("div", { class: "pay-card-t" }, h("b", {}, nm(m)), h("small", {}, L.apply(null, KIND[m.kind] || [m.kind, m.kind, m.kind]))), h("span", { class: "pay-chip " + s.c }, s.t)),
      ctxChips, meta,
      h("div", { class: "pay-card-f" },
        sw(m.enabled, function (v, inp) { quickToggle(m, v, inp); }, L("مفعّلة", "Enabled", "Activée"), ro || m.kind === "stripe"),
        h("button", { class: "pay-btn", type: "button", onclick: function () { editor(m); } }, ro ? L("عرض", "View", "Voir") : L("تعديل", "Edit", "Modifier"))),
      m.updatedAt ? h("div", { class: "pay-upd" }, L("آخر تعديل: ", "Last update: ", "Dernière modif. : "), new Date(m.updatedAt).toLocaleString(), " · v" + (m.version || 1)) : null);
  }
  function stats() {
    var ms = S.methods, on = ms.filter(function (m) { return m.enabled && m.kind !== "stripe"; }).length;
    var c = ms.filter(function (m) { return m.enabled && m.kind === "transfer" && m.contexts && m.contexts.customerTopup; }).length;
    var d = ms.filter(function (m) { return m.enabled && m.kind === "transfer" && m.contexts && m.contexts.driverTopup; }).length;
    var need = ms.filter(function (m) { return state(m).c === "warn"; }).length;
    var mk = function (n, t, k) { return h("div", { class: "pay-stat " + (k || "") }, h("b", {}, String(n)), h("span", {}, t)); };
    return h("div", { class: "pay-stats" }, mk(on, L("طرق مفعّلة", "Active methods", "Méthodes actives"), "good"), mk(c, L("متاحة لشحن الزبائن", "For customer top-ups", "Recharge clients")), mk(d, L("متاحة لشحن السائقين", "For driver top-ups", "Recharge livreurs")), mk(need, L("تحتاج إعداد", "Need setup", "À configurer"), need ? "warn" : ""));
  }

  function policyPanel() {
    var P = S.policy;
    if (!P) return h("div", { class: "pay-panel" }, h("p", { class: "pay-sub" }, S.err || L("تعذر تحميل سياسة الشحن", "Could not load the top-up policy", "Politique indisponible")));
    var ro = !canPolicy();
    var st = { enabled: P.enabled, minTopup: P.minTopup, maxTopup: P.maxTopup, feePercent: P.feePercent, feeFixed: P.feeFixed, presets: (P.presets || []).join(", ") };
    var calc = h("div", { class: "pay-calc" });
    var amountIn = h("input", { class: "pay-in", type: "number", min: "1", step: "any", value: "100", style: "margin-bottom:8px" });
    function recalc() {
      var a = Number(amountIn.value) || 0, fx = Number(st.feeFixed) || 0, pc = Number(st.feePercent) || 0;
      var fee = Math.round(Math.min(a, fx + a * pc / 100) * 100) / 100;
      calc.replaceChildren(
        h("div", {}, h("span", {}, L("مبلغ التحويل", "Transferred", "Viré")), h("b", {}, M(a) + " MAD")),
        h("div", {}, h("span", {}, L("الرسوم", "Fee", "Frais")), h("b", {}, M(fee) + " MAD")),
        h("div", { class: "net" }, h("span", {}, L("المبلغ المضاف", "Credited", "Crédité")), h("b", {}, M(a - fee) + " MAD")));
    }
    amountIn.addEventListener("input", recalc);
    var bind = function (k) { return function (v) { st[k] = v; recalc(); }; };
    var save = h("button", { class: "pay-btn primary", type: "button", onclick: function () {
      var presets = String(st.presets).split(/[,\s،]+/).filter(Boolean).map(Number);
      save.disabled = true;
      api("/api/admin/wallet/settings", { method: "PUT", body: JSON.stringify({ expectedVersion: P.version, enabled: !!st.enabled, minTopup: Number(st.minTopup), maxTopup: Number(st.maxTopup), feePercent: Number(st.feePercent) || 0, feeFixed: Number(st.feeFixed) || 0, presets: presets }) })
        .then(function () { say("✅ " + L("تم الحفظ", "Saved", "Enregistré")); load(); })
        .catch(function (e) { save.disabled = false; say(errText(e)); });
    } }, L("حفظ السياسة", "Save policy", "Enregistrer"));
    recalc();
    return h("div", { class: "pay-pol" },
      h("div", { class: "pay-panel" },
        h("div", { class: "pay-note" }, L("قاعدة واحدة للزبائن والسائقين. الرسوم الافتراضية صفر ولا تُفرض أي رسوم ما لم تحددها هنا (أو في طريقة بعينها).", "One rule set for customers and drivers. Fees default to zero and none apply unless you set them here (or per method).", "Une seule règle pour clients et livreurs. Frais à 0 par défaut.")),
        h("div", { class: "pay-vis" }, h("div", {}, h("b", {}, L("تفعيل الشحن", "Top-ups enabled", "Recharges activées")), h("small", {}, L("عند التعطيل يرفض الخادم كل طلبات الشحن الجديدة", "When off, the server refuses all new top-up requests", "Désactivé : toute nouvelle demande est refusée"))), sw(st.enabled, function (v) { st.enabled = v; }, null, ro)),
        h("div", { class: "pay-row2" },
          fl(L("الحد الأدنى (MAD)", "Minimum (MAD)", "Minimum"), tin(function () { return st.minTopup; }, bind("minTopup"), { type: "number", min: 1, step: "any", ro: ro })),
          fl(L("الحد الأقصى (MAD)", "Maximum (MAD)", "Maximum"), tin(function () { return st.maxTopup; }, bind("maxTopup"), { type: "number", min: 1, step: "any", ro: ro })),
          fl(L("رسوم ثابتة (MAD)", "Fixed fee (MAD)", "Frais fixes"), tin(function () { return st.feeFixed; }, bind("feeFixed"), { type: "number", min: 0, step: "any", ro: ro })),
          fl(L("رسوم نسبية (%)", "Percent fee (%)", "Frais (%)"), tin(function () { return st.feePercent; }, bind("feePercent"), { type: "number", min: 0, step: "any", ro: ro }))),
        fl(L("المبالغ الجاهزة (مفصولة بفواصل)", "Quick amounts (comma separated)", "Montants rapides"), tin(function () { return st.presets; }, function (v) { st.presets = v; }, { ltr: true, ro: ro })),
        ro ? h("span", { class: "pay-ro" }, "🔒 ", L("للقراءة فقط", "Read-only", "Lecture seule")) : save),
      h("div", { class: "pay-panel" }, h("b", {}, L("حاسبة المعاينة", "Preview calculator", "Calculateur")), h("div", { style: "height:8px" }), amountIn, calc));
  }

  function paint() {
    var root = S.root; if (!root) return;
    root.replaceChildren();
    root.appendChild(h("div", { class: "pay-top" },
      h("div", {}, h("h2", {}, L("إعدادات الدفع والشحن", "Payment & top-up settings", "Paiements et recharges")), h("p", { class: "pay-sub" }, L("سجل واحد لطرق الدفع يستعمله الزبون والسائق، مع بقاء المحفظتين والسجلين منفصلين تماماً. كل تعديل يُسجَّل في سجل التدقيق (أرقام الحسابات مخفية جزئياً).", "One registry of payment methods for customers and drivers; wallets and ledgers stay fully separate. Every change is audited (account numbers masked).", "Un seul registre pour clients et livreurs ; portefeuilles et registres séparés. Chaque modification est auditée."))),
      h("div", { class: "pay-chips" }, !canManage() ? h("span", { class: "pay-ro" }, "🔒 ", L("للقراءة فقط", "Read-only", "Lecture seule")) : null, h("button", { class: "pay-x", type: "button", "aria-label": L("إغلاق", "Close", "Fermer"), onclick: function () { showPayments(false); } }, "✕"))));
    root.appendChild(stats());
    var tabs = h("div", { class: "pay-tabs" });
    [["methods", L("طرق الدفع", "Payment methods", "Moyens de paiement")], ["policy", L("سياسة الشحن والرسوم", "Top-up policy & fees", "Politique & frais")]].forEach(function (t) {
      tabs.appendChild(h("button", { class: "pay-tab" + (S.tab === t[0] ? " on" : ""), type: "button", onclick: function () { S.tab = t[0]; paint(); } }, t[1]));
    });
    root.appendChild(tabs);
    if (S.tab === "methods") { var g = h("div", { class: "pay-grid" }); S.methods.forEach(function (m) { g.appendChild(card(m)); }); root.appendChild(g); }
    else root.appendChild(policyPanel());
  }

  function load() {
    var p1 = api("/api/admin/payment-methods").then(function (r) { S.methods = r.methods || []; S.stripeLabel = r.stripeUnavailableLabel || S.stripeLabel; });
    var p2 = api("/api/admin/wallet/settings").then(function (r) { S.policy = r.policy; S.err = null; }).catch(function (e) { S.policy = null; S.err = "❌ " + (e && e.message || "Error"); });
    Promise.all([p1, p2]).then(paint).catch(function (e) { if (S.root) { S.root.replaceChildren(h("p", { class: "pay-sub" }, "❌ " + (e && e.message || "Error"))); } });
  }

  function showPayments(show) {
    var m = doc.getElementById("paymentsModal"); m.classList.toggle("show", !!show);
    if (!show) { m.replaceChildren(); S.root = null; doc.querySelectorAll("[data-payment-editor]").forEach(function (e) { e.remove(); }); }
  }
  window.showPayments = showPayments;

  function open() {
    var ov = doc.getElementById("paymentsModal");
    S.root = h("div", { class: "pay-page", role: "region" }, h("p", { class: "pay-sub" }, "…"));
    ov.replaceChildren(S.root);
    showPayments(true);
    ov.replaceChildren(S.root);
    load();
  }

  // The shared hash router clicks the original source button after checking the role.
  doc.getElementById("paymentsBtn").addEventListener("click", function () {
    if (window.adminPerms && !window.adminPerms.canNav("payments")) return;
    open();
  });
})();
