/* siymon — paying an ORDER by manual transfer (customer side).
 * Shared by the checkout (/) and "My orders" (/orders/):
 *   - account card: receiving account, amount to transfer, instructions (data comes from the SERVER);
 *   - proof form: transfer reference + receipt image (compressed in the browser);
 *   - submitProof(): POST /api/customer/orders/:id/payment-proof.
 * Uploading a proof NEVER means "paid": the order stays PAYMENT_PENDING until a supervisor verifies the money.
 * Every server/user value is inserted with textContent (never innerHTML). */
(function () {
  "use strict";
  var LANG_KEY = "siymon_lang_v1";
  function lang() { try { var l = localStorage.getItem(LANG_KEY); return ["ar", "fr", "en"].indexOf(l) >= 0 ? l : "ar"; } catch (e) { return "ar"; } }
  function T(ar, fr, en) { var l = lang(); return l === "fr" ? fr : l === "en" ? en : ar; }
  function money(n) { return (Math.round((Number(n) || 0) * 100) / 100).toFixed(2); }

  var CSS = ".tp-box{border:1px solid var(--border,rgba(0,0,0,.12));border-radius:14px;padding:12px;margin-top:10px;background:var(--card,#fff);color:var(--text,#111);font-size:14px;line-height:1.7}" +
    ".tp-box h4{margin:0 0 8px;font-size:14px}" +
    ".tp-amount{display:flex;justify-content:space-between;gap:10px;align-items:center;background:rgba(93,214,44,.12);border-radius:10px;padding:10px 12px;margin-bottom:8px;font-weight:700}" +
    ".tp-amount b{direction:ltr;font-size:17px}" +
    ".tp-dl{display:grid;grid-template-columns:auto 1fr auto;gap:6px 10px;margin:0 0 8px;align-items:center}" +
    ".tp-dl dt{color:var(--muted,#666);font-size:12px}.tp-dl dd{margin:0;word-break:break-all;direction:ltr;text-align:start;font-weight:600}" +
    ".tp-copy{border:1px solid var(--border,rgba(0,0,0,.14));background:transparent;color:inherit;border-radius:8px;min-height:32px;min-width:44px;font-size:12px;cursor:pointer}" +
    ".tp-qr{display:block;margin:8px auto;max-width:180px;width:60%;border-radius:10px;background:#fff;padding:6px}" +
    ".tp-note{font-size:12px;color:var(--muted,#666);margin:6px 0}" +
    ".tp-warn{font-size:12px;border-radius:10px;padding:8px 10px;background:rgba(255,170,0,.14);margin:6px 0}" +
    ".tp-f{display:grid;gap:6px;margin-top:8px}.tp-f label{font-size:12px;color:var(--muted,#666)}" +
    ".tp-f input[type=text]{width:100%;min-height:46px;border-radius:12px;border:1px solid var(--border,rgba(0,0,0,.14));padding:0 12px;background:var(--card,#fff);color:inherit;font-size:16px;direction:ltr}" +
    ".tp-f input[type=file]{width:100%;font-size:14px}" +
    ".tp-prev{max-width:140px;max-height:140px;border-radius:10px;border:1px solid var(--border,rgba(0,0,0,.14))}" +
    ".tp-err{color:#d64545;font-size:13px;min-height:1em}" +
    ".tp-st{display:inline-block;border-radius:999px;padding:3px 10px;font-size:12px;font-weight:700}" +
    ".tp-st.UNPAID{background:rgba(255,170,0,.18)}.tp-st.PAYMENT_PENDING{background:rgba(60,140,255,.18)}.tp-st.PAYMENT_APPROVED{background:rgba(93,214,44,.22)}.tp-st.PAYMENT_REJECTED{background:rgba(214,69,69,.2)}" +
    ".tp-btn{min-height:46px;border-radius:12px;border:0;padding:0 16px;font-weight:700;font-size:15px;cursor:pointer;background:var(--brand,#5DD62C);color:#0F0F0F}.tp-btn[disabled]{opacity:.55}";
  function ensureCss() {
    if (document.getElementById("tpCss")) return;
    var st = document.createElement("style"); st.id = "tpCss"; st.textContent = CSS; document.head.appendChild(st);
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

  var STATUS = {
    UNPAID: function () { return T("بانتظار إثبات التحويل", "En attente de la preuve de virement", "Waiting for transfer proof"); },
    PAYMENT_PENDING: function () { return T("قيد المراجعة — لم يُعتبر مدفوعاً بعد", "En cours de vérification — pas encore payé", "Under review — not paid yet"); },
    PAYMENT_APPROVED: function () { return T("تم تأكيد الدفع", "Paiement confirmé", "Payment confirmed"); },
    PAYMENT_REJECTED: function () { return T("تعذّر تأكيد التحويل", "Virement non confirmé", "Transfer not confirmed"); }
  };
  function statusLabel(s) { return (STATUS[s] || STATUS.UNPAID)(); }

  var ERR = {
    REFERENCE_REQUIRED: function () { return T("أدخل مرجع التحويل (4 أحرف/أرقام على الأقل)", "Saisissez la référence du virement (4 caractères min.)", "Enter the transfer reference (at least 4 characters)"); },
    RECEIPT_REQUIRED: function () { return T("أرفق صورة الوصل", "Joignez la photo du reçu", "Attach the receipt image"); },
    DUPLICATE_REFERENCE: function () { return T("هذا المرجع استُعمل من قبل", "Cette référence a déjà été utilisée", "This reference was already used"); },
    DUPLICATE_RECEIPT: function () { return T("هذه الصورة استُعملت من قبل", "Cette image a déjà été utilisée", "This image was already used"); },
    ALREADY_PENDING: function () { return T("لديك إثبات قيد المراجعة", "Une preuve est déjà en cours de vérification", "A proof is already under review"); },
    ALREADY_APPROVED: function () { return T("تم تأكيد الدفع مسبقاً", "Paiement déjà confirmé", "Payment already confirmed"); },
    TOO_MANY_ATTEMPTS: function () { return T("تجاوزت عدد المحاولات، تواصل مع الدعم", "Trop de tentatives, contactez le support", "Too many attempts, contact support"); },
    INVALID_RECEIPT: function () { return T("صورة غير صالحة (JPG/PNG/WebP)", "Image invalide (JPG/PNG/WebP)", "Invalid image (JPG/PNG/WebP)"); },
    ORDER_CLOSED: function () { return T("الطلب مغلق", "Commande clôturée", "Order is closed"); },
    BUSY: function () { return T("الخادم مشغول، أعد المحاولة", "Serveur occupé, réessayez", "Server busy, try again"); }
  };
  function errorText(code, fallback) { return ERR[code] ? ERR[code]() : (fallback || T("تعذّر إرسال الإثبات", "Envoi impossible", "Could not send the proof")); }

  /* shrink the photo before upload (phones send 4-8 MB pictures); output JPEG <= ~1400px */
  function compress(file) {
    return new Promise(function (resolve, reject) {
      if (!file) return reject(new Error("INVALID_RECEIPT"));
      if (!/^image\/(jpeg|png|webp)$/i.test(file.type)) return reject(new Error("INVALID_RECEIPT"));
      var fr = new FileReader();
      fr.onerror = function () { reject(new Error("INVALID_RECEIPT")); };
      fr.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error("INVALID_RECEIPT")); };
        img.onload = function () {
          try {
            var max = 1400, w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, max / Math.max(w, h));
            var c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
            var ctx = c.getContext("2d"); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height);
            var out = c.toDataURL("image/jpeg", 0.82);
            if (out.length > 4000000) return reject(new Error("INVALID_RECEIPT"));
            resolve(out);
          } catch (e) { reject(new Error("INVALID_RECEIPT")); }
        };
        img.src = String(fr.result);
      };
      fr.readAsDataURL(file);
    });
  }

  function copyText(value) {
    var v = String(value);
    function legacy() {
      try {
        var ta = document.createElement("textarea");
        ta.value = v; ta.setAttribute("readonly", ""); ta.style.cssText = "position:fixed;top:0;left:0;opacity:0";
        document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, v.length);
        var ok = document.execCommand("copy"); ta.remove(); return !!ok;
      } catch (e) { return false; }
    }
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(v).then(function () { return true; }, function () { return legacy(); });
    return Promise.resolve(legacy());
  }

  function copyBtn(value) {
    var label = T("نسخ", "Copier", "Copy");
    var b = el("button", "tp-copy", label); b.type = "button";
    b.addEventListener("click", function () {
      var raw = String(value).replace(/\s+/g, ""); // digits only: pastes cleanly into a banking app
      copyText(raw).then(function (ok) {
        if (!ok) { window.prompt(label, raw); return; }
        b.textContent = "✓"; setTimeout(function () { b.textContent = label; }, 1400);
      });
    });
    return b;
  }

  /* receiving account + amount + instructions. method = the public view of the method (with .account for a signed-in customer) */
  function accountCard(method, amount, currency) {
    ensureCss();
    var box = el("div", "tp-box");
    box.appendChild(el("h4", null, T("حوّل المبلغ إلى هذا الحساب", "Virez le montant sur ce compte", "Transfer the amount to this account")));
    var am = el("div", "tp-amount"); am.appendChild(el("span", null, T("المبلغ المطلوب تحويله", "Montant à virer", "Amount to transfer"))); am.appendChild(el("b", null, money(amount) + " " + (currency || "MAD"))); box.appendChild(am);
    var a = method && method.account;
    if (!a) { box.appendChild(el("div", "tp-warn", T("بيانات الحساب غير متاحة الآن.", "Coordonnées indisponibles.", "Account details are not available right now."))); return box; }
    var dl = el("dl", "tp-dl");
    [[T("المستفيد", "Bénéficiaire", "Beneficiary"), a.holderName], [T("البنك / الخدمة", "Banque / service", "Bank / service"), a.bankName], ["RIB", a.rib], ["IBAN", a.iban], [T("رقم الحساب", "N° de compte", "Account no."), a.accountNumber], [T("المعرّف", "Identifiant", "Identifier"), a.paymentIdentifier], [T("الوكالة", "Agence", "Branch"), a.branch]].forEach(function (r) {
      if (!r[1]) return;
      dl.appendChild(el("dt", null, r[0])); dl.appendChild(el("dd", null, r[1]));
      if (r[0] === "RIB" || r[0] === "IBAN" || r[0] === T("رقم الحساب", "N° de compte", "Account no.") || r[0] === T("المعرّف", "Identifiant", "Identifier")) dl.appendChild(copyBtn(r[1])); else dl.appendChild(el("span"));
    });
    box.appendChild(dl);
    if (method.qrImage && /^(\/uploads\/|https:\/\/)/.test(method.qrImage)) { var q = el("img", "tp-qr"); q.alt = "QR"; q.referrerPolicy = "no-referrer"; q.src = method.qrImage; q.onerror = function () { q.remove(); }; box.appendChild(q); }
    var l = lang(), ins = a.instructions && (a.instructions[l] || a.instructions.ar);
    if (ins) box.appendChild(el("p", "tp-note", ins));
    if (a.referenceFormat) box.appendChild(el("p", "tp-note", T("شكل المرجع: ", "Format de référence : ", "Reference format: ") + a.referenceFormat));
    box.appendChild(el("p", "tp-note", T("المبلغ شامل رسوم التوصيل. لن يُعتبر طلبك مدفوعاً إلا بعد أن يتحقق المشرف من وصول المبلغ.", "Le montant inclut les frais de livraison. Votre commande n'est payée qu'après vérification du virement.", "The amount includes delivery. Your order only counts as paid after a supervisor verifies the transfer.")));
    return box;
  }

  /* reference + receipt inputs. Returns {el, values(), validate(), clear()} */
  function proofForm(opts) {
    ensureCss();
    opts = opts || {};
    var needReceipt = opts.requireReceipt !== false;
    var box = el("div", "tp-f");
    var l1 = el("label", null, T("مرجع التحويل", "Référence du virement", "Transfer reference")); l1.setAttribute("for", "tpRef" + (opts.idSuffix || ""));
    var ref = el("input"); ref.type = "text"; ref.id = "tpRef" + (opts.idSuffix || ""); ref.maxLength = 60; ref.autocomplete = "off"; ref.inputMode = "text"; ref.setAttribute("autocapitalize", "characters");
    var l2 = el("label", null, T("صورة الوصل", "Photo du reçu", "Receipt image") + (needReceipt ? " *" : "")); l2.setAttribute("for", "tpFile" + (opts.idSuffix || ""));
    var file = el("input"); file.type = "file"; file.accept = "image/jpeg,image/png,image/webp"; file.id = "tpFile" + (opts.idSuffix || "");
    var prev = el("img", "tp-prev"); prev.alt = ""; prev.hidden = true;
    var err = el("div", "tp-err"); err.setAttribute("role", "alert");
    var receipt = null;
    file.addEventListener("change", function () {
      receipt = null; prev.hidden = true; err.textContent = "";
      var f = file.files && file.files[0]; if (!f) return;
      compress(f).then(function (d) { receipt = d; prev.src = d; prev.hidden = false; }).catch(function () { file.value = ""; err.textContent = errorText("INVALID_RECEIPT"); });
    });
    [l1, ref, l2, file, prev, err].forEach(function (n) { box.appendChild(n); });
    return {
      el: box,
      values: function () { return { reference: ref.value.trim(), receipt: receipt }; },
      validate: function () {
        var v = this.values(); err.textContent = "";
        if (v.reference.replace(/[^A-Za-z0-9]/g, "").length < 4) { err.textContent = errorText("REFERENCE_REQUIRED"); ref.focus(); return false; }
        if (needReceipt && !v.receipt) { err.textContent = errorText("RECEIPT_REQUIRED"); return false; }
        return true;
      },
      showError: function (m) { err.textContent = m || ""; },
      clear: function () { ref.value = ""; file.value = ""; receipt = null; prev.hidden = true; err.textContent = ""; }
    };
  }

  /* POST the proof. Resolves {ok, data, code}. The customer token is read by the caller. */
  function submitProof(orderId, values, token) {
    return fetch("/api/customer/orders/" + encodeURIComponent(orderId) + "/payment-proof", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ reference: values.reference, receipt: values.receipt || undefined })
    }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { return { ok: r.ok && d && d.ok, data: d, code: d && d.code }; }); })
      .catch(function () { return { ok: false, data: {}, code: "NETWORK" }; });
  }

  function statusBadge(status) { var b = el("span", "tp-st " + status, statusLabel(status)); return b; }

  window.SiymonTransferPay = { accountCard: accountCard, proofForm: proofForm, submitProof: submitProof, statusLabel: statusLabel, statusBadge: statusBadge, errorText: errorText, compress: compress, ensureCss: ensureCss };
})();
