/* Siymon image helper — every image a store or an admin uploads is converted to WebP in the browser first.
 *   SiymonImg.toWebpDataUrl(file, { max: 1600, quality: 0.82 }) -> Promise<"data:image/webp;base64,...">
 * - resized so the longest side is <= max (phone photos are 4000px+), transparency is kept;
 * - a browser that cannot encode WebP (very old Safari / WebViews) falls back to JPEG, never to an unreadable file;
 * - if the image cannot be decoded at all the ORIGINAL file is sent untouched, so an upload never breaks because of this.
 * The server accepts JPG/PNG/WebP by file signature, so no server change is needed. */
(function () {
  "use strict";
  var DEFAULT_MAX = 1600;
  var DEFAULT_QUALITY = 0.82;

  function readAsDataUrl(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result || "")); };
      r.onerror = function () { reject(new Error("File read error")); };
      r.readAsDataURL(file);
    });
  }

  function decode(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("bad image")); };
      img.src = url;
    });
  }

  function draw(img, max, background) {
    var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
    if (!w || !h) throw new Error("bad image");
    var k = Math.min(1, max / Math.max(w, h));
    var cv = document.createElement("canvas");
    cv.width = Math.max(1, Math.round(w * k));
    cv.height = Math.max(1, Math.round(h * k));
    var g = cv.getContext("2d");
    if (background) { g.fillStyle = background; g.fillRect(0, 0, cv.width, cv.height); }
    g.drawImage(img, 0, 0, cv.width, cv.height);
    return cv;
  }

  function toWebpDataUrl(file, opts) {
    opts = opts || {};
    var max = opts.max || DEFAULT_MAX, q = opts.quality || DEFAULT_QUALITY;
    if (!file) return Promise.resolve("");
    return decode(file).then(function (img) {
      var out = draw(img, max, null).toDataURL("image/webp", q);
      if (/^data:image\/webp/i.test(out)) return out;                         // the normal case
      return draw(img, max, "#fff").toDataURL("image/jpeg", Math.max(q, 0.85)); // WebP encoding unsupported -> JPEG
    }).catch(function () {
      return readAsDataUrl(file);                                              // undecodable: send the original as before
    });
  }

  window.SiymonImg = { toWebpDataUrl: toWebpDataUrl };
})();
