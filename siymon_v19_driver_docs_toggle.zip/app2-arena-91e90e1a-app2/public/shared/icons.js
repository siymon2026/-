/* SIYMON — thin-line icon engine (replaces every emoji in the UI).
   Same style as the bottom-nav icons: 24px grid, 1.7 stroke, round caps, currentColor.
   - Any emoji / pictograph that reaches the DOM (static HTML, template strings, textContent, chat messages…) is swapped for a line icon.
   - The original character stays inside a visually-hidden span, so textContent / copy / comparisons keep working.
   - Emoji that cannot hold an icon (placeholder / title / alt / aria-label / <option> / <title> / alert() / confirm()) are removed.
   Public API: window.SiymonIcons = { svg(name), html(name, cls), el(name, cls), scan(root), strip(text), has(name) } */
(function () {
  "use strict";
  if (window.SiymonIcons) return;

  var FACE = '<circle cx="12" cy="12" r="9"/><path d="M9 10h.01M15 10h.01" stroke-width="2.4"/>';
  var P = {
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    "check-circle": '<circle cx="12" cy="12" r="9"/><path d="M8 12.3l2.8 2.8 5.4-5.6"/>',
    "x-circle": '<circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>',
    alert: '<path d="M12 4 2.8 19.5h18.4L12 4Z"/><path d="M12 10v4.5M12 17.3h.01"/>',
    ban: '<circle cx="12" cy="12" r="9"/><path d="M5.7 5.7l12.6 12.6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8h.01"/>',
    pin: '<path d="M12 21s6.5-5.6 6.5-11a6.5 6.5 0 1 0-13 0c0 5.4 6.5 11 6.5 11Z"/><circle cx="12" cy="10" r="2.3"/>',
    scooter: '<circle cx="5.5" cy="17" r="2.5"/><circle cx="18.5" cy="17" r="2.5"/><path d="M8 17h7.5l1-8.5M14 6h3.2M4 11.5h5.5l1.5 5.5"/>',
    store: '<path d="M4 9.5 5.6 4.5h12.8L20 9.5a2.5 2.5 0 0 1-4 2 2.5 2.5 0 0 1-4 0 2.5 2.5 0 0 1-4 0 2.5 2.5 0 0 1-4-2Z"/><path d="M5.5 12.8V20h13v-7.2"/>',
    bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15L6 16Z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
    "bell-off": '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15L6 16Z"/><path d="M10 20.5a2 2 0 0 0 4 0M4 4l16 16"/>',
    gift: '<path d="M4 10h16v4H4zM6 14v6h12v-6M12 10v10"/><path d="M12 10C10 10 8 9 8 7.5S10.5 5 12 8c1.5-3 4-2.5 4-.5S14 10 12 10Z"/>',
    utensils: '<path d="M7 3v7M5 3v4.5a2 2 0 0 0 4 0V3M7 10v11M17 21V3c-2.2 1.6-3 4.2-3 7v3h3"/>',
    cart: '<path d="M3 4h2l2.2 10.5a1.5 1.5 0 0 0 1.5 1.2h8.2a1.5 1.5 0 0 0 1.5-1.1L20.5 8H6"/><path d="M9 20h.01M17 20h.01" stroke-width="2.6"/>',
    chat: '<path d="M20 12a8 8 0 0 1-11.6 7.1L4 20l1-4A8 8 0 1 1 20 12Z"/>',
    camera: '<path d="M4 8h3l1.5-2.5h7L17 8h3v11H4V8Z"/><circle cx="12" cy="13" r="3.2"/>',
    party: '<path d="M4.5 20 8 9.5l6.5 6.5L4.5 20Z"/><path d="M14 5v2M19 10h-2M17.5 5.5 16 7M12.5 9.5 15.5 6.5"/>',
    heart: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.2a4.3 4.3 0 0 1 7.5 2.6C19.5 15.4 12 20 12 20Z"/>',
    star: '<path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.8l-5.2 2.9 1-5.9L3.5 9.7l5.9-.8L12 3.5Z"/>',
    truck: '<path d="M3 6.5h11v10H3zM14 10h4l3 3v3.5h-7"/><circle cx="7" cy="17.5" r="2"/><circle cx="17" cy="17.5" r="2"/>',
    package: '<path d="M3.5 7.5 12 3l8.5 4.5v9L12 21l-8.5-4.5v-9Z"/><path d="M3.5 7.5 12 12l8.5-4.5M12 12v9"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    hourglass: '<path d="M7 3h10M7 21h10M8 3v3.5l4 5.5-4 5.5V21M16 3v3.5L12 12l4 5.5V21"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
    pencil: '<path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19l-4 1Z"/><path d="M14.5 6.5l3 3"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m20 20-4.9-4.9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    card: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3 10h18M7 15h3"/>',
    cash: '<rect x="2.5" y="6.5" width="19" height="11" rx="2"/><circle cx="12" cy="12" r="2.5"/>',
    bank: '<path d="M3 9.5 12 4l9 5.5H3Z"/><path d="M5 10.5v6M9.5 10.5v6M14.5 10.5v6M19 10.5v6M3 20h18"/>',
    wallet: '<path d="M19 7V4.5a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1V11h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2"/><path d="M3 5.5V19a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
    user: '<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20c.8-4 4-6 7.5-6s6.7 2 7.5 6"/>',
    home: '<path d="M4 11 12 4l8 7v9H4v-9Z"/><path d="M10 20v-5h4v5"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1.5 1.5 0 0 1-1.600 1.500C10.500 20 4 13.500 3.500 5.600A1.500 1.500 0 0 1 5 4Z"/>',
    mobile: '<rect x="6.5" y="3" width="11" height="18" rx="2"/><path d="M11 18h2"/>',
    headset: '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14h3v5H5.5A1.5 1.5 0 0 1 4 17.5V14ZM20 14h-3v5h1.500a1.500 1.500 0 0 0 1.500-1.500V14Z"/>',
    clip: '<path d="M20 11.500 12 19.500a5 5 0 0 1-7-7l8-8a3.300 3.300 0 0 1 4.700 4.700l-8 8a1.700 1.700 0 0 1-2.400-2.400l7.300-7.300"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.700 0l3-3a4 4 0 0 0-5.700-5.700l-1 1"/><path d="M14 10a4 4 0 0 0-5.700 0l-3 3a4 4 0 0 0 5.700 5.700l1-1"/>',
    plug: '<path d="M9 3v5M15 3v5M6.500 8h11v3a5.500 5.500 0 0 1-11 0V8Z"/><path d="M12 16.500V21"/>',
    battery: '<rect x="3" y="8" width="16" height="8" rx="2"/><path d="M21 11v2M7 11v2"/>',
    mail: '<rect x="3" y="5.500" width="18" height="13" rx="2"/><path d="m3.500 7 8.500 6 8.500-6"/>',
    plane: '<path d="M21 4 3 11l6 2.500L11.500 20 21 4Z"/><path d="M9 13.500 21 4"/>',
    printer: '<path d="M7 9V3.500h10V9M7 17H5a1.500 1.500 0 0 1-1.500-1.500v-5A1.500 1.500 0 0 1 5 9h14a1.500 1.500 0 0 1 1.500 1.500v5A1.500 1.500 0 0 1 19 17h-2"/><path d="M7 14h10v7H7z"/>',
    image: '<rect x="3.500" y="4.500" width="17" height="15" rx="2"/><circle cx="9" cy="10" r="1.500"/><path d="m4 18 5-5 4 4 3-3 4 4"/>',
    doc: '<path d="M6 3.500h9l3.500 3.500v13.500H6V3.500Z"/><path d="M14.500 3.500V7.500h4M9 12h6M9 15.500h6"/>',
    flag: '<path d="M5 21V4M5 4h12l-2 4 2 4H5"/>',
    archive: '<rect x="3.500" y="4" width="17" height="5" rx="1.500"/><path d="M5 9v10.500h14V9M10 13h4"/>',
    parking: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M10 16.500V8h3a2.500 2.500 0 0 1 0 5h-3"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3v2.500M12 18.500V21M3 12h2.500M18.500 12H21M5.600 5.600l1.800 1.800M16.600 16.600l1.800 1.800M18.400 5.600l-1.800 1.800M7.400 16.600l-1.800 1.800"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    grid: '<path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/>',
    logout: '<path d="M10 4H6.500A1.500 1.500 0 0 0 5 5.500v13A1.500 1.500 0 0 0 6.500 20H10M14 8l4 4-4 4M18 12H9"/>',
    download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
    right: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    left: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
    up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
    swap: '<path d="M4 8h14l-3-3M20 16H6l3 3"/>',
    "swap-h": '<path d="M4 12h16M8 8l-4 4 4 4M16 8l4 4-4 4"/>',
    refresh: '<path d="M20 11a8 8 0 1 0-2.300 5.700M20 5v6h-6"/>',
    undo: '<path d="M9 7 4.500 11.500 9 16M4.500 11.500H15a5 5 0 0 1 0 9"/>',
    chev: '<path d="m6 9 6 6 6-6"/>',
    play: '<path d="M8 5.500v13l11-6.500-11-6.500Z"/>',
    "play-l": '<path d="M16 5.500v13L5 12l11-6.500Z"/>',
    dot: '<circle cx="12" cy="12" r="4.500"/>',
    flame: '<path d="M12 3.500c1 3 5 5 5 9.500a5 5 0 0 1-10 0c0-2.500 1.500-3.500 2.500-5 .5 1.500 1 2 1.500 2 0-3 0-4 1-6.500Z"/>',
    bed: '<path d="M3.500 18V7M3.500 14h17v4M20.500 14v-2a3 3 0 0 0-3-3h-7v5"/><path d="M6.500 11.500h.01"/>',
    flower: '<circle cx="12" cy="6.500" r="2.800"/><circle cx="12" cy="17.500" r="2.800"/><circle cx="6.500" cy="12" r="2.800"/><circle cx="17.500" cy="12" r="2.800"/><circle cx="12" cy="12" r="1.600"/>',
    leaf: '<path d="M5 19c0-8.500 5.500-14 15-14 0 9.500-5.500 15-13.500 15"/><path d="M5 19c2.500-4.500 6-7.500 10-9.500"/>',
    bottle: '<path d="M9.500 3h5v3h-5zM8 6h8v14a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V6Z"/><path d="M8 11h8"/>',
    cup: '<path d="M7 6h10l-1.200 14H8.200L7 6Z"/><path d="M6 6h12M12 3.500l1 2.500"/>',
    drop: '<path d="M12 3.500s6 6.200 6 10.500a6 6 0 0 1-12 0c0-4.300 6-10.500 6-10.500Z"/>',
    bowl: '<path d="M3.500 11h17a8.500 8.500 0 0 1-17 0Z"/><path d="M8 7c0-1.500 1-2 1-3.500M12 7c0-1.500 1-2 1-3.500"/>',
    jar: '<rect x="6.500" y="4" width="11" height="3" rx="1"/><path d="M7.500 7v12a1.500 1.500 0 0 0 1.500 1.500h6a1.500 1.500 0 0 0 1.500-1.500V7"/>',
    shirt: '<path d="M8 4 3.500 7l2 3.500L8 9.500V20h8V9.500l2.500 1 2-3.500L16 4a4 4 0 0 1-8 0Z"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="m15.500 8.500-2 5-5 2 2-5 5-2Z"/>',
    puzzle: '<path d="M4 8h4a2 2 0 1 1 4 0h4v4a2 2 0 1 1 0 4v4H4V8Z"/>',
    sparkle: '<path d="m12 3 1.800 5.200L19 10l-5.200 1.800L12 17l-1.800-5.200L5 10l5.200-1.800L12 3Z"/><path d="m18.500 16 .8 2.200 2.200.8-2.200.8-.8 2.200-.8-2.200-2.200-.8 2.200-.8.8-2.200Z"/>',
    bakery: '<path d="M5 10a4 4 0 0 1 3-6h8a4 4 0 0 1 3 6v8a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-8Z"/><path d="m9 9 1.500 3M13 9l1.500 3"/>',
    burger: '<path d="M4 11a8 8 0 0 1 16 0H4Z"/><path d="M3 14.500h18"/><path d="M4 17.500h16v.5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-.5Z"/>',
    pizza: '<path d="M12 21 3.500 6.600a17 17 0 0 1 17 0L12 21Z"/><path d="M9.500 10.500h.01M14.500 10.500h.01M12 15h.01" stroke-width="2.6"/>',
    coffee: '<path d="M5 9h11v5a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5V9Z"/><path d="M16 10h1.500a2.500 2.500 0 0 1 0 5H16M8 3v2M12 3v2"/>',
    meat: '<path d="M2.500 12c3-4.500 8-5.500 12-2.500L20 6v12l-5.500-3.500c-4 3-9 2-12-2.500Z"/><path d="M8 11.500h.01" stroke-width="2.6"/>',
    pill: '<path d="M10.500 20.500a5 5 0 0 1-7-7l9-9a5 5 0 0 1 7 7l-9 9Z"/><path d="m8.500 8.500 7 7"/>',
    thumb: '<path d="M7 11v9H4v-9h3Z"/><path d="M7 11l3.500-6.500a1.800 1.800 0 0 1 3.200 1.200L13 10h5.300a1.800 1.800 0 0 1 1.800 2.100l-1.100 6a1.800 1.800 0 0 1-1.800 1.500H7"/>',
    hand: '<path d="M8 12V5.500a1.500 1.500 0 0 1 3 0V11M11 10V4a1.500 1.500 0 0 1 3 0v6M14 10V5.500a1.500 1.500 0 0 1 3 0V13c0 4-2.500 7-6 7-3 0-4.500-1.500-6-4l-1.500-2.500a1.500 1.500 0 0 1 2.500-1.500L8 14"/>',
    smile: FACE + '<path d="M8.500 14.200a4.200 4.200 0 0 0 7 0"/>',
    grin: FACE + '<path d="M8 13.500h8a4 4 0 0 1-8 0Z"/>',
    sad: FACE + '<path d="M8.500 16.200a4.200 4.200 0 0 1 7 0"/>',
    wow: FACE + '<circle cx="12" cy="15.500" r="1.800"/>',
    neutral: FACE + '<path d="M9 15h6"/>',
    wink: '<circle cx="12" cy="12" r="9"/><path d="M8 10h2M15 10h.01" stroke-width="2.4"/><path d="M8.500 14.200a4.200 4.200 0 0 0 7 0"/>',
    cool: '<circle cx="12" cy="12" r="9"/><path d="M6.500 9.500h4v2.500h-4zM13.500 9.500h4V12h-4zM10.500 10.500h3"/><path d="M8.500 15a4.200 4.200 0 0 0 7 0"/>'
  };
  /* icons drawn solid (ratings, status dots, play) */
  var FILL = { star: 1, dot: 1, play: 1, "play-l": 1 };

  /* emoji / symbol -> icon (first code point of the sequence decides) */
  var MAP = {
    check: "✓✔☑", x: "✕✗✖✘", "check-circle": "✅", "x-circle": "❌❎", alert: "⚠‼⁉❗❕❓❔", ban: "⛔🚫", info: "ℹ💡",
    pin: "📍🗺📌", scooter: "🛵🏍🚲🛴", store: "🏪🏬🛍🏢", bell: "🔔", "bell-off": "🔕", gift: "🎁🎀", utensils: "🍽🍴🥄",
    cart: "🛒", chat: "💬🗨💭", camera: "📷📸", party: "🎉🎊", heart: "❤💚💙💜🧡💛🖤🤍💖💕💗♥😍🥰😘",
    star: "★⭐🌟", truck: "🚚🚛", package: "📦", clock: "⏱⏰🕐⌚⏲🕒", hourglass: "⏳⌛", lock: "🔒🔐🔓🔑",
    pencil: "✏✎📝🖊", search: "🔍🔎", plus: "➕", card: "💳", cash: "💵💰💴💶💷", bank: "🏦🏧", wallet: "👛👝", user: "👤👥",
    home: "🏠🏡", phone: "📞☎📲", mobile: "📱", headset: "🎧🎤", clip: "📎", link: "🔗", plug: "🔌", battery: "🔋",
    mail: "✉📧📩📨", plane: "✈🚀", printer: "🖨", image: "🖼", doc: "📜🧾📄📃📋", flag: "⚑🚩🏁", archive: "🗄🗃📁📂",
    parking: "🅿", gear: "⚙🛠🔧", menu: "☰", grid: "▦🧩", logout: "⎋🚪",
    download: "⬇📥", right: "→➡➜➔⇒▸", left: "←⬅", up: "↑⬆", down: "↓", swap: "⇄↕", "swap-h": "↔", refresh: "↻🔄🔁", undo: "↩↪",
    chev: "▾⌄▼", play: "▶", "play-l": "◀", dot: "●⚫▪◼⬛🔴🟢🟡🔵🟠🟣", flame: "🔥🕯", bed: "🛏", flower: "🌸🌹🌷💐🌼🌺",
    leaf: "🌿🥬🍃🌱🥦🥒🥑🍅🥔🫒🌰🍊🍎🍌🍇🍓🍋🥕🌽🍉🍑🥭🍍🫑🌶", bottle: "🧴", cup: "🥤🧃🥛🍼🍹🍺🥂", drop: "💧", bowl: "🍲🍚🥗🍳🧆🍜🍝🍛🥘",
    jar: "🧂🍯🥫", shirt: "👕👗👖👔👠👟🧥", compass: "🧭", puzzle: "🧩", sparkle: "✨🧼🧽🧹🪥🧸💎🎈", bakery: "🥖🥐🥨🍰🍪🍞🧁🎂🍩🥞",
    burger: "🍔🌭🥪🌮🌯🍟", pizza: "🍕", coffee: "☕🍵🫖", meat: "🥩🍗🍖🥓🐟🍤", pill: "💊💉🩺🩹",
    thumb: "👍👌✌🤞💯", hand: "👋🙌🙏🤝👏🤚✋🖐", smile: "😀😃😄😁😊🙂😇☺🤗😌🙃", grin: "😂🤣😅😆😝😜😋", sad: "😢😭😞☹🙁😔😟😥😰",
    wow: "😮😲😯😱😳", neutral: "🤔😴😷😐😑😶🤐🥱", wink: "😉😏", cool: "😎🤓", paw: "🐾🐶🐱"
  };
  P.paw = P.sparkle; // keeps the table above flat; no dedicated paw drawing needed here
  var CH = {};
  Object.keys(MAP).forEach(function (n) { Array.from(MAP[n]).forEach(function (c) { CH[c] = n; }); });

  /* ○ ⚪ -> hollow dot ; ☆ -> hollow star (handled below) */
  var HOLLOW = { "○": 1, "⚪": 1, "☆": 1, "⚬": 1, "◻": 1, "⬜": 1 };
  var COLOR = { "🟢": "#1fa971", "🔴": "#e5484d", "🟡": "#f5a524", "🔵": "#3b82f6" };

  function nameFor(seq) {
    var c = Array.from(seq)[0];
    if (CH[c]) return CH[c];
    if (HOLLOW[c]) return c === "☆" ? "star" : "dot";
    var cp = c.codePointAt(0);
    if ((cp >= 0x1F600 && cp <= 0x1F64F) || (cp >= 0x1F910 && cp <= 0x1F92F) || (cp >= 0x1F970 && cp <= 0x1F97F)) return "smile";
    if (cp >= 0x1F493 && cp <= 0x1F49F) return "heart";
    if (cp >= 0x1F550 && cp <= 0x1F567) return "clock";
    if (cp >= 0x1F32D && cp <= 0x1F37F) return "bowl";   // food & drink block
    if (cp >= 0x1F400 && cp <= 0x1F43F) return "paw";
    if (cp >= 0x1F680 && cp <= 0x1F6FF) return "scooter"; // transport
    return "sparkle";
  }

  /* what counts as an "emoji" here: every pictograph (except © ® ™) + the glyph-like symbols the UI used as icons */
  var RE, HAS;
  try {
    var SYMS = "✕✓✗★☆●○▾⌄⚑⎋▦☰↻⇄⇒➜←→↑↓⚙▸◀▶";
    var src = "(?:[\\u{1F1E6}-\\u{1F1FF}]{2}|[#*0-9]\\uFE0F?\\u20E3|(?![\\u00A9\\u00AE\\u2122])\\p{Extended_Pictographic}|[" + SYMS + "])(?:\\uFE0F|\\u20E3|[\\u{1F3FB}-\\u{1F3FF}]|\\u200D\\p{Extended_Pictographic})*";
    RE = new RegExp(src, "gu"); HAS = new RegExp(src, "u");
  } catch (e) {
    RE = /[\u2190-\u21FF\u2300-\u23FF\u25A0-\u27BF\u2B00-\u2BFF\uD83C-\uD83E][\uDC00-\uDFFF\uFE0F\u200D]*/g; HAS = /[\u2190-\u21FF\u2300-\u23FF\u25A0-\u27BF\u2B00-\u2BFF\uD83C-\uD83E]/;
  }

  function svg(name, hollow) {
    var inner = P[name] || P.sparkle;
    var f = FILL[name] && !hollow ? "currentColor" : "none";
    return '<svg viewBox="0 0 24 24" focusable="false" aria-hidden="true" fill="' + f + '" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + inner + "</svg>";
  }
  function html(name, cls) { return '<span class="sy-ic' + (cls ? " " + cls : "") + '" aria-hidden="true">' + svg(name) + "</span>"; }
  function el(name, cls) { var s = document.createElement("span"); s.className = "sy-ic" + (cls ? " " + cls : ""); s.setAttribute("aria-hidden", "true"); s.innerHTML = svg(name); return s; }
  function strip(s) { return String(s == null ? "" : s).replace(RE, "").replace(/[ \t]{2,}/g, " ").replace(/^[ \t]+|[ \t]+$/g, ""); }

  function make(seq) {
    var first = Array.from(seq)[0], n = nameFor(seq), hollow = !!HOLLOW[first];
    var s = document.createElement("span");
    s.className = "sy-ic" + (FILL[n] && !hollow ? " sy-ic-f" : "");
    s.setAttribute("data-ic", n);
    if (COLOR[first]) s.style.color = COLOR[first];
    var t = document.createElement("span"); t.className = "sy-ic-t"; t.textContent = seq;
    s.appendChild(t);
    var holder = document.createElement("span"); holder.innerHTML = svg(n, hollow);
    s.appendChild(holder.firstChild);
    return s;
  }

  var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, CODE: 0 };
  var STRIP_IN = { OPTION: 1, OPTGROUP: 1, TEXTAREA: 1, TITLE: 1, BUTTON: 0 };
  var ATTRS = ["placeholder", "title", "alt", "aria-label", "aria-description", "label"];

  function convertText(node) {
    var s = node.nodeValue;
    if (!s || !HAS.test(s)) return;
    var p = node.parentNode;
    if (!p || p.nodeType !== 1) return;
    if (SKIP[p.nodeName]) return;
    if (p.classList && p.classList.contains("sy-ic-t")) return;
    if (STRIP_IN[p.nodeName] || p.namespaceURI === "http://www.w3.org/2000/svg" || (p.closest && p.closest("[contenteditable='true']"))) { var c = strip(s); if (c !== s) node.nodeValue = c; return; }
    var frag = document.createDocumentFragment(), last = 0, m;
    RE.lastIndex = 0;
    while ((m = RE.exec(s))) {
      if (m.index > last) frag.appendChild(document.createTextNode(s.slice(last, m.index)));
      frag.appendChild(make(m[0]));
      last = m.index + m[0].length;
      if (m[0].length === 0) RE.lastIndex++;
    }
    if (last < s.length) frag.appendChild(document.createTextNode(s.slice(last)));
    p.replaceChild(frag, node);
  }
  function cleanAttrs(e) {
    for (var i = 0; i < ATTRS.length; i++) {
      var v = e.getAttribute && e.getAttribute(ATTRS[i]);
      if (v && HAS.test(v)) { var c = strip(v); if (c !== v) e.setAttribute(ATTRS[i], c); }
    }
    if (e.nodeName === "INPUT" && /^(button|submit|reset)$/i.test(e.type || "")) { var val = e.getAttribute("value"); if (val && HAS.test(val)) e.setAttribute("value", strip(val)); }
  }
  function scan(root) {
    if (!root) return;
    if (root.nodeType === 3) { convertText(root); return; }
    if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
    if (root.nodeType === 1) { if (SKIP[root.nodeName]) return; if (root.classList && root.classList.contains("sy-ic")) return; cleanAttrs(root); }
    var w = document.createTreeWalker(root, 1 | 4, {
      acceptNode: function (n) {
        if (n.nodeType === 1) return SKIP[n.nodeName] || (n.classList && n.classList.contains("sy-ic")) ? 2 /* REJECT subtree */ : 1;
        return HAS.test(n.nodeValue || "") ? 1 : 3;
      }
    });
    var texts = [], n;
    while ((n = w.nextNode())) { if (n.nodeType === 1) cleanAttrs(n); else texts.push(n); }
    for (var i = 0; i < texts.length; i++) convertText(texts[i]);
  }

  /* style (injected once) */
  var css = ".sy-ic{display:inline-block;position:relative;width:1.15em;height:1.15em;vertical-align:-.2em;line-height:1;flex:none;font-style:normal;font-weight:400;text-indent:0;letter-spacing:0}" +
    ".sy-ic>svg{display:block;width:100%;height:100%;overflow:visible}" +
    ".sy-ic>.sy-ic-t{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);clip-path:inset(50%);white-space:nowrap;border:0}" +
    ".sy-ic-f>svg{stroke-width:1.2}";
  function injectCss() {
    if (document.getElementById("siymon-ic-css")) return;
    var st = document.createElement("style"); st.id = "siymon-ic-css"; st.textContent = css;
    (document.head || document.documentElement).appendChild(st);
  }
  injectCss();

  /* alert / confirm / prompt cannot show icons -> drop the emoji from their text */
  ["alert", "confirm", "prompt"].forEach(function (fn) {
    var orig = window[fn]; if (typeof orig !== "function") return;
    window[fn] = function (msg) { var a = Array.prototype.slice.call(arguments); if (a.length && a[0] != null) a[0] = strip(a[0]); return orig.apply(window, a); };
  });

  var mo = new MutationObserver(function (list) {
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (r.type === "childList") { for (var j = 0; j < r.addedNodes.length; j++) scan(r.addedNodes[j]); }
      else if (r.type === "characterData") convertText(r.target);
      else if (r.type === "attributes") cleanAttrs(r.target);
    }
  });
  function start() {
    mo.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS.concat(["value"]) });
    scan(document.documentElement);
  }
  start();
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { injectCss(); scan(document.documentElement); });

  window.SiymonIcons = { svg: svg, html: html, el: el, scan: scan, strip: strip, has: function (n) { return !!P[n]; }, names: Object.keys(P) };
})();
