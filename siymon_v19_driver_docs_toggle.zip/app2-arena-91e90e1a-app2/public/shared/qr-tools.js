/* QR helpers shared by the driver (scan) and the store / customer pages (show).
   - SiymonQR.render(container, text, size): draws a QR code (qrcodejs from cdnjs, loaded on demand)
   - SiymonQR.scan(videoEl, onText): scans with BarcodeDetector, falls back to jsQR (cdnjs). Returns {stop()} */
(function () {
  "use strict";
  var CDN = "https://cdnjs.cloudflare.com/ajax/libs/";
  var loaded = {};
  function load(src) {
    if (loaded[src]) return loaded[src];
    loaded[src] = new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = src;
      s.onload = resolve;
      s.onerror = function () { delete loaded[src]; reject(new Error("load")); };
      document.head.appendChild(s);
    });
    return loaded[src];
  }

  function render(container, text, size) {
    size = size || 160;
    container.textContent = "";
    return load(CDN + "qrcodejs/1.0.0/qrcode.min.js").then(function () {
      container.textContent = "";
      new window.QRCode(container, { text: String(text), width: size, height: size, correctLevel: window.QRCode.CorrectLevel.M, colorDark: "#000000", colorLight: "#ffffff" });
      var im = container.querySelector("img"), cv = container.querySelector("canvas");
      if (im) { im.alt = "QR"; im.style.maxWidth = "100%"; }
      if (cv) cv.style.maxWidth = "100%";
    });
  }

  function scan(video, onText, onError) {
    var stopped = false, stream = null, timer = 0, detector = null, canvas = null, ctx = null;
    function stop() {
      stopped = true;
      clearTimeout(timer);
      if (stream) stream.getTracks().forEach(function (t) { try { t.stop(); } catch (_e) {} });
      try { video.srcObject = null; } catch (_e) {}
    }
    function tick() {
      if (stopped) return;
      timer = setTimeout(function () {
        if (stopped) return;
        if (video.readyState < 2 || !video.videoWidth) return tick();
        var p;
        if (detector) {
          p = detector.detect(video).then(function (r) { return r && r[0] ? r[0].rawValue : ""; }).catch(function () { return ""; });
        } else {
          var w = video.videoWidth, h = video.videoHeight, k = Math.min(1, 640 / w);
          canvas.width = Math.round(w * k); canvas.height = Math.round(h * k);
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          var d = ctx.getImageData(0, 0, canvas.width, canvas.height);
          var r = window.jsQR ? window.jsQR(d.data, d.width, d.height, { inversionAttempts: "dontInvert" }) : null;
          p = Promise.resolve(r ? r.data : "");
        }
        p.then(function (txt) {
          if (stopped) return;
          if (txt && onText(String(txt)) === true) return stop();
          tick();
        });
      }, 160);
    }
    var ready = (async function () {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error("nocamera");
      if ("BarcodeDetector" in window) {
        try { detector = new window.BarcodeDetector({ formats: ["qr_code"] }); } catch (_e) { detector = null; }
      }
      if (!detector) {
        await load(CDN + "jsQR/1.4.0/jsQR.min.js");
        canvas = document.createElement("canvas");
        ctx = canvas.getContext("2d", { willReadFrequently: true });
      }
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
      if (stopped) { stop(); return; }
      video.setAttribute("playsinline", "");
      video.muted = true;
      video.srcObject = stream;
      await video.play().catch(function () {});
      tick();
    })();
    ready.catch(function (e) { stop(); if (onError) onError(e); });
    return { stop: stop };
  }

  window.SiymonQR = { render: render, scan: scan };
})();
