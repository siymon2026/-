/* SIYMON — best-effort GPS fix for the customer app.
   A single getCurrentPosition() often returns the FIRST (coarse Wi-Fi / cell) reading, which put the address pin hundreds of
   metres away. This watches for a few seconds, keeps the most accurate reading and stops early once it is good enough.
   window.SiymonGeo.best({ goodM, maxWaitMs, onProgress }) -> Promise<{lat,lng,accuracy,coarse}>
   rejects with { code: 1 denied | 2 unavailable | 3 timeout | -1 unsupported }. */
(function () {
  "use strict";
  var GOOD_M = 30, COARSE_M = 150, MAX_WAIT = 9000, FIRST_TIMEOUT = 15000;
  function best(opt) {
    opt = opt || {};
    var good = opt.goodM || GOOD_M, wait = opt.maxWaitMs || MAX_WAIT;
    return new Promise(function (resolve, reject) {
      if (!navigator.geolocation) return reject({ code: -1, unsupported: true });
      var bestPos = null, watchId = null, done = false, timer = null, firstTimer = null;
      function finish(err) {
        if (done) return; done = true;
        if (watchId != null) { try { navigator.geolocation.clearWatch(watchId); } catch (e) {} }
        clearTimeout(timer); clearTimeout(firstTimer);
        if (!bestPos) return reject(err || { code: 3 });
        var c = bestPos.coords;
        resolve({ lat: c.latitude, lng: c.longitude, accuracy: Math.round(c.accuracy || 0), coarse: !(c.accuracy > 0) || c.accuracy > COARSE_M });
      }
      function onPos(p) {
        if (done) return;
        var acc = p.coords.accuracy > 0 ? p.coords.accuracy : 1e9;
        if (!bestPos || acc < (bestPos.coords.accuracy > 0 ? bestPos.coords.accuracy : 1e9)) bestPos = p;
        if (opt.onProgress) { try { opt.onProgress(Math.round(acc)); } catch (e) {} }
        if (acc <= good) finish();
        else if (!timer) timer = setTimeout(function () { finish(); }, wait); // wait a little for a better reading, then take the best
      }
      function onErr(e) {
        if (done) return;
        // a permission refusal / disabled GPS is final; a timeout is final only when nothing was ever read
        if (e && (e.code === 1 || e.code === 2) && !bestPos) return finish({ code: e.code });
        if (e && e.code === 3 && !bestPos) return; // keep waiting until FIRST_TIMEOUT
      }
      try { watchId = navigator.geolocation.watchPosition(onPos, onErr, { enableHighAccuracy: true, maximumAge: 0, timeout: 12000 }); }
      catch (e) { return reject({ code: 2 }); }
      firstTimer = setTimeout(function () { finish({ code: 3 }); }, FIRST_TIMEOUT);
    });
  }
  window.SiymonGeo = { best: best, COARSE_M: COARSE_M };
})();
