/* SIYMON — line icons for store categories (same style as the bottom-nav icons: 24px grid, 1.7 stroke, currentColor).
   window.SiymonTypeIcons.el(type, cls?) -> <span class="ti"><svg/></span>
   - the 12 built-in categories have a drawn icon;
   - a category the admin adds later gets one automatically: first by its name/id (keywords in ar/fr/en -> closest icon),
     otherwise a generated badge with its first letter. Emoji stored in the category are never shown. */
(function () {
  "use strict";
  var P = {
    all: '<path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/>',
    restaurant: '<path d="M7 3v7M5 3v4.5a2 2 0 0 0 4 0V3M7 10v11M17 21V3c-2.2 1.6-3 4.2-3 7v3h3"/>',
    fastfood: '<path d="M4 11a8 8 0 0 1 16 0H4Z"/><path d="M3 14.5h18"/><path d="M4 17.5h16v.5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-.5Z"/>',
    pizza: '<path d="M12 21 3.5 6.6a17 17 0 0 1 17 0L12 21Z"/><path d="M9.5 10.5h.01M14.5 10.5h.01M12 15h.01" stroke-width="2.6"/>',
    greengrocer: '<path d="M5 19c0-8.5 5.5-14 15-14 0 9.5-5.5 15-13.5 15"/><path d="M5 19c2.5-4.5 6-7.5 10-9.5"/>',
    grocery: '<path d="M3 4h2l2.2 10.500a1.5 1.5 0 0 0 1.5 1.200h8.200a1.5 1.5 0 0 0 1.5-1.100L20.5 8H6"/><path d="M9 20h.01M17 20h.01" stroke-width="2.6"/>',
    pharmacy: '<path d="M10.5 20.500a5 5 0 0 1-7-7l9-9a5 5 0 0 1 7 7l-9 9Z"/><path d="m8.5 8.5 7 7"/>',
    cafe: '<path d="M5 9h11v5a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5V9Z"/><path d="M16 10h1.500a2.5 2.5 0 0 1 0 5H16M8 3v2M12 3v2"/>',
    bakery: '<path d="M5 10a4 4 0 0 1 3-6h8a4 4 0 0 1 3 6v8a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-8Z"/><path d="m9 9 1.5 3M13 9l1.5 3"/>',
    butcher: '<path d="M2.5 12c3-4.5 8-5.5 12-2.500L20 6v12l-5.5-3.500c-4 3-9 2-12-2.500Z"/><path d="M8 11.500h.01" stroke-width="2.6"/>',
    clothing: '<path d="M8 4 3.5 7l2 3.500L8 9.500V20h8V9.500l2.5 1 2-3.500L16 4a4 4 0 0 1-8 0Z"/>',
    electronics: '<rect x="6.5" y="3" width="11" height="18" rx="2"/><path d="M11 18h2"/>',
    other: '<path d="M4 9.5 5.6 4.500h12.800L20 9.500a2.5 2.5 0 0 1-4 2 2.5 2.5 0 0 1-4 0 2.5 2.5 0 0 1-4 0 2.5 2.5 0 0 1-4-2Z"/><path d="M5.5 12.800V20h13v-7.2"/>',
    gift: '<path d="M4 10h16v4H4zM6 14v6h12v-6M12 10v10"/><path d="M12 10C10 10 8 9 8 7.500S10.5 5 12 8c1.5-3 4-2.5 4-.5S14 10 12 10Z"/>',
    flower: '<circle cx="12" cy="6.5" r="2.8"/><circle cx="12" cy="17.5" r="2.8"/><circle cx="6.5" cy="12" r="2.8"/><circle cx="17.5" cy="12" r="2.8"/><circle cx="12" cy="12" r="1.6"/>',
    book: '<path d="M4 5.500A1.5 1.5 0 0 1 5.5 4H11v16H5.500A1.5 1.5 0 0 1 4 18.500v-13ZM20 5.500A1.5 1.5 0 0 0 18.5 4H13v16h5.500a1.5 1.5 0 0 0 1.5-1.500v-13Z"/>',
    paw: '<circle cx="6.5" cy="10.5" r="1.6"/><circle cx="10" cy="6.5" r="1.6"/><circle cx="14" cy="6.5" r="1.6"/><circle cx="17.5" cy="10.5" r="1.6"/><path d="M12 12.500c-3 0-5 2.5-5 4.5 0 1.5 1.5 2.3 3 2 .7-.15 1.3-.4 2-.4s1.3.25 2 .4c1.5.3 3-.5 3-2 0-2-2-4.5-5-4.500Z"/>',
    sparkle: '<path d="m12 3 1.8 5.200L19 10l-5.2 1.800L12 17l-1.8-5.200L5 10l5.2-1.800L12 3Z"/><path d="m18.5 16 .8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.200Z"/>'
  };
  /* keyword -> icon, for categories the admin creates (matched on id + names in ar / fr / en) */
  var KW = [
    ["pizza", ["pizza", "بيتزا"]], ["fastfood", ["fast", "burger", "snack", "سريع", "برغر", "سناك", "sandwich", "ساندويتش", "tacos", "تاكوس"]],
    ["pharmacy", ["pharm", "صيدل", "دواء", "para", "بارا"]], ["cafe", ["cafe", "café", "coffee", "مقهى", "قهوة", "كافي", "tea", "شاي"]],
    ["bakery", ["bakery", "boulang", "pastry", "patiss", "cake", "مخبز", "حلويات", "حلوى", "كعك"]],
    ["butcher", ["butcher", "bouch", "fish", "poisson", "meat", "لحوم", "لحم", "سمك", "أسماك", "دجاج", "poulet"]],
    ["greengrocer", ["vegetable", "fruit", "légume", "legume", "greengrocer", "خضر", "فواك", "خضار"]],
    ["grocery", ["grocery", "épicerie", "epicerie", "market", "supermarket", "بقال", "سوق", "ماركت", "تموين"]],
    ["clothing", ["cloth", "vêtement", "vetement", "fashion", "shoe", "chauss", "ملاب", "ألبسة", "أحذية", "موضة"]],
    ["electronics", ["electron", "électron", "phone", "mobile", "computer", "إلكترون", "الكترون", "هاتف", "حاسوب"]],
    ["flower", ["flower", "fleur", "florist", "ورد", "ورود", "زهور", "زهر", "باقات"]], ["gift", ["gift", "cadeau", "هدايا", "هدية"]],
    ["book", ["book", "livre", "librairie", "stationery", "مكتب", "كتب", "قرطاس", "أدوات مدرس"]],
    ["paw", ["pet", "animal", "vet", "حيوان", "أليف"]], ["sparkle", ["beauty", "cosmet", "beauté", "parfum", "perfume", "تجميل", "عطور", "عطر", "حلاق"]],
    ["restaurant", ["restaurant", "resto", "food", "مطعم", "أكل", "طعام", "وجبات"]]
  ];
  function text(o) { return o && typeof o === "object" ? [o.ar, o.fr, o.en].filter(Boolean).join(" ") : String(o || ""); }
  function pick(ti) {
    if (!ti) return "other";
    var id = String(ti.id || "");
    if (P[id] && id !== "all") return id;
    var hay = (id + " " + text(ti.name)).toLowerCase();
    for (var i = 0; i < KW.length; i++) for (var j = 0; j < KW[i][1].length; j++) if (hay.indexOf(KW[i][1][j]) >= 0) return KW[i][0];
    return "";
  }
  function letterBadge(ti) {
    var nm = text(ti && ti.name).trim() || String((ti && ti.id) || "?");
    var ch = nm.charAt(0).toUpperCase().replace(/[^\p{L}\p{N}]/gu, "") || "•";
    return '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><text x="12" y="16.2" text-anchor="middle" font-size="11" font-weight="700" font-family="Tajawal,sans-serif" fill="currentColor" stroke="none">' + ch + "</text>";
  }
  function svg(key, ti) {
    var inner = key === "all" ? P.all : (pick(ti) ? P[pick(ti)] : letterBadge(ti));
    return '<svg viewBox="0 0 24 24" focusable="false" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + inner + "</svg>";
  }
  /* ti = a store type {id,name}; pass "all" for the "All" chip */
  function el(ti, cls) {
    var s = document.createElement("span"); s.className = "ti" + (cls ? " " + cls : ""); s.setAttribute("aria-hidden", "true");
    s.innerHTML = ti === "all" ? svg("all") : svg("", ti); // static trusted paths; the only dynamic part is one sanitised letter
    return s;
  }
  window.SiymonTypeIcons = { el: el, pick: pick };
})();
