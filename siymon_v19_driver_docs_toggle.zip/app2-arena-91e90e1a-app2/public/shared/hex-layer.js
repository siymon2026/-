/* SIYMON — hexagon layer for the admin maps (cells are 500 m corner to corner, see lib/hexcell.js).
 *   SiymonHex.attachLeaflet(map, { api, lang, blocked })  -> { refresh(), relabel(), destroy() }
 *   SiymonHex.describeCell(cell, lang)                    -> DOM node (counts + names), used by the zones map and dispatch
 * Click a hexagon: how many stores and drivers are inside it right now (and who). Counts refresh by themselves. */
(function () {
  "use strict";
  var TX = {
    ar: { title: "السداسيات", diam: "قطر كل سداسي 500 م", show: "إظهار السداسيات", cells: "سداسي يغطي منطقة العمل", stores: "المطاعم", drivers: "السائقون", available: "متاح", none: "لا يوجد", unl: "متاجر بلا موقع", unlHint: "لم يحدّد موقعه بعد", cell: "سداسي", inZone: "داخل منطقة الخدمة", outZone: "خارج منطقة الخدمة", legStores: "فيه مطعم", legDrivers: "فيه سائق", legBoth: "الاثنان", state: { available: "متاح", delivering: "في توصيل", busy: "مشغول", offered: "لديه عرض", away: "بعيد" }, refresh: "تحديث", load: "تعذّر تحميل السداسيات" },
    fr: { title: "Hexagones", diam: "Chaque hexagone : 500 m", show: "Afficher les hexagones", cells: "hexagones couvrent la zone", stores: "Commerces", drivers: "Livreurs", available: "disponibles", none: "Aucun", unl: "Commerces sans position", unlHint: "position non renseignée", cell: "Hexagone", inZone: "Dans la zone de service", outZone: "Hors zone de service", legStores: "Commerce", legDrivers: "Livreur", legBoth: "Les deux", state: { available: "Disponible", delivering: "En livraison", busy: "Occupé", offered: "Offre en cours", away: "Éloigné" }, refresh: "Actualiser", load: "Impossible de charger les hexagones" },
    en: { title: "Hexagons", diam: "Each hexagon is 500 m across", show: "Show hexagons", cells: "hexagons cover the work area", stores: "Stores", drivers: "Drivers", available: "available", none: "None", unl: "Stores without a location", unlHint: "has not set its location yet", cell: "Hexagon", inZone: "Inside the service area", outZone: "Outside the service area", legStores: "Has a store", legDrivers: "Has a driver", legBoth: "Both", state: { available: "Available", delivering: "Delivering", busy: "Busy", offered: "Has an offer", away: "Far" }, refresh: "Refresh", load: "Could not load the hexagons" },
  };
  var tx = function (l) { return TX[l] || TX.ar; };
  function pickName(n, lang) {
    if (n && typeof n === "object") return n[lang] || n.ar || n.en || n.fr || "";
    return String(n == null ? "" : n);
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

  /** DOM description of one cell: counts first, then who is in it. */
  function describeCell(c, lang) {
    var t = tx(lang), box = el("div", "hx-pop");
    box.appendChild(el("b", "hx-pop-h", t.cell + " · " + (c.inZone ? t.inZone : t.outZone)));
    var row = el("div", "hx-pop-stats");
    var s = el("div", "hx-stat"); s.appendChild(el("strong", "", String(c.stores))); s.appendChild(el("span", "", "🍽 " + t.stores));
    var d = el("div", "hx-stat"); d.appendChild(el("strong", "", String(c.drivers))); d.appendChild(el("span", "", "🛵 " + t.drivers + (c.drivers ? " (" + c.available + " " + t.available + ")" : "")));
    row.appendChild(s); row.appendChild(d); box.appendChild(row);
    function list(arr, mk) {
      var ul = el("ul", "hx-pop-list");
      if (!arr.length) { ul.appendChild(el("li", "hx-none", t.none)); return ul; }
      arr.forEach(function (x) { ul.appendChild(el("li", "", mk(x))); });
      return ul;
    }
    box.appendChild(el("small", "hx-pop-sub", "🍽 " + t.stores)); box.appendChild(list(c.storeList, function (x) { return pickName(x.name, lang) || x.id; }));
    box.appendChild(el("small", "hx-pop-sub", "🛵 " + t.drivers));
    box.appendChild(list(c.driverList, function (x) { return (x.name || x.id) + " · " + ((t.state && t.state[x.state]) || x.state || ""); }));
    return box;
  }

  function centerOf(b) {
    var la = 0, ln = 0; for (var i = 0; i < b.length; i++) { la += b[i][0]; ln += b[i][1]; }
    return [la / b.length, ln / b.length];
  }

  function styleOf(c) {
    var hasS = c.stores > 0, hasD = c.drivers > 0;
    if (!c.inZone) return { color: "#c2410c", weight: 1.5, dashArray: "4 4", fillColor: "#fb923c", fillOpacity: hasS || hasD ? 0.28 : 0.1 };
    return {
      color: hasD ? "#2563eb" : "#337418", weight: hasD ? 2.5 : 1,
      fillColor: hasS ? "#f59e0b" : hasD ? "#60a5fa" : "#5DD62C",
      fillOpacity: hasS && hasD ? 0.45 : hasS ? 0.38 : hasD ? 0.3 : 0.1, dashArray: null,
    };
  }

  function attachLeaflet(map, opt) {
    opt = opt || {};
    var lang = function () { return (opt.lang && opt.lang()) || "ar"; };
    var cellsLayer = L.layerGroup().addTo(map), labelsLayer = L.layerGroup();
    var polys = {}, labels = {}, data = null, visible = true, timer = null, destroyed = false, openId = null;
    var ctl = L.control({ position: "bottomright" });
    var ui = {};
    ctl.onAdd = function () {
      var box = el("div", "hx-ctl"); L.DomEvent.disableClickPropagation(box); L.DomEvent.disableScrollPropagation(box);
      ui.box = box; paintCtl(); return box;
    };
    ctl.addTo(map);

    function paintCtl() {
      var t = tx(lang()), box = ui.box; if (!box) return;
      box.replaceChildren();
      var head = el("label", "hx-ctl-head"); var cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = visible;
      cb.addEventListener("change", function () { setVisible(cb.checked); });
      head.appendChild(cb); head.appendChild(el("b", "", t.show)); box.appendChild(head);
      box.appendChild(el("small", "hx-ctl-sub", t.diam));
      if (data) {
        var s = data.summary;
        var g = el("div", "hx-ctl-grid");
        [[s.covered, t.cells], [s.stores, "🍽 " + t.stores], [s.drivers, "🛵 " + t.drivers + " (" + s.available + " " + t.available + ")"]].forEach(function (p) {
          var r = el("div", "hx-ctl-row"); r.appendChild(el("strong", "", String(p[0]))); r.appendChild(el("span", "", p[1])); g.appendChild(r);
        });
        box.appendChild(g);
        if (data.unlocated && data.unlocated.length) {
          var det = el("details", "hx-unl"); det.appendChild(el("summary", "", "⚠ " + t.unl + " (" + data.unlocated.length + ")"));
          var ul = el("ul", ""); data.unlocated.slice(0, 40).forEach(function (x) { ul.appendChild(el("li", "", (pickName(x.name, lang()) || x.id) + " — " + t.unlHint)); });
          det.appendChild(ul); box.appendChild(det);
        }
        var leg = el("div", "hx-leg");
        [["#5DD62C", t.cells], ["#f59e0b", t.legStores], ["#60a5fa", t.legDrivers]].forEach(function (p) { var i = el("span", "hx-leg-i"); var sw = el("i", "hx-sw"); sw.style.background = p[0]; i.appendChild(sw); i.appendChild(document.createTextNode(p[1])); leg.appendChild(i); });
        box.appendChild(leg);
      }
    }

    function labelIcon(c) {
      var parts = [];
      if (c.stores) parts.push("<b>🍽" + c.stores + "</b>");
      if (c.drivers) parts.push("<b>🛵" + c.drivers + "</b>");
      return L.divIcon({ className: "hx-lbl", html: parts.join(""), iconSize: [64, 22], iconAnchor: [32, 11] });
    }

    function draw() {
      if (!data) return;
      var seen = {};
      data.cells.forEach(function (c) {
        seen[c.id] = 1;
        var p = polys[c.id];
        if (!p) {
          p = L.polygon(c.boundary, styleOf(c)).addTo(cellsLayer);
          p.on("click", function () {
            if (opt.blocked && opt.blocked()) return;
            openId = c.id; openPopup(c.id);
          });
          polys[c.id] = p;
        } else p.setStyle(styleOf(c));
        p._cell = c;
        var need = c.stores > 0 || c.drivers > 0;
        if (need) {
          if (labels[c.id]) labelsLayer.removeLayer(labels[c.id]);
          labels[c.id] = L.marker(centerOf(c.boundary), { icon: labelIcon(c), interactive: false, keyboard: false }).addTo(labelsLayer);
        } else if (labels[c.id]) { labelsLayer.removeLayer(labels[c.id]); delete labels[c.id]; }
      });
      Object.keys(polys).forEach(function (id) { if (!seen[id]) { cellsLayer.removeLayer(polys[id]); delete polys[id]; if (labels[id]) { labelsLayer.removeLayer(labels[id]); delete labels[id]; } } });
      if (openId && polys[openId] && polys[openId].isPopupOpen && polys[openId].isPopupOpen()) openPopup(openId);
    }
    function openPopup(id) {
      var p = polys[id]; if (!p) return;
      p.unbindPopup().bindPopup(describeCell(p._cell, lang()), { maxWidth: 280, className: "hx-popup" }).openPopup();
    }
    function syncLabels() { if (visible && map.getZoom() >= 14) { if (!map.hasLayer(labelsLayer)) labelsLayer.addTo(map); } else if (map.hasLayer(labelsLayer)) map.removeLayer(labelsLayer); }
    function setVisible(v) {
      visible = !!v;
      if (visible) { if (!map.hasLayer(cellsLayer)) cellsLayer.addTo(map); } else { map.removeLayer(cellsLayer); }
      syncLabels();
    }
    map.on("zoomend", syncLabels);

    function refresh() {
      if (destroyed) return Promise.resolve();
      return opt.api("/api/admin/hex/overview").then(function (r) { data = r; draw(); paintCtl(); syncLabels(); })
        .catch(function (e) { if (ui.box && !data) { ui.box.replaceChildren(el("small", "hx-err", tx(lang()).load + (e && e.message ? " — " + e.message : ""))); } });
    }
    refresh();
    timer = setInterval(function () { if (!document.hidden) refresh(); }, 20000);
    return {
      refresh: refresh, relabel: paintCtl,
      get data() { return data; },
      destroy: function () { destroyed = true; clearInterval(timer); map.removeLayer(cellsLayer); map.removeLayer(labelsLayer); map.removeControl(ctl); },
    };
  }

  window.SiymonHex = { TX: TX, pickName: pickName, describeCell: describeCell, attachLeaflet: attachLeaflet };
})();
