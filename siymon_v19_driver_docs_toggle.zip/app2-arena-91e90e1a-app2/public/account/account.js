/* SIYMON — account page: edit name / e-mail / phone through the real PATCH /api/customer/me. */
(function () {
  "use strict";
  var TOKEN_KEY = "siymon_customer_token_v1", PROFILE_KEY = "siymon_customer_profile_v1", LANG_KEY = "siymon_lang_v1";
  function $(id) { return document.getElementById(id); }
  function ls(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  var lang = ls(LANG_KEY); if (["ar", "fr", "en"].indexOf(lang) < 0) lang = "ar";
  var TX = {
    ar: { title: "تعديل الحساب", first: "الاسم", last: "اللقب", email: "البريد الإلكتروني", phone: "الهاتف", save: "حفظ التغييرات", saving: "جارٍ الحفظ…", saved: "تم حفظ التغييرات.", none: "لا توجد تغييرات.", wallet: "محفظتي", orders: "طلباتي", needLogin: "سجّل الدخول لتعديل حسابك.", login: "تسجيل الدخول", err: "تعذّر تحميل بياناتك.", retry: "إعادة المحاولة", photo: "تغيير الصورة", rmPhoto: "إزالة الصورة", photoOk: "تم تحديث صورتك.", photoRm: "تمت إزالة الصورة.", photoBad: "تعذّر قراءة الصورة. اختر صورة JPG أو PNG.", photoBusy: "جارٍ رفع الصورة…", photoNet: "تعذّر رفع الصورة، تحقق من الاتصال.",
      DUPLICATE_EMAIL: "هذا البريد مستخدم بحساب آخر.", DUPLICATE_PHONE: "هذا الهاتف مستخدم بحساب آخر.", INVALID_EMAIL: "بريد غير صالح.", INVALID_PHONE: "رقم هاتف غير صالح." },
    fr: { title: "Modifier le compte", first: "Prénom", last: "Nom", email: "E-mail", phone: "Téléphone", save: "Enregistrer", saving: "Enregistrement…", saved: "Modifications enregistrées.", none: "Aucune modification.", wallet: "Portefeuille", orders: "Mes commandes", needLogin: "Connectez-vous pour modifier votre compte.", login: "Se connecter", err: "Impossible de charger vos données.", retry: "Réessayer", photo: "Changer la photo", rmPhoto: "Supprimer la photo", photoOk: "Photo mise à jour.", photoRm: "Photo supprimée.", photoBad: "Image illisible. Choisissez un JPG ou PNG.", photoBusy: "Envoi de la photo…", photoNet: "Envoi impossible, vérifiez la connexion.",
      DUPLICATE_EMAIL: "Cet e-mail est déjà utilisé.", DUPLICATE_PHONE: "Ce numéro est déjà utilisé.", INVALID_EMAIL: "E-mail invalide.", INVALID_PHONE: "Numéro invalide." },
    en: { title: "Edit account", first: "First name", last: "Last name", email: "Email", phone: "Phone", save: "Save changes", saving: "Saving…", saved: "Changes saved.", none: "No changes.", wallet: "Wallet", orders: "My orders", needLogin: "Sign in to edit your account.", login: "Sign in", err: "Could not load your details.", retry: "Retry", photo: "Change photo", rmPhoto: "Remove photo", photoOk: "Photo updated.", photoRm: "Photo removed.", photoBad: "Could not read the image. Pick a JPG or PNG.", photoBusy: "Uploading photo…", photoNet: "Upload failed, check your connection.",
      DUPLICATE_EMAIL: "This email is used by another account.", DUPLICATE_PHONE: "This phone is used by another account.", INVALID_EMAIL: "Invalid email.", INVALID_PHONE: "Invalid phone number." }
  }[lang];
  var me = null;

  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.title = "siymon | " + TX.title;
  $("acTitle").textContent = TX.title;
  $("lFirst").textContent = TX.first; $("lLast").textContent = TX.last; $("lEmail").textContent = TX.email; $("lPhone").textContent = TX.phone;
  $("acAvBtn").setAttribute("aria-label", TX.photo); $("acAvDel").textContent = TX.rmPhoto;
  $("acSave").textContent = TX.save; $("tWallet").textContent = TX.wallet; $("tOrders").textContent = TX.orders;

  function show(which) {
    ["acLoading", "acAuth", "acErr", "acBody"].forEach(function (id) { $(id).classList.toggle("hidden", id !== which); });
  }
  function api(path, opt) {
    opt = opt || {};
    return fetch(path, { method: opt.method || "GET", headers: { "Content-Type": "application/json", Authorization: "Bearer " + ls(TOKEN_KEY) }, body: opt.body, cache: "no-store" })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) { var e = new Error(j.error || "http " + r.status); e.status = r.status; e.code = j.code; throw e; } return j; }); });
  }
  function fill() {
    var f = $("acForm");
    ["firstName", "lastName", "email", "phone"].forEach(function (k) { f.elements[k].value = me[k] || ""; f.elements[k].classList.remove("bad"); });
    var name = ((me.firstName || "") + " " + (me.lastName || "")).trim();
    $("acName").textContent = name || "—";
    $("acSub").textContent = me.email || me.phone || "";
    paintAvatar(name);
  }
  function paintAvatar(name) {
    var box = $("acAv");
    box.textContent = "";
    if (me.avatar && /^(\/uploads\/|https:\/\/)/.test(me.avatar)) {
      var img = document.createElement("img"); img.alt = ""; img.src = me.avatar; img.decoding = "async";
      box.appendChild(img); box.classList.add("has-img");
    } else {
      box.classList.remove("has-img");
      box.textContent = ((name || me.email || "?") + "").charAt(0).toUpperCase();
    }
    $("acAvDel").classList.toggle("hidden", !me.avatar);
  }
  /* ---- profile photo: pick (gallery or camera) -> centre-crop square 512px JPEG -> upload ---- */
  function squareJpeg(file, size) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        var s = Math.min(img.naturalWidth, img.naturalHeight), sx = (img.naturalWidth - s) / 2, sy = (img.naturalHeight - s) / 2;
        var cv = document.createElement("canvas"); cv.width = size; cv.height = size;
        var ctx = cv.getContext("2d"); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, size, size);
        ctx.drawImage(img, sx, sy, s, s, 0, 0, size, size);
        URL.revokeObjectURL(url);
        resolve(cv.toDataURL("image/jpeg", 0.85));
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("bad image")); };
      img.src = url;
    });
  }
  function avMsg(text, ok) { var m = $("acAvMsg"); m.textContent = text || ""; m.classList.toggle("ok", !!ok); }
  $("acAvBtn").addEventListener("click", function () { $("acFile").click(); });
  $("acFile").addEventListener("change", function () {
    var f = this.files && this.files[0], input = this;
    if (!f) return;
    avMsg(TX.photoBusy, true); $("acAvBtn").disabled = true;
    squareJpeg(f, 512).then(function (dataUrl) {
      return api("/api/customer/avatar", { method: "POST", body: JSON.stringify({ image: dataUrl }) });
    }).then(function (d) {
      me = d.customer || me;
      try { localStorage.setItem(PROFILE_KEY, JSON.stringify(me)); } catch (e) {}
      fill(); avMsg(TX.photoOk, true);
    }).catch(function (e) {
      avMsg(e.status === undefined ? (e.message === "bad image" ? TX.photoBad : TX.photoNet) : (e.code === "INVALID_IMAGE" ? TX.photoBad : e.message));
    }).then(function () { $("acAvBtn").disabled = false; input.value = ""; });
  });
  $("acAvDel").addEventListener("click", function () {
    $("acAvDel").disabled = true;
    api("/api/customer/avatar", { method: "DELETE" }).then(function (d) {
      me = d.customer || me; try { localStorage.setItem(PROFILE_KEY, JSON.stringify(me)); } catch (e) {}
      fill(); avMsg(TX.photoRm, true);
    }).catch(function (e) { avMsg(e.message); }).then(function () { $("acAvDel").disabled = false; });
  });

  function msg(text, ok) { var m = $("acMsg"); m.textContent = text || ""; m.classList.toggle("ok", !!ok); }

  function load() {
    if (!ls(TOKEN_KEY)) {
      $("acAuth").innerHTML = "";
      var p = document.createElement("p"); p.textContent = TX.needLogin;
      var a = document.createElement("a"); a.className = "ac-btn"; a.href = "/orders/"; a.textContent = TX.login;
      $("acAuth").appendChild(p); $("acAuth").appendChild(a);
      return show("acAuth");
    }
    show("acLoading");
    api("/api/customer/me").then(function (d) {
      me = d.customer || {};
      try { localStorage.setItem(PROFILE_KEY, JSON.stringify(me)); } catch (e) {}
      fill(); show("acBody");
    }).catch(function (e) {
      if (e.status === 401) { try { localStorage.removeItem(TOKEN_KEY); } catch (x) {} return load(); }
      $("acErr").innerHTML = "";
      var p = document.createElement("p"); p.textContent = TX.err;
      var b = document.createElement("button"); b.type = "button"; b.className = "ac-btn"; b.textContent = TX.retry; b.addEventListener("click", load);
      $("acErr").appendChild(p); $("acErr").appendChild(b);
      show("acErr");
    });
  }

  $("acForm").addEventListener("submit", function (ev) {
    ev.preventDefault();
    var f = $("acForm"), body = {};
    msg("");
    ["firstName", "lastName", "email", "phone"].forEach(function (k) {
      f.elements[k].classList.remove("bad");
      var v = String(f.elements[k].value || "").trim();
      if (v !== String(me[k] || "")) body[k] = v;
    });
    if (!Object.keys(body).length) return msg(TX.none);
    var btn = $("acSave"); btn.disabled = true; btn.textContent = TX.saving;
    api("/api/customer/me", { method: "PATCH", body: JSON.stringify(body) }).then(function (d) {
      me = d.customer || me;
      try { localStorage.setItem(PROFILE_KEY, JSON.stringify(me)); } catch (e) {}
      fill(); msg(TX.saved, true);
    }).catch(function (e) {
      msg(TX[e.code] || e.message);
      var k = /EMAIL/.test(e.code || "") ? "email" : /PHONE/.test(e.code || "") ? "phone" : "";
      if (k) f.elements[k].classList.add("bad");
    }).then(function () { btn.disabled = false; btn.textContent = TX.save; });
  });

  $("acBack").addEventListener("click", function (e) {
    try { if (document.referrer && new URL(document.referrer).origin === location.origin && history.length > 1) { e.preventDefault(); history.back(); } } catch (er) {}
  });
  load();
})();
