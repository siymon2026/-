/* Guest order tracking. The private token travels in the URL fragment (never sent to the
   server in the URL / access logs) and is sent in the X-Track-Token header. */
(function () {
  "use strict";
  const lang = localStorage.getItem("siymon_lang_v1") || localStorage.getItem("siymon_lang") || "ar";
  const T = (ar, fr, en) => (lang === "ar" ? ar : lang === "fr" ? fr : en);
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const STATUS = {
    new: T("بانتظار المراجعة", "En attente", "Pending"),
    admin_accepted: T("تم قبول الطلب", "Acceptée", "Accepted"),
    restaurant_ready: T("جاهز للتوصيل", "Prête", "Ready for pickup"),
    accepted: T("السائق في الطريق للمتجر", "Livreur en route vers le magasin", "Driver heading to the store"),
    picked_up: T("تم استلام الطلب", "Commande récupérée", "Picked up"),
    on_the_way: T("في الطريق إليك", "En route vers vous", "On the way"),
    delivered: T("تم التسليم", "Livrée", "Delivered"),
    done: T("مكتمل", "Terminée", "Completed"),
    canceled: T("ملغي", "Annulée", "Canceled"),
  };
  const box = document.getElementById("tkBox");
  document.getElementById("tkTitle").textContent = T("تتبّع الطلب", "Suivi de commande", "Order tracking");
  const m = /^#([^.]+)\.(.+)$/.exec(location.hash || "");
  const bad = () => { box.textContent = T("رابط التتبع غير صالح.", "Lien de suivi invalide.", "Invalid tracking link."); };
  if (!m) return bad();
  const id = decodeURIComponent(m[1]), token = m[2];
  async function load() {
    try {
      const res = await fetch("/api/track/" + encodeURIComponent(id), { headers: { "X-Track-Token": token } });
      if (!res.ok) return bad();
      const { order: o } = await res.json();
      box.innerHTML = `<p><b>#${esc(o.id)}</b> — ${esc(o.store)}</p>
        <p style="font-size:1.2em"><b>${esc(STATUS[o.status] || o.status)}</b></p>
        <ul>${o.items.map((i) => `<li>${esc(i.name)} × ${i.qty}</li>`).join("")}</ul>
        <p>${esc(T("الإجمالي", "Total", "Total"))}: <b>${Number(o.total).toFixed(2)} ${esc(o.currency)}</b></p>`;
      if (!["done", "canceled", "cancelled"].includes(o.status)) setTimeout(load, 20000);
    } catch (_e) {
      box.textContent = T("تعذّر الاتصال. سنعيد المحاولة…", "Connexion impossible. Nouvel essai…", "Connection problem. Retrying…");
      setTimeout(load, 15000);
    }
  }
  load();

  /* ---------------- support chat for customers WITHOUT an account ----------------
     The private tracking link is the proof of identity: the same token opens the conversation. */
  const sup = document.getElementById("tkSupport");
  const SUP_T = {
    title: T("الدعم", "Support", "Support"),
    hint: T("اكتب لنا هنا وسنرد عليك على نفس هذه الصفحة.", "Écrivez-nous ici, nous répondons sur cette même page.", "Write to us here — we reply on this same page."),
    ph: T("اكتب رسالة…", "Écrire un message…", "Type a message…"),
    send: T("إرسال", "Envoyer", "Send"),
    photo: T("إرسال صورة", "Envoyer une photo", "Send a photo"),
    fail: T("تعذّر الإرسال، حاول مرة أخرى.", "Envoi impossible, réessayez.", "Couldn’t send, please try again."),
    bad: T("الصورة غير صالحة.", "Image invalide.", "Invalid image."),
    empty: T("لا رسائل بعد.", "Aucun message.", "No messages yet."),
    you: T("أنت", "Vous", "You"),
    team: T("الدعم", "Support", "Support"),
  };
  const sh = { "X-Track-Token": token, "Content-Type": "application/json" };
  const mkEl = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  let supBox = null, supSig = "", supBusy = false, supStarted = false;
  function supRender(list) {
    const last = list[list.length - 1];
    const sig = list.length + "|" + (last ? last.id : "");
    if (sig === supSig) return;
    supSig = sig;
    const near = supBox.scrollHeight - supBox.scrollTop - supBox.clientHeight < 80;
    supBox.replaceChildren();
    if (!list.length) supBox.appendChild(mkEl("p", "", SUP_T.empty)).style.opacity = ".6";
    for (const m of list) {
      const me = m.from === "customer";
      const row = mkEl("div");
      row.style.cssText = "display:flex;margin:6px 0;justify-content:" + (me ? "flex-end" : "flex-start");
      const b = mkEl("div");
      b.style.cssText = "max-width:80%;padding:8px 12px;border-radius:14px;line-height:1.6;word-break:break-word;background:" + (me ? "rgba(93,214,44,.22)" : "rgba(128,128,128,.16)");
      const who = mkEl("small", "", me ? SUP_T.you : SUP_T.team); who.style.cssText = "display:block;opacity:.65;font-size:11px";
      b.appendChild(who);
      if (m.type === "image" && /^\/[^\s"'<>]+$/.test(String(m.url || ""))) {
        const img = document.createElement("img");
        img.alt = ""; img.loading = "lazy"; img.src = m.url; img.style.cssText = "display:block;max-width:100%;max-height:260px;border-radius:10px;cursor:zoom-in";
        img.addEventListener("click", () => window.open(m.url, "_blank", "noopener"));
        b.appendChild(img);
      } else b.appendChild(mkEl("span", "", m.text || ""));
      row.appendChild(b); supBox.appendChild(row);
    }
    if (near || list.length) supBox.scrollTop = supBox.scrollHeight;
  }
  async function supLoad() {
    try {
      const res = await fetch("/api/track/" + encodeURIComponent(id) + "/support", { headers: sh });
      if (res.status === 409 || res.status === 404) { sup.hidden = true; return false; } // order has an account / bad link
      if (!res.ok) return true;
      const d = await res.json();
      supRender(Array.isArray(d.messages) ? d.messages : []);
      return true;
    } catch (_e) { return true; }
  }
  function supResize(file, max) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file), img = new Image();
      img.onload = () => {
        const k = Math.min(1, max / Math.max(img.width, img.height)), w = Math.max(1, Math.round(img.width * k)), h = Math.max(1, Math.round(img.height * k));
        const cv = document.createElement("canvas"); cv.width = w; cv.height = h;
        cv.getContext("2d").drawImage(img, 0, 0, w, h); URL.revokeObjectURL(url); resolve(cv.toDataURL("image/jpeg", 0.82));
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("bad image")); };
      img.src = url;
    });
  }
  async function supStart() {
    if (supStarted) return; supStarted = true;
    sup.replaceChildren();
    sup.appendChild(mkEl("h2", "", SUP_T.title)).style.margin = "0 0 4px";
    const hint = mkEl("p", "", SUP_T.hint); hint.style.cssText = "margin:0 0 8px;opacity:.7;font-size:13px"; sup.appendChild(hint);
    supBox = mkEl("div"); supBox.style.cssText = "max-height:320px;overflow:auto;padding:4px 2px"; supBox.setAttribute("role", "log"); sup.appendChild(supBox);
    const row = mkEl("div"); row.style.cssText = "display:flex;gap:8px;margin-top:10px;align-items:center";
    const input = mkEl("input"); input.type = "text"; input.maxLength = 2000; input.placeholder = SUP_T.ph; input.autocomplete = "off"; input.style.cssText = "flex:1;min-height:44px;padding:0 12px;border-radius:12px;border:1px solid rgba(128,128,128,.35);font:inherit;background:transparent;color:inherit";
    const photo = mkEl("button", "", "📷"); photo.type = "button"; photo.title = photo.ariaLabel = SUP_T.photo; photo.style.cssText = "min-width:44px;min-height:44px;border-radius:12px;border:1px solid rgba(128,128,128,.35);background:transparent;cursor:pointer;font-size:18px";
    const file = mkEl("input"); file.type = "file"; file.accept = "image/*"; file.hidden = true;
    const send = mkEl("button", "", SUP_T.send); send.type = "button"; send.style.cssText = "min-height:44px;padding:0 16px;border-radius:12px;border:0;background:#5DD62C;color:#0b1a05;font:inherit;font-weight:700;cursor:pointer";
    const msg = mkEl("p", "", ""); msg.style.cssText = "margin:6px 0 0;color:#b45309;font-size:13px"; msg.setAttribute("role", "alert");
    row.append(photo, file, input, send); sup.append(row, msg);
    async function post(path, body) {
      const res = await fetch("/api/track/" + encodeURIComponent(id) + path, { method: "POST", headers: sh, body: JSON.stringify(body) });
      if (!res.ok) { const e = new Error("send"); e.status = res.status; throw e; }
    }
    async function doSend() {
      const text = input.value.trim(); if (!text || supBusy) return;
      supBusy = true; send.disabled = true; msg.textContent = "";
      try { await post("/support", { text }); input.value = ""; supSig = ""; await supLoad(); }
      catch (_e) { msg.textContent = SUP_T.fail; }
      finally { supBusy = false; send.disabled = false; input.focus(); }
    }
    send.addEventListener("click", doSend);
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); doSend(); } });
    photo.addEventListener("click", () => file.click());
    file.addEventListener("change", async () => {
      const f = file.files && file.files[0]; if (!f || supBusy) return;
      supBusy = true; photo.disabled = true; msg.textContent = "";
      try { await post("/support/image", { image: await supResize(f, 1280) }); supSig = ""; await supLoad(); }
      catch (e) { msg.textContent = e && e.message === "bad image" ? SUP_T.bad : SUP_T.fail; }
      finally { supBusy = false; photo.disabled = false; file.value = ""; }
    });
    // build first (hidden), then load: a 404/409 (bad link / order with an account) keeps the panel hidden
    if (!(await supLoad())) return;
    sup.hidden = false;
    supBox.scrollTop = supBox.scrollHeight;
    setInterval(() => { if (!document.hidden) supLoad(); }, 8000);
  }
  supStart();
})();
