/* SIYMON GRID BATTLE — sound + haptics. Every sound is synthesised here with WebAudio (original, no files, no licences). */
(function (root) {
  "use strict";
  var ctx = null, master = null, cfg = { sound: true, volume: 0.7, vibrate: true };
  function ensure() {
    if (!cfg.sound) return null;
    try {
      if (!ctx) { var AC = root.AudioContext || root.webkitAudioContext; if (!AC) return null; ctx = new AC(); master = ctx.createGain(); master.connect(ctx.destination); }
      if (ctx.state === "suspended") ctx.resume();
      master.gain.value = Math.max(0, Math.min(1, cfg.volume)) * 0.6;
      return ctx;
    } catch (e) { return null; }
  }
  /** one oscillator note; slide = target frequency reached by the end */
  function tone(f, dur, type, vol, slide, delay) {
    var c = ensure(); if (!c) return;
    var t0 = c.currentTime + (delay || 0), o = c.createOscillator(), g = c.createGain();
    o.type = type || "sine"; o.frequency.setValueAtTime(f, t0);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol || 0.2, t0 + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(master); o.start(t0); o.stop(t0 + dur + 0.02);
  }
  function noise(dur, vol, freq) {
    var c = ensure(); if (!c) return;
    var n = Math.floor(c.sampleRate * dur), buf = c.createBuffer(1, n, c.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    var s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = buf; f.type = "lowpass"; f.frequency.value = freq || 1400; g.gain.value = vol || 0.3;
    s.connect(f); f.connect(g); g.connect(master); s.start();
  }
  function buzz(p) { if (cfg.vibrate && navigator.vibrate) { try { navigator.vibrate(p); } catch (e) {} } }
  var A = {
    configure: function (o) { for (var k in o) cfg[k] = o[k]; },
    unlock: function () { ensure(); },
    click: function () { tone(520, 0.05, "triangle", 0.08); },
    count: function (n) { if (n > 0) tone(440, 0.14, "sine", 0.22); else { tone(880, 0.28, "triangle", 0.26); tone(1320, 0.28, "sine", 0.12, 0, 0.02); } },
    turn: function () { tone(660, 0.035, "square", 0.035); },
    step: function () { tone(420, 0.09, "sine", 0.16, 640); buzz(6); },
    wall: function () { tone(190, 0.1, "square", 0.12, 110); noise(0.07, 0.16, 900); buzz(14); },
    crash: function () { noise(0.45, 0.4, 1800); tone(150, 0.4, "sawtooth", 0.2, 38); buzz([70, 30, 90]); },
    roundWin: function () { tone(523, 0.12, "triangle", 0.2); tone(784, 0.18, "triangle", 0.2, 0, 0.1); },
    roundLose: function () { tone(330, 0.18, "triangle", 0.2, 220); },
    win: function () { [523, 659, 784, 1046].forEach(function (f, i) { tone(f, 0.22, "triangle", 0.24, 0, i * 0.11); }); tone(1046, 0.6, "sine", 0.14, 0, 0.5); buzz([40, 40, 40]); },
    lose: function () { [392, 330, 262, 196].forEach(function (f, i) { tone(f, 0.26, "sawtooth", 0.14, f * 0.92, i * 0.16); }); },
    tap: function () { buzz(8); },
  };
  root.GridAudio = A;
})(window);
