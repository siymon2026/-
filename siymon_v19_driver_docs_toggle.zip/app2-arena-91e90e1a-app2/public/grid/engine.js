/* SIYMON GRID BATTLE — rules engine (turn-based race with barriers).
   One file, two runtimes: the browser (solo + local matches) and Node (lib/grid-battle.js, the online referee).
   The server NEVER trusts a client's idea of the board: it runs this same code and only accepts one action per turn.
   Pure and deterministic: no DOM, no clock, no randomness.

   The game: a grid of squares, two balls. Player 0 starts at the bottom and must reach the TOP row, player 1 starts at
   the top and must reach the BOTTOM row. On your turn you do exactly ONE thing:
     - move your ball one square (up/down/left/right), or
     - place a barrier: a segment two squares long lying on the line between squares.
   A barrier blocks passing through it, never completely: an action that would leave either ball with no path to its
   goal is refused. There is no limit on the number of barriers. A ball cannot enter the other ball's square; it jumps
   over it when the square behind is free, otherwise it may step diagonally around it (Quoridor-style). */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.GridEngine = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  var DIRS = { U: { x: 0, y: -1 }, D: { x: 0, y: 1 }, L: { x: -1, y: 0 }, R: { x: 1, y: 0 } };
  var DIR_KEYS = ["U", "D", "L", "R"];
  var DEFAULTS = Object.freeze({
    w: 9, h: 11,
    turnMs: 30000,          // online only: a player who does not act in time gets an automatic step toward the goal
    maxRoundTurns: 160,     // total actions (both players) before a round is declared a draw: stops endless wall-building
  });

  function clampInt(v, lo, hi, d) { v = Math.round(Number(v)); return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; }
  function cfg(o) {
    o = o || {};
    return {
      w: clampInt(o.w, 5, 15, DEFAULTS.w), h: clampInt(o.h, 5, 17, DEFAULTS.h),
      turnMs: clampInt(o.turnMs, 5000, 120000, DEFAULTS.turnMs),
      maxRoundTurns: clampInt(o.maxRoundTurns, 40, 1000, DEFAULTS.maxRoundTurns),
    };
  }

  /** Mirrored (180 degree) starts, so neither side has a positional advantage. Player 0 = bottom, player 1 = top. */
  function startPositions(w, h) {
    var x = Math.floor(w / 2);
    return [{ x: x, y: h - 1 }, { x: w - 1 - x, y: 0 }];
  }
  function goalRow(h, pi) { return pi === 0 ? 0 : h - 1; }

  /** `first` = who moves first this round (callers alternate it so the first-move edge is shared). */
  function create(options, first) {
    var c = cfg(options), st = startPositions(c.w, c.h);
    return {
      cfg: c, w: c.w, h: c.h, turn: 0, cur: first === 1 ? 1 : 0,
      players: st.map(function (p, i) { return { x: p.x, y: p.y, goal: goalRow(c.h, i), placed: 0 }; }),
      hw: new Uint8Array(c.w * c.h), vw: new Uint8Array(c.w * c.h), walls: [],
      over: false, winner: null, reason: null,
    };
  }

  function clone(s) {
    return {
      cfg: s.cfg, w: s.w, h: s.h, turn: s.turn, cur: s.cur,
      players: s.players.map(function (p) { return { x: p.x, y: p.y, goal: p.goal, placed: p.placed }; }),
      hw: new Uint8Array(s.hw), vw: new Uint8Array(s.vw), walls: s.walls.map(function (q) { return q.slice(); }),
      over: s.over, winner: s.winner, reason: s.reason,
    };
  }

  /* ----- walls: hw[x,y] = horizontal barrier on the line between rows y and y+1, covering columns x and x+1.
           vw[x,y] = vertical barrier on the line between columns x and x+1, covering rows y and y+1. ----- */
  function wallAt(arr, w, h, x, y) { return x >= 0 && y >= 0 && x < w - 1 && y < h - 1 && arr[y * w + x] === 1; }

  /** Is the step from (x,y) in direction d impossible because of the edge or a barrier? (Pawns are not considered.) */
  function blocked(s, x, y, d) {
    var w = s.w, h = s.h;
    if (d === "U") return y === 0 || wallAt(s.hw, w, h, x, y - 1) || wallAt(s.hw, w, h, x - 1, y - 1);
    if (d === "D") return y === h - 1 || wallAt(s.hw, w, h, x, y) || wallAt(s.hw, w, h, x - 1, y);
    if (d === "L") return x === 0 || wallAt(s.vw, w, h, x - 1, y) || wallAt(s.vw, w, h, x - 1, y - 1);
    return x === w - 1 || wallAt(s.vw, w, h, x, y) || wallAt(s.vw, w, h, x, y - 1);
  }

  /** Steps needed from (x,y) to row goalY, walking around barriers (pawns ignored). -1 = unreachable. */
  function distFrom(s, x, y, goalY) {
    var w = s.w, h = s.h, seen = new Uint8Array(w * h), q = [x, y], qi = 0, d = 0, level = 1;
    if (y === goalY) return 0;
    seen[y * w + x] = 1;
    while (qi < q.length) {
      var end = q.length;
      d++;
      while (qi < end) {
        var cx = q[qi++], cy = q[qi++];
        for (var k = 0; k < 4; k++) {
          var dk = DIR_KEYS[k];
          if (blocked(s, cx, cy, dk)) continue;
          var nx = cx + DIRS[dk].x, ny = cy + DIRS[dk].y, id = ny * w + nx;
          if (seen[id]) continue;
          if (ny === goalY) return d;
          seen[id] = 1; q.push(nx, ny);
        }
      }
      level++;
    }
    return -1;
  }
  function dist(s, pi) { var p = s.players[pi]; return distFrom(s, p.x, p.y, p.goal); }

  /** Squares the player may step to now, including the jump / diagonal rules around the other ball. */
  function legalMoves(s, pi) {
    var me = s.players[pi], op = s.players[1 - pi], out = [], k, d, p;
    for (k = 0; k < 4; k++) {
      d = DIR_KEYS[k];
      if (blocked(s, me.x, me.y, d)) continue;
      var nx = me.x + DIRS[d].x, ny = me.y + DIRS[d].y;
      if (nx !== op.x || ny !== op.y) { out.push([nx, ny]); continue; }
      if (!blocked(s, nx, ny, d)) { out.push([nx + DIRS[d].x, ny + DIRS[d].y]); continue; }
      var sides = d === "U" || d === "D" ? ["L", "R"] : ["U", "D"];
      for (p = 0; p < 2; p++) if (!blocked(s, nx, ny, sides[p])) out.push([nx + DIRS[sides[p]].x, ny + DIRS[sides[p]].y]);
    }
    return out;
  }
  function isLegalMove(s, pi, x, y) { return legalMoves(s, pi).some(function (m) { return m[0] === x && m[1] === y; }); }

  /** Where would both balls stand (steps to goal) if this barrier were placed? null = the barrier is not allowed.
   *  Returns { d: [d0, d1] } or { code } so callers (bot, UI) can show WHY. */
  function wallEval(s, o, x, y) {
    var w = s.w, h = s.h;
    if ((o !== "h" && o !== "v") || !Number.isInteger(x) || !Number.isInteger(y) || x < 0 || y < 0 || x > w - 2 || y > h - 2) return { code: "BAD_WALL" };
    var a = o === "h" ? s.hw : s.vw, b = o === "h" ? s.vw : s.hw, i = y * w + x;
    if (a[i]) return { code: "OVERLAP" };
    if (o === "h" ? (x > 0 && a[i - 1]) || (x < w - 2 && a[i + 1]) : (y > 0 && a[i - w]) || (y < h - 2 && a[i + w])) return { code: "OVERLAP" };
    if (b[i]) return { code: "CROSS" };
    a[i] = 1;
    var d0 = dist(s, 0), d1 = dist(s, 1);
    a[i] = 0;
    if (d0 < 0 || d1 < 0) return { code: "BLOCKS_PATH" };
    return { d: [d0, d1] };
  }

  /** The only way a board changes. a = { t:"m", x, y } (move) or { t:"w", o:"h"|"v", x, y } (barrier). */
  function act(s, pi, a) {
    if (s.over) return { ok: false, code: "OVER" };
    if (pi !== s.cur) return { ok: false, code: "NOT_YOUR_TURN" };
    if (!a || typeof a !== "object") return { ok: false, code: "BAD_ACTION" };
    var p = s.players[pi];
    if (a.t === "m") {
      if (!Number.isInteger(a.x) || !Number.isInteger(a.y) || !isLegalMove(s, pi, a.x, a.y)) return { ok: false, code: "ILLEGAL_MOVE" };
      p.x = a.x; p.y = a.y;
      if (p.y === p.goal) { s.over = true; s.winner = pi; s.reason = "goal"; }
    } else if (a.t === "w") {
      var ev = wallEval(s, a.o, a.x, a.y);
      if (!ev.d) return { ok: false, code: ev.code };
      (a.o === "h" ? s.hw : s.vw)[a.y * s.w + a.x] = 1;
      s.walls.push([a.o, a.x, a.y, pi]); p.placed++;
    } else return { ok: false, code: "BAD_ACTION" };
    s.turn++;
    if (!s.over) {
      s.cur = 1 - pi;
      if (s.turn >= s.cfg.maxRoundTurns) { s.over = true; s.winner = -1; s.reason = "time"; }
    }
    return { ok: true };
  }

  /** The automatic action for a player who ran out of time: one step along a shortest path (never a barrier). */
  function autoMove(s, pi) {
    var mv = legalMoves(s, pi), best = null, bd = 1e9, i;
    for (i = 0; i < mv.length; i++) { var d = distFrom(s, mv[i][0], mv[i][1], s.players[pi].goal); if (d >= 0 && d < bd) { bd = d; best = mv[i]; } }
    if (!best) best = mv[0];
    return best ? { t: "m", x: best[0], y: best[1] } : null;
  }

  /** What goes over the wire / to a bot: everything is public in this game (no hidden hands), still as plain data. */
  function publicView(s) {
    return { w: s.w, h: s.h, cfg: s.cfg, turn: s.turn, cur: s.cur, pos: s.players.map(function (p) { return [p.x, p.y]; }), walls: s.walls.map(function (q) { return q.slice(); }),
      placed: s.players.map(function (p) { return p.placed; }) };
  }
  /** Rebuild a full engine state from a public view (client after a server event, bot before thinking). */
  function fromView(v) {
    var c = cfg(v.cfg || { w: v.w, h: v.h }), s = create(c, v.cur);
    s.w = v.w; s.h = v.h; s.hw = new Uint8Array(s.w * s.h); s.vw = new Uint8Array(s.w * s.h);
    s.turn = v.turn | 0; s.cur = v.cur === 1 ? 1 : 0;
    s.players = [0, 1].map(function (i) { return { x: v.pos[i][0], y: v.pos[i][1], goal: goalRow(v.h, i), placed: v.placed ? v.placed[i] | 0 : 0 }; });
    s.walls = [];
    (v.walls || []).forEach(function (q) { (q[0] === "h" ? s.hw : s.vw)[q[2] * s.w + q[1]] = 1; s.walls.push([q[0], q[1], q[2], q[3] | 0]); });
    return s;
  }

  return { DIRS: DIRS, DIR_KEYS: DIR_KEYS, DEFAULTS: DEFAULTS, cfg: cfg, startPositions: startPositions, goalRow: goalRow, create: create, clone: clone,
    blocked: blocked, distFrom: distFrom, dist: dist, legalMoves: legalMoves, isLegalMove: isLegalMove, wallEval: wallEval, act: act, autoMove: autoMove,
    publicView: publicView, fromView: fromView };
});
