/* SIYMON GRID BATTLE — texts (ar / fr / en). The language key is shared with the rest of the app (siymon_lang_v1). */
(function (root) {
  "use strict";
  var T = {
    ar: {
      tag: "سباق على الشبكة: تقدّم وأعرقل خصمك", play: "العب الآن", back: "رجوع", cancel: "إلغاء", close: "إغلاق", retry: "إعادة المحاولة", ok: "حسناً", copy: "نسخ", copied: "تم النسخ", share: "مشاركة",
      leaderboard: "لوحة الترتيب", profile: "ملفي", settings: "الإعدادات", home: "الرئيسية", resume: "متابعة", pause: "إيقاف مؤقت", quit: "خروج",
      mode_title: "اختر نمط اللعب", solo: "ضد الحاسوب", solo_d: "تحدَّ بوت ذكياً بثلاثة مستويات", local: "لاعبان على جهاز واحد", local_d: "تجلسان وجهاً لوجه وتتناوبان على نفس الشاشة",
      online: "أونلاين", online_d: "ضد لاعبين حقيقيين مع ترتيب ونقاط", online_off: "اللعب الأونلاين متوقف حالياً",
      diff_title: "اختر المستوى", easy: "سهل", medium: "متوسط", hard: "صعب", easy_d: "بوت يخطئ أحياناً — مناسب للتعلّم", medium_d: "يحسب الطريق ويضع الحواجز في الوقت المناسب", hard_d: "يقرأ ردّك قبل أن يلعب ويعطّل طريقك بذكاء",
      lobby_title: "اللعب أونلاين", quick: "بحث عن خصم", quick_d: "مباراة مصنّفة ضد لاعب بمستواك", create: "إنشاء غرفة خاصة", create_d: "ادعُ صديقاً برمز (غير مصنّفة)", join: "انضمام برمز", join_d: "أدخل رمز الغرفة الذي وصلك",
      join_title: "الانضمام إلى غرفة", code_ph: "رمز الغرفة", code_hint: "6 أحرف وأرقام", join_btn: "انضم",
      searching: "جارٍ البحث عن خصم…", searching_d: "نبحث عن لاعب حقيقي قريب من مستواك", elapsed: "منذ", no_opp: "لم نجد خصماً الآن", no_opp_d: "لا نستعمل لاعبين وهميين. جرّب لاحقاً أو العب ضد البوت.", vs_bot: "العب ضد البوت", try_again: "ابحث من جديد",
      room_title: "غرفتك الخاصة", room_wait: "بانتظار انضمام صديقك…", room_code: "رمز الدعوة", room_share: "انضم إلى مباراتي في Siymon Grid Battle برمز: ",
      you: "أنت", bot: "البوت", p1: "اللاعب 1", p2: "اللاعب 2", round: "الجولة", best_of: "الأفضل من", start: "انطلق!",
      r_win: "فزت بالجولة", r_lose: "خسرت الجولة", r_draw: "تعادل", r_p_win: "فاز {n} بالجولة", why_goal: "وصل {n} إلى الهدف", why_time: "انتهت الجولة دون فائز",
      m_move: "تحريك", m_wall: "حاجز", confirm: "تأكيد", hint_move: "اضغط مربعاً مضيئاً لتحريك كرتك", hint_wall: "اضغط على الخط الذي تريد وضع الحاجز عليه", hint_confirm: "اضغط تأكيد لوضع الحاجز", bad_block: "لا يجوز: الحاجز يغلق الطريق على أحد اللاعبين", bad_overlap: "لا يمكن وضع الحاجز هنا", your_turn: "دورك", opp_turn: "دور الخصم", auto_moved: "انتهى وقتك — تحركت كرتك خطوة تلقائياً",
      victory: "فوز!", defeat: "خسارة", draw: "تعادل", p_wins: "فاز {n}", match_over: "انتهت المباراة", rating: "التصنيف", points: "النقاط", streak: "سلسلة الانتصارات", rank_now: "رتبتك",
      unranked: "مباراة غير مصنّفة", unranked_why: "لا تغيّر التصنيف", pair_cap: "وصلتما الحد اليومي للمباريات المصنّفة بين الحسابين نفسيهما", rematch: "إعادة المباراة", rematch_wait: "بانتظار موافقة الخصم…", play_again: "العب مجدداً", opp_left: "غادر الخصم الغرفة",
      aborted: "أُلغيت المباراة دون نتيجة", forfeit_win: "غادر الخصم — فزت بالمباراة", forfeit_lose: "خسرت المباراة بسبب الانقطاع",
      lb_empty: "لا توجد مباريات مصنّفة بعد. كن أول المتصدرين!", lb_me: "ترتيبك", lb_you: "(أنت)", lb_players: "لاعب", lb_login: "سجّل الدخول لتظهر في الترتيب",
      stats: "الإحصائيات", played: "المباريات", wins: "الانتصارات", losses: "الهزائم", draws: "التعادل", win_rate: "نسبة الفوز", best_streak: "أفضل سلسلة", peak: "أعلى تصنيف",
      history: "سجل المباريات", no_history: "لا توجد مباريات أونلاين بعد", to_next: "تبقّى {n} للوصول إلى {t}", max_tier: "وصلت إلى أعلى رتبة", practice: "التدريب على هذا الجهاز", practice_note: "مباريات الحاسوب والجهاز الواحد لا تدخل في الترتيب ولا في النقاط.",
      s_sound: "الصوت", s_volume: "مستوى الصوت", s_vibrate: "الاهتزاز", s_controls: "طريقة التحكم", c_both: "أزرار + سحب", c_btn: "أزرار فقط", c_swipe: "سحب فقط", s_pad: "موضع الأزرار", left: "يسار", right: "يمين", s_quality: "جودة الرسوم", q_auto: "تلقائي", q_high: "عالية", q_low: "خفيفة", s_lang: "اللغة",
      
      reconnecting: "إعادة الاتصال…", opp_offline: "انقطع اتصال الخصم — ينتظر {n} ث", you_offline: "انقطع اتصالك", conn_lost: "تعذّر الاتصال بالخادم",
      login_t: "سجّل الدخول للعب أونلاين", login_txt: "الترتيب والنقاط مرتبطان بحسابك في Siymon.", login_btn: "تسجيل الدخول", leave_q: "مغادرة المباراة؟", leave_online: "مغادرتك أثناء المباراة تُحتسب هزيمة.", leave_ok: "غادر",
      e_room: "الغرفة غير موجودة أو ممتلئة", e_in_room: "أنت في مباراة بالفعل", e_disabled: "هذه الميزة متوقفة حالياً", e_generic: "حدث خطأ، حاول مرة أخرى", e_code: "أدخل رمزاً من 6 خانات",
      bronze: "برونزي", silver: "فضي", gold: "ذهبي", platinum: "بلاتيني", diamond: "ماسي", rank: "الرتبة", player: "اللاعب", signin_hint: "الدخول مطلوب للمباريات الأونلاين فقط",
    },
    fr: {
      tag: "Une course sur la grille : avancez, ralentissez l’autre", play: "Jouer", back: "Retour", cancel: "Annuler", close: "Fermer", retry: "Réessayer", ok: "OK", copy: "Copier", copied: "Copié", share: "Partager",
      leaderboard: "Classement", profile: "Mon profil", settings: "Réglages", home: "Accueil", resume: "Reprendre", pause: "Pause", quit: "Quitter",
      mode_title: "Choisir un mode", solo: "Contre l’ordinateur", solo_d: "Un bot intelligent, trois niveaux", local: "Deux joueurs, un appareil", local_d: "Face à face, chacun son tour sur le même écran",
      online: "En ligne", online_d: "Contre de vrais joueurs, classement et points", online_off: "Le jeu en ligne est désactivé pour le moment",
      diff_title: "Choisir le niveau", easy: "Facile", medium: "Moyen", hard: "Difficile", easy_d: "Un bot qui se trompe parfois — pour apprendre", medium_d: "Compte les chemins et pose ses barrières à propos", hard_d: "Anticipe votre réponse et vous ralentit avec malice",
      lobby_title: "Jouer en ligne", quick: "Trouver un adversaire", quick_d: "Match classé contre un joueur de votre niveau", create: "Créer un salon privé", create_d: "Invitez un ami avec un code (non classé)", join: "Rejoindre avec un code", join_d: "Saisissez le code reçu",
      join_title: "Rejoindre un salon", code_ph: "Code du salon", code_hint: "6 lettres ou chiffres", join_btn: "Rejoindre",
      searching: "Recherche d’un adversaire…", searching_d: "Nous cherchons un vrai joueur proche de votre niveau", elapsed: "depuis", no_opp: "Aucun adversaire pour l’instant", no_opp_d: "Nous n’utilisons pas de faux joueurs. Réessayez plus tard ou jouez contre le bot.", vs_bot: "Jouer contre le bot", try_again: "Chercher encore",
      room_title: "Votre salon privé", room_wait: "En attente de votre ami…", room_code: "Code d’invitation", room_share: "Rejoins mon match Siymon Grid Battle avec le code : ",
      you: "Vous", bot: "Bot", p1: "Joueur 1", p2: "Joueur 2", round: "Manche", best_of: "Au meilleur de", start: "GO !",
      r_win: "Manche gagnée", r_lose: "Manche perdue", r_draw: "Égalité", r_p_win: "{n} gagne la manche", why_goal: "{n} atteint l’arrivée", why_time: "Manche sans vainqueur",
      m_move: "Avancer", m_wall: "Barrière", confirm: "Valider", hint_move: "Touchez une case éclairée pour déplacer votre bille", hint_wall: "Touchez la ligne où poser la barrière", hint_confirm: "Touchez Valider pour poser la barrière", bad_block: "Interdit : la barrière fermerait le chemin d’un joueur", bad_overlap: "Impossible de poser la barrière ici", your_turn: "Votre tour", opp_turn: "Tour de l’adversaire", auto_moved: "Temps écoulé — votre bille a avancé d’une case",
      victory: "Victoire !", defeat: "Défaite", draw: "Égalité", p_wins: "{n} gagne", match_over: "Match terminé", rating: "Classement", points: "Points", streak: "Série de victoires", rank_now: "Votre rang",
      unranked: "Match non classé", unranked_why: "N’affecte pas le classement", pair_cap: "Limite quotidienne de matchs classés entre ces deux comptes atteinte", rematch: "Revanche", rematch_wait: "En attente de l’adversaire…", play_again: "Rejouer", opp_left: "L’adversaire a quitté le salon",
      aborted: "Match annulé sans résultat", forfeit_win: "L’adversaire est parti — match gagné", forfeit_lose: "Match perdu à cause de la déconnexion",
      lb_empty: "Aucun match classé pour l’instant. Soyez le premier !", lb_me: "Votre rang", lb_you: "(vous)", lb_players: "joueurs", lb_login: "Connectez-vous pour apparaître au classement",
      stats: "Statistiques", played: "Matchs", wins: "Victoires", losses: "Défaites", draws: "Égalités", win_rate: "Taux de victoire", best_streak: "Meilleure série", peak: "Meilleur classement",
      history: "Historique", no_history: "Aucun match en ligne pour l’instant", to_next: "Encore {n} pour atteindre {t}", max_tier: "Rang maximal atteint", practice: "Entraînement sur cet appareil", practice_note: "Les matchs contre le bot ou à deux ne comptent ni pour le classement ni pour les points.",
      s_sound: "Son", s_volume: "Volume", s_vibrate: "Vibration", s_controls: "Contrôles", c_both: "Boutons + glisser", c_btn: "Boutons seulement", c_swipe: "Glisser seulement", s_pad: "Position des boutons", left: "Gauche", right: "Droite", s_quality: "Qualité graphique", q_auto: "Auto", q_high: "Élevée", q_low: "Légère", s_lang: "Langue",
      
      reconnecting: "Reconnexion…", opp_offline: "Adversaire déconnecté — attente {n} s", you_offline: "Vous êtes déconnecté", conn_lost: "Serveur injoignable",
      login_t: "Connectez-vous pour jouer en ligne", login_txt: "Classement et points sont liés à votre compte Siymon.", login_btn: "Se connecter", leave_q: "Quitter le match ?", leave_online: "Quitter en cours de match compte comme une défaite.", leave_ok: "Quitter",
      e_room: "Salon introuvable ou complet", e_in_room: "Vous êtes déjà dans un match", e_disabled: "Fonction désactivée pour le moment", e_generic: "Une erreur est survenue, réessayez", e_code: "Saisissez un code à 6 caractères",
      bronze: "Bronze", silver: "Argent", gold: "Or", platinum: "Platine", diamond: "Diamant", rank: "Rang", player: "Joueur", signin_hint: "La connexion n’est requise que pour le jeu en ligne",
    },
    en: {
      tag: "Race across the grid: advance, and slow your rival", play: "Play", back: "Back", cancel: "Cancel", close: "Close", retry: "Retry", ok: "OK", copy: "Copy", copied: "Copied", share: "Share",
      leaderboard: "Leaderboard", profile: "My profile", settings: "Settings", home: "Home", resume: "Resume", pause: "Pause", quit: "Quit",
      mode_title: "Choose a mode", solo: "Vs computer", solo_d: "A smart bot with three levels", local: "Two players, one device", local_d: "Sit face to face and take turns on one screen",
      online: "Online", online_d: "Real players, ranking and points", online_off: "Online play is switched off right now",
      diff_title: "Choose a level", easy: "Easy", medium: "Medium", hard: "Hard", easy_d: "A bot that slips up — good for learning", medium_d: "Counts paths and places barriers at the right moment", hard_d: "Looks at your reply before it plays and slows you down cleverly",
      lobby_title: "Play online", quick: "Find an opponent", quick_d: "Ranked match against a player of your level", create: "Create a private room", create_d: "Invite a friend with a code (unranked)", join: "Join with a code", join_d: "Enter the room code you received",
      join_title: "Join a room", code_ph: "Room code", code_hint: "6 letters or digits", join_btn: "Join",
      searching: "Looking for an opponent…", searching_d: "Searching for a real player near your level", elapsed: "for", no_opp: "No opponent right now", no_opp_d: "We never use fake players. Try again later or play the bot.", vs_bot: "Play the bot", try_again: "Search again",
      room_title: "Your private room", room_wait: "Waiting for your friend…", room_code: "Invite code", room_share: "Join my Siymon Grid Battle match with code: ",
      you: "You", bot: "Bot", p1: "Player 1", p2: "Player 2", round: "Round", best_of: "Best of", start: "GO!",
      r_win: "Round won", r_lose: "Round lost", r_draw: "Draw", r_p_win: "{n} wins the round", why_goal: "{n} reached the goal", why_time: "Round ended with no winner",
      m_move: "Move", m_wall: "Barrier", confirm: "Confirm", hint_move: "Tap a lit square to move your ball", hint_wall: "Tap the line where you want the barrier", hint_confirm: "Tap Confirm to place the barrier", bad_block: "Not allowed: that barrier would close a player's path", bad_overlap: "A barrier cannot go here", your_turn: "Your turn", opp_turn: "Opponent's turn", auto_moved: "Time is up — your ball stepped forward automatically",
      victory: "Victory!", defeat: "Defeat", draw: "Draw", p_wins: "{n} wins", match_over: "Match over", rating: "Rating", points: "Points", streak: "Win streak", rank_now: "Your rank",
      unranked: "Unranked match", unranked_why: "Does not change your rating", pair_cap: "Daily limit of ranked games between the same two accounts reached", rematch: "Rematch", rematch_wait: "Waiting for your opponent…", play_again: "Play again", opp_left: "Your opponent left the room",
      aborted: "Match cancelled with no result", forfeit_win: "Opponent left — you win the match", forfeit_lose: "Match lost because of the disconnection",
      lb_empty: "No ranked matches yet. Be the first on top!", lb_me: "Your rank", lb_you: "(you)", lb_players: "players", lb_login: "Sign in to appear on the leaderboard",
      stats: "Statistics", played: "Matches", wins: "Wins", losses: "Losses", draws: "Draws", win_rate: "Win rate", best_streak: "Best streak", peak: "Peak rating",
      history: "Match history", no_history: "No online matches yet", to_next: "{n} more to reach {t}", max_tier: "Top rank reached", practice: "Practice on this device", practice_note: "Bot and same-device games never count for ranking or points.",
      s_sound: "Sound", s_volume: "Volume", s_vibrate: "Vibration", s_controls: "Controls", c_both: "Buttons + swipe", c_btn: "Buttons only", c_swipe: "Swipe only", s_pad: "Button position", left: "Left", right: "Right", s_quality: "Graphics quality", q_auto: "Auto", q_high: "High", q_low: "Light", s_lang: "Language",
      
      reconnecting: "Reconnecting…", opp_offline: "Opponent disconnected — waiting {n}s", you_offline: "You are disconnected", conn_lost: "Cannot reach the server",
      login_t: "Sign in to play online", login_txt: "Ranking and points are tied to your Siymon account.", login_btn: "Sign in", leave_q: "Leave the match?", leave_online: "Leaving during a match counts as a loss.", leave_ok: "Leave",
      e_room: "Room not found or already full", e_in_room: "You are already in a match", e_disabled: "This feature is switched off right now", e_generic: "Something went wrong, try again", e_code: "Enter a 6-character code",
      bronze: "Bronze", silver: "Silver", gold: "Gold", platinum: "Platinum", diamond: "Diamond", rank: "Rank", player: "Player", signin_hint: "Sign-in is only needed for online matches",
    },
  };
  var LANG_KEY = "siymon_lang_v1", lang = "ar";
  try { lang = localStorage.getItem(LANG_KEY) || "ar"; } catch (e) {}
  if (!T[lang]) lang = "ar";
  function t(k, vars) {
    var s = (T[lang] && T[lang][k]) || T.en[k] || k;
    if (vars) for (var v in vars) s = s.split("{" + v + "}").join(vars[v]);
    return s;
  }
  function set(l) { if (!T[l]) return; lang = l; try { localStorage.setItem(LANG_KEY, l); } catch (e) {} var h = document.documentElement; h.lang = l; h.dir = l === "ar" ? "rtl" : "ltr"; }
  root.GridI18n = { t: t, set: set, get: function () { return lang; }, dict: T, isRtl: function () { return lang === "ar"; } };
})(window);
