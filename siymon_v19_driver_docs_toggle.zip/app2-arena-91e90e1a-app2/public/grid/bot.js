/* SIYMON GRID BATTLE — bot.
   FAIR PLAY: the bot receives GridEngine.publicView() only and plays by the same rules (one action per turn, no
   barrier that closes a path). Difficulty differs by how many options it weighs and how often it errs, never by cheating.
   "Learning": inside one match the bot keeps a small memory (how many rounds it lost, how often the human builds
   barriers) and becomes a little more careful with its own path. It is adaptation, not a trained model, and it resets
   with the match. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory(require("./engine.js"));
  else root.GridBot = factory(root.GridEngine);
})(typeof self !== "undefined" ? self : this, function (E) {
  "use strict";

  var LEVELS = {
    easy:   { random: 0.30, wallGain: 3, wallChance: 0.35, look: false },
    medium: { random: 0.14, wallGain: 2, wallChance: 1,    look: false },
    hard:   { random: 0,    wallGain: 2, wallChance: 1,    look: true  },
  };

  function newMemory() { return { rounds: 0, lost: 0, humanActs: 0, humanWalls: 0, caution: 0 }; }
  function observeHuman(mem, a) { if (!mem || !a) return; mem.humanActs++; if (a.t === "w") mem.humanWalls++; }
  function adapt(mem, info) {
    if (!mem) return; mem.rounds++;
    if (info && info.botLost) mem.lost++;
    var wallRate = mem.humanActs ? mem.humanWalls / mem.humanActs : 0;
    mem.caution = Math.min(0.4, mem.lost * 0.1 + (wallRate > 0.4 ? 0.1 : 0));
  }

  /** Every legal action with the two distances it would leave: { a, mine, theirs }. */
  function options(s, me, wallsToo) {
    var op = 1 - me, goal = s.players[me].goal, out = [], mv = E.legalMoves(s, me), i, theirs = E.dist(s, op);
    for (i = 0; i < mv.length; i++) out.push({ a: { t: "m", x: mv[i][0], y: mv[i][1] }, mine: E.distFrom(s, mv[i][0], mv[i][1], goal), theirs: theirs });
    if (wallsToo) {
      for (var o = 0; o < 2; o++) {
        var ot = o ? "v" : "h";
        for (var y = 0; y <= s.h - 2; y++) for (var x = 0; x <= s.w - 2; x++) {
          var ev = E.wallEval(s, ot, x, y);
          if (ev.d) out.push({ a: { t: "w", o: ot, x: x, y: y }, mine: ev.d[me], theirs: ev.d[op] });
        }
      }
    }
    return out;
  }
  function score(opt, caution) { return opt.theirs - opt.mine * (1 + (caution || 0)); }

  /** Pick one action. view = GridEngine.publicView(state); slot = the bot's seat; rnd() in [0,1). */
  function decide(view, slot, level, mem, rnd) {
    rnd = rnd || Math.random;
    var L = LEVELS[level] || LEVELS.medium, s = E.fromView(view), caution = mem ? mem.caution : 0;
    var moves = options(s, slot, false);
    if (!moves.length) return null;
    moves.sort(function (a, b) { return a.mine - b.mine; });
    var bestMove = moves[0];
    if (bestMove.mine === 0) return bestMove.a;                      // the goal is one step away: take it
    if (L.random && rnd() < L.random) { var near = moves.filter(function (m) { return m.mine <= bestMove.mine + 1; }); return near[Math.floor(rnd() * near.length)].a; }

    var myD = E.dist(s, slot), opD = E.dist(s, 1 - slot);
    // an easy bot only thinks about barriers some of the time, and mostly when it is about to lose the race
    var useWalls = L.wallChance >= 1 || rnd() < L.wallChance || opD <= 2;
    if (!useWalls) return bestMove.a;
    var all = options(s, slot, true).filter(function (o) { return o.a.t === "w"; });
    // Stepping forward is worth `moveScore` (their path minus mine, after my step). A barrier must beat it by `wallGain - 1`.
    // But when the plain race is already lost (moveScore < 1: they arrive first if we both just walk), a barrier that merely
    // equals stepping is better than certain defeat, so it is allowed.
    var moveScore = score(bestMove, caution), need = moveScore < 1 ? moveScore : moveScore + (L.wallGain - 1);
    var cands = all.filter(function (o) { return o.theirs - opD >= 1 && score(o, caution) >= need; });
    if (!cands.length) return bestMove.a;
    cands.sort(function (a, b) { return score(b, caution) - score(a, caution); });
    if (!L.look) { var top = cands.slice(0, 3); return top[Math.floor(rnd() * top.length)].a; }

    // hard: look one reply ahead on the best few candidates (and on the plain step) and keep the one that survives it best
    var pool = cands.slice(0, 6).concat([bestMove]), best = null, bv = -1e9;
    for (var i = 0; i < pool.length; i++) {
      var t = E.clone(s); var r = E.act(t, slot, pool[i].a); if (!r.ok) continue;
      var v;
      if (t.over) v = t.winner === slot ? 1e6 : -1e6;
      else {
        var replies = options(t, 1 - slot, true), worst = 1e9;
        for (var j = 0; j < replies.length; j++) { worst = Math.min(worst, replies[j].mine - replies[j].theirs); }   // their best reply minimises (their path - my path)
        v = worst;
      }
      if (v > bv) { bv = v; best = pool[i]; }
    }
    return (best || bestMove).a;
  }

  return { LEVELS: LEVELS, newMemory: newMemory, observeHuman: observeHuman, adapt: adapt, decide: decide };
});
