/* SIYMON GRID BATTLE — UI + match controller.
   Solo and local matches run entirely in the browser (practice, never ranked). Online matches are refereed by the server:
   this file only sends one action per turn (a move or a barrier) and draws what the server reports. */
(function () {
  "use strict";
  var E = GridEngine, B = GridBot, T = GridI18n, A = GridAudio, N = GridNet;
  var t = T.t;
  var SET_KEY = "siymon_grid_settings_v1", PRACTICE_KEY = "siymon_grid_practice_v1";

  /* ------------------------------------------------------------------ helpers */
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function load(key, def) { try { var v = JSON.parse(localStorage.getItem(key) || "null"); return v && typeof v === "object" ? v : def; } catch (e) { return def; } }
  function save(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch (e) {} }
  var settings = Object.assign({ sound: true, volume: 0.7, vibrate: true, quality: "auto" }, load(SET_KEY, {}));
  var practice = Object.assign({ played: 0, wins: 0, losses: 0, draws: 0 }, load(PRACTICE_KEY, {}));
  function applySettings() { A.configure({ sound: settings.sound, volume: settings.volume, vibrate: settings.vibrate }); save(SET_KEY, settings); }
  applySettings();

  var ICON = {
    back: '<path d="M15 5l-7 7 7 7"/>', chev: '<path d="M9 5l7 7-7 7"/>',
    bot: '<rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0M16 5.5a3 3 0 0 1 0 5.5M17.5 14.2A5.5 5.5 0 0 1 21 19"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0V4Z"/><path d="M8 6H5a3 3 0 0 0 3 4M16 6h3a3 3 0 0 1-3 4M12 13v4M8.5 20h7M10 17h4"/>',
    user: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>',
    pause: '<path d="M9 5v14M15 5v14"/>', play: '<path d="M8 5l11 7-11 7V5Z"/>', exit: '<path d="M10 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4M15 8l4 4-4 4M19 12H9"/>',
    U: '<path d="M12 19V6M6 11l6-6 6 6"/>', D: '<path d="M12 5v13M6 13l6 6 6-6"/>', L: '<path d="M19 12H6M11 6l-6 6 6 6"/>', R: '<path d="M5 12h13M13 6l6 6-6 6"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>', bolt: '<path d="M13 3L5 13h6l-1 8 8-10h-6l1-8Z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l8-8M16 7l3 3"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',
    redo: '<path d="M4 12a8 8 0 0 1 14-5l2 2M20 4v5h-5M20 12a8 8 0 0 1-14 5l-2-2M4 20v-5h5"/>',
    ball: '<circle cx="12" cy="12" r="5"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3"/>', wall: '<rect x="3" y="9.5" width="18" height="5" rx="2.5"/>', check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
  };
  function nm(x) { return "<bdi>" + esc(x) + "</bdi>"; }     // names/numbers keep their own direction inside Arabic text
  function ic(n, cls) { return '<svg class="i ' + (cls || "") + '" viewBox="0 0 24 24" aria-hidden="true">' + ICON[n] + "</svg>"; }
  var TIER_COLOR = { bronze: "#D39A6A", silver: "#C3CCD6", gold: "#EBC25B", platinum: "#9ED8E8", diamond: "#B9A8FF" };
  function badge(tier, cls) {
    var c = TIER_COLOR[tier] || "#5DD62C";
    return '<svg class="g-badge ' + (cls || "") + '" viewBox="0 0 48 48" aria-label="' + esc(t(tier)) + '"><path d="M24 4l16 6v12c0 10-7 18-16 22C15 40 8 32 8 22V10l16-6Z" fill="' + c + '" fill-opacity=".16" stroke="' + c + '" stroke-width="2.5" stroke-linejoin="round"/><path d="M24 15l2.7 5.6 6.1.8-4.5 4.2 1.1 6-5.4-3-5.4 3 1.1-6-4.5-4.2 6.1-.8L24 15Z" fill="' + c + '"/></svg>';
  }
  var toastTimer;
  function toast(msg) { var el = $("gToast"); el.textContent = msg; el.classList.add("on"); clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.classList.remove("on"); }, 2600); }
  function errMsg(e) { var c = e && e.code; return c === "ROOM_NOT_FOUND" ? t("e_room") : c === "ALREADY_IN_ROOM" ? t("e_in_room") : c === "DISABLED" ? t("e_disabled") : t("e_generic"); }
  var coarse = root_matches("(pointer:coarse)");
  function root_matches(q) { try { return window.matchMedia(q).matches; } catch (e) { return false; } }

  /* ------------------------------------------------------------------- state */
  var S = { screen: "home", hist: [], me: null, cfg: null, lb: null, queue: { state: "idle", since: 0 }, room: null, result: null, diff: "medium", mode: null, loadingMe: false, netState: "idle", rematchWaiting: false, queueTimer: null, last: null };
  var M = null;        // the running match
  var R = null;        // renderer
  N.loadToken();

  /* -------------------------------------------------------------- bottom sheet */
  function sheet(html, onclick) {
    var sh = $("gSheet"), sc = $("gScrim");
    sh.innerHTML = '<div class="grab"></div>' + html; sh.hidden = false; sc.classList.remove("hidden");
    sh.onclick = function (e) { var b = e.target.closest("[data-sh]"); if (b) { var k = b.getAttribute("data-sh"); closeSheet(); if (onclick) onclick(k); } };
  }
  function closeSheet() { $("gSheet").hidden = true; $("gScrim").classList.add("hidden"); }
  $("gScrim").addEventListener("click", function () { closeSheet(); if (M && M.status === "paused" && M.mode !== "online") resumeLocal(); });

  /* ------------------------------------------------------------------- views */
  function heroArt() {
    return '<svg class="g-hero-art" viewBox="0 0 200 120" aria-hidden="true"><defs><filter id="gl"><feGaussianBlur stdDeviation="2.2"/></filter></defs>' +
      '<rect width="200" height="120" rx="14" fill="#0B0D0A"/>' + gridLines() +
      '<g stroke-linecap="round" fill="none"><path d="M40 60H80M100 40V80M120 80H160M60 30H100" stroke="#5DD62C" stroke-width="5" opacity=".95"/><path d="M80 90H120M150 40V80M30 90H70" stroke="#FF8A3D" stroke-width="5" opacity=".95"/></g>' +
      '<circle cx="90" cy="105" r="7" fill="#5DD62C" opacity=".45" filter="url(#gl)"/><circle cx="90" cy="105" r="6" fill="#E4FFD3" stroke="#5DD62C" stroke-width="2"/>' +
      '<circle cx="110" cy="15" r="7" fill="#FF8A3D" opacity=".45" filter="url(#gl)"/><circle cx="110" cy="15" r="6" fill="#FFE3CF" stroke="#FF8A3D" stroke-width="2"/></svg>';
  }
  function gridLines() { var s = '<g stroke="rgba(248,248,248,.07)" stroke-width=".6">', i; for (i = 10; i < 200; i += 10) s += '<path d="M' + i + ' 0V120"/>'; for (i = 10; i < 120; i += 10) s += '<path d="M0 ' + i + 'H200"/>'; return s + "</g>"; }
  function passCard() {
    var p = S.me && S.me.profile;
    if (!N.hasToken()) return '<div class="g-card"><div class="g-pass"><div class="info"><div class="nm">' + esc(t("login_t")) + '</div><div class="rt">' + esc(t("signin_hint")) + '</div></div></div><a class="g-btn ghost sm press" style="margin-top:10px" href="/orders/?next=' + encodeURIComponent("/grid/") + '">' + esc(t("login_btn")) + "</a></div>";
    if (!p) return '<div class="g-card"><div class="g-pass"><div class="info"><div class="nm">…</div></div></div></div>';
    return '<div class="g-card"><div class="g-pass">' + badge(p.tier.id) + '<div class="info"><div class="nm">' + nm(p.name) + '</div><div class="rt">' + esc(t(p.tier.id)) + " · " + esc(t("rating")) + " " + nm(p.rating) + '</div></div></div>' +
      '<div class="g-mini"><div><b class="num">' + p.wins + "</b><small>" + esc(t("wins")) + '</small></div><div><b class="num">' + p.losses + "</b><small>" + esc(t("losses")) + '</small></div><div><b class="num">' + p.streak + "</b><small>" + esc(t("streak")) + "</small></div></div></div>";
  }
  var VIEWS = {
    home: function () {
      return '<section class="g-screen"><div class="g-hero">' + heroArt() + '<h2>GRID BATTLE</h2><p>' + esc(t("tag")) + "</p></div>" + passCard() +
        '<button class="g-btn press" data-act="go" data-to="modes" style="margin-bottom:12px">' + ic("play") + esc(t("play")) + "</button>" +
        '<div class="g-row3"><button class="g-tile press" data-act="go" data-to="lb">' + ic("trophy") + "<span>" + esc(t("leaderboard")) + '</span></button><button class="g-tile press" data-act="go" data-to="profile">' + ic("user") + "<span>" + esc(t("profile")) + '</span></button><button class="g-tile press" data-act="go" data-to="settings">' + ic("gear") + "<span>" + esc(t("settings")) + "</span></button></div></section>";
    },
    modes: function () {
      var off = S.cfg && !S.cfg.onlineEnabled;
      return '<section class="g-screen"><h1 class="g-h">' + esc(t("mode_title")) + '</h1><div class="g-stack">' +
        mode("solo", "bot", t("solo"), t("solo_d")) + mode("local", "users", t("local"), t("local_d")) +
        '<button class="g-mode press" data-act="mode" data-m="online"' + (off ? " disabled" : "") + '><span class="ic">' + ic("globe") + '</span><span class="tx"><b>' + esc(t("online")) + "</b><span>" + esc(off ? t("online_off") : t("online_d")) + "</span>" + (!N.hasToken() ? '<span class="g-lock">' + ic("lock") + esc(t("signin_hint")) + "</span>" : "") + '</span><span class="go">' + ic("chev") + "</span></button></div></section>";
      function mode(m, icon, ti, d) { return '<button class="g-mode press" data-act="mode" data-m="' + m + '"><span class="ic">' + ic(icon) + '</span><span class="tx"><b>' + esc(ti) + "</b><span>" + esc(d) + '</span></span><span class="go">' + ic("chev") + "</span></button>"; }
    },
    diff: function () {
      return '<section class="g-screen"><h1 class="g-h">' + esc(t("diff_title")) + '</h1><div class="g-stack">' + ["easy", "medium", "hard"].map(function (l, i) {
        return '<button class="g-mode press" data-act="level" data-l="' + l + '"><span class="ic"><b style="font-size:20px">' + (i + 1) + '</b></span><span class="tx"><b>' + esc(t(l)) + "</b><span>" + esc(t(l + "_d")) + '</span></span><span class="go">' + ic("chev") + "</span></button>";
      }).join("") + "</div></section>";
    },
    lobby: function () {
      return '<section class="g-screen"><h1 class="g-h">' + esc(t("lobby_title")) + '</h1><div class="g-stack">' +
        big("quick", "bolt", t("quick"), t("quick_d")) + big("create", "plus", t("create"), t("create_d")) + big("joinpage", "key", t("join"), t("join_d")) + "</div></section>";
      function big(a, icon, ti, d) { return '<button class="g-mode press" data-act="' + a + '"><span class="ic">' + ic(icon) + '</span><span class="tx"><b>' + esc(ti) + "</b><span>" + esc(d) + '</span></span><span class="go">' + ic("chev") + "</span></button>"; }
    },
    join: function () {
      return '<section class="g-screen"><h1 class="g-h">' + esc(t("join_title")) + '</h1><p class="g-sub">' + esc(t("code_hint")) + '</p><input id="gCode" class="g-code" maxlength="6" inputmode="text" autocapitalize="characters" autocomplete="off" spellcheck="false" placeholder="••••••" aria-label="' + esc(t("code_ph")) + '" />' +
        '<button class="g-btn press" data-act="joinroom" style="margin-top:14px">' + esc(t("join_btn")) + "</button></section>";
    },
    queue: function () {
      var q = S.queue;
      if (q.state === "timeout") return '<section class="g-screen g-center"><h1 class="g-h">' + esc(t("no_opp")) + '</h1><p class="g-sub">' + esc(t("no_opp_d")) + '</p><div class="g-stack"><button class="g-btn press" data-act="quick">' + ic("redo") + esc(t("try_again")) + '</button><button class="g-btn ghost press" data-act="go" data-to="diff">' + ic("bot") + esc(t("vs_bot")) + "</button></div></section>";
      return '<section class="g-screen g-center"><div class="g-spin"></div><h1 class="g-h">' + esc(t("searching")) + '</h1><p class="g-sub">' + esc(t("searching_d")) + '</p><p class="g-sub"><b class="num" id="gQTime">0:00</b></p><button class="g-btn ghost press" data-act="cancelq">' + esc(t("cancel")) + "</button></section>";
    },
    room: function () {
      var r = S.room || {}, code = esc(r.code || "");
      return '<section class="g-screen g-center"><h1 class="g-h">' + esc(t("room_title")) + '</h1><p class="g-sub">' + esc(t("room_code")) + '</p><div class="g-roomcode num">' + code + '</div><div class="g-spin"></div><p class="g-sub">' + esc(t("room_wait")) + '</p><div class="g-row2"><button class="g-btn ghost press" data-act="copycode">' + ic("copy") + esc(t("copy")) + '</button><button class="g-btn ghost press" data-act="sharecode">' + ic("share") + esc(t("share")) + '</button></div><button class="g-btn ghost press" data-act="cancelroom" style="margin-top:10px">' + esc(t("cancel")) + "</button></section>";
    },
    result: function () {
      var r = S.result; if (!r) return VIEWS.home();
      var cls = r.outcome === "win" ? "win" : r.outcome === "loss" ? "lose" : "", ttl = r.title;
      var delta = "";
      if (r.online && r.res) {
        var d = r.res.delta;
        delta = r.res.rated ? '<div class="g-delta"><div><b class="num ' + (d >= 0 ? "d-up" : "d-down") + '">' + (d >= 0 ? "+" : "") + d + "</b><small>" + esc(t("rating")) + " · " + r.res.ratingAfter + '</small></div><div><b class="num">+' + r.res.points + "</b><small>" + esc(t("points")) + '</small></div><div><b class="num">' + r.res.streak + "</b><small>" + esc(t("streak")) + "</small></div></div>"
          : '<div class="g-card g-note"><b>' + esc(t("unranked")) + "</b><br>" + esc(S.room && S.room.kind === "private" ? t("unranked_why") : t("pair_cap")) + "</div>";
      }
      var btns = "";
      if (r.online) {
        var priv = S.room && S.room.kind === "private", left = S.room && S.room.players && S.room.players.some(function (p) { return p && p.slot !== S.room.you && !p.connected; });
        btns = (priv ? '<button class="g-btn press" data-act="rematch"' + (S.rematchWaiting || r.oppLeft ? " disabled" : "") + ">" + ic("redo") + esc(S.rematchWaiting ? t("rematch_wait") : t("rematch")) + "</button>"
          : '<button class="g-btn press" data-act="quick">' + ic("redo") + esc(t("play_again")) + "</button>") + (left ? "" : "");
        btns += '<button class="g-btn ghost press" data-act="leaveresult">' + esc(t("home")) + "</button>";
      } else btns = '<button class="g-btn press" data-act="again">' + ic("redo") + esc(t("play_again")) + '</button><button class="g-btn ghost press" data-act="leaveresult">' + esc(t("home")) + "</button>";
      return '<section class="g-screen g-result"><div class="ttl ' + cls + '">' + esc(ttl) + '</div><p class="g-sub">' + esc(r.sub || "") + '</p><div class="g-score"><div><span class="num">' + r.score[0] + "</span><small>" + nm(r.names[0]) + '</small></div><span style="opacity:.4">:</span><div><span class="num">' + r.score[1] + "</span><small>" + nm(r.names[1]) + "</small></div></div>" + delta + '<div class="g-stack">' + btns + "</div></section>";
    },
    lb: function () {
      var d = S.lb, h = '<section class="g-screen"><h1 class="g-h">' + esc(t("leaderboard")) + "</h1>";
      if (!N.hasToken()) return h + '<div class="g-card g-center"><p class="g-sub">' + esc(t("lb_login")) + '</p><a class="g-btn press" href="/orders/?next=' + encodeURIComponent("/grid/") + '">' + esc(t("login_btn")) + "</a></div></section>";
      if (!d) return h + '<div class="g-card"><div class="g-spin"></div></div></section>';
      if (!d.rows.length) return h + '<div class="g-card g-center"><p class="g-sub">' + esc(t("lb_empty")) + "</p></div></section>";
      return h + (d.myRank ? '<div class="g-sub">' + esc(t("lb_me")) + " " + nm("#" + d.myRank) + " / " + nm(d.total) + " " + esc(t("lb_players")) + "</div>" : "") + '<div class="g-card">' + d.rows.map(function (r) {
        return '<div class="g-lb-row ' + (r.me ? "me " : "") + (r.rank <= 3 ? "top" : "") + '"><span class="rk num">' + r.rank + "</span>" + badge(r.tier) + '<span class="nm">' + nm(r.name) + (r.me ? " " + esc(t("lb_you")) : "") + '<small>' + esc(t(r.tier)) + " · " + r.wins + " " + esc(t("wins")) + '</small></span><span class="sc num">' + r.rating + "</span></div>";
      }).join("") + "</div></section>";
    },
    profile: function () {
      var h = '<section class="g-screen"><h1 class="g-h">' + esc(t("profile")) + "</h1>", p = S.me && S.me.profile, pr = practice;
      var practiceCard = '<div class="g-card"><b>' + esc(t("practice")) + '</b><div class="g-mini"><div><b class="num">' + pr.played + "</b><small>" + esc(t("played")) + '</small></div><div><b class="num">' + pr.wins + "</b><small>" + esc(t("wins")) + '</small></div><div><b class="num">' + pr.losses + "</b><small>" + esc(t("losses")) + '</small></div></div><p class="g-note" style="margin:10px 0 0">' + esc(t("practice_note")) + "</p></div>";
      if (!N.hasToken()) return h + passCard() + practiceCard + "</section>";
      if (!p) return h + '<div class="g-card"><div class="g-spin"></div></div>' + practiceCard + "</section>";
      var nx = p.tier.next, prog = nx ? Math.max(4, Math.min(100, Math.round(100 - (nx.remaining / Math.max(1, nx.from - tierFrom(p))) * 100))) : 100;
      return h + '<div class="g-card"><div class="g-pass">' + badge(p.tier.id) + '<div class="info"><div class="nm">' + nm(p.name) + '</div><div class="rt">' + esc(t(p.tier.id)) + " · " + esc(t("rating")) + " <b class=num>" + p.rating + "</b>" + (p.rank ? " · " + nm("#" + p.rank) : "") + '</div></div></div><div class="g-bar-prog"><i style="width:' + prog + '%"></i></div><small style="color:var(--g-muted)">' + esc(nx ? t("to_next", { n: nx.remaining, t: t(nx.id) }) : t("max_tier")) + "</small></div>" +
        '<div class="g-card"><div class="g-stats"><div><b class="num">' + p.played + "</b><small>" + esc(t("played")) + '</small></div><div><b class="num">' + p.wins + "</b><small>" + esc(t("wins")) + '</small></div><div><b class="num">' + p.losses + "</b><small>" + esc(t("losses")) + '</small></div><div><b class="num">' + p.winRate + "%</b><small>" + esc(t("win_rate")) + '</small></div><div><b class="num">' + p.bestStreak + "</b><small>" + esc(t("best_streak")) + '</small></div><div><b class="num">' + p.points + "</b><small>" + esc(t("points")) + "</small></div></div></div>" +
        '<div class="g-card"><b>' + esc(t("history")) + "</b>" + (p.history.length ? p.history.map(function (x) {
          return '<div class="g-hist"><span class="res ' + x.result + '">' + (x.result === "win" ? "W" : x.result === "loss" ? "L" : "D") + '</span><span class="tx">' + nm(x.opponent) + "<small>" + x.scoreFor + " : " + x.scoreAgainst + (x.rated ? "" : " · " + esc(t("unranked"))) + '</small></span><span class="' + (x.ratingDelta >= 0 ? "d-up" : "d-down") + ' num">' + (x.rated ? (x.ratingDelta >= 0 ? "+" : "") + x.ratingDelta : "") + "</span></div>";
        }).join("") : '<p class="g-note" style="margin-top:8px">' + esc(t("no_history")) + "</p>") + "</div>" + practiceCard + "</section>";
    },
    settings: function () {
      return '<section class="g-screen"><h1 class="g-h">' + esc(t("settings")) + '</h1><div class="g-card">' +
        sw("sound", t("s_sound")) + '<div class="g-set"><span>' + esc(t("s_volume")) + '</span><input type="range" min="0" max="100" value="' + Math.round(settings.volume * 100) + '" id="gVol" aria-label="' + esc(t("s_volume")) + '"></div>' + sw("vibrate", t("s_vibrate")) +
        seg("quality", t("s_quality"), [["auto", t("q_auto")], ["high", t("q_high")], ["low", t("q_low")]]) + "</div></section>";
      function sw(k, label) { return '<div class="g-set"><span>' + esc(label) + '</span><button type="button" class="g-sw" role="switch" aria-checked="' + !!settings[k] + '" data-act="toggle" data-k="' + k + '" aria-label="' + esc(label) + '"></button></div>'; }
      function seg(k, label, opts) { return '<div class="g-set"><span>' + esc(label) + '</span><div class="g-seg">' + opts.map(function (o) { return '<button type="button" data-act="seg" data-k="' + k + '" data-v="' + o[0] + '" class="' + (settings[k] === o[0] ? "is-on" : "") + '">' + esc(o[1]) + "</button>"; }).join("") + "</div></div>"; }
    },
  };
  function tierFrom(p) { var tiers = (S.cfg && S.cfg.tiers) || []; for (var i = 0; i < tiers.length; i++) if (tiers[i].id === p.tier.id) return tiers[i].from; return 0; }

  /* -------------------------------------------------------------- navigation */
  var NO_BAR_BACK = { home: 1 };
  function render() {
    var el = $("gMain");
    if (S.screen === "match") return;
    document.body.classList.remove("in-match");
    var v = VIEWS[S.screen] || VIEWS.home; el.innerHTML = v();
    $("gBack").innerHTML = ic("back"); $("gBack").style.visibility = NO_BAR_BACK[S.screen] ? "hidden" : "visible";
    Array.prototype.forEach.call(document.querySelectorAll("[data-lang]"), function (b) { b.classList.toggle("is-on", b.getAttribute("data-lang") === T.get()); });
    var q = $("gQTime"); if (q) tickQueueTimer();
    var c = $("gCode"); if (c) { c.focus(); c.addEventListener("input", function () { c.value = c.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6); }); c.addEventListener("keydown", function (e) { if (e.key === "Enter") act("joinroom"); }); }
    var vol = $("gVol"); if (vol) vol.addEventListener("input", function () { settings.volume = vol.value / 100; applySettings(); }), vol.addEventListener("change", function () { A.click(); });
    window.scrollTo(0, 0);
  }
  function go(screen, opts) {
    opts = opts || {};
    if (S.screen === "match" && screen !== "match") destroyMatch();
    if (!opts.replace && S.screen !== screen) S.hist.push(S.screen);
    S.screen = screen;
    try { history.pushState({ g: 1 }, ""); } catch (e) {}
    render();
    if (screen === "lb") loadLb();
    if (screen === "profile" || screen === "modes") loadMe();
  }
  function back() {
    if (M) return askLeave();
    if (S.screen === "queue") return act("cancelq");
    if (S.screen === "room") return act("cancelroom");
    var prev = S.hist.pop();
    if (!prev || prev === S.screen || prev === "queue" || prev === "room" || prev === "result" || prev === "match") { if (S.screen === "home") { location.href = "/"; return; } S.screen = "home"; S.hist = []; }
    else S.screen = prev;
    render();
  }
  window.addEventListener("popstate", function () {
    // Siymon AI pushes a history entry when its panel opens; closing it with Back must not also navigate the game.
    var ai = document.querySelector('.sai-panel[data-open="true"]'); if (ai) return;
    if (M || S.screen === "queue" || S.screen === "room") { try { history.pushState({ g: 1 }, ""); } catch (e) {} } back(); });

  /* ------------------------------------------------------------------- server data */
  function loadMe() {
    if (!N.hasToken() || S.loadingMe) return Promise.resolve();
    S.loadingMe = true;
    return N.api("/api/grid/me").then(function (d) { S.me = d; S.cfg = d.settings; }).catch(function (e) { if (e.status === 401) { N.token = ""; } }).then(function () { S.loadingMe = false; if (S.screen !== "match" && S.screen !== "result" && S.screen !== "room" && S.screen !== "queue") render(); });
  }
  function loadCfg() { return fetch("/api/grid/config", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (d) { if (d && d.settings) S.cfg = d.settings; }).catch(function () {}); }
  function loadLb() { if (!N.hasToken()) return; S.lb = null; N.api("/api/grid/leaderboard?limit=50").then(function (d) { S.lb = d; if (S.screen === "lb") render(); }).catch(function () { S.lb = { rows: [], total: 0 }; if (S.screen === "lb") render(); }); }
  function tickQueueTimer() {
    clearInterval(S.queueTimer);
    S.queueTimer = setInterval(function () { var el = $("gQTime"); if (!el) return clearInterval(S.queueTimer); var s = Math.max(0, Math.floor((Date.now() - (S.queue.since || Date.now())) / 1000)); el.textContent = Math.floor(s / 60) + ":" + ("0" + (s % 60)).slice(-2); }, 500);
  }

  /* ------------------------------------------------------------------- actions */
  function act(a, el) {
    A.unlock(); A.tap();
    switch (a) {
      case "back": return back();
      case "go": return go(el.getAttribute("data-to"));
      case "mode": {
        var m = el.getAttribute("data-m"); S.mode = m;
        if (m === "solo") return go("diff");
        if (m === "local") return startLocal("local");
        return enterOnline();
      }
      case "level": S.diff = el.getAttribute("data-l"); return startLocal("solo");
      case "quick": if (!ensureOnline()) return; return N.api("/api/grid/queue/join", { method: "POST", body: {} }).then(function () { if (S.screen === "match" || S.queue.state === "matched") return; S.queue = { state: "searching", since: Date.now() }; go("queue", { replace: S.screen === "queue" || S.screen === "result" }); }).catch(function (e) { toast(errMsg(e)); });
      case "cancelq": return N.api("/api/grid/queue/leave", { method: "POST", body: {} }).catch(function () {}).then(function () { S.queue = { state: "idle" }; S.screen = "lobby"; S.hist = ["home", "modes"]; render(); });
      case "create": if (!ensureOnline()) return; return N.api("/api/grid/rooms", { method: "POST", body: {} }).then(function (d) { if (S.screen === "match") return; S.room = S.room && S.room.id === d.room.id ? S.room : d.room; go("room"); }).catch(function (e) { toast(errMsg(e)); });
      case "joinpage": return go("join");
      case "joinroom": {
        var code = ($("gCode") && $("gCode").value || "").trim(); if (code.length !== 6) return toast(t("e_code"));
        if (!ensureOnline()) return;
        return N.api("/api/grid/rooms/join", { method: "POST", body: { code: code } }).then(function (d) { if (!S.room) S.room = d.room; }).catch(function (e) { toast(errMsg(e)); });
      }
      case "cancelroom": return N.api("/api/grid/rooms/leave", { method: "POST", body: {} }).catch(function () {}).then(function () { S.room = null; S.screen = "lobby"; S.hist = ["home", "modes"]; render(); });
      case "copycode": return copyText(S.room && S.room.code).then(function () { toast(t("copied")); });
      case "sharecode": { var txt = t("room_share") + (S.room && S.room.code); if (navigator.share) return navigator.share({ text: txt }).catch(function () {}); return copyText(txt).then(function () { toast(t("copied")); }); }
      case "again": return startLocal(S.last && S.last.mode || "solo");
      case "rematch": return N.api("/api/grid/rooms/rematch", { method: "POST", body: {} }).then(function () { S.rematchWaiting = true; render(); }).catch(function (e) { toast(errMsg(e)); });
      case "leaveresult": return N.api("/api/grid/rooms/leave", { method: "POST", body: {} }).catch(function () {}).then(function () { S.room = null; S.result = null; S.rematchWaiting = false; S.screen = "home"; S.hist = []; loadMe(); render(); });
      case "toggle": { var k = el.getAttribute("data-k"); settings[k] = !settings[k]; applySettings(); if (k === "sound" && settings.sound) A.click(); return render(); }
      case "seg": { settings[el.getAttribute("data-k")] = el.getAttribute("data-v"); applySettings(); return render(); }
    }
  }
  function copyText(s) { try { if (navigator.clipboard) return navigator.clipboard.writeText(s || ""); } catch (e) {} return Promise.resolve(); }
  function ensureOnline() { if (!N.hasToken()) { toast(t("login_t")); return false; } if (!N.connect(netHandlers())) return false; return true; }
  function enterOnline() {
    if (!N.hasToken()) { location.href = "/orders/?next=" + encodeURIComponent("/grid/"); return; }
    if (S.cfg && !S.cfg.onlineEnabled) return toast(t("e_disabled"));
    N.connect(netHandlers()); go("lobby");
  }

  document.addEventListener("click", function (e) {
    var l = e.target.closest("[data-lang]"); if (l) { T.set(l.getAttribute("data-lang")); A.click(); if (!M) render(); return; }
    var b = e.target.closest("[data-act]"); if (b && !b.disabled) act(b.getAttribute("data-act"), b);
  });

  /* ======================================================================= MATCH */
  var BOT_THINK_MS = 700;
  function boardCfg() { var g = (S.cfg && S.cfg.grid) || {}; return { w: g.w || 9, h: g.h || 11, turnMs: 30000, maxRoundTurns: (S.cfg && S.cfg.maxRoundTurns) || 160 }; }

  /** the drawable model of an engine state; `flip` puts seat 2 at the bottom of its own screen (online only) */
  function viewFrom(st, flip) {
    return { w: st.w, h: st.h, flip: !!flip, cur: st.cur, over: !!st.over, hints: [], ghost: null, moveAt: 0, moveMs: 0, lastWall: -1, lastWallAt: 0,
      pos: st.players.map(function (p) { return { x: p.x, y: p.y, px: p.x, py: p.y }; }), walls: st.walls.map(function (q) { return q.slice(); }) };
  }
  /** copy an engine state into the view after an action; the ball that moved slides from where it was */
  function syncView(animate) {
    var v = M.view, st = M.state, before = v.walls.length, now = performance.now();
    for (var i = 0; i < 2; i++) {
      var p = v.pos[i], q = st.players[i];
      if (animate && (p.x !== q.x || p.y !== q.y)) { p.px = p.x; p.py = p.y; v.moveAt = now; v.moveMs = 190; } else { p.px = q.x; p.py = q.y; }
      p.x = q.x; p.y = q.y;
    }
    v.walls = st.walls.map(function (q) { return q.slice(); });
    if (v.walls.length > before) { v.lastWall = v.walls.length - 1; v.lastWallAt = now; }
    v.cur = st.cur; v.over = !!st.over;
    M.pending = null; M.sel = "move"; M.lock = false;
    refresh();
  }
  /** whose hands are on the screen: the local player (solo / online) or whoever's turn it is (two on one device) */
  function actor() { return M.mode === "local" ? M.state.cur : M.me; }
  function myTurn() { return !!(M && M.state && !M.state.over && M.status === "playing" && !M.lock && M.state.cur === actor() && (M.mode !== "solo" || M.state.cur === 0)); }
  function wallMsg(code) { return code === "BLOCKS_PATH" ? t("bad_block") : t("bad_overlap"); }
  /** hints, ghost barrier and control bars follow the state */
  function refresh() {
    if (!M || !M.view) return;
    var v = M.view, ok = myTurn(), ev = null;
    v.cur = M.state.cur;
    v.hints = ok && M.sel === "move" ? E.legalMoves(M.state, actor()) : [];
    v.ghost = null;
    if (ok && M.sel === "wall" && M.pending) { ev = E.wallEval(M.state, M.pending.o, M.pending.x, M.pending.y); v.ghost = { o: M.pending.o, x: M.pending.x, y: M.pending.y, ok: !!ev.d }; }
    M.pendingOk = !!(ev && ev.d);
    var msg = !ok ? "" : M.sel === "move" ? t("hint_move") : !M.pending ? t("hint_wall") : ev.d ? t("hint_confirm") : wallMsg(ev.code);
    Array.prototype.forEach.call(document.querySelectorAll(".g-ctl"), function (bar) {
      var k = +bar.getAttribute("data-bar"), mine = M.mode === "local" ? (M.state.cur === k) : true, on = ok && mine;
      bar.classList.toggle("off", !on);
      Array.prototype.forEach.call(bar.querySelectorAll("[data-mode]"), function (b) { b.classList.toggle("on", b.getAttribute("data-mode") === M.sel); b.disabled = !on; });
      bar.querySelector("[data-ok]").disabled = !(on && M.sel === "wall" && M.pendingOk);
      bar.querySelector(".g-ctl-msg").textContent = on ? msg : (M.status === "playing" && !M.state.over && !(M.mode === "local") ? t("opp_turn") : "");
    });
    paintHud();
  }

  function matchHtml(m) {
    var two = m.mode === "local";
    function bar(k) {
      return '<div class="g-ctl' + (k ? " top" : "") + '" data-bar="' + k + '"><div class="g-ctl-row"><div class="g-mseg">' +
        '<button type="button" data-mode="move" class="on">' + ic("ball") + "<span>" + esc(t("m_move")) + '</span></button><button type="button" data-mode="wall">' + ic("wall") + "<span>" + esc(t("m_wall")) + "</span></button></div>" +
        '<button type="button" class="g-okb" data-ok disabled>' + ic("check") + "<span>" + esc(t("confirm")) + '</span></button></div><div class="g-ctl-msg"></div></div>';
    }
    return '<div class="g-match" id="gMatch" data-two="' + (two ? 1 : 0) + '">' + (two ? bar(1) : "") +
      '<div class="g-mcenter"><div class="g-hud"><div class="g-chip p1" id="gC0"><i></i><span class="nm" id="gN0" dir="auto"></span><span class="pips" id="gP0"></span></div>' +
      '<div class="g-mid"><small id="gRound"></small><b id="gTimer" class="num"></b><button type="button" id="gPause" aria-label="' + esc(m.mode === "online" ? t("quit") : t("pause")) + '">' + ic(m.mode === "online" ? "exit" : "pause") + "</button></div>" +
      '<div class="g-chip p2" id="gC1"><i></i><span class="nm" id="gN1" dir="auto"></span><span class="pips" id="gP1"></span></div></div>' +
      '<div class="g-arena-wrap"><div class="g-arena" id="gArena"><canvas id="gCv"></canvas><div class="g-ov" id="gOv"></div><div class="g-net hidden" id="gNet"></div></div></div></div>' + bar(0) + "</div>";
  }

  function createMatch(opts) {
    destroyMatch();
    var m = M = Object.assign({ status: "countdown", wins: [0, 0], round: 1, roundsToWin: 2, names: ["", ""], me: 0, draws: 0, timers: [], listeners: [], view: null, state: null, sel: "move", pending: null, pendingOk: false, lock: false, deadline: 0 }, opts);
    S.screen = "match"; document.body.classList.add("in-match");
    $("gMain").innerHTML = matchHtml(m);
    var root = $("gMatch");
    R = GridRender.create($("gCv")); R.setQuality(settings.quality);
    var ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(function () { if (m.view) R.resize(m.view.w, m.view.h); }) : null; if (ro) ro.observe($("gArena"));
    m.ro = ro;
    function on(target, ev, fn, o) { target.addEventListener(ev, fn, o); m.listeners.push([target, ev, fn, o]); }
    // tapping the board: a lit square moves the ball; in barrier mode the nearest line is previewed until confirmed
    on($("gCv"), "pointerdown", function (e) {
      e.preventDefault(); A.unlock();
      if (!myTurn() || !R) return;
      var rc = $("gCv").getBoundingClientRect(), h = R.hit(e.clientX - rc.left, e.clientY - rc.top);
      if (M.sel === "move") { if (E.isLegalMove(M.state, actor(), h.cell[0], h.cell[1])) submit({ t: "m", x: h.cell[0], y: h.cell[1] }); }
      else { M.pending = h.wall; A.click(); refresh(); }
    });
    on(root, "click", function (e) {
      var b = e.target.closest("[data-mode],[data-ok]"); if (!b || b.disabled) return;
      A.unlock();
      if (b.hasAttribute("data-ok")) { if (M.sel === "wall" && M.pending && M.pendingOk) submit({ t: "w", o: M.pending.o, x: M.pending.x, y: M.pending.y }); return; }
      if (!myTurn()) return; M.sel = b.getAttribute("data-mode"); M.pending = null; A.click(); refresh();
    });
    on(root, "touchmove", function (e) { e.preventDefault(); }, { passive: false });
    on(document, "visibilitychange", function () { if (document.hidden && M && M.mode !== "online" && M.status === "playing") pauseLocal(); else if (!document.hidden && M && M.mode === "online") N.nudge(); });
    on($("gPause"), "click", function () { A.unlock(); A.click(); if (m.mode === "online") askLeave(); else if (m.status === "playing") pauseLocal(); });
    paintHud();
    m.raf = requestAnimationFrame(frame);
    return m;
  }
  function destroyMatch() {
    if (!M) return;
    cancelAnimationFrame(M.raf); M.timers.forEach(clearTimeout); clearInterval(M.offTimer);
    M.listeners.forEach(function (l) { l[0].removeEventListener(l[1], l[2], l[3]); });
    if (M.ro) M.ro.disconnect();
    M = null; R = null; document.body.classList.remove("in-match");
  }
  function paintHud() {
    if (!M) return;
    var st = M.state;
    [0, 1].forEach(function (i) {
      var n = $("gN" + i); if (n) n.textContent = M.names[i];
      var p = $("gP" + i); if (p) { var h = ""; for (var k = 0; k < M.roundsToWin; k++) h += '<s class="' + (k < M.wins[i] ? "on" : "") + '"></s>'; p.innerHTML = h; }
      var c = $("gC" + i); if (c) c.classList.toggle("turn", !!(st && !st.over && M.status === "playing" && st.cur === i));
    });
    var r = $("gRound"); if (r) r.textContent = t("round") + " " + M.round + (M.mode === "solo" ? " · " + t(S.diff) : "");
  }
  function ov(html) { var o = $("gOv"); if (o) o.innerHTML = html; }

  var lastTimerPaint = 0;
  function frame(now) {
    if (!M) return;
    M.raf = requestAnimationFrame(frame);
    if (M.view && R) R.draw(M.view, now);
    if (now - lastTimerPaint > 200) {
      lastTimerPaint = now;
      var el = $("gTimer");
      if (el) {
        if (M.mode === "online" && M.status === "playing" && M.state && !M.state.over && M.deadline) { var s = Math.max(0, Math.ceil((M.deadline - Date.now()) / 1000)); el.textContent = s; el.classList.toggle("warn", s <= 5); }
        else { el.textContent = M.state && !M.state.over && M.status === "playing" ? (M.mode === "local" ? M.names[M.state.cur] : (M.state.cur === actor() ? t("your_turn") : t("opp_turn"))) : ""; el.classList.remove("warn"); }
      }
    }
  }

  /* ---- sending an action ---- */
  function submit(a) {
    if (!myTurn()) return;
    if (M.mode === "online") {
      M.lock = true; refresh();
      N.api("/api/grid/input", { method: "POST", body: { room: S.room && S.room.id, act: a } })
        .then(function (r) { if (r && r.ok === false && M) { M.lock = false; toast(r.code === "BLOCKS_PATH" || r.code === "OVERLAP" || r.code === "CROSS" ? wallMsg(r.code) : t("e_generic")); refresh(); } })
        .catch(function () { if (M) { M.lock = false; refresh(); } });
      return;
    }
    doAction(M.state.cur, a);
  }

  /* ---- local (solo + 2 players) ---- */
  function startLocal(mode) {
    var solo = mode === "solo";
    S.last = { mode: mode };
    var m = createMatch({ mode: mode, roundsToWin: 2, names: solo ? [t("you"), t("bot")] : [t("p1"), t("p2")], mem: B.newMemory() });
    m.status = "countdown"; startLocalRound(); return m;
  }
  function startLocalRound() {
    var m = M; m.state = E.create(boardCfg(), (m.round - 1) % 2);       // the opening move alternates round by round
    m.view = viewFrom(m.state, false); m.sel = "move"; m.pending = null; m.lock = false;
    R.clearFx(); R.resize(m.state.w, m.state.h, true); refresh();
    countdown(3, function () {
      if (!M) return; M.status = "playing"; ov('<div class="big go">' + esc(t("start")) + "</div>"); M.timers.push(setTimeout(function () { ov(""); }, 650));
      refresh(); botMaybe();
    });
  }
  function countdown(n, done) {
    if (!M) return;
    M.status = "countdown"; refresh();
    if (n > 0) { ov('<div class="big" key="' + n + '">' + n + "</div>"); A.count(n); M.timers.push(setTimeout(function () { countdown(n - 1, done); }, 800)); }
    else { A.count(0); done(); }
  }
  function botMaybe() { if (M && M.mode === "solo" && M.status === "playing" && M.state && !M.state.over && M.state.cur === 1) M.timers.push(setTimeout(botTurn, BOT_THINK_MS)); }
  function botTurn() {
    if (!M || M.status !== "playing" || M.state.over || M.state.cur !== 1) return;
    var a = B.decide(E.publicView(M.state), 1, S.diff, M.mem);
    if (!a || !E.act(E.clone(M.state), 1, a).ok) a = E.autoMove(M.state, 1);
    doAction(1, a);
  }
  function doAction(slot, a) {
    var m = M, r = E.act(m.state, slot, a);
    if (!r.ok) { toast(wallMsg(r.code)); return; }
    if (m.mode === "solo" && slot === 0) B.observeHuman(m.mem, a);
    (a.t === "w" ? A.wall : A.step)();
    syncView(true);
    if (m.state.over) return localRoundEnd();
    botMaybe();
  }
  function goalText(w) { return t("why_goal", { n: M.names[w] }); }
  function localRoundEnd() {
    var m = M, st = m.state, w = st.winner; m.status = "roundover";
    if (w >= 0) { m.wins[w]++; R.burst(st.players[w].x, st.players[w].y, w); } else m.draws++;
    refresh();
    var title, cls = "", sub = w >= 0 ? goalText(w) : t("why_time");
    if (w < 0) { title = t("r_draw"); A.roundLose(); }
    else if (m.mode === "solo") { title = w === 0 ? t("r_win") : t("r_lose"); cls = w === 0 ? "win" : "lose"; (w === 0 ? A.roundWin : A.roundLose)(); }
    else { title = t("r_p_win", { n: m.names[w] }); cls = "win"; A.roundWin(); }
    if (m.mode === "solo") B.adapt(m.mem, { botLost: w === 0 });
    ov('<div class="banner ' + cls + '">' + esc(title) + "<small>" + esc(sub) + "</small></div>");
    paintHud();
    if (m.wins[0] >= m.roundsToWin || m.wins[1] >= m.roundsToWin || m.draws > 3) m.timers.push(setTimeout(finishLocal, 1900));
    else m.timers.push(setTimeout(function () { if (!M) return; M.round++; ov(""); startLocalRound(); }, 2100));
  }
  function finishLocal() {
    var m = M; if (!m) return;
    var w = m.wins[0] === m.wins[1] ? -1 : m.wins[0] > m.wins[1] ? 0 : 1, solo = m.mode === "solo", names = m.names.slice();
    var r = { online: false, names: names, score: m.wins.slice(), outcome: solo ? (w === 0 ? "win" : w === 1 ? "loss" : "draw") : (w >= 0 ? "win" : "draw"), title: w < 0 ? t("draw") : solo ? (w === 0 ? t("victory") : t("defeat")) : t("p_wins", { n: names[w] }), sub: t("match_over") };
    if (solo) { practice.played++; if (w === 0) practice.wins++; else if (w === 1) practice.losses++; else practice.draws++; save(PRACTICE_KEY, practice); }
    (w >= 0 && (!solo || w === 0) ? A.win : A.lose)();
    S.result = r; destroyMatch(); S.screen = "result"; render();
  }
  function pauseLocal() {
    if (!M || M.status !== "playing") return; M.status = "paused"; refresh();
    sheet('<h3>' + esc(t("pause")) + '</h3><div class="g-stack" style="margin-top:12px"><button class="g-btn press" data-sh="resume">' + ic("play") + esc(t("resume")) + '</button><button class="g-btn ghost press" data-sh="quit">' + esc(t("quit")) + "</button></div>", function (k) { if (k === "resume") resumeLocal(); else { destroyMatch(); S.screen = "home"; S.hist = []; render(); } });
  }
  function resumeLocal() { if (M && M.status === "paused") { M.status = "playing"; refresh(); botMaybe(); } }

  /* ---- online ---- */
  function askLeave() {
    if (!M) return;
    if (M.mode !== "online") return pauseLocal();
    sheet('<h3>' + esc(t("leave_q")) + "</h3><p>" + esc(t("leave_online")) + '</p><div class="g-stack"><button class="g-btn danger press" data-sh="leave">' + esc(t("leave_ok")) + '</button><button class="g-btn ghost press" data-sh="stay">' + esc(t("cancel")) + "</button></div>", function (k) {
      if (k !== "leave") return;
      N.api("/api/grid/rooms/leave", { method: "POST", body: {} }).catch(function () {}).then(function () { S.room = null; destroyMatch(); S.screen = "home"; S.hist = []; loadMe(); render(); });
    });
  }
  function onlineNames() { var r = S.room, me = r ? r.you : 0; return [0, 1].map(function (i) { var p = r && r.players && r.players[i]; return i === me ? t("you") : (p ? p.name : t("player")); }); }
  function ensureOnlineMatch() {
    if (M && M.mode === "online") return M;
    var r = S.room || {};
    createMatch({ mode: "online", roundsToWin: r.roundsToWin || 2, me: r.you || 0, names: onlineNames(), wins: (r.wins || [0, 0]).slice() });
    return M;
  }
  function netHandlers() {
    return {
      __state: function (s) { S.netState = s; var el = $("gNet"); if (el) { el.classList.toggle("hidden", s === "live"); el.textContent = t("reconnecting"); } },
      hello: function (d) {
        S.queue = d.queue || { state: "idle" }; S.room = d.room || null;
        if (S.room && S.room.status !== "closed") {
          if (S.room.status === "waiting") { if (S.screen !== "room") go("room", { replace: true }); }
          else if (S.room.status === "finished") { /* result already shown or will be via match_end */ }
          else { ensureOnlineMatch(); if (d.round) onRound(d.round, true); M.status = S.room.status === "playing" ? "playing" : S.room.status === "paused" ? "paused" : M.status; refresh(); }
        } else if (S.queue.state === "searching" && S.screen !== "queue") go("queue", { replace: true });
      },
      queue: function (d) { if (S.queue.state === "matched" && d.state === "searching") return; S.queue = d; if (d.state === "timeout") { if (S.screen === "queue") render(); } if (d.state === "searching" && !d.since) S.queue.since = Date.now(); },
      room: function (d) {
        if (d.status === "closed") { if (S.screen === "room") { toast(t("opp_left")); S.screen = "lobby"; render(); } S.room = null; return; }
        var prev = S.room; S.room = d;
        if (d.status === "finished" && !d.players.every(function (p) { return p && p.rematch; })) { S.rematchWaiting = !!(d.players[d.you] && d.players[d.you].rematch); if (S.screen === "result") render(); }
        if (M && M.mode === "online") { M.names = onlineNames(); M.wins = d.wins.slice(); M.round = d.round || M.round; M.status = d.status === "playing" ? "playing" : d.status === "paused" ? "paused" : d.status === "countdown" ? "countdown" : d.status === "roundover" ? "roundover" : M.status; refresh(); }
        if (prev && prev.status === "finished" && d.status === "countdown") S.rematchWaiting = false;
      },
      round: function (d) { onRound(d); },
      countdown: function (d) { if (!M) return; M.status = "countdown"; refresh(); if (d.n > 0) { ov('<div class="big">' + d.n + "</div>"); A.count(d.n); } else { A.count(0); ov('<div class="big go">' + esc(t("start")) + "</div>"); M.timers.push(setTimeout(function () { ov(""); }, 650)); } },
      turnstart: function (d) { if (!M || !M.state) return; M.status = "playing"; M.state.cur = d.cur; M.deadline = Date.now() + d.ms; M.lock = false; refresh(); },
      turn: function (d) {
        if (!M || !M.view) return; M.status = d.over ? "roundover" : "playing";
        M.state = E.fromView(d.view); M.deadline = Date.now() + (d.ms || 30000);
        (d.act && d.act.t === "w" ? A.wall : A.step)();
        if (d.auto && d.by === M.me) toast(t("auto_moved"));
        syncView(true);
      },
      round_end: function (d) {
        if (!M) return; M.wins = d.wins.slice(); M.status = "roundover"; refresh();
        var mine = d.winner === M.me, title = d.winner < 0 ? t("r_draw") : mine ? t("r_win") : t("r_lose");
        (d.winner < 0 ? A.roundLose : mine ? A.roundWin : A.roundLose)();
        if (d.winner >= 0 && M.state) R.burst(M.state.players[d.winner].x, M.state.players[d.winner].y, d.winner);
        var sub = d.winner >= 0 ? goalText(d.winner) : t("why_time");
        ov('<div class="banner ' + (d.winner < 0 ? "" : mine ? "win" : "lose") + '">' + esc(title) + "<small>" + esc(sub) + "</small></div>");
      },
      match_end: function (d) { onMatchEnd(d); },
      presence: function (d) {
        if (!M || d.slot === M.me) return;
        clearInterval(M.offTimer); var el = $("gNet");
        if (d.connected) { if (el) el.classList.add("hidden"); return; }
        var end = Date.now() + d.leftMs; function paint() { var s = Math.max(0, Math.ceil((end - Date.now()) / 1000)); var e2 = $("gNet"); if (e2) { e2.classList.remove("hidden"); e2.textContent = t("opp_offline", { n: s }); } }
        paint(); M.offTimer = setInterval(paint, 500);
      },
    };
  }
  function onRound(d, silent) {
    var m = ensureOnlineMatch(); if (S.screen !== "match") { S.screen = "match"; }
    m.state = E.fromView(d.view); m.view = viewFrom(m.state, m.me === 1); m.round = d.round; m.sel = "move"; m.pending = null; m.lock = false; m.deadline = Date.now() + (d.ms || 30000);
    R.clearFx(); R.resize(d.w, d.h, true); if (!silent) ov("");
    document.body.classList.add("in-match"); refresh();
  }
  function onMatchEnd(d) {
    var names = M ? M.names.slice() : onlineNames(), me = S.room ? S.room.you : 0;
    if (d.reason === "abort") { toast(t("aborted")); N.api("/api/grid/rooms/leave", { method: "POST", body: {} }).catch(function () {}); S.room = null; destroyMatch(); S.screen = "lobby"; render(); return; }
    var win = d.winner === me, draw = d.winner < 0, wins = d.wins || [0, 0];
    var r = { online: true, names: names, score: [wins[0], wins[1]], res: d.result, outcome: draw ? "draw" : win ? "win" : "loss", title: draw ? t("draw") : win ? t("victory") : t("defeat"), sub: d.reason === "forfeit" ? (win ? t("forfeit_win") : t("forfeit_lose")) : t("match_over"), oppLeft: d.reason === "forfeit" && win };
    (win ? A.win : A.lose)();
    var finish = function () { S.result = r; S.rematchWaiting = false; destroyMatch(); S.screen = "result"; render(); loadMe(); };
    if (M) M.timers.push(setTimeout(finish, 1900)); else finish();
  }

  /* ---------------------------------------------------------------------- boot */
  T.set(T.get());
  window.addEventListener("pageshow", function (e) { if (e.persisted) { N.loadToken(); render(); } });
  document.addEventListener("visibilitychange", function () { if (!document.hidden && N.hasToken() && !M) N.nudge(); });
  window.addEventListener("online", function () { N.nudge(); });
  loadCfg().then(function () { if (S.screen === "home") render(); });
  if (N.hasToken()) { N.connect(netHandlers()); loadMe(); }
  render();
  try { history.replaceState({ g: 1 }, ""); } catch (e) {}
  window.__grid = { S: function () { return S; }, M: function () { return M; }, go: go, startLocal: startLocal, settings: settings };
})();
