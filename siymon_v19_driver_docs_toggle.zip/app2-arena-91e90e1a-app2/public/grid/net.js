/* SIYMON GRID BATTLE — network layer.
   - api(): JSON calls with the customer token the rest of Siymon already stores.
   - connect(): live events from /api/grid/stream. EventSource cannot send the auth header, so the stream is read with
     fetch() + ReadableStream and parsed as SSE. It reconnects by itself (the server then sends a full snapshot) and
     falls back to short polling when a network/proxy refuses long-lived responses. */
(function (root) {
  "use strict";
  var TOKEN_KEY = "siymon_customer_token_v1";
  var N = { token: "", handlers: {}, state: "idle", lastId: 0, ctl: null, mode: "stream", pollTimer: null, fails: 0, stopped: true, wantOpen: false };

  N.loadToken = function () { try { N.token = localStorage.getItem(TOKEN_KEY) || ""; } catch (e) { N.token = ""; } return N.token; };
  N.hasToken = function () { return !!N.token; };

  N.api = function (path, opts) {
    opts = opts || {};
    var headers = { "Content-Type": "application/json" };
    if (N.token) headers["X-Customer-Token"] = N.token;
    return fetch(path, { method: opts.method || "GET", headers: headers, body: opts.body ? JSON.stringify(opts.body) : undefined, cache: "no-store", keepalive: !!opts.keepalive }).then(function (res) {
      return res.text().then(function (txt) {
        var body = {}; try { body = txt ? JSON.parse(txt) : {}; } catch (e) {}
        if (!res.ok) { var err = new Error(body.error || "HTTP " + res.status); err.status = res.status; err.code = body.code || ""; throw err; }
        return body;
      });
    });
  };

  function setState(s) { if (N.state !== s) { N.state = s; if (N.handlers.__state) N.handlers.__state(s); } }
  function dispatch(id, type, data) {
    if (type === "hello") N.lastId = id || 0;                  // a snapshot always wins (also after a server restart resets the counter)
    else if (id && id <= N.lastId) return;                     // duplicate (reconnect overlap)
    else if (id) N.lastId = id;
    var h = N.handlers[type]; if (h) { try { h(data); } catch (e) { if (root.console) console.error(e); } }
  }

  function parseFrames(buf, onFrame) {
    var idx;
    while ((idx = buf.indexOf("\n\n")) >= 0) {
      var raw = buf.slice(0, idx); buf = buf.slice(idx + 2);
      var ev = { id: 0, type: "message", data: "" };
      raw.split("\n").forEach(function (line) {
        if (line.charAt(0) === ":") return;
        var c = line.indexOf(":"); if (c < 0) return;
        var k = line.slice(0, c), v = line.slice(c + 1).replace(/^ /, "");
        if (k === "id") ev.id = parseInt(v, 10) || 0; else if (k === "event") ev.type = v; else if (k === "data") ev.data += v;
      });
      if (ev.data) { try { onFrame(ev.id, ev.type, JSON.parse(ev.data)); } catch (e) {} }
    }
    return buf;
  }

  function openStream() {
    if (N.stopped) return;
    if (!root.ReadableStream || !root.TextDecoder || !root.AbortController) return startPolling();
    N.ctl = new AbortController();
    var ctl = N.ctl, started = Date.now();
    setState(N.state === "live" ? "reconnecting" : "connecting");
    fetch("/api/grid/stream", { headers: { "X-Customer-Token": N.token, Accept: "text/event-stream" }, cache: "no-store", signal: ctl.signal }).then(function (res) {
      if (res.status === 401) { setState("auth"); N.stopped = true; return; }
      if (!res.ok || !res.body) throw new Error("stream " + res.status);
      N.fails = 0; setState("live");
      var reader = res.body.getReader(), dec = new TextDecoder("utf-8"), buf = "";
      function pump() {
        return reader.read().then(function (r) {
          if (r.done) throw new Error("closed");
          buf = parseFrames(buf + dec.decode(r.value, { stream: true }), dispatch);
          return pump();
        });
      }
      return pump();
    }).catch(function () {
      if (N.stopped || ctl.signal.aborted && N.ctl !== ctl) return;
      N.fails++;
      setState("reconnecting");
      // a stream that dies instantly several times in a row = a network that blocks streaming: poll instead
      if (N.fails >= 4 && Date.now() - started < 4000) return startPolling();
      setTimeout(openStream, Math.min(3000, 400 * N.fails));
    });
  }

  function startPolling() {
    N.mode = "poll"; setState("live");
    (function tick() {
      if (N.stopped) return;
      N.api("/api/grid/poll?since=" + N.lastId).then(function (d) {
        setState("live");
        (d.events || []).forEach(function (e) { dispatch(e.id, e.type, e.data); });
        N.pollTimer = setTimeout(tick, 260);
      }).catch(function (e) { if (e.status === 401) { setState("auth"); N.stopped = true; return; } setState("reconnecting"); N.pollTimer = setTimeout(tick, 1200); });
    })();
  }

  /** handlers: { hello, queue, room, round, countdown, tick, round_end, match_end, presence, __state } */
  N.connect = function (handlers) {
    N.handlers = handlers || {}; if (!N.token) return false;
    if (!N.stopped && N.state !== "idle") return true;
    N.stopped = false; N.fails = 0; N.mode = "stream"; openStream(); return true;
  };
  N.disconnect = function () { N.stopped = true; if (N.ctl) try { N.ctl.abort(); } catch (e) {} if (N.pollTimer) clearTimeout(N.pollTimer); N.state = "idle"; N.lastId = 0; };
  /** page came back to the foreground: mobile browsers freeze streams in the background */
  N.nudge = function () { if (N.stopped) return; if (N.mode === "stream") { if (N.ctl) try { N.ctl.abort(); } catch (e) {} openStream(); } };

  root.GridNet = N;
})(window);
