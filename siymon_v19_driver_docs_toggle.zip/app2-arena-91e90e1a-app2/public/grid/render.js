/* SIYMON GRID BATTLE — canvas renderer.
   Draws a "view" model: { w, h, flip, pos:[{x,y,px,py}], walls:[[o,x,y,owner]], cur, hints:[[x,y]], ghost:{o,x,y,ok}|null, moveAt, moveMs, over }.
   Board squares, goal rows, balls (with a short slide between squares), barriers, move hints and the barrier preview.
   `flip` turns the board 180 degrees so the local player always sits at the bottom (online, seat 2).
   Quality: "high" = glow + shadows, "low" = flat shapes, DPR capped. "auto" starts high and drops to low on slow frames.
   No emoji, no external assets. */
(function (root) {
  "use strict";
  var COLORS = [{ main: "#5DD62C", core: "#E4FFD3", glow: "93,214,44" }, { main: "#FF8A3D", core: "#FFE3CF", glow: "255,138,61" }];
  var BG = "#0B0D0A";

  function create(canvas) {
    var g = canvas.getContext("2d", { alpha: false }), R = { quality: "auto" };
    var cell = 10, W = 0, H = 0, dpr = 1, low = false, ema = 16, lastT = 0, lowCount = 0, started = 0, flash = 0, parts = [], rings = [], flip = false;

    R.setQuality = function (q) { R.quality = q; low = q === "low"; ema = 16; lowCount = 0; if (W) R.resize(W, H, true); };
    R.isLow = function () { return low; };

    R.resize = function (gw, gh, force) {
      var box = canvas.parentNode.getBoundingClientRect();
      if (box.width < 40 || box.height < 40) return;
      W = gw; H = gh;
      dpr = Math.min(root.devicePixelRatio || 1, low ? 1.25 : 2);
      var css = Math.floor(Math.min(box.width / W, box.height / H)), cw = css * W, ch = css * H;
      var pw = Math.floor(cw * dpr), ph = Math.floor(ch * dpr);
      if (!force && canvas.width === pw && canvas.height === ph) return;
      canvas.style.width = cw + "px"; canvas.style.height = ch + "px"; canvas.width = pw; canvas.height = ph;
      cell = pw / W;
    };

    /* ----- coordinate helpers (board <-> screen, honouring `flip`) ----- */
    function vx(x) { return flip ? W - 1 - x : x; }
    function vy(y) { return flip ? H - 1 - y : y; }
    function rr(x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

    /** Convert a pointer position (CSS px relative to the canvas) into the square and the nearest 2-long barrier slot. */
    R.hit = function (px, py) {
      var k = cell / dpr, fx0 = px / k, fy0 = py / k;
      var cx = Math.min(W - 1, Math.max(0, Math.floor(fx0))), cy = Math.min(H - 1, Math.max(0, Math.floor(fy0)));
      var fx = fx0 - cx, fy = fy0 - cy;
      var dl = fx, dr = 1 - fx, dt = fy, db = 1 - fy, m = Math.min(dl, dr, dt, db), o, ax, ay;
      if (m === dt || m === db) {            // horizontal line above / below this square
        o = "h"; ay = m === dt ? cy - 1 : cy; ax = fx < 0.5 ? cx - 1 : cx;
      } else {                               // vertical line left / right of this square
        o = "v"; ax = m === dl ? cx - 1 : cx; ay = fy < 0.5 ? cy - 1 : cy;
      }
      ax = Math.min(W - 2, Math.max(0, ax)); ay = Math.min(H - 2, Math.max(0, ay));
      if (flip) { ax = W - 2 - ax; ay = H - 2 - ay; cx = W - 1 - cx; cy = H - 1 - cy; }
      return { cell: [cx, cy], wall: { o: o, x: ax, y: ay } };
    };

    function glow(c, b) { if (!low) { g.shadowColor = c; g.shadowBlur = b; } }
    function noGlow() { g.shadowBlur = 0; }

    function drawBoard(view) {
      var i, x, y, gap = cell * 0.07;
      g.globalCompositeOperation = "source-over"; g.globalAlpha = 1;
      g.fillStyle = BG; g.fillRect(0, 0, canvas.width, canvas.height);
      // goal rows: the row a player must reach, tinted with that player's colour
      for (i = 0; i < 2; i++) {
        var goalY = vy(i === 0 ? 0 : H - 1), c = COLORS[i];
        var gr = g.createLinearGradient(0, goalY * cell, 0, (goalY + 1) * cell);
        gr.addColorStop(0, "rgba(" + c.glow + (goalY === 0 ? ",.30)" : ",.06)")); gr.addColorStop(1, "rgba(" + c.glow + (goalY === 0 ? ",.06)" : ",.30)"));
        g.fillStyle = gr; g.fillRect(0, goalY * cell, W * cell, cell);
      }
      for (y = 0; y < H; y++) for (x = 0; x < W; x++) {
        g.fillStyle = (x + y) % 2 ? "rgba(248,248,248,.060)" : "rgba(248,248,248,.032)";
        rr(x * cell + gap, y * cell + gap, cell - gap * 2, cell - gap * 2, cell * 0.16); g.fill();
      }
      // finish markers: small chevrons along each goal row
      g.lineWidth = Math.max(1.5, cell * 0.06); g.lineCap = "round"; g.lineJoin = "round";
      for (i = 0; i < 2; i++) {
        var gy = vy(i === 0 ? 0 : H - 1), up = (i === 0) !== flip ? -1 : 1; g.strokeStyle = "rgba(" + COLORS[i].glow + ",.55)";
        for (x = 0; x < W; x++) { var cxm = (x + 0.5) * cell, cym = (gy + 0.5) * cell, s = cell * 0.13; g.beginPath(); g.moveTo(cxm - s, cym - up * s * 0.4); g.lineTo(cxm, cym + up * s * 0.9); g.lineTo(cxm + s, cym - up * s * 0.4); g.stroke(); }
      }
    }

    function wallRect(o, ax, ay) {            // board anchor -> screen bar (centre line, length 2 cells)
      if (flip) { ax = W - 2 - ax; ay = H - 2 - ay; }
      return o === "h" ? { x0: ax * cell, y0: (ay + 1) * cell, x1: (ax + 2) * cell, y1: (ay + 1) * cell } : { x0: (ax + 1) * cell, y0: ay * cell, x1: (ax + 1) * cell, y1: (ay + 2) * cell };
    }
    function bar(o, ax, ay, color, alpha, thick) {
      var r = wallRect(o, ax, ay), pad = cell * 0.09, dx = r.x1 > r.x0 ? pad : 0, dy = r.y1 > r.y0 ? pad : 0;
      g.globalAlpha = alpha; g.strokeStyle = color; g.lineCap = "round"; g.lineWidth = cell * (thick || 0.17);
      g.beginPath(); g.moveTo(r.x0 + dx, r.y0 + dy); g.lineTo(r.x1 - dx, r.y1 - dy); g.stroke(); g.globalAlpha = 1;
    }

    function ball(ci, x, y, now, active) {
      var col = COLORS[ci], r = cell * 0.34, pulse = active ? 1 + Math.sin(now / 220) * 0.06 : 1;
      if (active) { g.globalAlpha = 0.5 + Math.sin(now / 220) * 0.2; g.strokeStyle = col.main; g.lineWidth = cell * 0.07; g.beginPath(); g.arc(x, y, r * 1.5 * pulse, 0, 6.2832); g.stroke(); g.globalAlpha = 1; }
      glow(col.main, cell * 0.9);
      var gr = g.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r * pulse * 1.1);
      gr.addColorStop(0, col.core); gr.addColorStop(0.45, col.main); gr.addColorStop(1, "rgba(" + col.glow + ",.55)");
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, r * pulse, 0, 6.2832); g.fill(); noGlow();
    }

    R.burst = function (bx, by, ci) {
      var n = low ? 16 : 40, col = COLORS[ci], X = (vx(bx) + 0.5) * cell, Y = (vy(by) + 0.5) * cell;
      for (var i = 0; i < n; i++) { var a = Math.random() * 6.2832, s = (0.4 + Math.random() * 3.2) * cell * 0.12; parts.push({ x: X, y: Y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 1, k: 0.016 + Math.random() * 0.02, c: i % 3 ? col.main : "#FFFFFF" }); }
      rings.push({ x: X, y: Y, r: cell * 0.5, life: 1, c: col.main }); flash = 0.28;
    };
    R.clearFx = function () { parts.length = 0; rings.length = 0; flash = 0; };

    /** draw one frame. view = model, now = performance.now() */
    R.draw = function (view, now) {
      if (!view || !W) return;
      flip = !!view.flip;
      var dt = Math.min(64, now - (lastT || now)); lastT = now;
      ema = ema * 0.94 + dt * 0.06;
      if (!started) started = now;
      if (R.quality === "auto" && !low && now - started > 2500) { if (ema > 26) lowCount++; else lowCount = Math.max(0, lowCount - 1); if (lowCount > 50) { low = true; R.resize(W, H, true); } }
      drawBoard(view);
      var i, k, h;
      // move hints for the player whose turn it is (only when a human may act)
      if (view.hints && view.hints.length) {
        var hc = COLORS[view.cur], pl = 0.55 + Math.sin(now / 260) * 0.25;
        for (k = 0; k < view.hints.length; k++) {
          h = view.hints[k]; var hx = (vx(h[0]) + 0.5) * cell, hy = (vy(h[1]) + 0.5) * cell;
          g.globalAlpha = 0.16; g.fillStyle = hc.main; rr(vx(h[0]) * cell + cell * 0.07, vy(h[1]) * cell + cell * 0.07, cell * 0.86, cell * 0.86, cell * 0.16); g.fill();
          g.globalAlpha = pl; g.strokeStyle = hc.main; g.lineWidth = cell * 0.05; rr(vx(h[0]) * cell + cell * 0.07, vy(h[1]) * cell + cell * 0.07, cell * 0.86, cell * 0.86, cell * 0.16); g.stroke();
          g.globalAlpha = 1; g.fillStyle = hc.main; g.beginPath(); g.arc(hx, hy, cell * 0.08, 0, 6.2832); g.fill();
        }
      }
      // placed barriers (the newest one flashes briefly)
      for (k = 0; k < view.walls.length; k++) {
        var q = view.walls[k], c = COLORS[q[3]], fresh = view.lastWall === k ? Math.max(0, 1 - (now - view.lastWallAt) / 700) : 0;
        glow(c.main, cell * (0.35 + fresh * 0.8)); bar(q[0], q[1], q[2], c.main, 1, 0.17); noGlow(); bar(q[0], q[1], q[2], c.core, 0.55, 0.06);
      }
      // barrier preview
      if (view.ghost) { var gh = view.ghost; bar(gh.o, gh.x, gh.y, gh.ok ? COLORS[view.cur].main : "#FF6B6B", 0.55 + Math.sin(now / 150) * 0.15, 0.2); }
      // balls (slide to the new square)
      var a = view.moveMs ? Math.min(1, Math.max(0, (now - view.moveAt) / view.moveMs)) : 1; a = 1 - Math.pow(1 - a, 3);
      for (i = 0; i < 2; i++) {
        var p = view.pos[i], sx = p.px + (p.x - p.px) * a, sy = p.py + (p.y - p.py) * a;
        ball(i, (vx(sx) + 0.5) * cell, (vy(sy) + 0.5) * cell, now, !view.over && view.cur === i);
      }
      // particles + shock rings
      for (k = parts.length - 1; k >= 0; k--) { var pt = parts[k]; pt.x += pt.vx * dt * 0.06; pt.y += pt.vy * dt * 0.06; pt.vx *= 0.985; pt.vy *= 0.985; pt.life -= pt.k * dt * 0.06; if (pt.life <= 0) { parts.splice(k, 1); continue; } g.globalAlpha = pt.life; g.fillStyle = pt.c; g.fillRect(pt.x - cell * 0.05, pt.y - cell * 0.05, cell * 0.1, cell * 0.1); }
      for (k = rings.length - 1; k >= 0; k--) { var rg = rings[k]; rg.r += cell * 0.09 * dt * 0.06 * 3; rg.life -= 0.03 * dt * 0.06 * 3; if (rg.life <= 0) { rings.splice(k, 1); continue; } g.globalAlpha = rg.life * 0.8; g.strokeStyle = rg.c; g.lineWidth = cell * 0.12; g.beginPath(); g.arc(rg.x, rg.y, rg.r, 0, 6.2832); g.stroke(); }
      g.globalAlpha = 1;
      if (flash > 0.01) { g.fillStyle = "rgba(255,255,255," + flash * 0.4 + ")"; g.fillRect(0, 0, canvas.width, canvas.height); flash *= 0.86; }
    };
    return R;
  }
  root.GridRender = { create: create, COLORS: COLORS };
})(window);
