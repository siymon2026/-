# Siymon AI — المساعد الذكي للزبائن

## ما الذي أُضيف
مساعد عائم داخل صفحات الزبائن (الرئيسية، الطلبات، المحفظة، النقاط، الحساب، الإشعارات، المتاجر، الصيدلية، الدعم). يتصل بمزود AI حقيقي عبر السيرفر فقط، ويقرأ بيانات Siymon الفعلية عبر أدوات (Tools) مقيّدة بهوية الزبون الموثقة.

## المعمارية
```
المتصفح (public/ai/*)                    السيرفر (lib/ai/*)                          المزود
siymon-ai.js  ──POST /api/ai/chat (SSE)──▶ routes.js ─▶ engine.js ──▶ providers.js ──▶ Gemini / متوافق مع OpenAI
 UI + بطاقات                               │            │  حلقة: نموذج ⇄ أدوات
siymon-ai-core.js                          │            ├─ tools.js  ◀─ data.js ◀─ دوال التحميل الحالية في server.js
siymon-ai-character.js (SVG)               │            ├─ guard.js  (تنقية، إخفاء أسرار، حقن)
siymon-ai-i18n.js (ar/fr/en)               │            ├─ limits.js (حدود الرسائل)
                                           └─ store.js (محادثات + إحصاءات) · settings.js · prompt.js
```
- المفتاح لا يصل إلى المتصفح أبداً ولا يُخزَّن في ملفات البيانات ولا يُعرض في لوحة الإدارة (آخر 4 أحرف فقط).
- الهوية تؤخذ من توكن الزبون الموثق في السيرفر. لا يُقبل أي `customerId` من المتصفح أو من النموذج.
- الأدوات للقراءة فقط. طلب الدعم يُقترح فقط، ولا يُنشأ إلا بعد ضغط الزبون على زر التأكيد (`POST /api/ai/support`).
- التخزين: ملفات JSON الحالية في `DATA_DIR` (`ai_settings.json`, `ai_conversations.json`, `ai_stats.json`). لم تتغير قاعدة البيانات ولا المصادقة.
- محادثات الزبون المسجل تُحفظ حسب `retentionDays` (افتراضياً 30 يوماً) ويحذفها الزبون من القائمة، وتُحذف مع حذف الحساب. محادثات الزوار في ذاكرة السيرفر فقط (3 ساعات) ولا تُكتب على القرص.

## الأدوات
`search_products`, `get_product_details`, `get_restaurants`, `get_order_status`, `get_customer_orders`, `get_delivery_tracking`, `get_wallet_balance`, `get_payment_methods`, `get_customer_profile`, `get_loyalty_points`, `get_app_settings`, `navigate_to_app_page`, `create_support_request`.
أدوات الحساب الخاص (الطلبات، المحفظة، النقاط، الملف) مرفوضة للزوار. صفحات التنقل المسموحة هي الصفحات الموجودة فعلاً فقط.

## الإعداد
1. أضف المفتاح كمتغير بيئة على السيرفر ثم أعد التشغيل:
   - Gemini: `GEMINI_API_KEY=...`
   - أي مزود متوافق مع OpenAI: `AI_API_KEY=...` (ويمكن ضبط العنوان من لوحة الإدارة، https فقط).
2. افتح لوحة الإدارة، قسم «مساعد Siymon AI»: اختر المزود والنموذج، اضغط «اختبار الاتصال»، ثم فعّل المساعد واحفظ.
3. حتى يتم ضبط المفتاح والتفعيل، لا يظهر المساعد للزبائن إطلاقاً.

متغيرات البيئة: `GEMINI_API_KEY` أو `AI_API_KEY` (أو `OPENAI_API_KEY`). كل شيء آخر من لوحة الإدارة.

## الاختبارات
`node --test tests/ai-engine.test.js tests/ai-routes.test.js` (محاكي مزود محلي، لا يحتاج إنترنت)، والمشروع كله: `node --test tests/*.test.js`.
