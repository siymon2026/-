"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const loyalty = require("../lib/loyalty");
const app = require("../lib/loyalty-app");

const NOW = "2026-10-31T12:00:00.000Z";
const S = loyalty.settingsOf({ enabled: true, earn: { enabled: true, unitAmount: 10, pointsPerUnit: 1 }, redeem: { enabled: true, minPoints: 100, pointsPerCurrencyUnit: 100 }, expiry: { enabled: true, days: 365 } });
const acct = () => ({ customerId: "C1", entries: [] });
function earn(a, n, points, at, extra = {}) {
  return loyalty.credit(a, Object.assign({ ref: "loyalty:earn:" + n, kind: "earn", points, at, expiresDays: 365 }, extra));
}

test("tier: bronze by default, silver at 500, gold at 1500 (rolling 12 months)", () => {
  const a = acct();
  assert.equal(app.tierState(a, Date.parse(NOW)).id, "bronze");
  earn(a, 1, 500, "2026-09-01T00:00:00.000Z");
  const t = app.tierState(a, Date.parse(NOW));
  assert.equal(t.id, "silver");
  assert.equal(t.next.id, "gold");
  assert.equal(t.toNext, 1000);
  earn(a, 2, 1000, "2026-10-01T00:00:00.000Z");
  assert.equal(app.tierState(a, Date.parse(NOW)).id, "gold");
  assert.equal(app.tierState(a, Date.parse(NOW)).progress, 1);
});

test("tier: points older than 12 months do not count; redeem/expire do not lower status", () => {
  const a = acct();
  earn(a, 1, 900, "2025-01-01T00:00:00.000Z");
  assert.equal(app.tierState(a, Date.parse(NOW)).earnedInWindow, 0);
  const b = acct();
  earn(b, 1, 600, "2026-09-01T00:00:00.000Z");
  loyalty.debit(b, { ref: "loyalty:redeem:x", kind: "redeem", points: 300, at: "2026-09-02T00:00:00.000Z" });
  assert.equal(app.tierState(b, Date.parse(NOW)).id, "silver");
});

test("tier: a reversed order lowers earned-in-window, never below 0", () => {
  const a = acct();
  earn(a, 1, 100, "2026-09-01T00:00:00.000Z");
  loyalty.debit(a, { ref: "loyalty:reverse:1", kind: "reverse", points: 100, at: "2026-09-03T00:00:00.000Z" });
  assert.equal(app.earnedInWindow(a, Date.parse(NOW)), 0);
});

test("ladder: next step, missing points and progress", () => {
  const l = app.ladder(250, S);
  assert.equal(l.steps[0].points, 500); // 5 MAD = 500 pts at 100 pts/MAD
  assert.equal(l.next.points, 500);
  assert.equal(l.next.missing, 250);
  assert.equal(l.progress, 0.5);
  const l2 = app.ladder(1200, S);
  assert.equal(l2.steps.filter((s) => s.unlocked).length, 2);
  assert.equal(l2.next.value, 20);
  assert.equal(app.ladder(999999, S).next, null);
});

test("ladder: minimum conversion above the first money step becomes the first rung", () => {
  const s = loyalty.settingsOf({ enabled: true, redeem: { enabled: true, minPoints: 1000, pointsPerCurrencyUnit: 100 } });
  assert.equal(app.ladder(0, s).steps[0].points, 1000);
});

test("expiring: groups lots by day, ignores far/expired/pending", () => {
  const a = acct();
  earn(a, 1, 40, "2025-11-10T00:00:00.000Z"); // expires 2026-11-10 (10 days)
  earn(a, 2, 60, "2025-11-10T08:00:00.000Z"); // same day
  earn(a, 3, 30, "2026-02-01T00:00:00.000Z"); // expires 2027-02 (far)
  const e = app.expiring(a, Date.parse(NOW), 30);
  assert.equal(e.total, 100);
  assert.equal(e.items.length, 1);
  assert.equal(e.next.date, "2026-11-10");
});

test("appView: expiry off => nothing expiring; earn preview follows the live rule", () => {
  const off = loyalty.settingsOf({ enabled: true, expiry: { enabled: false, days: 365 } });
  const a = acct();
  earn(a, 1, 40, "2025-11-10T00:00:00.000Z");
  const v = app.appView(a, off, loyalty.balances(a, NOW), NOW);
  assert.equal(v.expiring.total, 0);
  assert.equal(v.earnPer100, 10);
  assert.equal(app.earnPreview(loyalty.settingsOf({ enabled: false }), 100), 0);
});
