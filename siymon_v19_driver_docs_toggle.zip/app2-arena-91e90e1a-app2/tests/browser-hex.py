"""500 m hexagons: admin map counts, customer "nearest store in my hexagon", store asked for its location.
Leaflet is replaced by tests/leaflet-stub.js + tests/leaflet-hex-ext.js (no internet in the sandbox): this verifies the LOGIC and DOM
(cells created, counts, popups, control, banner, geolocation flow) against the REAL lib/hex-routes.js and REAL role table.
Run: PORT=4031 node tests/zones-mock-server.js &  python3 tests/browser-hex.py"""
import asyncio, json, os, urllib.request
from playwright.async_api import async_playwright
BASE = "http://127.0.0.1:4031"
T = os.path.dirname(__file__)
STUB = open(os.path.join(T, "leaflet-stub.js")).read() + "\n" + open(os.path.join(T, "leaflet-hex-ext.js")).read()
fails = []; errs = []
def check(n, c, x=""):
    print(("PASS " if c else "FAIL ") + n + ("" if c else " -> " + str(x)))
    if not c: fails.append(n)
def http(method, path, body=None, token=None):
    h = {"Content-Type": "application/json"}
    if token: h["X-Admin-Token"] = token
    r = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method=method)
    try:
        with urllib.request.urlopen(r) as x: return x.status, json.load(x)
    except urllib.error.HTTPError as e: return e.code, json.load(e)
def at(dx, dy):  # metres east / north of the grid origin (Berrechid)
    return {"lat": 33.265 + dy / 111194.9, "lng": -7.59 + dx / (111194.9 * 0.83619)}
S = lambda i, n, p=None, st="active": {"id": i, "name": {"ar": n, "en": n}, "status": st, **({"lat": p["lat"], "lng": p["lng"]} if p else {})}
async def main():
    http("POST", "/__reset")
    http("POST", "/__seed-hex", {
        "restaurants": [S("S1", "Pizza Berrechid", at(20, 20)), S("S2", "Tacos Center", at(60, 30)), S("S3", "Far Burger", at(2600, 1500)),
                        S("S4", "No Location Cafe"), S("S5", "Hidden", at(10, 10), "unpublished")],
        "drivers": [{"id": "d1", "name": "Ali", "dispatchState": "available", "freshness": "live", "location": at(40, 40)},
                    {"id": "d2", "name": "Omar", "dispatchState": "delivering", "freshness": "live", "location": at(2600, 1500)},
                    {"id": "d3", "name": "Off", "dispatchState": "offline", "freshness": "live", "location": at(40, 40)}]})
    st, ov = http("GET", "/api/admin/hex/overview", token="tok-system")
    check("overview: real role table lets the system admin in", st == 200 and ov["ok"], st)
    check("overview: 500 m cells, ~1000 of them cover the default 7 km area", ov["diameterM"] == 500 and 700 < ov["summary"]["covered"] < 1400, ov["summary"])
    check("overview: 4 published stores, 1 without location, 2 live drivers", (ov["summary"]["stores"], ov["summary"]["unlocated"], ov["summary"]["drivers"], ov["summary"]["available"]) == (4, 1, 2, 1), ov["summary"])
    check("overview: order supervisor can read it", http("GET", "/api/admin/hex/overview", token="tok-ordersup")[0] == 200)
    check("overview: accountant is refused (no zones.read)", http("GET", "/api/admin/hex/overview", token="tok-accountant")[0] == 403)
    check("overview: no token -> 401", http("GET", "/api/admin/hex/overview")[0] == 401)
    home = next(c for c in ov["cells"] if any(s["id"] == "S1" for s in c["storeList"]))
    check("S1 and S2 share their hexagon with driver Ali", home["stores"] == 2 and home["drivers"] == 1 and home["available"] == 1, home["stores"])

    async with async_playwright() as p:
        b = await p.chromium.launch()
        # ---------------- admin zones map ----------------
        ctx = await b.new_context(viewport={"width": 1300, "height": 850}, service_workers="block")
        await ctx.route("**/leaflet.min.js", lambda r: r.fulfill(status=200, content_type="text/javascript", body=STUB))
        await ctx.route("**/leaflet.min.css", lambda r: r.fulfill(status=200, content_type="text/css", body=""))
        await ctx.add_init_script("localStorage.setItem('siymon_admin_lang_v1','ar'); localStorage.setItem('siymon_admin_token_v2','tok-system');")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("zones: " + str(e)))
        await pg.goto(BASE + "/admin/zones/"); await pg.wait_for_function("window.__hex && __hex.cells().length > 500", timeout=10000)
        n = await pg.evaluate("__hex.cells().length")
        check("map: one hexagon polygon per covered cell", n == len(ov["cells"]), (n, len(ov["cells"])))
        ctl = await pg.inner_text("[data-stub-ctl]")
        check("map: control shows covered cells, stores and drivers", str(ov["summary"]["covered"]) in ctl and "المطاعم" in ctl and "السائقون" in ctl, ctl[:120])
        check("map: stores without a location are listed for the admin", "No Location Cafe" in await pg.evaluate("document.querySelector('[data-stub-ctl]').innerHTML") or "No Location Cafe" in await pg.evaluate("[...document.querySelectorAll('[data-stub-ctl] li')].map(x=>x.textContent).join()"))
        labels = await pg.evaluate("__hex.labels()")
        check("map: cells with stores/drivers carry a count label", any("🍽2" in l and "🛵1" in l for l in labels), labels[:3])
        check("click on a hexagon: shows 2 stores and 1 driver, with names", await pg.evaluate("__hex.click(%s)" % json.dumps(home["id"])))
        txt = await pg.evaluate("__hex.popupText()")
        check("popup: counts", "2" in txt and "1" in txt and "متاح" in txt, txt)
        check("popup: store names + driver name", "Pizza Berrechid" in txt and "Tacos Center" in txt and "Ali" in txt, txt)
        check("popup: unpublished and offline are NOT counted", "Hidden" not in txt and "Off" not in txt, txt)
        empty = next(c for c in ov["cells"] if c["stores"] == 0 and c["drivers"] == 0)
        await pg.evaluate("__hex.click(%s)" % json.dumps(empty["id"]))
        txt0 = await pg.evaluate("__hex.popupText()")
        check("popup of an empty hexagon says there is none", txt0.count("0") >= 2 and "لا يوجد" in txt0, txt0)
        await ctx.close()

        # ---------------- customer: nearest store in my hexagon ----------------
        async def customer(point, acc=12):
            c = await b.new_context(viewport={"width": 390, "height": 844}, permissions=["geolocation"], geolocation={"latitude": point["lat"], "longitude": point["lng"], "accuracy": acc}, service_workers="block")
            await c.add_init_script("localStorage.setItem('siymon_lang_v1','ar');")
            pg = await c.new_page(); pg.on("pageerror", lambda e: errs.append("home: " + str(e)))
            await pg.goto(BASE + "/"); await pg.wait_for_selector(".near-btn", timeout=10000)
            await pg.locator(".near-btn").click()
            await pg.wait_for_function("document.querySelector('.near-list') || document.querySelector('.near-msg.bad')", timeout=15000)
            return c, pg
        c, pg = await customer(at(30, 25))
        items = await pg.locator(".near-item").all_inner_texts()
        check("customer in the hexagon: his hexagon's stores come first, nearest first", len(items) >= 2 and "Pizza Berrechid" in items[0] and "Tacos Center" in items[1], items)
        check("customer: each store shows only a distance (no explanation of how the search works)", "سداسي" not in items[0] and ("م" in items[0]), items[0])
        check("customer: far store (4 km) is not offered", not any("Far Burger" in i for i in items), items)
        check("customer: the unpublished and unlocated stores never appear", not any(("Hidden" in i or "No Location" in i) for i in items), items)
        await pg.screenshot(path="/tmp/shots/hex_near.png")
        await c.close()
        c, pg = await customer(at(430, 0))     # the next hexagon over: none of our stores in it
        its = await pg.locator(".near-item").all_inner_texts()
        card = await pg.inner_text("#nearCard")
        check("customer in an empty hexagon: still shown the stores around, no hexagon wording", len(its) >= 1 and "سداسي" not in card, (card, its))
        await c.close()
        c, pg = await customer(at(9000, 9000))
        bad = await pg.inner_text(".near-msg.bad")
        check("customer outside every service area: told so, no store offered", "خارج مناطق الخدمة" in bad and await pg.locator(".near-item").count() == 0, bad)
        await c.close()

        # ---------------- store: asked for its location ----------------
        c = await b.new_context(viewport={"width": 1200, "height": 800}, permissions=["geolocation"], geolocation={"latitude": 33.2655, "longitude": -7.5895, "accuracy": 800}, service_workers="block")
        pg = await c.new_page(); pg.on("pageerror", lambda e: errs.append("store: " + str(e)))
        await pg.goto(BASE + "/restaurant/#admintoken=tok-rest-S4"); await pg.wait_for_selector("#locBanner:not([hidden])", timeout=10000)
        check("store without a location: the banner asks for it", "حدّد موقع متجرك" in await pg.inner_text("#locBannerTitle") and not await pg.evaluate("document.getElementById('locBanner').classList.contains('ok')"))
        await pg.locator("#locBannerBtn").click(); await pg.wait_for_timeout(1800)
        s4 = next(s for s in json.load(urllib.request.urlopen(BASE + "/__stores")) if s["id"] == "S4")
        check("imprecise reading (800 m) is refused: nothing saved, banner still asks", "lat" not in s4 and not await pg.evaluate("document.getElementById('locBanner').classList.contains('ok')"), s4)
        await c.set_geolocation({"latitude": 33.2655, "longitude": -7.5895, "accuracy": 10})
        await pg.locator("#locBannerBtn").click()
        await pg.wait_for_function("document.getElementById('locBanner').classList.contains('ok')", timeout=15000)
        s4 = next(s for s in json.load(urllib.request.urlopen(BASE + "/__stores")) if s["id"] == "S4")
        check("good reading: saved on the store itself and the banner turns green", abs(s4["lat"] - 33.2655) < 1e-3 and s4["locationBy"] == "store" and s4["locationAccuracy"] == 10, s4)
        await pg.screenshot(path="/tmp/shots/hex_store_banner.png")
        st, ov2 = http("GET", "/api/admin/hex/overview", token="tok-system")
        check("admin map now counts that store (no longer 'without location')", ov2["summary"]["unlocated"] == 0 and ov2["summary"]["storesLocated"] == 4, ov2["summary"])
        await c.close()

        # ---------------- dispatch (distribution) map: the same 500 m hexagons, clickable ----------------
        http("POST", "/__seed-hex", {"restaurants": [S("S1", "Pizza Berrechid", at(20, 20))],
                                     "drivers": [{"id": "d1", "name": "Ali", "dispatchState": "available", "freshness": "live", "location": at(40, 40)}]})
        c = await b.new_context(viewport={"width": 1300, "height": 900}, service_workers="block")
        await c.add_init_script("localStorage.setItem('siymon_admin_token_v2','tok-system');localStorage.setItem('siymon_admin_lang_v1','ar')")
        pg = await c.new_page(); pg.on("pageerror", lambda e: errs.append("dispatch: " + str(e)))
        await pg.goto(BASE + "/admin/"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.getElementById('dispatchBtn').click()")
        await pg.wait_for_function("document.querySelectorAll('#dspMap polygon').length > 300", timeout=15000)
        check("dispatch map: the whole hexagon grid is drawn (not only cells with drivers)", await pg.evaluate("document.querySelectorAll('#dspMap polygon').length") > 700)
        await pg.evaluate("""() => { const hit=[...document.querySelectorAll('#dspMap polygon')].find(p=>p.querySelector('title') && p.querySelector('title').textContent.includes('🍽 1')); hit.dispatchEvent(new MouseEvent('click',{bubbles:true})); }""")
        await pg.wait_for_selector("#dspCellInfo:not([hidden])", timeout=4000)
        info = await pg.inner_text("#dspCellInfo")
        check("dispatch map: clicking a hexagon shows its stores and drivers", "Pizza" in info and "Ali" in info and "متاح" in info, info)
        await c.close()
        await b.close()
asyncio.run(main())
check("no JS errors on any page", not errs, errs[:3])
print("ALL PASS" if not fails else "FAILED: " + ", ".join(fails))
