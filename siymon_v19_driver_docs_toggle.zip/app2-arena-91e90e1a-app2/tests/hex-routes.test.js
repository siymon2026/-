"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const hex = require("../lib/hexcell");
const Z = require("../lib/service-zones");
const H = require("../lib/hex-routes");
const catalog = require("../lib/catalog");

const B = { lat: 33.265, lng: -7.59 };
const at = (dx, dy) => hex.fromXY(hex.toXY(B.lat, B.lng).x + dx, hex.toXY(B.lat, B.lng).y + dy); // metres east / north of Berrechid
const store = (id, p, extra = {}) => ({ id, name: { ar: "م" + id }, status: "active", ...(p ? { lat: p.lat, lng: p.lng } : {}), ...extra });
const poly = Z.circlePolygon(B, 1500, 36);
const zone = { id: "z1", name: "B", city: "Berrechid", active: true, polygon: poly };

test("zone gate: a customer in a hexagon that covers the zone is served; far away is not; legacy polygon behaviour kept", () => {
  const inside = at(100, 100), far = at(9000, 0);
  assert.equal(Z.evaluate({ zones: [zone], dropoff: inside }).ok, true);
  assert.equal(Z.evaluate({ zones: [zone], dropoff: far }).reason, "OUTSIDE_SERVICE_AREA");
  // just outside the polygon edge but inside a hexagon that overlaps the zone -> served (what the map shows is what the gate enforces)
  const edge = at(1500 + 60, 0);
  assert.equal(Z.pointInPolygon(edge.lat, edge.lng, poly), false);
  const covered = hex.coverSet(poly).has(hex.cellOf(edge.lat, edge.lng));
  assert.equal(Z.evaluate({ zones: [zone], dropoff: edge }).ok, covered);
  // a point beyond any covering hexagon is refused
  assert.equal(Z.evaluate({ zones: [zone], dropoff: at(1500 + 700, 0) }).ok, false);
  // inactive zone never serves
  assert.equal(Z.evaluate({ zones: [{ ...zone, active: false }], dropoff: inside }).reason, "NO_ACTIVE_ZONES");
});

test("zone cover contains every point of the polygon (no customer inside the polygon is ever refused)", () => {
  let seed = 3; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 300; i++) {
    const a = rnd() * 2 * Math.PI, r = Math.sqrt(rnd()) * 1490;
    const p = at(Math.cos(a) * r, Math.sin(a) * r);
    assert.equal(Z.inZone(zone, p.lat, p.lng), true);
  }
});

test("overview: covered cells + store and driver counts per cell; unlocated stores listed", () => {
  const sA = store("A", at(10, 10)), sB = store("B", at(20, 5)), sC = store("C", at(2000, 2000)), sNo = store("N", null);
  const sHidden = store("H", at(0, 0), { status: "unpublished" });
  const drivers = [
    { id: "d1", name: "Ali", dispatchState: "available", freshness: "live", location: at(30, 30) },
    { id: "d2", name: "Omar", dispatchState: "delivering", freshness: "live", location: at(15, 15) },
    { id: "d3", name: "Off", dispatchState: "offline", freshness: "live", location: at(15, 15) },     // offline: not counted
    { id: "d4", name: "Lost", dispatchState: "available", freshness: "lost", location: at(15, 15) },  // no signal: not counted
    { id: "d5", name: "NoGPS", dispatchState: "available", freshness: "lost", location: null },
  ];
  const ov = H.buildOverview({ zones: [zone], stores: [sA, sB, sC, sNo, sHidden], drivers, isPublic: catalog.isPublic });
  assert.equal(ov.diameterM, 500);
  assert.equal(ov.summary.stores, 4);          // an unpublished store is not counted
  assert.equal(ov.summary.unlocated, 1);
  assert.deepEqual(ov.unlocated.map((x) => x.id), ["N"]);
  assert.equal(ov.summary.drivers, 2); assert.equal(ov.summary.available, 1);
  const cellA = ov.cells.find((c) => c.id === hex.cellOf(at(10, 10).lat, at(10, 10).lng));
  assert.ok(cellA && cellA.inZone);
  assert.equal(cellA.stores, 2);               // A and B share the home cell
  assert.equal(cellA.drivers, 2); assert.equal(cellA.available, 1);
  assert.deepEqual(cellA.storeList.map((x) => x.id).sort(), ["A", "B"]);
  assert.equal(cellA.boundary.length, 6);
  const cellC = ov.cells.find((c) => c.stores === 1 && c.storeList[0].id === "C");
  assert.ok(cellC, "a store outside the zone still appears (with inZone=false) so the admin can see it");
  assert.equal(cellC.inZone, false);
  assert.ok(ov.summary.covered >= 20 && ov.summary.covered < 100);
  assert.ok(ov.cells.every((c) => c.id.startsWith("hx:")));
});

test("nearest store: his own hexagon first, nearest first; otherwise the rings around it", () => {
  const home = at(5, 5);
  const near = store("near", at(60, 60)), same2 = store("same2", at(-80, 40)), next = store("next", at(500, 0)), far = store("far", at(3000, 0)), nowhere = store("nowhere", null);
  const r = H.findNearby({ stores: [far, next, same2, near, nowhere], lat: home.lat, lng: home.lng, isPublic: catalog.isPublic });
  assert.equal(r.cell, hex.cellOf(home.lat, home.lng));
  assert.deepEqual(r.inCell.map((x) => x.store.id), ["near", "same2"]);
  assert.ok(r.inCell[0].distanceM < r.inCell[1].distanceM);
  assert.equal(r.hasInCell, true);
  assert.deepEqual(r.nearby.map((x) => x.store.id), ["next"]);  // 'far' is beyond 3 rings, 'nowhere' has no location
  // nothing in my hexagon -> the neighbours are offered and hasInCell says so
  const lonely = H.findNearby({ stores: [next, far], lat: home.lat, lng: home.lng, isPublic: catalog.isPublic });
  assert.equal(lonely.hasInCell, false); assert.deepEqual(lonely.inCell, []); assert.equal(lonely.nearby[0].store.id, "next");
  assert.equal(H.findNearby({ stores: [near], lat: NaN, lng: 1 }), null);
  // unpublished stores never leak
  assert.deepEqual(H.findNearby({ stores: [store("d", at(10, 10), { status: "unpublished" })], lat: home.lat, lng: home.lng, isPublic: catalog.isPublic }).inCell, []);
});

test("store location: real coordinates and a usable accuracy only", () => {
  assert.equal(H.validateStoreLocation({ lat: 33.2651, lng: -7.5901, accuracy: 12.6 }).accuracy, 13);
  assert.equal(H.validateStoreLocation({ lat: "33.2651", lng: "-7.5901" }).ok, true);
  for (const bad of [{}, null, { lat: 0, lng: 0 }, { lat: 91, lng: 1 }, { lat: "", lng: "" }, { lat: 1, lng: 1, accuracy: -2 }]) assert.equal(H.validateStoreLocation(bad).code, "BAD_COORDS", JSON.stringify(bad));
  assert.equal(H.validateStoreLocation({ lat: 33.2, lng: -7.5, accuracy: 900 }).code, "LOW_ACCURACY");
  assert.equal(H.validateStoreLocation({ lat: 33.2, lng: -7.5, accuracy: 150 }).ok, true);
});

/* ---- HTTP wiring through a fake app ---- */
function fakeApp() {
  const routes = {};
  const reg = (m) => (path, ...h) => { routes[m + " " + path] = h; };
  return { routes, get: reg("GET"), put: reg("PUT"), post: reg("POST") };
}
async function call(app, key, { query = {}, body = {}, restaurantId = "S1" } = {}) {
  const chain = app.routes[key]; assert.ok(chain, "route " + key);
  const out = { status: 200, body: null, headers: {} };
  const res = { status(c) { out.status = c; return this; }, json(b) { out.body = b; return this; }, set(k, v) { out.headers[k] = v; return this; } };
  const req = { query, body, restaurantId, adminId: "a1" };
  for (const h of chain) { let nexted = false; await h(req, res, () => { nexted = true; }); if (!nexted) break; }
  return out;
}
function wire(stores) {
  const db = { restaurants: stores.map((s) => ({ ...s })) };
  const audit = [];
  const app = fakeApp();
  H.registerHexRoutes(app, {
    requireAdmin: (_q, _r, n) => n(), requireRestaurant: (_q, _r, n) => n(),
    loadRestaurants: () => db, saveRestaurants: (d) => { db.restaurants = d.restaurants; },
    loadZones: () => [zone], driversState: () => [{ id: "d1", name: "Ali", dispatchState: "available", freshness: "live", location: at(30, 30) }],
    catalog, appendAuditLog: (e) => audit.push(e), now: () => new Date("2026-11-02T10:00:00Z"),
  });
  return { app, db, audit };
}

test("HTTP: admin overview, nearby, and the store setting its own location", async () => {
  const { app, db, audit } = wire([store("S1", null), store("S2", at(50, 50))]);
  // admin overview
  const ov = await call(app, "GET /api/admin/hex/overview");
  assert.equal(ov.body.ok, true); assert.equal(ov.body.summary.unlocated, 1); assert.equal(ov.body.summary.drivers, 1);
  assert.equal(ov.headers["Cache-Control"], "no-store");
  // nearby for a customer in the same hexagon as S2
  const me = at(10, 10);
  const nb = await call(app, "GET /api/stores/nearby", { query: { lat: String(me.lat), lng: String(me.lng) } });
  assert.equal(nb.body.inServiceArea, true); assert.equal(nb.body.hasInCell, true);
  assert.equal(nb.body.inCell[0].id, "S2"); assert.ok(nb.body.inCell[0].distanceM > 0);
  assert.equal("lat" in nb.body.inCell[0].store, false, "store coordinates are not exposed to customers");
  assert.equal((await call(app, "GET /api/stores/nearby", { query: { lat: "x", lng: "1" } })).status, 400);
  const out = at(8000, 0);
  assert.equal((await call(app, "GET /api/stores/nearby", { query: { lat: String(out.lat), lng: String(out.lng) } })).body.inServiceArea, false);
  // S1 has no location yet
  assert.equal((await call(app, "GET /api/restaurant/location")).body.hasLocation, false);
  const bad = await call(app, "PUT /api/restaurant/location", { body: { lat: 33.2, lng: -7.5, accuracy: 800 } });
  assert.equal(bad.status, 422); assert.equal(bad.body.code, "LOW_ACCURACY");
  assert.equal(db.restaurants[0].lat, undefined, "a refused location changes nothing");
  const good = await call(app, "PUT /api/restaurant/location", { body: { lat: 33.2651, lng: -7.5901, accuracy: 20 } });
  assert.equal(good.body.ok, true); assert.ok(good.body.cell.startsWith("hx:"));
  assert.equal(db.restaurants[0].lat, 33.2651); assert.equal(db.restaurants[0].locationBy, "store");
  assert.equal(audit.length, 1); assert.equal(audit[0].action, "store.location.set");
  assert.equal((await call(app, "GET /api/restaurant/location")).body.hasLocation, true);
  assert.equal((await call(app, "PUT /api/restaurant/location", { body: { lat: 33.2, lng: -7.5 }, restaurantId: "ghost" })).status, 404);
  // a store can only ever change its OWN location
  assert.equal(db.restaurants[1].lat, hex.fromXY(hex.toXY(B.lat, B.lng).x + 50, hex.toXY(B.lat, B.lng).y + 50).lat);
});
