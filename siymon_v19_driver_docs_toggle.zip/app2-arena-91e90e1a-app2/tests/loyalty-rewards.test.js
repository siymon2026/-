"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const loyalty = require("../lib/loyalty");
const rw = require("../lib/loyalty-rewards");

const NOW = "2026-10-31T10:00:00.000Z";
const S = loyalty.settingsOf({ enabled: true, expiry: { enabled: true, days: 90, alertDays: 30 } });
const P = (o = {}) => Object.assign({ names: { ar: "قهوة مجانية", en: "Free coffee" }, points: 200 }, o);
function setup(stock = null, pts = 500) {
  const prod = rw.normalizeProduct(P({ stock })).value; prod.id = "rw_1";
  const rewards = { products: [prod], redemptions: [] };
  const account = { customerId: "C1", entries: [] };
  if (pts) loyalty.credit(account, { ref: "e1", kind: "earn", points: pts, at: "2026-10-01T10:00:00.000Z" });
  return { rewards, account, prod };
}
const run = (x, id = "red1", over = {}) => rw.redeem(Object.assign({ rewards: x.rewards, account: x.account, settings: S, productId: "rw_1", customerId: "C1", customerName: "Sara", redemptionId: id, now: NOW }, over));

test("product validation is strict", () => {
  assert.equal(rw.normalizeProduct(P()).ok, true);
  assert.equal(rw.normalizeProduct(P()).value.names.fr, "قهوة مجانية"); // falls back to Arabic
  for (const bad of [{ points: 0 }, { points: 1.5 }, { points: -5 }, { points: "" }, { points: true }, { names: {} }, { names: { ar: " " } },
    { stock: -1 }, { stock: 2.5 }, { active: "yes" }, { image: "javascript:alert(1)" }, { image: "//evil.com/x.png" }, { image: "http://x.com/a.png" }, { color: "red" }]) {
    assert.equal(rw.normalizeProduct(P(bad)).ok, false, JSON.stringify(bad));
  }
  assert.equal(rw.normalizeProduct(P({ image: "https://cdn.x.com/a.png" })).ok, true);
  assert.equal(rw.normalizeProduct(P({ image: "/uploads/a.png" })).ok, true);
  assert.equal(rw.normalizeProduct(P({ stock: "" })).value.stock, null);
  assert.equal(rw.normalizeProduct(P({ stock: 0 })).value.stock, 0);
});

test("update keeps untouched fields and revalidates changed ones", () => {
  const p = rw.normalizeProduct(P({ stock: 4 })).value;
  const u = rw.normalizeProduct({ points: 300 }, p);
  assert.equal(u.value.points, 300); assert.equal(u.value.stock, 4); assert.equal(u.value.names.ar, "قهوة مجانية");
  assert.equal(rw.normalizeProduct({ points: 0 }, p).ok, false);
});

test("redeem debits points, creates a pending record and lowers stock", () => {
  const x = setup(3);
  const r = run(x);
  assert.ok(r.ok && !r.duplicate);
  assert.equal(loyalty.balances(x.account, NOW).available, 300);
  assert.equal(x.rewards.products[0].stock, 2);
  assert.equal(x.rewards.redemptions[0].status, "pending");
  assert.equal(x.rewards.redemptions[0].points, 200);
});

test("same redemption id is idempotent (no second debit, no second stock use)", () => {
  const x = setup(3);
  run(x); const again = run(x);
  assert.ok(again.ok && again.duplicate);
  assert.equal(loyalty.balances(x.account, NOW).available, 300);
  assert.equal(x.rewards.products[0].stock, 2);
  assert.equal(x.rewards.redemptions.length, 1);
});

test("another customer cannot replay someone else's redemption id", () => {
  const x = setup(); run(x);
  const r = run(x, "red1", { customerId: "C2" });
  assert.equal(r.ok, false); assert.equal(r.status, 404);
});

test("refuses when points are not enough, stock is out, product inactive or programme off", () => {
  let x = setup(null, 100);
  let r = run(x); assert.equal(r.code, "INSUFFICIENT_POINTS"); assert.equal(r.available, 100);
  assert.equal(x.rewards.redemptions.length, 0); assert.equal(loyalty.balances(x.account, NOW).available, 100);
  x = setup(0); assert.equal(run(x).code, "OUT_OF_STOCK");
  x = setup(); x.rewards.products[0].active = false; assert.equal(run(x).code, "PRODUCT_UNAVAILABLE");
  x = setup(); assert.equal(run(x, "r2", { productId: "nope" }).code, "PRODUCT_UNAVAILABLE");
  x = setup(); assert.equal(run(x, "r3", { settings: loyalty.settingsOf({ enabled: false }) }).code, "PROGRAM_OFF");
  x = setup(null, 0); assert.equal(run(x, "r4", { account: null }).code, "INSUFFICIENT_POINTS");
});

test("last unit can only be redeemed once", () => {
  const x = setup(1, 1000);
  assert.ok(run(x, "a").ok);
  assert.equal(run(x, "b").code, "OUT_OF_STOCK");
  assert.equal(loyalty.balances(x.account, NOW).available, 800);
});

test("fulfil is final and idempotent", () => {
  const x = setup(); run(x);
  assert.equal(rw.fulfil({ rewards: x.rewards, redemptionId: "red1", actorId: "a1", now: NOW }).ok, true);
  assert.equal(x.rewards.redemptions[0].status, "fulfilled");
  assert.equal(rw.fulfil({ rewards: x.rewards, redemptionId: "red1", now: NOW }).duplicate, true);
  const c = rw.cancel({ rewards: x.rewards, account: x.account, settings: S, redemptionId: "red1", now: NOW });
  assert.equal(c.code, "BAD_STATE");
  assert.equal(loyalty.balances(x.account, NOW).available, 300);
});

test("cancel refunds the points once and returns the stock", () => {
  const x = setup(2); run(x);
  const c = rw.cancel({ rewards: x.rewards, account: x.account, settings: S, redemptionId: "red1", actorId: "a1", reason: "غير متوفر", now: NOW });
  assert.ok(c.ok && !c.duplicate);
  assert.equal(loyalty.balances(x.account, NOW).available, 500);
  assert.equal(x.rewards.products[0].stock, 2);
  assert.equal(x.rewards.redemptions[0].status, "cancelled");
  const again = rw.cancel({ rewards: x.rewards, account: x.account, settings: S, redemptionId: "red1", now: NOW });
  assert.ok(again.duplicate);
  assert.equal(loyalty.balances(x.account, NOW).available, 500);
  assert.equal(rw.fulfil({ rewards: x.rewards, redemptionId: "red1", now: NOW }).code, "BAD_STATE");
});

test("refunded points never count toward the customer's level", () => {
  const app = require("../lib/loyalty-app");
  const x = setup(null, 600); run(x);
  rw.cancel({ rewards: x.rewards, account: x.account, settings: S, redemptionId: "red1", now: NOW });
  assert.equal(app.tierState(x.account, Date.parse(NOW), S).earnedInWindow, 600);
});

test("public view hides stock numbers and shows what is missing", () => {
  const p = rw.normalizeProduct(P({ stock: 3 })).value; p.id = "x";
  const v = rw.publicProduct(p, "en", 120);
  assert.equal(v.name, "Free coffee"); assert.equal(v.missing, 80); assert.equal(v.affordable, false); assert.equal(v.lowStock, 3);
  assert.equal("stock" in v, false);
  assert.equal(rw.publicProduct({ ...p, stock: 0 }, "ar", 999).soldOut, true);
});

test("rewardsOf tolerates missing or corrupt data", () => {
  assert.deepEqual(rw.rewardsOf(null), { products: [], redemptions: [] });
  assert.deepEqual(rw.rewardsOf({ products: "x" }), { products: [], redemptions: [] });
});
