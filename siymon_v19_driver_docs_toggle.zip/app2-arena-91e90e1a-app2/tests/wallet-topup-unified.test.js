"use strict";
/**
 * Unified wallet top-up (customer + driver): one method registry, one policy, one validation path,
 * separate ledgers, human verification, no double credit. Pure-module tests + source guards for the
 * server wiring (the server itself needs express; the isolated e2e script covers the HTTP layer).
 */
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const P = require("../lib/payment-methods");
const T = require("../lib/topups");
const W = require("../lib/wallet-service");
const ledger = require("../lib/wallet-ledger");
const roles = require("../lib/admin-roles");

const RIB = "230780000012345678901234";
const SERVER = fs.readFileSync(path.join(__dirname, "..", "server.js"), "utf8");

function methods(patch = {}) {
  let list = P.withDefaults([]);
  const set = (id, body) => { const cur = list.find((m) => m.id === id); const r = P.applyUpdate(cur, body); assert.ok(r.ok, JSON.stringify(r)); list = list.map((m) => (m.id === id ? r.value : m)); };
  set("cih", { enabled: true, details: { default: { holderName: "SIYMON", rib: RIB } } });
  set("barid", { enabled: true, contexts: { driverTopup: false }, details: { default: { holderName: "SIYMON", rib: RIB } } });
  for (const [id, body] of Object.entries(patch)) set(id, body);
  return list;
}
const req = (o = {}) => ({ walletType: "customer", ownerId: "c1", methodId: "cih", amount: 100, reference: "TRX-0001", hasReceipt: true, methods: methods(), topups: [], policy: W.policyOf(null), ...o });
const ok = (r) => { assert.equal(r.ok, true, JSON.stringify(r)); return r.value; };

test("1+2+3: customer and driver top up through the SAME method and the same validation", () => {
  const c = ok(T.validateRequest(req()));
  const d = ok(T.validateRequest(req({ walletType: "driver", ownerId: "d1" })));
  assert.equal(c.methodId, "cih"); assert.equal(d.methodId, "cih");
  assert.equal(c.context, "customerTopup"); assert.equal(d.context, "driverTopup");
  assert.deepEqual([d.amount, d.fee, d.creditAmount], [c.amount, c.fee, c.creditAmount]);
});

test("4+5: a disabled method, or one hidden from a context, is refused there", () => {
  assert.equal(T.validateRequest(req({ methods: methods({ cih: { enabled: false } }) })).code, "METHOD_UNAVAILABLE");
  const m = methods();
  assert.equal(T.validateRequest(req({ methods: m, methodId: "barid", walletType: "driver" })).code, "METHOD_UNAVAILABLE"); // hidden from drivers
  assert.equal(T.validateRequest(req({ methods: m, methodId: "barid", walletType: "customer" })).ok, true);
  assert.equal(T.validateRequest(req({ methodId: "cod" })).code, "METHOD_UNAVAILABLE"); // order-only method is never a wallet method
});

test("6+7: the shared policy limits apply to the DRIVER too (min and max)", () => {
  const policy = W.policyOf({ minTopup: 50, maxTopup: 500 });
  for (const walletType of ["customer", "driver"]) {
    assert.equal(T.validateRequest(req({ walletType, policy, amount: 49 })).code, "BELOW_MIN", walletType);
    assert.equal(T.validateRequest(req({ walletType, policy, amount: 501 })).code, "ABOVE_MAX", walletType);
    assert.equal(T.validateRequest(req({ walletType, policy, amount: 500 })).ok, true, walletType);
  }
});

test("8: fees are 0 by default; a policy fee is applied to both wallets; a method can override it", () => {
  assert.deepEqual([ok(T.validateRequest(req())).fee, ok(T.validateRequest(req())).creditAmount], [0, 100]);
  const policy = W.policyOf({ feeFixed: 2 });
  for (const walletType of ["customer", "driver"]) {
    const v = ok(T.validateRequest(req({ walletType, policy })));
    assert.deepEqual([v.amount, v.fee, v.creditAmount], [100, 2, 98], walletType); // the 100 -> 2 -> 98 example
  }
  const pct = ok(T.validateRequest(req({ policy: W.policyOf({ feePercent: 1.5 }), amount: 200 })));
  assert.deepEqual([pct.fee, pct.creditAmount], [3, 197]);
  const over = ok(T.validateRequest(req({ policy, methods: methods({ cih: { feeFixed: 5 } }) })));
  assert.equal(over.fee, 5); // per-method override beats the shared fee
  assert.equal(ok(T.validateRequest(req({ policy, methods: methods({ cih: { feeFixed: 0 } }) }))).fee, 0);
});

test("8b: a disabled top-up policy refuses new requests for customers and drivers", () => {
  for (const walletType of ["customer", "driver"]) {
    assert.equal(T.validateRequest(req({ walletType, policy: W.policyOf({ enabled: false }) })).code, "TOPUP_DISABLED");
  }
});

test("9: a transfer reference identifies ONE transfer: not reusable on another wallet or method", () => {
  const prior = { id: "t0", walletType: "customer", customerId: "c9", methodId: "cih", reference: "TRX-0001", refKey: "TRX0001", status: "approved" };
  assert.equal(T.validateRequest(req({ walletType: "driver", ownerId: "d1", topups: [prior] })).code, "DUPLICATE_REFERENCE");
  assert.equal(T.validateRequest(req({ methodId: "barid", topups: [prior] })).code, "DUPLICATE_REFERENCE");
  assert.equal(T.validateRequest(req({ reference: "trx 0001", topups: [prior] })).code, "DUPLICATE_REFERENCE");
});

test("10b: a missing receipt is refused when the method requires one; a reference is always required", () => {
  assert.equal(T.validateRequest(req({ hasReceipt: false })).code, "RECEIPT_REQUIRED");
  assert.equal(T.validateRequest(req({ reference: "" })).code, "REFERENCE_REQUIRED");
  assert.equal(T.validateRequest(req({ reference: "ab" })).code, "REFERENCE_REQUIRED");
});

/* ---- ledger / approval flow, modelled on PATCH /api/admin/topups/:id ---- */
function approve(topup, owner, by = "admin1") {
  const r = T.decide(topup, { to: "approved", by });
  if (!r.ok) return r;
  const e = ledger.applyEntry(owner, { ref: T.ledgerRef(topup), type: "topup", amount: T.creditAmountOf(topup), topupId: topup.id });
  return e.ok ? { ok: true, entry: e.entry } : e;
}
const pending = (extra = {}) => ({ id: "t1", status: "pending", walletType: "driver", driverId: "d1", amount: 100, fee: 2, creditAmount: 98, ...extra });

test("11: submitting a request never moves a balance (only the review does)", () => {
  const owner = { walletBalance: 10, walletHistory: [] };
  ok(T.validateRequest(req({ walletType: "driver" })));
  assert.equal(owner.walletBalance, 10);
  assert.equal(ledger.reconcile(owner).entries, 0);
});

test("12+13: approval credits the NET amount once; a second approval is refused and credits nothing", () => {
  const owner = { walletBalance: 10, walletHistory: [] };
  const t = pending();
  const a = approve(t, owner);
  assert.equal(a.ok, true);
  assert.equal(owner.walletBalance, 108); // 10 + (100 - 2)
  assert.equal(t.decidedBy, "admin1");
  assert.ok(t.decidedAt);
  assert.equal(approve(t, owner, "admin2").code, "ALREADY_DECIDED");
  assert.equal(owner.walletBalance, 108);
  // even if the status flag were lost, the unique ledger ref stops a second credit
  const again = ledger.applyEntry(owner, { ref: T.ledgerRef(t), type: "topup", amount: 98 });
  assert.equal(again.duplicate, true);
  assert.equal(owner.walletBalance, 108);
});

test("14: a rejection needs a reason, stores it and never credits", () => {
  const owner = { walletBalance: 0, walletHistory: [] };
  assert.equal(T.decide(pending(), { to: "rejected", by: "admin1" }).code, "REASON_REQUIRED");
  const t = pending();
  assert.equal(T.decide(t, { to: "rejected", by: "admin1", reason: "Amount never arrived" }).credit, false);
  assert.equal(t.decisionNote, "Amount never arrived");
  assert.equal(owner.walletBalance, 0);
  assert.equal(T.decide(t, { to: "approved", by: "admin1" }).code, "ALREADY_DECIDED"); // no reopening
});

test("19+21: the ledger refuses a negative balance and always reconciles with the balance", () => {
  const w = { walletBalance: 20, walletHistory: [{ ref: "seed", type: "topup", amount: 20, status: "succeeded" }] };
  assert.equal(ledger.applyEntry(w, { ref: "x1", type: "order_deduct", amount: -50 }).code, "INSUFFICIENT_FUNDS");
  ledger.applyEntry(w, { ref: "x2", type: "topup", amount: 30 });
  assert.equal(ledger.reconcile(w).ok, true);
  assert.equal(w.walletBalance, 50);
});

test("customer and driver ledgers are separate objects: a credit on one never touches the other", () => {
  const driver = { walletBalance: 0, walletHistory: [] }, customer = { walletBalance: 0, walletHistory: [] };
  approve(pending(), driver);
  assert.equal(driver.walletBalance, 98);
  assert.equal(customer.walletBalance, 0);
  assert.equal(customer.walletHistory.length, 0);
  assert.equal(T.ownerIdOf({ walletType: "customer", customerId: "c1", driverId: "d1" }), "c1");
});

test("22: legacy driver top-ups (no walletType / refKey / fee) still read, review and credit correctly", () => {
  const legacy = { id: "old", status: "pending", driverId: "d7", amount: 75, receiptFile: "old.png", createdAt: "2025-01-01T00:00:00.000Z" };
  assert.equal(T.walletTypeOf(legacy), "driver");
  assert.equal(T.creditAmountOf(legacy), 75);
  assert.equal(T.feeOf(legacy), 0);
  const v = T.ownerView(legacy);
  assert.equal(v.creditAmount, 75); assert.equal(v.hasReceipt, true);
  const owner = { walletBalance: 0, walletHistory: [] };
  assert.equal(approve(legacy, owner).ok, true);
  assert.equal(owner.walletBalance, 75);
});

/* ---- permissions ---- */
test("15+17: only roles with topups.review may decide; viewing, deciding, adjusting and editing methods are separate", () => {
  const decide = ["PATCH", "/api/admin/topups/t1"], list = ["GET", "/api/admin/topups"], receipt = ["GET", "/api/admin/topups/t1/receipt"];
  assert.equal(roles.authorize("accountant", ...decide).ok, true);
  for (const role of ["order_supervisor", "driver_supervisor", "support", "driver", "customer", ""] ) {
    if (role === "") continue; // legacy empty role == full admin by design
    assert.equal(roles.authorize(role, ...decide).ok, false, role);
    assert.equal(roles.authorize(role, ...list).ok, false, role);
    assert.equal(roles.authorize(role, ...receipt).ok, false, role);
  }
  // "view requests" is its own permission: a role with topups.read only cannot decide
  assert.equal(roles.permissionFor(...list), "topups.read");
  assert.equal(roles.permissionFor(...decide), "topups.review");
  assert.equal(roles.permissionFor("POST", "/api/admin/drivers/d1/wallet-adjust"), "wallet.adjust");
  assert.equal(roles.permissionFor("GET", "/api/admin/payment-methods"), "payments.read");
  assert.equal(roles.permissionFor("PUT", "/api/admin/payment-methods/cih"), "payments.manage");
  assert.ok(roles.EXPLICIT_ONLY.includes("payments.read") && roles.EXPLICIT_ONLY.includes("payments.manage"));
  assert.equal(roles.authorize("accountant", "PUT", "/api/admin/payment-methods/cih").ok, false);
});

/* ---- server wiring guards (no express needed) ---- */
test("server: the legacy driver fallback is gone and the unified creator runs inside the financial lock", () => {
  assert.equal(/Legacy flow \(no transfer method/.test(SERVER), false);
  const fn = SERVER.slice(SERVER.indexOf("function createTransferRequest("), SERVER.indexOf('app.post(\n  "/api/driver/topups"'));
  assert.match(fn, /financeTx\(/);
  assert.match(fn, /store\.topups\.topups/);
  assert.match(fn, /store\.policy\(\)/);
  assert.equal(/loadTopups\(\)/.test(fn) || /saveTopups\(/.test(fn), false);
  const route = SERVER.slice(SERVER.indexOf('app.post(\n  "/api/driver/topups"'), SERVER.indexOf('app.get("/api/driver/topups/:id/receipt"'));
  assert.match(route, /createTransferRequest\(/);
  assert.equal(/walletBalance/.test(route), false); // the route can never touch a balance
});

test("server: receipts live in private storage and are only served through owner/admin-checked routes", () => {
  assert.match(SERVER, /PRIVATE_TOPUP_DIR = path\.join\(PRIVATE_UPLOADS_DIR, "topups"\)/);
  assert.equal(/express\.static\([^)]*PRIVATE_UPLOADS_DIR/.test(SERVER), false);
  assert.match(SERVER, /\/api\/customer\/wallet\/topups\/:id\/receipt/);
  assert.match(SERVER, /String\(t\.customerId\) !== String\(req\.customerId\)/); // a customer cannot open another user's receipt
  assert.match(SERVER, /String\(t\.driverId\) !== String\(req\.driverId\)/);
});

test("server: only the admin PATCH route credits a wallet, inside financeTx, with a ledger ref", () => {
  // the ONLY ledger write that carries a top-up ref (type: "topup" elsewhere is a display view)
  assert.equal(SERVER.split("topupsLib.ledgerRef(").length - 1, 1);
  assert.equal((SERVER.match(/walletLedger\.applyEntry\([^)]*\{\s*ref: topupsLib\.ledgerRef/g) || []).length, 1);
  const patch = SERVER.slice(SERVER.indexOf('app.patch("/api/admin/topups/:id"'));
  assert.match(patch.slice(0, 900), /financeTx\(/);
  assert.match(patch.slice(0, 2500), /ledgerRef\(topup\)/);
});
