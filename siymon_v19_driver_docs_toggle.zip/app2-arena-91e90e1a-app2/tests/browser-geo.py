"""Customer GPS helper (public/shared/geo.js): picks the most accurate reading, flags coarse ones, reports refusals.
Uses Chromium's real Geolocation API with Playwright-controlled positions (no mocks of the page code).
Run: python3 tests/browser-geo.py"""
import subprocess, time, os, json, tempfile
from playwright.sync_api import sync_playwright
PORT = "4034"; B = "http://localhost:" + PORT
SEED = tempfile.mkdtemp()
json.dump({"restaurants": [{"id": "r1", "name": {"ar": "مطعم", "en": "R", "fr": "R"}, "isActive": True, "deliveryFee": 10, "minOrder": 0, "createdAt": "2026-01-01T00:00:00Z", "type": "restaurant"}]}, open(SEED + "/restaurants.json", "w"))
json.dump({"items": []}, open(SEED + "/menu.json", "w"))
srv = subprocess.Popen(["node", "tests/ui-mock-server.js"], env={"PORT": PORT, "PATH": os.environ["PATH"], "SEED_DIR": SEED}); time.sleep(1.2)
ok = True
def check(n, c, x=""):
    global ok; print(("PASS " if c else "FAIL ") + n + ("" if c else " -> " + str(x))); ok = ok and bool(c)
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        # 1) coarse first, precise a moment later -> the precise one wins and we stop early
        c = b.new_context(permissions=["geolocation"], geolocation={"latitude": 33.30, "longitude": -7.60, "accuracy": 900}, service_workers="block")
        pg = c.new_page(); pg.goto(B + "/"); pg.wait_for_function("window.SiymonGeo")
        pg.evaluate("(() => { window.__r = null; SiymonGeo.best({maxWaitMs: 6000}).then(r => window.__r = r, e => window.__r = {err: e}); return 1; })()")
        pg.wait_for_timeout(700)
        check("still waiting while only a coarse reading exists", pg.evaluate("window.__r") is None)
        c.set_geolocation({"latitude": 33.2655, "longitude": -7.5872, "accuracy": 12})
        pg.wait_for_function("window.__r !== null", timeout=5000)
        r = pg.evaluate("window.__r")
        check("returns the precise reading (not the first coarse one)", r.get("accuracy") == 12 and abs(r["lat"] - 33.2655) < 1e-6 and r["coarse"] is False, r)
        c.close()
        # 2) only a coarse reading ever arrives -> returned after the wait, flagged coarse
        c = b.new_context(permissions=["geolocation"], geolocation={"latitude": 33.30, "longitude": -7.60, "accuracy": 800}, service_workers="block")
        pg = c.new_page(); pg.goto(B + "/"); pg.wait_for_function("window.SiymonGeo")
        t0 = time.time()
        r = pg.evaluate("SiymonGeo.best({maxWaitMs: 1500}).then(r => r, e => ({err: e}))")
        check("coarse-only reading is returned after the short wait and flagged coarse", r.get("coarse") is True and r["accuracy"] == 800 and time.time() - t0 < 6, r)
        c.close()
        # 3) permission refused -> a clear error, no hang
        c = b.new_context(service_workers="block")
        pg = c.new_page(); pg.goto(B + "/"); pg.wait_for_function("window.SiymonGeo")
        r = pg.evaluate("SiymonGeo.best().then(r => ({ok: r}), e => ({err: e.code}))")
        check("refused permission rejects with code 1", r.get("err") == 1, r)
        c.close()
        b.close()
finally:
    srv.terminate()
print("ALL PASS" if ok else "SOME FAILED")
