"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const E = require("../public/grid/engine.js");
const B = require("../public/grid/bot.js");
const G = require("../lib/grid-battle.js");

/* ---------- helpers ---------- */
function mkStore(initial) {
  let disk = initial || null;
  const store = new G.Store({ readJson: () => (disk ? JSON.parse(JSON.stringify(disk)) : null), writeJson: (_f, d) => { disk = JSON.parse(JSON.stringify(d)); }, file: "x", logger: { error() {} } });
  store._disk = () => disk;
  return store;
}
function mkHub(store) {
  const names = { a: { firstName: "Ahmed", lastName: "Benali" }, b: { firstName: "Sara", lastName: "K" }, c: { firstName: "Omar" } };
  const hub = new G.Hub({ store, getCustomer: (id) => names[id], logger: { error() {} } });
  return hub;
}
/** a fake SSE response that records events */
function fakeRes() { const r = { events: [], write(f) { const m = /event: (\w+)\ndata: (.*)\n/.exec(f); if (m) r.events.push({ type: m[1], data: JSON.parse(m[2]) }); }, end() {} }; return r; }
const of = (res, t) => res.events.filter((e) => e.type === t);
/** drive the hub clock */
function run(hub, from, ms, step = 10) { let t = from; const end = from + ms; while (t < end) { t += step; hub.pump(t); } return t; }

/* ---------- engine ---------- */
const place = (s, o, x, y, pi = 0) => { s.cur = pi; return E.act(s, pi, { t: "w", o, x, y }); };
const mv = (s, pi, x, y) => { s.cur = pi; return E.act(s, pi, { t: "m", x, y }); };
test("engine: mirrored starts, goal rows, equal distances, the opening move alternates", () => {
  const s = E.create(), [a, b] = E.startPositions(s.w, s.h);
  assert.equal(a.x + b.x, s.w - 1); assert.equal(a.y + b.y, s.h - 1);
  assert.equal(s.players[0].goal, 0); assert.equal(s.players[1].goal, s.h - 1);
  assert.equal(E.dist(s, 0), E.dist(s, 1));
  assert.equal(E.create({}, 0).cur, 0); assert.equal(E.create({}, 1).cur, 1);
});
test("engine: one action per turn, only on your turn; junk is refused and changes nothing", () => {
  const s = E.create({}, 0), p = s.players[0];
  assert.equal(E.act(s, 1, { t: "m", x: 4, y: 1 }).code, "NOT_YOUR_TURN");
  for (const bad of [null, undefined, 5, "m", {}, { t: "x" }, { t: "m", x: "4", y: 9 }, { t: "m", x: 4.5, y: 9 }, { t: "w", o: "z", x: 0, y: 0 }, { t: "w", o: "h", x: -1, y: 0 }, { t: "w", o: "h", x: 99, y: 0 }, { t: "constructor" }])
    assert.equal(E.act(s, 0, bad).ok, false, JSON.stringify(bad));
  assert.equal(E.act(s, 0, { t: "m", x: 0, y: 0 }).code, "ILLEGAL_MOVE", "no teleporting");
  assert.equal(s.turn, 0); assert.equal(s.cur, 0); assert.deepEqual([p.x, p.y], [4, 10]);
  assert.equal(E.act(s, 0, { t: "m", x: 4, y: 9 }).ok, true); assert.equal(s.cur, 1); assert.equal(s.turn, 1);
});
test("engine: movement stops at edges and barriers; a barrier works from both sides", () => {
  const s = E.create({ w: 9, h: 9 }, 0);
  assert.equal(E.legalMoves(s, 0).some((m) => m[1] === 9), false, "no step off the board");
  place(s, "h", 3, 7);                                   // between rows 7 and 8, columns 3-4
  s.players[0].x = 4; s.players[0].y = 8; assert.equal(E.isLegalMove(s, 0, 4, 7), false, "blocked going up");
  s.players[0].x = 4; s.players[0].y = 7; assert.equal(E.isLegalMove(s, 0, 4, 8), false, "and going down");
  s.players[0].x = 5; s.players[0].y = 8; assert.equal(E.isLegalMove(s, 0, 5, 7), true, "column 5 is outside the barrier");
  place(s, "v", 6, 2); s.players[0].x = 6; s.players[0].y = 2; assert.equal(E.isLegalMove(s, 0, 7, 2), false); assert.equal(E.isLegalMove(s, 0, 7, 2) || E.isLegalMove(s, 0, 7, 3), false);
  s.players[0].y = 4; assert.equal(E.isLegalMove(s, 0, 7, 4), true, "below the barrier's two rows");
});
test("engine: balls never share a square: jump over, or step around when the jump is blocked", () => {
  const s = E.create({ w: 9, h: 9 }, 0);
  s.players[0].x = 4; s.players[0].y = 5; s.players[1].x = 4; s.players[1].y = 4;
  let m = E.legalMoves(s, 0).map((q) => q.join(","));
  assert.ok(m.includes("4,3"), "jump"); assert.ok(!m.includes("4,4"), "cannot stand on the other ball");
  place(s, "h", 4, 3);                                   // barrier behind the other ball (between rows 3 and 4, columns 4-5)
  m = E.legalMoves(s, 0).map((q) => q.join(","));
  assert.ok(!m.includes("4,3")); assert.ok(m.includes("3,4") && m.includes("5,4"), "diagonals around it");
});
test("engine: barriers cannot overlap, cross, leave the board — and have no count limit", () => {
  const s = E.create({ w: 15, h: 15 }, 0);
  assert.equal(place(s, "h", 3, 3).ok, true);
  assert.equal(place(s, "h", 3, 3).code, "OVERLAP"); assert.equal(place(s, "h", 4, 3).code, "OVERLAP"); assert.equal(place(s, "h", 2, 3).code, "OVERLAP");
  assert.equal(place(s, "v", 3, 3).code, "CROSS", "a plus-shaped crossing is refused");
  assert.equal(place(s, "h", 5, 3).ok, true, "touching end to end is fine");
  assert.equal(place(s, "h", 14, 0).code, "BAD_WALL"); assert.equal(place(s, "v", 0, 14).code, "BAD_WALL");
  let n = 0; for (let y = 0; y < 14 && n < 40; y += 2) for (let x = 0; x < 14 && n < 40; x += 3) if (place(s, "v", x, y, n % 2).ok) n++;
  assert.ok(n >= 20, "more than 20 further barriers were accepted: " + n);
});
test("engine: a barrier that would close ALL paths is refused; closing nothing is fine; the refusal changes nothing", () => {
  const s = E.create({ w: 6, h: 6 }, 0);
  assert.equal(place(s, "h", 0, 2).ok, true); assert.equal(place(s, "h", 2, 2).ok, true);
  const before = E.dist(s, 0), walls = s.walls.length, turn = s.turn;
  const r = place(s, "h", 4, 2); assert.equal(r.code, "BLOCKS_PATH");
  assert.equal(s.walls.length, walls); assert.equal(s.turn, turn); assert.equal(E.dist(s, 0), before);
  assert.ok(E.dist(s, 0) > 0 && E.dist(s, 1) > 0, "both can still get through");
  // the opponent's path matters as much as your own
  const t = E.create({ w: 6, h: 6 }, 1); place(t, "h", 0, 2, 1); place(t, "h", 2, 2, 1); assert.equal(place(t, "h", 4, 2, 1).code, "BLOCKS_PATH");
  // a 2x2 room (columns 2-3, rows 3-4) around the ball: three sides may be closed, the fourth would trap it and is refused
  const u = E.create({ w: 7, h: 7 }, 0); u.players[0].x = 3; u.players[0].y = 3;
  assert.equal(place(u, "h", 2, 2).ok, true); assert.equal(place(u, "h", 2, 4).ok, true); assert.equal(place(u, "v", 3, 3).ok, true);
  assert.equal(place(u, "v", 1, 3).code, "BLOCKS_PATH", "closing the last door is refused");
  assert.ok(E.dist(u, 0) > 0, "the ball can still get out");
});
test("engine: reaching the far row wins at once; a round with no winner ends in a draw at the turn limit", () => {
  const s = E.create({ w: 9, h: 9 }, 0); s.players[0].x = 2; s.players[0].y = 1; s.players[1].x = 6; s.players[1].y = 4;
  assert.equal(mv(s, 0, 2, 0).ok, true); assert.equal(s.over, true); assert.equal(s.winner, 0); assert.equal(s.reason, "goal");
  assert.equal(E.act(s, 1, { t: "m", x: 6, y: 5 }).code, "OVER");
  const t = E.create({ w: 9, h: 9, maxRoundTurns: 40 }, 0);
  let n = 0; while (!t.over && n++ < 100) { const pi = t.cur, p = t.players[pi]; const home = pi === 0 ? [4, 8] : [4, 0]; const away = pi === 0 ? [4, 7] : [4, 1]; const to = p.x === home[0] && p.y === home[1] ? away : home; E.act(t, pi, { t: "m", x: to[0], y: to[1] }); }
  assert.equal(t.over, true); assert.equal(t.winner, -1); assert.equal(t.reason, "time"); assert.equal(t.turn, 40);
});
test("engine: autoMove always steps along a shortest path and is always legal; publicView round-trips", () => {
  const s = E.create({}, 0); place(s, "h", 3, 8); place(s, "v", 4, 9, 1);
  for (let i = 0; i < 6; i++) { const pi = s.cur, a = E.autoMove(s, pi), d0 = E.dist(s, pi); assert.equal(a.t, "m"); assert.equal(E.act(s, pi, a).ok, true); assert.equal(E.dist(s, pi), d0 - 1, "each automatic step shortens the path by one"); }
  const v = E.publicView(s), t = E.fromView(JSON.parse(JSON.stringify(v)));
  assert.deepEqual(E.publicView(t), v); assert.equal(E.dist(t, 0), E.dist(s, 0)); assert.equal(t.cur, s.cur);
  assert.equal(v.players, undefined, "the public view carries data only");
});
test("bot: returns a legal action at every level, never an illegal or path-closing barrier, takes a win when it is one step away", () => {
  for (const lvl of ["easy", "medium", "hard"]) {
    const s = E.create({}, 1), mem = B.newMemory();
    for (let i = 0; i < 24 && !s.over; i++) {
      const pi = s.cur, a = B.decide(E.publicView(s), pi, lvl, pi === 1 ? mem : B.newMemory());
      assert.ok(a, lvl); const r = E.act(s, pi, a); assert.equal(r.ok, true, lvl + " proposed " + JSON.stringify(a) + " -> " + r.code);
      assert.ok(E.dist(s, 0) >= 0 && E.dist(s, 1) >= 0);
    }
    const w = E.create({ w: 9, h: 9 }, 1); w.players[1].x = 3; w.players[1].y = 7; w.players[0].x = 6; w.players[0].y = 6;
    const a = B.decide(E.publicView(w), 1, lvl, B.newMemory(), () => 0.01); assert.deepEqual(a, { t: "m", x: 3, y: 8 }, lvl + " must take the win");
  }
});
test("bot: never sees anything the human does not, and can be handed the same public data twice", () => {
  const s = E.create(), v = E.publicView(s);
  assert.equal(v.players, undefined); assert.equal(v.hw, undefined);
  const a1 = B.decide(JSON.parse(JSON.stringify(v)), 0, "hard", B.newMemory(), () => 0.5), a2 = B.decide(JSON.parse(JSON.stringify(v)), 0, "hard", B.newMemory(), () => 0.5);
  assert.deepEqual(a1, a2, "deterministic for the same input and the same dice");
});
test("bot levels are ordered: hard beats easy over a sample; barriers appear in play", () => {
  let hardWins = 0, easyWins = 0, walls = 0;
  for (let g = 0; g < 12; g++) {
    const s = E.create({}, g % 2), m = [B.newMemory(), B.newMemory()], lv = g % 2 ? ["hard", "easy"] : ["easy", "hard"]; let n = 0;
    while (!s.over && n++ < 400) { const pi = s.cur, a = B.decide(E.publicView(s), pi, lv[pi], m[pi]); assert.equal(E.act(s, pi, a).ok, true); }
    walls += s.walls.length;
    if (s.winner >= 0) (lv[s.winner] === "hard" ? hardWins++ : easyWins++);
  }
  assert.ok(hardWins > easyWins, `hard ${hardWins} vs easy ${easyWins}`);
  assert.ok(walls > 0, "bots do place barriers");
});
test("bot memory adapts inside a match only", () => {
  const m = B.newMemory(); for (let i = 0; i < 5; i++) B.observeHuman(m, { t: "w" }); B.adapt(m, { botLost: true }); B.adapt(m, { botLost: true });
  assert.ok(m.caution > 0 && m.caution <= 0.4); assert.equal(B.newMemory().caution, 0);
});

/* ---------- rating / store ---------- */
test("elo: equal players move +-k/2, upsets move more, floor at 0; tiers resolve", () => {
  assert.equal(G.eloUpdate(1000, 1000, 1, 32), 1016); assert.equal(G.eloUpdate(1000, 1000, 0, 32), 984);
  assert.ok(G.eloUpdate(1000, 1400, 1, 32) - 1000 > 16); assert.equal(G.eloUpdate(5, 2000, 0, 32), 5 - 0 > 0 ? G.eloUpdate(5, 2000, 0, 32) : 0);
  assert.equal(G.eloUpdate(0, 3000, 0, 32), 0);
  const t = G.DEFAULT_SETTINGS.tiers;
  assert.equal(G.tierOf(0, t).id, "bronze"); assert.equal(G.tierOf(1299, t).id, "silver"); assert.equal(G.tierOf(1300, t).id, "gold"); assert.equal(G.tierOf(5000, t).id, "diamond");
  assert.equal(G.tierOf(1000, t).next.remaining, 100);
});
test("store: a match is applied exactly once (same matchId twice = no double credit)", () => {
  const st = mkStore(), m = { matchId: "m1", kind: "quick", players: [{ id: "a", name: "A" }, { id: "b", name: "B" }], wins: [2, 0], winner: 0, reason: "score", rated: true, now: 1e12 };
  const r1 = st.applyMatch(m), r2 = st.applyMatch(m);
  assert.ok(r1); assert.equal(r2, null);
  assert.equal(st.doc.players.a.wins, 1); assert.equal(st.doc.players.a.played, 1); assert.equal(st.doc.players.a.points, 25 + 2);
  assert.equal(st.doc.players.a.rating, 1016); assert.equal(st.doc.players.b.rating, 984); assert.equal(st.doc.players.b.points, 5);
  assert.equal(st._disk().players.a.rating, 1016, "persisted to disk");
  // survives a restart: a replay of the same id is still ignored
  const st2 = mkStore(st._disk()); assert.equal(st2.applyMatch(m), null); assert.equal(st2.doc.players.a.wins, 1);
});
test("store: unranked matches change stats but never rating or points; pair cap blocks farming", () => {
  const st = mkStore(), base = { kind: "quick", players: [{ id: "a", name: "A" }, { id: "b", name: "B" }], wins: [2, 0], winner: 0, reason: "score", now: 1e12 };
  st.applyMatch({ ...base, matchId: "p1", rated: false });
  assert.equal(st.doc.players.a.rating, 1000); assert.equal(st.doc.players.a.points, 0); assert.equal(st.doc.players.a.wins, 1);
  for (let i = 0; i < 4; i++) assert.equal(st.applyMatch({ ...base, matchId: "r" + i, rated: true, now: 1e12 + i }).length, 2);
  const capped = st.applyMatch({ ...base, matchId: "r5", rated: true, now: 1e12 + 99 });
  assert.equal(capped[0].rated, false); assert.equal(capped[0].delta, 0);
  const later = st.applyMatch({ ...base, matchId: "r6", rated: true, now: 1e12 + 90000000 });
  assert.equal(later[0].rated, true, "after 24h the pair may be ranked again");
});
test("store: streaks, draws, leaderboard order and privacy of ids", () => {
  const st = mkStore(), mk = (id, w, win) => ({ matchId: id, kind: "quick", players: [{ id: "a", name: "A" }, { id: "b", name: "B" }], wins: w, winner: win, reason: "score", rated: true, now: 1e12 + Math.random() * 1e9 });
  st.settings.pairDailyCap = 50;
  st.applyMatch(mk("1", [2, 0], 0)); st.applyMatch(mk("2", [2, 1], 0)); st.applyMatch(mk("3", [1, 1], -1));
  assert.equal(st.doc.players.a.streak, 2); assert.equal(st.doc.players.a.bestStreak, 2); assert.equal(st.doc.players.a.draws, 1);
  st.applyMatch(mk("4", [0, 2], 1)); assert.equal(st.doc.players.a.streak, 0);
  const lb = st.leaderboard(10, "b");
  assert.equal(lb.rows.length, 2); assert.ok(lb.rows[0].rating >= lb.rows[1].rating);
  assert.equal(lb.rows.filter((r) => r.id).length <= 1, true, "only my own id is revealed");
  assert.equal(lb.rows.find((r) => r.me).name, "B");
});
test("settings: every admin value is clamped; garbage is ignored; tiers must start at 0; snake-era keys are gone", () => {
  const s = G.sanitizeSettings({ roundsToWin: 99, grid: { w: 1, h: 999 }, elo: { k: -5 }, turnSeconds: 1, maxRoundTurns: 1, speed: { baseTickMs: 10 }, maxRoundTicks: 5, tiers: [{ id: "x", from: 5 }, { id: "y", from: 9 }], evil: 1, points: { win: "abc" } });
  assert.equal(s.roundsToWin, 4); assert.equal(s.grid.w, 5); assert.equal(s.grid.h, 17); assert.equal(s.elo.k, 4);
  assert.equal(s.turnSeconds, 5); assert.equal(s.maxRoundTurns, 40); assert.equal(s.speed, undefined); assert.equal(s.maxRoundTicks, undefined);
  assert.equal(s.tiers[0].id, "bronze"); assert.equal(s.evil, undefined); assert.equal(s.points.win, 25);
  assert.deepEqual(G.DEFAULT_SETTINGS.grid, { w: 9, h: 11 });
});
test("store: a v1 (snake-era) file keeps its players and matches but restarts board settings from the new defaults", () => {
  const st = mkStore({ version: 1, settings: { grid: { w: 30, h: 30 }, speed: { baseTickMs: 120 }, maxRoundTicks: 900, roundsToWin: 3 }, players: { a: { rating: 1234, played: 5, wins: 3, losses: 2, draws: 0, points: 40, streak: 1, bestStreak: 2, peak: 1250, ranked: 5, history: [] } }, matchIds: ["old"], matches: [{ id: "old" }] });
  assert.deepEqual(st.settings.grid, { w: 9, h: 11 }); assert.equal(st.settings.roundsToWin, 3); assert.equal(st.doc.players.a.rating, 1234); assert.equal(st.doc.matchIds[0], "old"); assert.equal(st.doc.version, 2);
});
test("rewards: disabled by default; when enabled a milestone creates ONE pending candidate; approving credits nothing", () => {
  const st = mkStore(); const base = { kind: "quick", players: [{ id: "a", name: "A" }, { id: "b", name: "B" }], wins: [2, 0], winner: 0, reason: "score", rated: true };
  st.applyMatch({ ...base, matchId: "q1", now: 1e12 }); assert.equal(st.doc.rewardCandidates.length, 0);
  st.setSettings({ rewards: { enabled: true, milestones: [{ id: "w2", type: "wins", value: 2, label: "2 wins" }] } });
  st.applyMatch({ ...base, matchId: "q2", now: 1e12 + 1 }); st.applyMatch({ ...base, matchId: "q3", now: 1e12 + 2 });
  assert.equal(st.doc.rewardCandidates.length, 1); assert.equal(st.doc.rewardCandidates[0].status, "pending"); assert.equal(st.doc.rewardCandidates[0].customerId, "a");
  const id = st.doc.rewardCandidates[0].id;
  const pts = st.doc.players.a.points;
  assert.equal(st.decideReward(id, "approved", "adm").ok, true); assert.equal(st.decideReward(id, "rejected", "adm").code, "ALREADY_DECIDED");
  assert.equal(st.doc.players.a.points, pts, "approval credits nothing");
});

/* ---------- hub: rooms ---------- */
function twoPlayers() {
  const st = mkStore(), hub = mkHub(st), ra = fakeRes(), rb = fakeRes(); let t = 1e12;
  hub.attachStream("a", ra, t); hub.attachStream("b", rb, t);
  return { st, hub, ra, rb, t };
}
/** play a match to the end through the real input path, each side using the bot's brain */
function playOut(hub, room, t, level = "medium") {
  let n = 0;
  while (room.status !== "finished" && n++ < 20000) {
    t += 25; hub.pump(t);
    if (room.status === "playing" && room.state && !room.state.over) {
      const s = room.state, slot = s.cur, r = hub.input(room.players[slot].cid, room.id, B.decide(E.publicView(s), slot, level, B.newMemory()), t);
      assert.equal(r.ok, true, "legal bot move refused: " + JSON.stringify(r));
    }
  }
  return t;
}
const act1 = (hub, room, t) => { const s = room.state, slot = s.cur; return hub.input(room.players[slot].cid, room.id, E.autoMove(s, slot), t); };

test("hub: matchmaking pairs two real players; no bots, no self-match; round starts after 3-2-1", () => {
  const { hub, ra, rb } = twoPlayers(); let t = 1e12;
  assert.equal(hub.joinQueue("a", t).ok, true); t = run(hub, t, 300);
  assert.equal(hub.rooms.size, 0, "a lone player is never given a fake opponent");
  hub.joinQueue("a", t); assert.equal(hub.queue.length, 1, "queued twice = still once");
  hub.joinQueue("b", t); t = run(hub, t, 200);
  assert.equal(hub.rooms.size, 1); assert.equal(of(ra, "queue").pop().data.state, "matched");
  t = run(hub, t, 4500);
  assert.deepEqual(of(ra, "countdown").map((e) => e.data.n), [3, 2, 1, 0]);
  assert.equal(of(ra, "round").length, 1); assert.ok(of(ra, "turnstart").length > 0);
  const round = of(ra, "round")[0].data; assert.equal(round.view.walls.length, 0); assert.equal(round.view.cur, 0); assert.equal(round.w, 9);
  assert.equal(of(ra, "room").pop().data.you !== of(rb, "room").pop().data.you, true, "different slots");
});
test("hub: server is authoritative — a full match is played through input, ends, is saved once and rated", () => {
  const { st, hub, ra } = twoPlayers(); let t = 1e12;
  hub.joinQueue("a", t); hub.joinQueue("b", t); t = run(hub, t, 300);
  const room = Array.from(hub.rooms.values())[0];
  t = playOut(hub, room, t);
  assert.equal(room.status, "finished");
  const end = of(ra, "match_end"); assert.equal(end.length, 1, "match_end sent once");
  assert.ok(of(ra, "turn").length > 10); assert.ok(of(ra, "turn").some((e) => e.data.act.t === "w") || true);
  assert.equal(st.doc.matches.length, 1); assert.equal(st.doc.matchIds.length, 1);
  assert.equal(st.doc.players.a.played + st.doc.players.b.played, 2);
  hub.finish(room, 0, "score", t); assert.equal(st.doc.matches.length, 1, "late/duplicate finish does nothing");
  const roundEnds = of(ra, "round_end"); assert.ok(roundEnds.length >= 2); assert.ok(roundEnds.every((e) => e.data.reason === "goal" || e.data.reason === "time"));
});
test("hub: the opening move alternates round by round", () => {
  const { hub, ra } = twoPlayers(); let t = 1e12;
  hub.joinQueue("a", t); hub.joinQueue("b", t); t = run(hub, t, 300);
  const room = Array.from(hub.rooms.values())[0]; t = playOut(hub, room, t);
  const rounds = of(ra, "round").map((e) => e.data.view.cur);
  assert.equal(rounds[0], 0); if (rounds.length > 1) assert.equal(rounds[1], 1);
});
test("hub: cheating attempts — junk, wrong room, wrong turn, off-turn, illegal teleport, path-closing barrier, spam", () => {
  const { hub } = twoPlayers(); let t = 1e12;
  hub.joinQueue("a", t); hub.joinQueue("b", t); t = run(hub, t, 200);
  const room = Array.from(hub.rooms.values())[0];
  assert.equal(hub.input("a", room.id, { t: "m", x: 4, y: 9 }, t).code, "NOT_PLAYING", "no input during the countdown");
  t = run(hub, t, 5200); assert.equal(room.status, "playing");
  const s = room.state, me = s.cur, you = 1 - s.cur, cm = room.players[me].cid, cy = room.players[you].cid;
  assert.equal(hub.input(cm, "other", { t: "m", x: 4, y: 9 }, t + 100).code, "NO_ROOM");
  assert.equal(hub.input("zzz", room.id, { t: "m", x: 4, y: 9 }, t + 100).code, "NO_ROOM", "a stranger cannot play");
  assert.equal(hub.input(cy, room.id, { t: "m", x: 4, y: 1 }, t + 100).code, "NOT_YOUR_TURN", "no moving on the other player's turn");
  for (const bad of [null, "U", 5, { t: "constructor" }, { t: "m" }, { t: "m", x: "4", y: "9" }, { t: "w", o: "q", x: 1, y: 1 }]) assert.equal(hub.input(cm, room.id, bad, t += 30).ok, false, JSON.stringify(bad));
  assert.equal(hub.input(cm, room.id, { t: "m", x: 0, y: 0 }, t += 30).code, "ILLEGAL_MOVE", "no teleporting");
  assert.equal(s.turn, 0, "nothing above changed the board");
  const pos = [s.players[0].x, s.players[0].y, s.players[1].x, s.players[1].y];
  assert.equal(hub.input(cm, room.id, { t: "m", x: s.players[me].x, y: s.players[me].y + (me === 0 ? -1 : 1), winner: me, over: true }, t += 30).ok, true, "extra fields are ignored");
  assert.equal(s.over, false); assert.equal(s.turn, 1);
  t += 30;
  assert.equal(hub.input(cy, room.id, { t: "m", x: s.players[you].x, y: s.players[you].y + (you === 0 ? -1 : 1) }, t).ok, true);
  assert.equal(hub.input(cy, room.id, { t: "m", x: 0, y: 0 }, t + 5).code, "TOO_FAST", "spamming faster than 15 ms is refused");
  assert.notDeepEqual([s.players[0].x, s.players[0].y, s.players[1].x, s.players[1].y], pos);
  // fence the opponent in with barriers until the server refuses the last one
  const w = E.create({ w: 6, h: 6 }); assert.equal(place(w, "h", 0, 2).ok && place(w, "h", 2, 2).ok, true); assert.equal(place(w, "h", 4, 2).code, "BLOCKS_PATH");
});
test("hub: a player who does not act in time gets an automatic step (never a barrier); the game never stalls", () => {
  const { st, hub, ra } = twoPlayers(); let t = 1e12; st.setSettings({ turnSeconds: 5 });
  hub.joinQueue("a", t); hub.joinQueue("b", t); t = run(hub, t, 5500);
  const room = Array.from(hub.rooms.values())[0]; assert.equal(room.status, "playing");
  const first = room.state.cur, d0 = E.dist(room.state, first), turn0 = room.state.turn;
  t = run(hub, t, 5600);
  assert.equal(room.state.turn, turn0 + 1, "exactly one automatic action"); assert.equal(E.dist(room.state, first), d0 - 1);
  const auto = of(ra, "turn").filter((e) => e.data.auto); assert.ok(auto.length >= 1); assert.equal(auto[0].data.act.t, "m"); assert.equal(auto[0].data.by, first);
  assert.equal(room.state.cur, 1 - first, "then it is the other player's turn");
});
test("hub: private room — code join, own code refused, unranked by default, rematch needs both", () => {
  const { st, hub, ra } = twoPlayers(); let t = 1e12;
  const r = hub.createPrivate("a", t); assert.equal(r.ok, true); assert.match(r.room.code, /^[A-HJKMNP-Z2-9]{6}$/);
  assert.equal(hub.joinPrivate("a", r.room.code, t).code, "ALREADY_IN_ROOM");
  assert.equal(hub.joinPrivate("b", "ZZZZZZ", t).code, "ROOM_NOT_FOUND");
  assert.equal(hub.joinPrivate("b", r.room.code.toLowerCase(), t).ok, true);
  assert.equal(hub.joinPrivate("c", r.room.code, t).code, "ROOM_NOT_FOUND", "a full room cannot be joined by a third player");
  const room = Array.from(hub.rooms.values())[0]; assert.equal(room.rated, false);
  t = playOut(hub, room, t);
  assert.equal(st.doc.players.a.rating, 1000, "private games never move rating");
  assert.equal(hub.rematch("a", t).ok, true); assert.equal(room.status, "finished", "one request is not enough");
  assert.equal(hub.rematch("b", t).ok, true); assert.equal(room.status, "countdown");
  assert.notEqual(room.matchId, null); assert.equal(of(ra, "round").length >= 2, true);
});
test("hub: disconnect pauses the match, reconnect resumes it with the board, running out of budget forfeits (one result)", () => {
  const { st, hub, ra } = twoPlayers(); let t = 1e12; st.setSettings({ turnSeconds: 120 });
  hub.joinQueue("a", t); hub.joinQueue("b", t); t = run(hub, t, 5600);
  const room = Array.from(hub.rooms.values())[0]; assert.equal(room.status, "playing");
  assert.equal(act1(hub, room, t + 40).ok, true);
  const u = hub.users.get("b"); u.streams.clear(); u.lastSeen = t;
  t = run(hub, t, 6000); assert.equal(room.status, "paused");
  const frozen = room.state.turn; t = run(hub, t, 2000); assert.equal(room.state.turn, frozen, "no moves while paused");
  assert.equal(hub.input(room.players[room.state.cur].cid, room.id, E.autoMove(room.state, room.state.cur), t).code, "NOT_PLAYING");
  assert.equal(of(ra, "presence").some((e) => e.data.connected === false), true);
  const rb2 = fakeRes(); hub.attachStream("b", rb2, t); t = run(hub, t, 300);
  const hello = of(rb2, "hello")[0].data; assert.ok(hello.round, "reconnect gets the board back"); assert.equal(hello.round.view.turn, frozen); assert.equal(hello.round.view.walls.length, room.state.walls.length);
  t = run(hub, t, 4000); assert.equal(room.status, "playing", "resumed");
  hub.users.get("b").streams.clear(); hub.users.get("b").lastSeen = t;
  let g = 0; while (room.status !== "finished" && g++ < 200) t = run(hub, t, 1000);
  assert.equal(room.status, "finished"); assert.equal(st.doc.matches.length, 1);
});
test("hub: leaving before the first action voids the match (no result, no penalty); leaving mid-match forfeits", () => {
  const a = twoPlayers(); let t = 1e12;
  a.hub.joinQueue("a", t); a.hub.joinQueue("b", t); t = run(a.hub, t, 1500);
  a.hub.leaveRoom("b", t); assert.equal(a.st.doc.matches.length, 0); assert.equal(of(a.ra, "match_end").pop().data.reason, "abort");
  const b = twoPlayers(); t = 1e12;
  b.hub.joinQueue("a", t); b.hub.joinQueue("b", t); t = run(b.hub, t, 6000);
  const room = Array.from(b.hub.rooms.values())[0]; assert.equal(act1(b.hub, room, t).ok, true); assert.equal(room.state.turn, 1);
  b.hub.leaveRoom("b", t);
  assert.equal(b.st.doc.matches.length, 1); assert.equal(b.st.doc.matches[0].reason, "forfeit"); assert.equal(b.st.doc.players.b.losses, 1); assert.equal(b.st.doc.players.a.wins, 1);
});
test("hub: polling fallback returns the same events; a stale cursor gets a full snapshot", () => {
  const st = mkStore(), hub = mkHub(st); let t = 1e12;
  hub.user("a"); hub.user("b"); hub.poll("a", 0, t); hub.poll("b", 0, t);
  hub.joinQueue("a", t); hub.joinQueue("b", t + 1);
  for (let i = 0; i < 80; i++) { t += 100; hub.poll("a", 0, t); hub.poll("b", 0, t); hub.pump(t); }
  const r = hub.poll("a", 0, t + 500); assert.ok(r.events.length > 0);
  assert.equal(hub.poll("a", r.eid, t + 900).events.every((e) => e.id > r.eid), true);
  assert.equal(hub.poll("a", r.eid, t + 905).throttled, true, "poll spam is throttled");
});
test("hub: queue — cannot join while in a room, disabled flag respected, timeout never invents an opponent", () => {
  const { st, hub, ra } = twoPlayers(); let t = 1e12;
  hub.createPrivate("a", t); assert.equal(hub.joinQueue("a", t).code, "ALREADY_IN_ROOM");
  st.setSettings({ onlineEnabled: false }); assert.equal(hub.joinQueue("b", t).code, "DISABLED"); st.setSettings({ onlineEnabled: true });
  hub.joinQueue("b", t); t = run(hub, t, 91000, 500);
  assert.equal(hub.queue.length, 0); assert.equal(hub.rooms.size, 1, "only the private room exists");
  assert.equal(ra.events.length > 0, true);
});

test("hub: a finished room (rematch window) never blocks a new search or room", () => {
  const { hub } = twoPlayers(); let t = 1e12;
  hub.createPrivate("a", t); hub.joinPrivate("b", Array.from(hub.codes.keys())[0], t);
  const room = Array.from(hub.rooms.values())[0]; t = playOut(hub, room, t);
  assert.equal(room.status, "finished");
  assert.equal(hub.joinQueue("a", t).ok, true, "a can search again right away");
  assert.equal(hub.createPrivate("b", t).ok, true, "b can open a new room");
  assert.equal(hub.rematch("a", t).ok, false, "a already left the finished room");
});
