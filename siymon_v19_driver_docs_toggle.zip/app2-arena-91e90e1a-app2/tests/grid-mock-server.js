"use strict";
/**
 * Browser-test server for Grid Battle: serves /public and mounts the REAL lib/grid-battle.js routes on a tiny
 * Express-compatible shim (the project has no node_modules in CI sandboxes). Customer tokens are "tok-<id>".
 * Usage: node tests/grid-mock-server.js [port]   (data in a temp dir, nothing touches the real DATA_DIR)
 */
const http = require("http"), fs = require("fs"), path = require("path"), os = require("os"), url = require("url");
const { registerGridRoutes } = require("../lib/grid-battle");
const PORT = Number(process.argv[2] || process.env.PORT || 4041);
const PUB = path.join(__dirname, "..", "public");
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), "grid-"));
const FILE = path.join(DATA, "grid_battle.json");
const CUSTOMERS = { a: { id: "a", firstName: "Ahmed", lastName: "Benali" }, b: { id: "b", firstName: "Sara", lastName: "Khan" }, c: { id: "c", firstName: "Omar", lastName: "Z" } };

const routes = [];
const app = { get: (p, ...h) => routes.push(["GET", p, h]), post: (p, ...h) => routes.push(["POST", p, h]), put: (p, ...h) => routes.push(["PUT", p, h]), delete: (p, ...h) => routes.push(["DELETE", p, h]) };
const requireCustomer = (req, res, next) => { const m = /^tok-(\w+)$/.exec(String(req.headers["x-customer-token"] || "")); if (!m || !CUSTOMERS[m[1]]) return res.status(401).json({ error: "Unauthorized" }); req.customerId = m[1]; next(); };
const requireAdmin = (req, res, next) => { if (req.headers["x-admin-token"] !== "adm") return res.status(401).json({ error: "Unauthorized" }); req.adminId = "adm"; next(); };
const { hub, store, assistantApi } = registerGridRoutes(app, {
  requireCustomer, requireAdmin, appendAuditLog() {}, logger: console, file: FILE,
  readJson: (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { return d; } },
  writeJson: (f, d) => fs.writeFileSync(f, JSON.stringify(d)),
  getCustomer: (id) => CUSTOMERS[id] || null,
  limiter: () => (req, res, next) => next(),
});

/* ---- optional: the REAL Siymon AI routes + a tiny scripted "model", to test the assistant inside the game (WITH_AI=1) ---- */
let aiRt = null;
if (process.env.WITH_AI) {
  const aiFiles = { "ai_settings.json": { enabled: true } }, support = [];
  // a play history so stats exist: Ahmed beat Sara 2-1 (ranked)
  store.applyMatch({ matchId: "seed1", kind: "quick", players: [{ id: "a", name: "Ahmed B." }, { id: "b", name: "Sara K." }], wins: [2, 1], winner: 0, reason: "score", rated: true, now: Date.now() });
  const prov = http.createServer((rq, rs) => {
    let b = ""; rq.on("data", (c) => (b += c)); rq.on("end", () => {
      const body = JSON.parse(b || "{}"), last = (body.contents || []).slice(-1)[0] || { parts: [] }, part = last.parts[0] || {};
      let parts;
      if (part.functionResponse) {
        const r = JSON.stringify(part.functionResponse.response || {});
        const m = /"rating":(\d+)/.exec(r), tier = /"tier":"(\w+)"/.exec(r);
        parts = [{ text: m ? `Your Grid Battle rating is ${m[1]} (${tier ? tier[1] : "?"}).` : part.functionResponse.name === "get_game_info" ? "Grid Battle: win rounds by outlasting your rival." : "Done." }];
      } else {
        const q = String(part.text || "").toLowerCase();
        parts = /rating|stats|إحصاء|تصنيف/.test(q) ? [{ functionCall: { name: "get_game_stats", args: {} } }] : /rule|قواعد/.test(q) ? [{ functionCall: { name: "get_game_info", args: {} } }] : [{ text: "Hello from the scripted model." }];
      }
      rs.writeHead(200, { "content-type": "text/event-stream" });
      rs.write("data: " + JSON.stringify({ candidates: [{ content: { parts } }], usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 5 } }) + "\n\n"); rs.end();
    });
  });
  prov.listen(0, "127.0.0.1");
  aiRt = require("../lib/ai/routes").register(app, {
    rateLimit: () => (_q, _s, next) => next(), requireAdmin,
    readJson: (f, d) => (aiFiles[f] !== undefined ? aiFiles[f] : d), writeJson: (f, v) => { aiFiles[f] = JSON.parse(JSON.stringify(v)); },
    settingsFile: "ai_settings.json", convFile: "ai_conversations.json", statsFile: "ai_stats.json",
    getCustomerTokenFromReq: (req) => { const a = String(req.header("authorization") || ""); return a.startsWith("Bearer ") ? a.slice(7) : ""; },
    getCustomerIdFromToken: (t) => { const m = /^tok-(\w+)$/.exec(t); return m && CUSTOMERS[m[1]] ? m[1] : null; },
    audit() {}, logger: console, adminId: () => "adm", supportSend: (id, text) => { support.push({ id, text }); return { ok: true, messageId: "m1" }; },
    env: { GEMINI_API_KEY: "abcdefgh12345678" },
    fetchImpl: (u, init) => fetch(String(u).replace(/^https:\/\/[^/]+/, "http://127.0.0.1:" + prov.address().port), init),
    dataDeps: {
      loadMenu: () => ({ items: [] }), loadRestaurants: () => ({ restaurants: [] }), loadOrders: () => ({ orders: [] }), loadCustomers: () => ({ customers: Object.values(CUSTOMERS) }), loadDrivers: () => ({ drivers: [] }),
      customerById: (d, id) => (d.customers || []).find((c) => String(c.id) === String(id)) || null, catalogLib: require("../lib/catalog"), searchLib: require("../lib/search"), customerAccount: require("../lib/customer-account"),
      loadConfig: () => ({ currency: "MAD" }), loadPaymentMethods: () => ({}), paymentMethods: () => [], customerWalletView: () => ({}), loadLoyalty: () => ({}), loadTopups: () => ({ topups: [] }), ratingFor: () => null,
      gameApi: assistantApi,
    },
  });
}
const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".webmanifest": "application/json", ".svg": "image/svg+xml" };
function match(pattern, p) {
  const names = [], re = new RegExp("^" + pattern.replace(/:(\w+)(\([^)]*\))?/g, (_m, n, g) => { names.push(n); return g ? "(" + g.slice(1, -1) + ")" : "([^/]+)"; }) + "$");
  const m = re.exec(p); if (!m) return null; const o = {}; names.forEach((n, i) => (o[n] = m[i + 1])); return o;
}
http.createServer((req, res) => {
  const u = url.parse(req.url, true);
  res.status = (c) => { res.statusCode = c; return res; };
  res.json = (o) => { if (!res.headersSent) res.setHeader("Content-Type", "application/json"); res.end(JSON.stringify(o)); };
  res.set = (k, v) => { if (k && typeof k === "object") Object.entries(k).forEach(([a, b]) => res.setHeader(a, b)); else res.setHeader(k, v); return res; };
  res.flushHeaders = res.flushHeaders || (() => {});
  req.header = (n) => req.headers[String(n).toLowerCase()];
  req.query = u.query; req.originalUrl = req.url;
  const r = routes.find(([m, p]) => m === req.method && match(p, u.pathname));
  if (!r) {
    let f = path.join(PUB, decodeURIComponent(u.pathname)); if (!f.startsWith(PUB)) { res.statusCode = 403; return res.end(); }
    if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, "index.html");
    if (!fs.existsSync(f)) { res.statusCode = 404; return res.end("nf"); }
    // same shape as the production helmet CSP (no inline scripts, no inline handlers) so violations show up in browser tests
    res.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; script-src-attr 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self' data:; object-src 'none'; media-src 'self'; worker-src 'self'");
    res.setHeader("Content-Type", MIME[path.extname(f)] || "application/octet-stream"); return fs.createReadStream(f).pipe(res);
  }
  req.params = match(r[1], u.pathname);
  let body = ""; req.on("data", (c) => (body += c));
  req.on("end", () => {
    try { req.body = body ? JSON.parse(body) : {}; } catch (e) { req.body = {}; }
    let i = 0; const next = () => { const h = r[2][i++]; if (h) h(req, res, next); }; next();
  });
}).listen(PORT, () => console.log("grid mock server on", PORT, "data", DATA));
module.exports = { hub, store };
