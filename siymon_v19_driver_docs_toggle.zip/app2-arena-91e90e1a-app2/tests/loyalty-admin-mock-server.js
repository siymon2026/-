"use strict";
/** TEST-ONLY: serves /public + the loyalty admin endpoints backed by the REAL lib/loyalty (same validation as server.js). */
const http = require("http"), fs = require("fs"), path = require("path");
const roles = require("../lib/admin-roles");
const loyalty = require("../lib/loyalty");
const rewardsLib = require("../lib/loyalty-rewards");
const loyaltyApp = require("../lib/loyalty-app");
const supportChat = require("../lib/support-chat");
const pickupPin = require("../lib/pickup-pin");
const PUB = path.join(__dirname, "..", "public");
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png", ".webmanifest": "application/json" };

function create(role = "system_admin") {
  let stored = loyalty.settingsOf({ enabled: true, version: 3 });
  const requests = [];
  let lastUpload = null;
  const avatars = new Map();
  const convs = [];                                   // support conversations (real lib)
  const ordersDb = [
    { id: "G1", createdAt: new Date().toISOString(), status: "new", customer: { name: "عمر الضيف", phone: "+212 611-111111" } },   // NO account
    { id: "R1", createdAt: new Date().toISOString(), status: "restaurant_ready", restaurantId: "RS1", customerId: "C1", total: 55, currency: "MAD", items: [], customer: { name: "سارة", phone: "0600000000", addr: "x" } },
    { id: "A1", createdAt: new Date().toISOString(), status: "new", customerId: "C1", customer: { name: "سارة", phone: "0600000000" } },
  ];
  const GUEST_TOKEN = "tok-g1";
  const convOf = (id) => { let c = convs.find((x) => x.customerId === id); if (!c) { c = supportChat.newConversation(id, new Date().toISOString()); convs.unshift(c); } return c; };
  const saveImg = (dataUrl) => {
    const m = String(dataUrl || "").match(/^data:image\/(?:jpeg|webp|png);base64,(.+)$/); if (!m) return null;
    const buf = Buffer.from(m[1], "base64");
    const jpg = buf[0] === 0xff && buf[1] === 0xd8, webp = buf.slice(0, 4).toString("ascii") === "RIFF" && buf.slice(8, 12).toString("ascii") === "WEBP";
    if (!jpg && !webp) return null;
    const url = "/uploads/chat/support_" + Date.now() + Math.floor(Math.random() * 1e4) + (webp ? ".webp" : ".jpg"); avatars.set(url, buf); return url;
  };
  const me = { id: "C1", firstName: "سارة", lastName: "ك", email: "s@t.t", phone: "0600000000" };
  const rewards = rewardsLib.empty();
  const account = { customerId: "C1", entries: [] };
  loyalty.credit(account, { ref: "seed", kind: "earn", points: 1000, at: new Date().toISOString() });
  const send = (res, code, obj) => { res.writeHead(code, { "content-type": "application/json" }); res.end(JSON.stringify(obj)); };
  const previewOf = (s) => ({ ar: loyalty.publicView(s, "ar"), fr: loyalty.publicView(s, "fr"), en: loyalty.publicView(s, "en") });
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, "http://x"), p = url.pathname;
    let raw = ""; req.on("data", (c) => (raw += c)); req.on("end", () => {
      if (p.startsWith("/api/")) requests.push(req.method + " " + p);
      const body = raw ? JSON.parse(raw) : {};
      if (p === "/api/admin/me") return send(res, 200, { id: "a1", role, permissions: roles.permissionsOf(role), email: "a@t.t", name: "admin" });
      if (p === "/api/admin/loyalty/settings" && req.method === "GET")
        return send(res, 200, { ok: true, settings: stored, preview: previewOf(stored), canEdit: roles.can(role, "loyalty.settings"), canAdjust: roles.can(role, "loyalty.adjust"), overview: { accounts: 128, availablePoints: 48210, pendingPoints: 930, usedPoints: 15200 } });
      if (p === "/api/admin/loyalty/settings" && req.method === "PUT") {
        if (!roles.can(role, "loyalty.settings")) return send(res, 403, { ok: false, code: "FORBIDDEN" });
        const v = loyalty.normalizeSettings(body, stored);
        if (!v.ok) return send(res, v.status || 400, { ok: false, error: v.error, code: v.code });
        stored = Object.assign({}, v.value, { updatedAt: new Date().toISOString(), updatedBy: "a1" });
        return send(res, 200, { ok: true, settings: stored, preview: previewOf(stored) });
      }
      if (p === "/api/admin/loyalty/preview") {
        const v = loyalty.normalizeSettings(body, stored);
        if (!v.ok) return send(res, 400, { ok: false, error: v.error, code: v.code });
        return send(res, 200, { ok: true, preview: previewOf(v.value) });
      }
      const ID = (re) => { const m = p.match(re); return m ? decodeURIComponent(m[1]) : null; };
      if (p === "/api/admin/loyalty/rewards" && req.method === "GET")
        return send(res, 200, { ok: true, products: rewards.products, redemptions: rewards.redemptions, pending: rewards.redemptions.filter((r) => r.status === "pending").length, canEdit: roles.can(role, "loyalty.settings"), canFulfil: roles.can(role, "loyalty.adjust") });
      if (p === "/api/admin/loyalty/rewards/products" && req.method === "POST") {
        if (!roles.can(role, "loyalty.settings")) return send(res, 403, { ok: false, code: "FORBIDDEN" });
        const v = rewardsLib.normalizeProduct(body);
        if (!v.ok) return send(res, v.status, { ok: false, error: v.error, code: v.code });
        const now = new Date().toISOString();
        const prod = { ...v.value, id: rewardsLib.newProductId(), createdAt: now, updatedAt: now };
        rewards.products.push(prod);
        return send(res, 200, { ok: true, product: prod });
      }
      if (ID(/^\/api\/admin\/loyalty\/rewards\/products\/([^/]+)$/) && ["PUT", "DELETE"].includes(req.method)) {
        if (!roles.can(role, "loyalty.settings")) return send(res, 403, { ok: false, code: "FORBIDDEN" });
        const id = ID(/^\/api\/admin\/loyalty\/rewards\/products\/([^/]+)$/);
        const i = rewards.products.findIndex((x) => x.id === id);
        if (i < 0) return send(res, 404, { ok: false, code: "NOT_FOUND", error: "Not found" });
        if (req.method === "DELETE") {
          if (rewards.redemptions.some((r) => r.productId === id && r.status === "pending")) return send(res, 409, { ok: false, code: "HAS_PENDING", error: "pending" });
          rewards.products.splice(i, 1); return send(res, 200, { ok: true, id });
        }
        const v = rewardsLib.normalizeProduct(body, rewards.products[i]);
        if (!v.ok) return send(res, v.status, { ok: false, error: v.error, code: v.code });
        rewards.products[i] = { ...v.value, id, createdAt: rewards.products[i].createdAt, updatedAt: new Date().toISOString() };
        return send(res, 200, { ok: true, product: rewards.products[i] });
      }
      if (ID(/^\/api\/admin\/loyalty\/redemptions\/([^/]+)\/(?:fulfil|cancel)$/) && req.method === "POST") {
        const id = ID(/^\/api\/admin\/loyalty\/redemptions\/([^/]+)\//);
        const kind = p.endsWith("/fulfil") ? "fulfil" : "cancel";
        const now = new Date().toISOString();
        const r = kind === "fulfil" ? rewardsLib.fulfil({ rewards, redemptionId: id, actorId: "a1", now }) : rewardsLib.cancel({ rewards, account, settings: stored, redemptionId: id, actorId: "a1", reason: body.reason, now });
        return r.ok ? send(res, 200, { ok: true, redemption: r.redemption }) : send(res, r.status || 400, { ok: false, error: r.error, code: r.code });
      }
      if (p === "/__seed-redemption" && req.method === "POST") {
        const r = rewardsLib.redeem({ rewards, account, settings: stored, productId: body.productId, customerId: "C1", customerName: "سارة", redemptionId: "seed" + Date.now(), now: new Date().toISOString() });
        return send(res, r.ok ? 200 : 400, { ok: r.ok, code: r.code, available: loyalty.balances(account, new Date().toISOString()).available });
      }
      if (p === "/__balance") return send(res, 200, { available: loyalty.balances(account, new Date().toISOString()).available });
      const now0 = () => new Date().toISOString();
      if (p === "/api/customer/wallet") {
        const bal = loyalty.balances(account, now0());
        return send(res, 200, { ok: true, walletBalance: 0, currency: "MAD", walletHistory: [], loyalty: { program: loyalty.publicView(stored, "ar"), balances: bal, valueMAD: bal.available / 10, canRedeem: true, minPoints: stored.redeem.minPoints, pointsPerCurrencyUnit: stored.redeem.pointsPerCurrencyUnit, maxPointsPerTx: stored.redeem.maxPointsPerTx, app: loyaltyApp.appView(account, stored, bal), entries: loyalty.statement(account, { limit: 100 }) } });
      }
      if (p === "/api/customer/loyalty/rewards" && req.method === "GET") {
        const avail = loyalty.balances(account, now0()).available;
        return send(res, 200, { ok: true, enabled: stored.enabled, available: avail, products: rewards.products.filter((x) => x.active).map((x) => rewardsLib.publicProduct(x, "ar", avail)), redemptions: rewards.redemptions.slice(0, 20).map((x) => rewardsLib.redemptionView(x, "ar")) });
      }
      if (ID(/^\/api\/customer\/loyalty\/rewards\/([^/]+)\/redeem$/) && req.method === "POST") {
        const r = rewardsLib.redeem({ rewards, account, settings: stored, productId: ID(/rewards\/([^/]+)\/redeem/), customerId: "C1", customerName: "سارة", redemptionId: "rd-" + (body.requestId || Date.now()), now: now0() });
        return r.ok ? send(res, 200, { ok: true, duplicate: !!r.duplicate, redemption: rewardsLib.redemptionView(r.redemption, "ar") }) : send(res, r.status || 400, { ok: false, error: r.error, code: r.code });
      }
      const customerList = () => [{ id: "C1", firstName: me.firstName, lastName: me.lastName, phone: me.phone, email: me.email }];
      const guestsNow = () => supportChat.guestContacts(ordersDb, customerList());
      if (p === "/api/admin/customers") return send(res, 200, { ok: true, customers: customerList() });
      if (p === "/api/admin/support/guests") return send(res, 200, { ok: true, guests: guestsNow().map((g) => ({ customerId: g.id, isGuest: true, customerName: g.name, customerPhone: g.phone, ordersCount: g.orders })) });
      if (p === "/api/admin/support/conversations") {
        const gs = new Map(guestsNow().map((g) => [g.id, g]));
        return send(res, 200, { ok: true, conversations: convs.map((c) => { const g = gs.get(c.customerId); const last = c.messages[c.messages.length - 1]; return { customerId: c.customerId, isGuest: supportChat.isGuestId(c.customerId), customerName: g ? g.name : c.customerId === "C1" ? me.firstName : "", customerPhone: g ? g.phone : "", lastAt: c.lastAt, lastText: supportChat.previewOf(last), unreadForAdmin: c.unreadForAdmin, unreadForCustomer: c.unreadForCustomer }; }) });
      }
      let mm = p.match(/^\/api\/admin\/support\/([^/]+)(\/image)?$/);
      if (mm && !["guests", "conversations"].includes(mm[1])) {
        const id = decodeURIComponent(mm[1]);
        const known = supportChat.isGuestId(id) ? guestsNow().some((g) => g.id === id) : id === "C1";
        if (!known) return send(res, 404, { error: "Not found" });
        const c = convOf(id);
        if (req.method === "GET") { c.unreadForAdmin = 0; return send(res, 200, { ok: true, customerId: id, isGuest: supportChat.isGuestId(id), messages: supportChat.publicMessages(c) }); }
        const r = mm[2] ? (() => { const u = saveImg(body.image); return u ? supportChat.addMessage(c, { id: "m" + Date.now(), from: "admin", type: "image", url: u, now: new Date().toISOString() }) : { ok: false, code: "BAD_IMAGE" }; })() : supportChat.addMessage(c, { id: "m" + Date.now(), from: "admin", text: body.text, now: new Date().toISOString() });
        return r.ok ? send(res, 200, { ok: true, message: r.message }) : send(res, 400, { error: r.code });
      }
      if (p === "/api/customer/support" && req.method === "GET") { const c = convOf("C1"); c.unreadForCustomer = 0; return send(res, 200, { ok: true, messages: supportChat.publicMessages(c) }); }
      if ((p === "/api/customer/support" || p === "/api/customer/support/image") && req.method === "POST") {
        const c = convOf("C1");
        const r = p.endsWith("/image") ? (() => { const u = saveImg(body.image); return u ? supportChat.addMessage(c, { id: "m" + Date.now(), from: "customer", type: "image", url: u, now: new Date().toISOString() }) : { ok: false, code: "BAD_IMAGE" }; })() : supportChat.addMessage(c, { id: "m" + Date.now(), from: "customer", text: body.text, now: new Date().toISOString() });
        return r.ok ? send(res, 200, { ok: true, message: r.message }) : send(res, 400, { error: r.code });
      }
      mm = p.match(/^\/api\/track\/([^/]+)(\/support(\/image)?)?$/);
      if (mm) {
        const o = ordersDb.find((x) => x.id === decodeURIComponent(mm[1]));
        if (!o || req.headers["x-track-token"] !== GUEST_TOKEN) return send(res, 404, { error: "Not found" });
        if (!mm[2]) return send(res, 200, { ok: true, order: { id: o.id, store: "مطعم", status: o.status, items: [], total: 0, currency: "MAD" } });
        const gid = supportChat.guestIdOfOrder(o);
        if (!gid) return send(res, 409, { error: "account", code: "HAS_ACCOUNT" });
        if (req.method === "GET") { const c = convs.find((x) => x.customerId === gid); if (c) c.unreadForCustomer = 0; return send(res, 200, { ok: true, messages: c ? supportChat.publicMessages(c) : [] }); }
        const c = convOf(gid);
        const r = mm[3] ? (() => { const u = saveImg(body.image); return u ? supportChat.addMessage(c, { id: "m" + Date.now(), from: "customer", type: "image", url: u, now: new Date().toISOString() }) : { ok: false, code: "BAD_IMAGE" }; })() : supportChat.addMessage(c, { id: "m" + Date.now(), from: "customer", text: body.text, now: new Date().toISOString() });
        return r.ok ? send(res, 200, { ok: true, message: r.message }) : send(res, 400, { error: r.code });
      }
      if (p === "/api/payment-methods") return send(res, 200, { ok: true, methods: [{ id: "bank1", kind: "transfer", available: true, name: { ar: "تحويل بنكي" }, account: { holderName: "SIYMON SARL", bankName: "CIH", rib: "230 780 1234567890123456 78", iban: "MA64 2307 8012 3456 7890 1234 5678" } }] });
      if (p === "/api/restaurant/me") return send(res, 200, { ok: true, restaurant: { id: "RS1", name: { ar: "مطعم الاختبار" } } });
      if (p === "/api/restaurant/orders" && req.method === "GET") return send(res, 200, { ok: true, orders: ordersDb.filter((o) => o.restaurantId === "RS1") });
      mm = p.match(/^\/api\/restaurant\/orders\/([^/]+)\/pickup-location$/);
      if (mm && req.method === "POST") {
        const o = ordersDb.find((x) => x.id === decodeURIComponent(mm[1]));
        const can = pickupPin.canShare(o, "RS1"); if (!can.ok) return send(res, can.status, { error: can.error, code: can.code });
        const v = pickupPin.validatePin(body, new Date().toISOString()); if (!v.ok) return send(res, v.status, { error: v.error, code: v.code });
        o.storePin = v.pin; return send(res, 200, { ok: true, storePin: o.storePin });
      }
      if (p === "/__order-pin") { const o = ordersDb.find((x) => x.id === url.searchParams.get("id")); return send(res, 200, { storePin: (o && o.storePin) || null }); }
      if (p.startsWith("/api/admin/upload/") && req.method === "POST") { lastUpload = { path: p, head: String(body.image || "").slice(0, 24), bytes: String(body.image || "").length }; return send(res, 200, { ok: true, url: "/uploads/menu/up_" + Date.now() + ".webp" }); }
      if (p === "/__last-upload") return send(res, 200, lastUpload);
      if (p === "/api/customer/me") return send(res, 200, { ok: true, customer: me });
      if (p === "/api/customer/avatar" && req.method === "POST") {
        const m = String(body.image || "").match(/^data:image\/jpeg;base64,(.+)$/);
        if (!m) return send(res, 400, { ok: false, code: "INVALID_IMAGE", error: "bad" });
        const buf = Buffer.from(m[1], "base64");
        if (buf[0] !== 0xff || buf[1] !== 0xd8 || buf.length > 600000) return send(res, 400, { ok: false, code: "INVALID_IMAGE", error: "bad" });
        const url = "/uploads/avatars/av_" + Date.now() + ".jpg"; avatars.set(url, buf); me.avatar = url;
        return send(res, 200, { ok: true, avatar: url, customer: me });
      }
      if (p === "/api/customer/avatar" && req.method === "DELETE") { delete me.avatar; return send(res, 200, { ok: true, customer: me }); }
      if (avatars.has(p)) { res.writeHead(200, { "content-type": p.endsWith(".webp") ? "image/webp" : "image/jpeg" }); return res.end(avatars.get(p)); }
      if (p === "/api/admin/loyalty/customers") return send(res, 200, { ok: true, customers: [] });
      if (p.startsWith("/api/")) return send(res, 200, p.includes("list") || p.endsWith("s") ? [] : {});
      let f = path.join(PUB, p === "/" ? "index.html" : p);
      if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, "index.html");
      if (!f.startsWith(PUB) || !fs.existsSync(f)) { res.writeHead(404); return res.end("nf"); }
      res.writeHead(200, { "content-type": MIME[path.extname(f)] || "application/octet-stream" }); res.end(fs.readFileSync(f));
    });
  });
  return { server, requests, get stored() { return stored; }, listen: (port) => new Promise((ok) => server.listen(port, "127.0.0.1", ok)), close: () => server.close() };
}
module.exports = { create };
if (require.main === module) create().listen(Number(process.env.PORT || 4031)).then(() => console.log("loyalty admin mock on", process.env.PORT || 4031));
