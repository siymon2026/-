"""Customer: wallet = its own real page (no iframe), 'edit account' = its own page (not the orders page).
Mock server serves /public + wallet/me stand-ins (tests/ui-mock-server.js); PATCH /api/customer/me is stubbed with page.route.
Run: python3 tests/browser-customer-profile-pages.py"""
import subprocess, time, json, os, tempfile
from playwright.sync_api import sync_playwright
PORT = "4033"; B = "http://localhost:" + PORT
SEED = tempfile.mkdtemp()
json.dump({"restaurants": [{"id": "r1", "name": {"ar": "مطعم", "en": "R", "fr": "R"}, "isActive": True, "deliveryFee": 10, "minOrder": 0, "createdAt": "2026-01-01T00:00:00Z", "type": "restaurant"}]}, open(SEED + "/restaurants.json", "w"))
json.dump({"items": []}, open(SEED + "/menu.json", "w"))
srv = subprocess.Popen(["node", "tests/ui-mock-server.js"], env={"PORT": PORT, "PATH": os.environ["PATH"], "SEED_DIR": SEED}); time.sleep(1.2)
ok = True; errs = []
def check(n, c, x=""):
    global ok; print(("PASS " if c else "FAIL ") + n + ("" if c else " -> " + str(x))); ok = ok and bool(c)
INIT = "localStorage.setItem('siymon_customer_token_v1','ctok'); localStorage.setItem('siymon_customer_profile_v1', JSON.stringify({firstName:'علي',lastName:'الإدريسي',phone:'0611111111'}))"
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        for w, h in ((360, 800), (375, 812), (390, 844), (412, 915)):
            t = f"[{w}]"
            ctx = b.new_context(viewport={"width": w, "height": h}, locale="ar", service_workers="block")
            ctx.add_init_script(INIT)
            pg = ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
            patches = []
            def patch(route):
                req = route.request
                if req.method == "PATCH":
                    body = json.loads(req.post_data or "{}"); patches.append(body)
                    if body.get("email") == "dup@x.com":
                        return route.fulfill(status=409, content_type="application/json", body=json.dumps({"error": "email already in use", "code": "DUPLICATE_EMAIL"}))
                    return route.fulfill(status=200, content_type="application/json", body=json.dumps({"ok": True, "customer": {"id": "c1", "firstName": body.get("firstName", "علي"), "lastName": "الإدريسي", "phone": "0611111111"}}))
                route.continue_()
            pg.route("**/api/customer/me", patch)
            # ---- profile -> wallet
            pg.goto(B + "/#profile"); pg.wait_for_selector("#pfWalletOpen", timeout=8000)
            check(t + " profile has the wallet button", pg.locator("#pfWalletOpen").is_visible())
            pg.click("#pfWalletOpen"); pg.wait_for_url("**/wallet/**", timeout=8000); pg.wait_for_selector("#wBal", timeout=8000); pg.wait_for_timeout(500)
            check(t + " wallet is a real page (no iframe, URL /wallet/)", pg.url.endswith("/wallet/") and pg.locator("iframe").count() == 0, pg.url)
            check(t + " wallet shows the real balance", "125.50" in pg.locator("#wBal").inner_text().replace(",", "."), pg.locator("#wBal").inner_text())
            check(t + " wallet page has the bottom nav with Profile active", pg.locator(".sub-nav a.on[data-key=user]").count() == 1)
            check(t + " wallet page does not show the orders list", pg.locator("#ordersList").count() == 0)
            inside = pg.evaluate("[...document.querySelectorAll('.w-hero,.w-stats,.w-loyalty,.w-terms')].every(e=>{const r=e.getBoundingClientRect();return r.left>=8&&r.right<=innerWidth-8})")
            check(t + " wallet cards keep a margin on both sides (nothing clipped)", inside)
            check(t + " wallet: no sideways scroll", pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth") <= 0)
            if w == 390: pg.screenshot(path="/tmp/claude-0/shot-wallet-390.png")
            # ---- profile -> edit account
            pg.goto(B + "/#profile"); pg.wait_for_selector(".pf-head a.pf-btn", timeout=8000)
            pg.click(".pf-head a.pf-btn"); pg.wait_for_url("**/account/**", timeout=8000); pg.wait_for_selector("#acForm", state="visible", timeout=8000)
            check(t + " edit account opens the account page, not orders", "/account/" in pg.url and pg.locator("#ordersList").count() == 0, pg.url)
            check(t + " account page does not show the wallet", pg.locator("#wBal").count() == 0 and pg.locator("#pfWalletAmt").count() == 0)
            check(t + " form is prefilled from the account", pg.input_value("input[name=firstName]") == "علي")
            for sel in ("#acSave", "input[name=firstName]", "#lnWallet"):
                bx = pg.locator(sel).bounding_box()
                check(t + f" {sel} touch target >=44 and inside screen", bx["height"] >= 44 and bx["x"] >= 0 and bx["x"] + bx["width"] <= w, bx)
            check(t + " account: no sideways scroll", pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth") <= 0)
            pg.fill("input[name=email]", "dup@x.com"); pg.click("#acSave"); pg.wait_for_timeout(400)
            check(t + " duplicate e-mail shows a clear error", "مستخدم" in pg.locator("#acMsg").inner_text(), pg.locator("#acMsg").inner_text())
            pg.fill("input[name=email]", ""); pg.fill("input[name=firstName]", "أحمد"); pg.click("#acSave"); pg.wait_for_timeout(400)
            check(t + " save sends only changed fields", patches and patches[-1] == {"firstName": "أحمد"}, patches)
            check(t + " save confirms and updates the header", "تم حفظ" in pg.locator("#acMsg").inner_text() and "أحمد" in pg.locator("#acName").inner_text())
            if w == 390: pg.screenshot(path="/tmp/claude-0/shot-account-390.png")
            # ---- orders page: orders only
            pg.goto(B + "/orders/"); pg.wait_for_selector("#ordersView", state="visible", timeout=8000)
            check(t + " orders page has no wallet block and no inline edit button", pg.locator("#pfWalletLink").count() == 0 and pg.locator("#pfEditBtn").count() == 0)
            check(t + " orders page links to the account page", pg.locator("#pfAccountLink[href='/account/']").count() == 1)
            ctx.close()
        # logged out account page
        ctx = b.new_context(viewport={"width": 390, "height": 844}, locale="ar", service_workers="block"); pg = ctx.new_page()
        pg.goto(B + "/account/"); pg.wait_for_selector("#acAuth", state="visible", timeout=5000)
        check("logged-out account page asks to sign in", pg.locator("#acAuth a").count() == 1)
        b.close()
finally:
    srv.terminate()
bad = [e for e in errs if "404" not in e]
print("JS ERRORS:", bad[:5]); print("ALL PASS" if ok and not bad else "SOME FAILED")
