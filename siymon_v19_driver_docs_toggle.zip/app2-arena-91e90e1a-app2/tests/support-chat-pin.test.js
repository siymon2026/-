"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const sc = require("../lib/support-chat");
const pin = require("../lib/pickup-pin");

const NOW = "2026-11-01T10:00:00.000Z";
const ord = (id, phone, extra = {}) => ({ id, createdAt: NOW, status: "new", customer: { name: "Omar", phone }, ...extra });

test("phones are normalised so every spelling is the same contact", () => {
  assert.equal(sc.normPhone("+212 6 12-34-56-78"), "0612345678");
  assert.equal(sc.normPhone("00212612345678"), "0612345678");
  assert.equal(sc.normPhone("0612345678"), "0612345678");
  assert.equal(sc.guestId("+212612345678"), "g:0612345678");
  assert.equal(sc.guestId("12"), null);
  assert.equal(sc.guestId(""), null);
  assert.equal(sc.guestId("1".repeat(20)), null);
  assert.ok(sc.isGuestId("g:0612345678"));
  for (const bad of ["g:", "g:12", "g:abc12345", "0612345678", "g:0612345678;drop", null, undefined]) assert.equal(sc.isGuestId(bad), false, String(bad));
});

test("guest contacts: only account-less orders, grouped by phone, newest first", () => {
  const orders = [
    ord("1", "0611111111", { createdAt: "2026-10-01T10:00:00Z" }),
    ord("2", "+212611111111", { createdAt: "2026-10-05T10:00:00Z", customer: { name: "Omar B", phone: "+212611111111" } }),
    ord("3", "0622222222", { createdAt: "2026-10-09T10:00:00Z" }),
    ord("4", "0633333333", { customerId: "C9" }),           // has an account
    ord("5", "0644444444"),                                   // phone belongs to a registered customer
    ord("6", ""),                                             // no usable phone
  ];
  const list = sc.guestContacts(orders, [{ id: "C1", phone: "0644444444" }]);
  assert.deepEqual(list.map((g) => g.id), ["g:0622222222", "g:0611111111"]);
  const omar = list.find((g) => g.id === "g:0611111111");
  assert.equal(omar.orders, 2); assert.equal(omar.lastOrderId, "2"); assert.equal(omar.name, "Omar B");
});

test("an order's tracking link opens the guest conversation only for account-less orders", () => {
  assert.equal(sc.guestIdOfOrder(ord("1", "0611111111")), "g:0611111111");
  assert.equal(sc.guestIdOfOrder(ord("1", "0611111111", { customerId: "C1" })), null);
  assert.equal(sc.guestIdOfOrder(null), null);
});

test("addMessage: text, image, unread counters and refusals", () => {
  const c = sc.newConversation("g:0611111111", NOW);
  assert.equal(sc.addMessage(c, { id: "1", from: "admin", text: "  مرحبا  ", now: NOW }).message.text, "مرحبا");
  assert.equal(c.unreadForCustomer, 1); assert.equal(c.unreadForAdmin, 0);
  assert.ok(sc.addMessage(c, { id: "2", from: "customer", type: "image", url: "/uploads/chat/x.jpg", now: NOW }).ok);
  assert.equal(c.unreadForAdmin, 1);
  assert.equal(sc.addMessage(c, { id: "3", from: "customer", text: "   ", now: NOW }).code, "EMPTY");
  assert.equal(sc.addMessage(c, { id: "4", from: "customer", type: "image", url: "javascript:alert(1)", now: NOW }).code, "BAD_IMAGE");
  assert.equal(sc.addMessage(c, { id: "5", from: "customer", type: "image", url: "https://evil.example/x.jpg", now: NOW }).code, "BAD_IMAGE");
  assert.equal(sc.addMessage(c, { id: "6", from: "bot", text: "x", now: NOW }).code, "BAD_SENDER");
  assert.equal(c.messages.length, 2);
  const long = sc.addMessage(c, { id: "7", from: "admin", text: "x".repeat(5000), now: NOW }).message;
  assert.equal(long.text.length, sc.MAX_TEXT);
});

test("public messages expose only the safe fields", () => {
  const c = sc.newConversation("1", NOW);
  sc.addMessage(c, { id: "1", from: "customer", type: "image", url: "/uploads/chat/a.jpg", now: NOW });
  c.messages[0].internal = "secret";
  const m = sc.publicMessages(c)[0];
  assert.deepEqual(Object.keys(m).sort(), ["createdAt", "from", "id", "text", "type", "url"]);
  assert.equal(sc.previewOf(c.messages[0]), "📷");
});

test("pickup pin: coordinates are validated and rounded", () => {
  const ok = pin.validatePin({ lat: "33.2631234567", lng: -7.5871234567, accuracy: 12.4 }, NOW);
  assert.ok(ok.ok); assert.deepEqual(ok.pin, { lat: 33.263123, lng: -7.587123, accuracy: 12, at: NOW });
  for (const bad of [{}, { lat: 91, lng: 0.5 }, { lat: 10, lng: 181 }, { lat: "x", lng: 1 }, { lat: 0, lng: 0 }, { lat: null, lng: null }, { lat: "", lng: "" }, { lat: 10, lng: 10, accuracy: -1 }, null])
    assert.equal(pin.validatePin(bad, NOW).code, "BAD_COORDS", JSON.stringify(bad));
  assert.equal(pin.validatePin({ lat: 33, lng: -7, accuracy: 5000 }, NOW).code, "LOW_ACCURACY");
  assert.equal(pin.validatePin({ lat: 33, lng: -7 }, NOW).pin.accuracy, null);
});

test("pickup pin: only the order's own store, only before pickup", () => {
  const o = { id: "1", restaurantId: "R1", status: "restaurant_ready" };
  assert.ok(pin.canShare(o, "R1").ok);
  assert.equal(pin.canShare(o, "R2").status, 403);
  assert.equal(pin.canShare(null, "R1").status, 404);
  for (const st of ["new", "picked_up", "on_the_way", "delivered", "canceled"]) assert.equal(pin.canShare({ ...o, status: st }, "R1").status, 409, st);
  for (const st of ["admin_accepted", "restaurant_ready", "accepted"]) assert.ok(pin.canShare({ ...o, status: st }, "R1").ok, st);
});

test("pickup pin: the driver stops seeing it once the food is picked up", () => {
  const o = { id: "1", status: "accepted", storePin: { lat: 1, lng: 2 } };
  assert.ok(pin.forDriver(o).storePin);
  assert.equal("storePin" in pin.forDriver({ ...o, status: "picked_up" }), false);
  assert.equal(pin.forDriver({ id: "2", status: "accepted" }).storePin, undefined);
  assert.ok(o.storePin, "never mutates its input");
});
