"use strict";
const test = require("node:test");
const assert = require("node:assert");
const http = require("node:http");
const routes = require("../lib/ai/routes");

function fakeApp() {
  const table = [];
  const add = (method) => (path, ...h) => table.push({ method, path, h });
  const app = { get: add("GET"), post: add("POST"), put: add("PUT"), delete: add("DELETE") };
  app.call = async (method, url, { headers = {}, body = {}, params } = {}) => {
    const route = table.find((r) => r.method === method && (r.path === url || (r.path.includes(":") && new RegExp("^" + r.path.replace(/:[^/]+/g, "([^/]+)") + "$").test(url))));
    if (!route) throw new Error(`no route ${method} ${url}`);
    const m = route.path.includes(":") ? url.match(new RegExp("^" + route.path.replace(/:[^/]+/g, "([^/]+)") + "$")) : null;
    const names = (route.path.match(/:[^/]+/g) || []).map((s) => s.slice(1));
    const req = { headers: Object.fromEntries(Object.entries(headers).map(([k, v]) => [k.toLowerCase(), v])), body, params: params || Object.fromEntries(names.map((n, i) => [n, m[i + 1]])), ip: "9.9.9.9", header(k) { return this.headers[k.toLowerCase()]; }, on() {} };
    const out = { status: 200, json: null, chunks: [], ended: false, headers: {} };
    const res = {
      writableEnded: false, destroyed: false,
      status(s) { out.status = s; return this; }, set(a, b) { Object.assign(out.headers, typeof a === "object" ? a : { [a]: b }); return this; },
      json(j) { out.json = j; this.writableEnded = true; return this; }, write(c) { out.chunks.push(String(c)); return true; }, end() { this.writableEnded = true; out.ended = true; }, flushHeaders() {}, on() {},
    };
    for (const fn of route.h) { let nexted = false; await fn(req, res, () => { nexted = true; }); if (!nexted) break; }
    out.events = out.chunks.join("").split("\n\n").filter((c) => c.startsWith("data: ")).map((c) => JSON.parse(c.slice(6)));
    return out;
  };
  return app;
}
function provider(script) {
  const seen = [];
  const srv = http.createServer((req, res) => { let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => { seen.push(JSON.parse(b || "{}")); const parts = script.shift() || [{ text: "ok" }]; res.writeHead(200, { "content-type": "text/event-stream" }); res.write(`data: ${JSON.stringify({ candidates: [{ content: { parts } }], usageMetadata: { promptTokenCount: 4, candidatesTokenCount: 2 } })}\n\n`); res.end(); }); });
  return new Promise((r) => srv.listen(0, "127.0.0.1", () => r({ srv, seen, url: `http://127.0.0.1:${srv.address().port}` })));
}

async function boot(opts = {}) {
  const files = { "ai_settings.json": { enabled: true, ...(opts.settings || {}) } };
  const support = [];
  const app = fakeApp();
  const customers = { tok_A: "A", tok_B: "B" };
  const rt = routes.register(app, {
    rateLimit: () => (_q, _s, next) => next(), requireAdmin: (_q, _s, next) => next(),
    readJson: (f, d) => (files[f] !== undefined ? files[f] : d), writeJson: (f, v) => { files[f] = JSON.parse(JSON.stringify(v)); },
    settingsFile: "ai_settings.json", convFile: "ai_conversations.json", statsFile: "ai_stats.json",
    getCustomerTokenFromReq: (req) => { const a = String(req.header("authorization") || ""); return a.startsWith("Bearer ") ? a.slice(7) : ""; }, getCustomerIdFromToken: (t) => customers[t] || null,
    audit: () => {}, logger: { error() {} }, adminId: () => "adm", supportSend: (id, text) => { support.push({ id, text }); return { ok: true, messageId: "m1" }; },
    env: opts.env || { GEMINI_API_KEY: "abcdefgh12345678" }, fetchImpl: undefined,
    dataDeps: {
      loadMenu: () => ({ items: [] }), loadRestaurants: () => ({ restaurants: [] }), loadOrders: () => ({ orders: [{ id: "o-A-1", customerId: "A", status: "new", total: 10, items: [], createdAt: "2026-11-01" }, { id: "o-B-1", customerId: "B", status: "new", total: 99, items: [], createdAt: "2026-11-02" }] }),
      loadCustomers: () => ({ customers: [{ id: "A", firstName: "Aya", walletBalance: 5 }, { id: "B", firstName: "Bilal", walletBalance: 77 }] }), loadDrivers: () => ({ drivers: [] }), customerById: (d, id) => d.customers.find((c) => c.id === id),
      catalogLib: require("../lib/catalog"), searchLib: require("../lib/search"), customerAccount: require("../lib/customer-account"), loadConfig: () => ({ currency: "MAD" }), loadPaymentMethods: () => [], paymentMethods: {},
      customerWalletView: ({ customer }) => ({ walletBalance: customer.walletBalance, currency: "MAD", wallet: { enabled: true }, topups: [] }), loadLoyalty: () => ({}), loadTopups: () => ({ topups: [] }),
    },
  });
  return { app, files, support, rt };
}

test("config is public, hides nothing secret, and reflects key + guest policy", async () => {
  const { app } = await boot();
  const r = await app.call("GET", "/api/ai/config");
  assert.equal(r.json.available, true);
  assert.equal(JSON.stringify(r.json).includes("abcdefgh"), false);
  const b = await boot({ env: {} });
  assert.equal((await b.app.call("GET", "/api/ai/config")).json.available, false);
  const c = await boot({ settings: { allowGuests: false } });
  assert.equal((await c.app.call("GET", "/api/ai/config")).json.available, false);
  assert.equal((await c.app.call("GET", "/api/ai/config", { headers: { authorization: "Bearer tok_A" } })).json.available, true);
});

test("chat uses the VERIFIED token: wallet tool reads A's balance even if the browser claims to be B", async () => {
  const p = await provider([[{ functionCall: { name: "get_wallet_balance", args: { customerId: "B" } } }], [{ text: "Votre solde est de 5 MAD." }]]);
  const { app } = await boot({ settings: { baseUrl: undefined } });
  // point the already-created runtime at the fake provider
  const rt = (await boot()).rt; void rt;
  const boot2 = await boot();
  boot2.rt.saveSettings({ ...boot2.rt.getSettings(), enabled: true });
  boot2.rt.getSettings().baseUrl = p.url;
  const r = await boot2.app.call("POST", "/api/ai/chat", { headers: { authorization: "Bearer tok_A" }, body: { message: "رصيدي؟", customerId: "B", lang: "ar" } });
  p.srv.close();
  const fr = p.seen[1].contents.at(-1).parts[0].functionResponse.response.result;
  assert.equal(fr.balance, 5);
  assert.equal(r.events.some((e) => e.type === "final" && e.text.includes("5 MAD")), true);
});

test("history is private to the signed-in customer; deletion works; guests have no history API", async () => {
  const { app, rt } = await boot();
  const convA = rt.store.open({ customerId: "A" }, "");
  rt.store.append(convA, { role: "user", text: "hello" }, true);
  const mine = await app.call("GET", "/api/ai/history", { headers: { authorization: "Bearer tok_A" } });
  assert.equal(mine.json.conversations.length, 1);
  assert.equal((await app.call("GET", "/api/ai/history/" + convA.id, { headers: { authorization: "Bearer tok_B" } })).status, 404);
  assert.equal((await app.call("GET", "/api/ai/history")).status, 401);
  const del = await app.call("DELETE", "/api/ai/history", { headers: { authorization: "Bearer tok_A" } });
  assert.equal(del.json.deleted, 1);
});

test("support hand-off needs login, redacts secrets, only links the customer's own order", async () => {
  const { app, support } = await boot();
  assert.equal((await app.call("POST", "/api/ai/support", { body: { summary: "Commande non reçue" } })).status, 401);
  const ok = await app.call("POST", "/api/ai/support", { headers: { authorization: "Bearer tok_A" }, body: { summary: "Commande non reçue, carte 4111 1111 1111 1111", orderId: "o-B-1" } });
  assert.equal(ok.json.ok, true);
  assert.equal(support[0].id, "A");
  assert.equal(support[0].text.includes("4111"), false);
  assert.equal(support[0].text.includes("o-B-1"), false); // B's order is not attached to A's request
  assert.ok(support[0].text.startsWith("[Siymon AI]"));
});

test("admin settings never accept or return an API key; invalid values are bounded", async () => {
  const { app } = await boot();
  const put = await app.call("PUT", "/api/admin/ai/settings", { body: { apiKey: "sk-secretsecretsecret", name: "Sam", limits: { perMinute: 9999 }, baseUrl: "http://evil.test", model: "x y" } });
  const s = put.json.settings;
  assert.equal(JSON.stringify(s).includes("secretsecret"), false);
  assert.equal(s.limits.perMinute, 60);
  assert.equal(s.baseUrl, "");
  assert.equal(s.key.configured, true);
  assert.equal(s.key.hint, "…5678");
});
