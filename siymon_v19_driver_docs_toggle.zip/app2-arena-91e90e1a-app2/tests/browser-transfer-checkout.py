"""Checkout by manual bank transfer (customer) + driver wallet inside the profile.
Server routes are the real rules (tested in tests/order-transfer.test.js); here the BROWSER side is checked with the
payment-methods / order / proof endpoints stubbed through page.route (the stubs are test-only).
Run: python3 tests/browser-transfer-checkout.py"""
import subprocess, time, json, urllib.request, os, base64, io, tempfile
from playwright.sync_api import sync_playwright
PORT = "4031"; B = "http://localhost:" + PORT; TOK = "test-admin-token"
SEED = tempfile.mkdtemp()
json.dump({"restaurants": [{"id": "r1", "name": {"ar": "مطعم", "en": "R", "fr": "R"}, "isActive": True, "deliveryFee": 10, "minOrder": 0, "createdAt": "2026-01-01T00:00:00Z", "type": "restaurant"}]}, open(SEED + "/restaurants.json", "w"))
json.dump({"items": [{"id": "i1", "restaurantId": "r1", "name": {"ar": "وجبة", "en": "Meal", "fr": "Repas"}, "price": 40, "isAvailable": True, "category": "x"}]}, open(SEED + "/menu.json", "w"))
srv = subprocess.Popen(["node", "tests/ui-mock-server.js"], env={"PORT": PORT, "PATH": os.environ["PATH"], "SEED_DIR": SEED}); time.sleep(1.2)
def call(method, path, body=None):
    r = urllib.request.Request(B + path, data=json.dumps(body).encode() if body is not None else None, headers={"Content-Type": "application/json", "X-Admin-Token": TOK}, method=method)
    return json.load(urllib.request.urlopen(r))
ok = True; errs = []
def check(n, c, x=""):
    global ok; print(("PASS " if c else "FAIL ") + n + ("" if c else " -> " + str(x))); ok = ok and bool(c)
# a real tiny PNG for the receipt
from PIL import Image
buf = io.BytesIO(); Image.new("RGB", (40, 30), (200, 30, 30)).save(buf, "PNG"); open("/tmp/claude-0/receipt.png", "wb").write(buf.getvalue())
CIH = {"id": "cih", "kind": "transfer", "name": {"ar": "تطبيق CIH Bank"}, "available": True, "reason": None, "requireReceipt": True, "sortOrder": 40,
       "account": {"holderName": "SIYMON SARL", "bankName": "CIH Bank", "rib": "230000000000000000000001", "iban": "", "accountNumber": "", "paymentIdentifier": "", "branch": "", "referenceFormat": "", "instructions": {"ar": "اكتب رقم الطلب في الملاحظة", "fr": "", "en": ""}}, "qrImage": ""}
COD = {"id": "cod", "kind": "cod", "name": {"ar": "الدفع عند الاستلام"}, "available": True, "reason": None, "sortOrder": 20}
CASHPLUS_OFF = {"id": "cashplus", "kind": "transfer", "name": {"ar": "كاش بلس"}, "available": False, "reason": "context_off", "sortOrder": 60}
try:
    rs = call("GET", "/api/admin/restaurants")["restaurants"]; store = rs[0]["id"]
    items = [i for i in call("GET", "/api/admin/menu")["items"] if i["restaurantId"] == store and i.get("isAvailable") != False]
    a = items[0]
    with sync_playwright() as p:
        br = p.chromium.launch()
        for w, h in ((360, 800), (390, 844), (412, 915)):
            ctx = br.new_context(viewport={"width": w, "height": h}, locale="ar", service_workers="block")
            ctx.add_init_script("localStorage.setItem('siymon_addr_prompted_v1','true');localStorage.setItem('siymon_lang_v1','ar');localStorage.setItem('siymon_customer_token_v1','ctok');")
            pg = ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
            pg.route("**/fonts.g*/**", lambda r: r.abort()); pg.route("**/accounts.google.com/**", lambda r: r.abort())
            pg.route("**/api/public-config", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps({"restaurantMode": "open"})))
            pg.route("**/api/payment-methods*", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps({"ok": True, "methods": [COD, CIH, CASHPLUS_OFF]})))
            orders = []; proofs = []; proof_status = {"code": 200}
            def order_route(r):
                orders.append(json.loads(r.request.post_data or "{}"))
                r.fulfill(status=200, content_type="application/json", body=json.dumps({"ok": True, "id": "T1", "requiresPaymentProof": True, "paymentStatus": "UNPAID"}))
            def proof_route(r):
                proofs.append(json.loads(r.request.post_data or "{}"))
                if proof_status["code"] == 200: r.fulfill(status=200, content_type="application/json", body=json.dumps({"ok": True, "paymentTransfer": {"status": "PAYMENT_PENDING"}}))
                else: r.fulfill(status=409, content_type="application/json", body=json.dumps({"ok": False, "code": "DUPLICATE_REFERENCE"}))
            pg.route("**/api/orders", order_route); pg.route("**/api/customer/orders/*/payment-proof", proof_route)
            dialogs = []; pg.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss()))
            pg.goto(B + "/"); pg.wait_for_timeout(1500)
            pg.evaluate("selectedRestaurantId=%s; addToCart(%s,2);" % (json.dumps(store), json.dumps(a["id"]))); pg.evaluate("document.getElementById('goCart').click()"); pg.wait_for_timeout(500)
            tag = f"[{w}]"
            check(tag + " no wallet tab in the bottom bar", pg.locator(".bottom-nav #navWallet").count() == 0 and pg.locator("#navWallet").count() == 0)
            methods = pg.locator("#payList .pay-opt")
            check(tag + " checkout lists COD + CIH + disabled Cash Plus", methods.count() == 3, methods.count())
            check(tag + " disabled method is not selectable", pg.locator("#payList .pay-opt.is-disabled").count() == 1)
            check(tag + " transfer box hidden while COD selected", pg.locator("#transferUse").is_hidden())
            pg.locator("#payList .pay-opt[data-method=cih]").click(); pg.wait_for_timeout(300)
            box = pg.locator("#transferUse"); txt = box.inner_text()
            check(tag + " account details shown (holder, RIB, bank)", "SIYMON SARL" in txt and "230000000000000000000001" in txt and "CIH Bank" in txt, txt[:200])
            grand = pg.evaluate("cartGrandTotal()")
            check(tag + " amount to transfer = whole total (goods + delivery)", ("%.2f" % grand) in txt and grand > pg.evaluate("cartSubTotal()"), (grand, txt[:120]))
            check(tag + " instructions shown", "اكتب رقم الطلب" in txt)
            over = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            check(tag + " no sideways scroll", over <= 0, over)
            # fill customer data, try without proof -> blocked, no order request
            pg.fill("#custName", "اختبار"); pg.fill("#custPhone", "0612345678"); pg.fill("#custAddr", "الدار البيضاء")
            pg.locator("#placeOrder").click(); pg.wait_for_timeout(300)
            check(tag + " order blocked without reference/receipt", len(orders) == 0 and "مرجع" in box.inner_text())
            pg.fill("#tpRefCo", "CIH-2026-0001"); pg.locator("#placeOrder").click(); pg.wait_for_timeout(300)
            check(tag + " order blocked without receipt image", len(orders) == 0 and "الوصل" in box.inner_text())
            pg.set_input_files("#tpFileCo", "/tmp/claude-0/receipt.png"); pg.wait_for_selector("#transferUse .tp-prev:not([hidden])", timeout=4000)
            pg.locator("#placeOrder").click(); pg.wait_for_timeout(900)
            check(tag + " ONE order request with the method id, no amount from the client", len(orders) == 1 and orders[0].get("paymentMethod") == "cih" and "total" not in orders[0] and "amount" not in orders[0], orders)
            check(tag + " proof sent after the order, JPEG receipt + reference", len(proofs) == 1 and proofs[0].get("reference") == "CIH-2026-0001" and str(proofs[0].get("receipt", "")).startswith("data:image/jpeg"), proofs and list(proofs[0].keys()))
            hint = pg.locator("#orderHint").inner_text()
            check(tag + " message says waiting for verification (not paid)", "بانتظار تأكيد" in hint and "تم الدفع" not in hint, hint)
            # proof refused by the server -> order exists, user is sent to My orders
            pg.evaluate("addToCart(%s,1);" % json.dumps(a["id"])); pg.wait_for_timeout(300)
            proof_status["code"] = 409
            pg.locator("#payList .pay-opt[data-method=cih]").click(); pg.wait_for_timeout(200)
            pg.fill("#tpRefCo", "CIH-2026-0002"); pg.set_input_files("#tpFileCo", "/tmp/claude-0/receipt.png"); pg.wait_for_selector("#transferUse .tp-prev:not([hidden])", timeout=4000)
            pg.locator("#placeOrder").click(); pg.wait_for_timeout(900)
            check(tag + " refused proof -> clear message + link to My orders", "مستعمل" in pg.locator("#orderHint").inner_text() or "استُعمل" in pg.locator("#orderHint").inner_text(), pg.locator("#orderHint").inner_text())
            check(tag + " link goes to the order", pg.locator("#orderHint a[href*='/orders/?order=T1']").count() == 1)
            ctx.close()
        # guest: transfer method comes back as "sign in" (server rule) and cannot be selected
        ctx = br.new_context(viewport={"width": 390, "height": 844}, locale="ar", service_workers="block")
        ctx.add_init_script("localStorage.setItem('siymon_addr_prompted_v1','true');localStorage.setItem('siymon_lang_v1','ar');")
        pg = ctx.new_page(); pg.route("**/fonts.g*/**", lambda r: r.abort()); pg.route("**/accounts.google.com/**", lambda r: r.abort())
        pg.route("**/api/public-config", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps({"restaurantMode": "open"})))
        g = dict(CIH, available=False, reason="login_required"); g.pop("account")
        pg.route("**/api/payment-methods*", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps({"ok": True, "methods": [COD, g]})))
        pg.goto(B + "/"); pg.wait_for_timeout(1200)
        pg.evaluate("selectedRestaurantId=%s; addToCart(%s,1);" % (json.dumps(store), json.dumps(a["id"]))); pg.evaluate("document.getElementById('goCart').click()"); pg.wait_for_timeout(400)
        d = pg.locator("#payList .pay-opt[data-method=cih]")
        check("guest: transfer shown as sign-in-first and disabled", d.get_attribute("aria-disabled") == "true" and "سجّل الدخول" in d.inner_text(), d.inner_text())
        ctx.close(); br.close()
finally:
    srv.terminate()
bad = [e for e in errs if "404" not in e and "ERR_FAILED" not in e]
print("JS ERRORS:", bad[:6]); print("ALL PASS" if ok and not bad else "SOME FAILED")
