"""Driver app screens (v2): login social buttons, profile wallet card, account-info page, wallet top-up steps.
The Node mock (tests/offline-driver-server.js) serves /public; payment methods + wallet policy are stubbed with page.route
(test-only stand-ins, same JSON shape as the real GET /api/payment-methods?context=driverTopup and GET /api/driver/wallet).
Run: python3 tests/browser-driver-app.py"""
import subprocess, time, json, os
from playwright.sync_api import sync_playwright
PORT = "4035"; B = "http://localhost:" + PORT
srv = subprocess.Popen(["node", "tests/offline-driver-server.js"], env={"PORT": PORT, "PATH": os.environ["PATH"]}); time.sleep(1.2)
ok = True; errs = []
def check(n, c, x=""):
    global ok; print(("PASS " if c else "FAIL ") + n + ("" if c else " -> " + str(x))); ok = ok and bool(c)
CIH = {"id": "cih", "kind": "transfer", "name": {"ar": "تطبيق CIH Bank", "fr": "CIH Bank", "en": "CIH Bank"}, "available": True, "requireReceipt": True, "minAmount": 50, "maxAmount": 5000,
       "account": {"holderName": "SIYMON SARL", "bankName": "CIH Bank", "rib": "230000000000000000000001", "iban": "", "accountNumber": "", "paymentIdentifier": "", "branch": "", "referenceFormat": "SIY-<phone>"}}
CASHP = {"id": "cashplus", "kind": "transfer", "name": {"ar": "كاش بلس", "fr": "Cash Plus", "en": "Cash Plus"}, "available": True, "requireReceipt": False,
         "account": {"holderName": "SIYMON", "bankName": "Cash Plus", "rib": "", "iban": "", "accountNumber": "", "paymentIdentifier": "0600112233", "branch": "", "referenceFormat": ""}}
WALLET = {"ok": True, "walletBalance": 100, "currency": "MAD", "policy": {"enabled": True, "currency": "MAD", "minTopup": 20, "maxTopup": 20000, "feePercent": 0, "feeFixed": 0, "presets": [50, 100, 200, 500]}, "walletHistory": [], "topups": []}
ME = {"ok": True, "driver": {"id": "D1", "name": "Driver", "status": "approved", "phone": "0600000000", "email": "d@x.com", "cardNumber": "AB123456", "walletBalance": 100, "createdAt": "2026-01-05T10:00:00Z", "approvedAt": "2026-01-07T10:00:00Z"}}
def stubs(pg, methods):
    pg.route("**/api/payment-methods*", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps({"ok": True, "methods": methods})))
    pg.route("**/api/driver/wallet", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps(WALLET)))
    pg.route("**/api/driver/me", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps(ME)))
def inside(pg, sel, w, m=8):
    return pg.evaluate("(s)=>[...document.querySelectorAll(s)].filter(e=>e.offsetParent).every(e=>{const r=e.getBoundingClientRect();return r.left>=%d&&r.right<=innerWidth-%d})" % (m, m), sel)
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        for w, h in ((360, 800), (375, 812), (390, 844), (412, 915)):
            t = f"[{w}]"
            # ---- login screen
            c = b.new_context(viewport={"width": w, "height": h}, locale="ar", service_workers="block")
            pg = c.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
            pg.goto(B + "/driver/"); pg.wait_for_selector("#googleBtn", state="visible", timeout=8000)
            g = pg.locator("#googleBtn").bounding_box(); a = pg.locator("#appleBtn").bounding_box(); card = pg.locator(".auth-card").bounding_box()
            check(t + " Google and Apple buttons are the same size", abs(g["width"] - a["width"]) < 1 and abs(g["height"] - a["height"]) < 1 and g["height"] >= 48, (g, a))
            check(t + " both buttons are centred in the card (equal margins)", abs((g["x"] - card["x"]) - (card["x"] + card["width"] - g["x"] - g["width"])) < 2 and abs((a["x"] - card["x"]) - (card["x"] + card["width"] - a["x"] - a["width"])) < 2, (g, a, card))
            gc = pg.evaluate("(()=>{const b=document.getElementById('googleBtn'),i=b.querySelector('.brand'),s=b.querySelector('span');const r=b.getBoundingClientRect(),a=i.getBoundingClientRect(),c=s.getBoundingClientRect();const l=Math.min(a.left,c.left),rt=Math.max(a.right,c.right);return [l-r.left, r.right-rt]})()")
            check(t + " icon + label centred inside the Google button", abs(gc[0] - gc[1]) < 3, gc)
            check(t + " login: no sideways scroll", pg.evaluate("document.documentElement.scrollWidth - innerWidth") <= 0)
            if w == 390: pg.screenshot(path="/tmp/claude-0/drv2-login.png")
            c.close()
            # ---- logged in
            c = b.new_context(viewport={"width": w, "height": h}, locale="ar", service_workers="block")
            c.add_init_script("localStorage.setItem('SIYMON_DRIVER_TOKEN','dtok'); localStorage.setItem('SIYMON_DRIVER_SOUND_PROMPTED','1')")
            pg = c.new_page(); pg.on("pageerror", lambda e: errs.append(str(e))); stubs(pg, [CIH, CASHP])
            pg.goto(B + "/driver/"); pg.wait_for_timeout(1500)
            pg.click(".nav-item[data-page=profile]"); pg.wait_for_timeout(500)
            wb = pg.locator("#profileWalletLink").bounding_box()
            check(t + " profile wallet card keeps a gutter on both sides", wb["x"] >= 12 and wb["x"] + wb["width"] <= w - 12 and wb["height"] >= 56, wb)
            check(t + " profile: every block keeps a gutter", inside(pg, "#pageProfile .menu, #pageProfile .pf-wallet, #pageProfile .profile-card, #ratingsCard", w, 12))
            pg.click("#rowAccountInfo"); pg.wait_for_selector("#pageAccount", state="visible", timeout=4000); pg.wait_for_timeout(300)
            check(t + " account info opens as a full page (no sheet)", pg.locator("#accountSheetBackdrop").count() == 0 and pg.locator("#pageAccount").is_visible())
            txt = pg.locator("#pageAccount").inner_text()
            check(t + " account page shows phone, e-mail, card number, dates", all(v in txt for v in ("0600000000", "d@x.com", "AB123456")) and "2026" in txt, txt[:200])
            check(t + " account page keeps the profile tab highlighted", pg.locator(".nav-item[data-page=profile].active").count() == 1)
            check(t + " account page: blocks inside the screen + no sideways scroll", inside(pg, "#pageAccount .menu, #pageAccount .acc-hero", w, 12) and pg.evaluate("document.documentElement.scrollWidth - innerWidth") <= 0)
            for sel in ("[data-copy=profilePhone]", "#accountBackBtn"):
                bx = pg.locator(sel).bounding_box(); check(t + f" {sel} is a >=44px target", bx["height"] >= 44 and bx["width"] >= 44, bx)
            if w == 390: pg.screenshot(path="/tmp/claude-0/drv2-account.png")
            pg.click("#accountBackBtn"); pg.wait_for_timeout(300)
            check(t + " back returns to the profile", pg.locator("#pageProfile").is_visible())
            # ---- wallet top-up
            pg.click("#profileWalletLink"); pg.wait_for_selector("#topupMethodCards .tp-method", timeout=5000); pg.wait_for_timeout(300)
            check(t + " both payment methods are shown as cards", pg.locator("#topupMethodCards .tp-method").count() == 2)
            check(t + " details stay hidden until a method is chosen", pg.locator("#topupPanel").is_hidden())
            pg.click("#topupMethodCards .tp-method[data-method=cih]"); pg.wait_for_timeout(300)
            check(t + " chosen card is marked selected", pg.locator("#topupMethodCards .tp-method[aria-checked=true]").count() == 1)
            acct = pg.locator("#topupAccount").inner_text()
            check(t + " account details shown (holder, bank, RIB) with copy buttons", "SIYMON SARL" in acct and "CIH Bank" in acct and "230000000000000000000001" in acct and pg.locator("#topupAccount [data-copytext]").count() >= 3, acct)
            check(t + " preset amounts shown (only those inside the method limits)", pg.locator("#topupPresets .tp-chip").count() >= 3)
            pg.click("#topupPresets .tp-chip[data-preset='100']"); pg.wait_for_timeout(200)
            check(t + " tapping a preset fills the amount", pg.input_value("#topupAmount") == "100")
            pg.click("#topupSendBtn"); pg.wait_for_timeout(300)
            check(t + " sending without a reference is refused with a clear message", pg.locator("#topupHint").inner_text().strip() != "", pg.locator("#topupHint").inner_text())
            check(t + " wallet: blocks inside the screen + no sideways scroll", inside(pg, "#pageWallet .tp-method, #pageWallet .tp-account, #pageWallet .tp-form, #pageWallet .wallet-hero", w, 12) and pg.evaluate("document.documentElement.scrollWidth - innerWidth") <= 0)
            if w == 390:
                pg.locator("#topupBlock").scroll_into_view_if_needed(); pg.screenshot(path="/tmp/claude-0/drv2-wallet.png")
            c.close()
        # no methods configured -> clear empty state, send disabled
        c = b.new_context(viewport={"width": 390, "height": 844}, locale="ar", service_workers="block")
        c.add_init_script("localStorage.setItem('SIYMON_DRIVER_TOKEN','dtok'); localStorage.setItem('SIYMON_DRIVER_SOUND_PROMPTED','1')")
        pg = c.new_page(); stubs(pg, []); pg.goto(B + "/driver/"); pg.wait_for_timeout(1500)
        pg.click(".nav-item[data-page=profile]"); pg.click("#profileWalletLink"); pg.wait_for_timeout(800)
        check("no methods configured: explanation shown, send disabled", pg.locator("#topupEmpty").is_visible() and pg.locator("#topupSendBtn").is_disabled() or pg.locator("#topupPanel").is_hidden())
        b.close()
finally:
    srv.terminate()
bad = [e for e in errs if "404" not in e]
print("JS ERRORS:", bad[:5]); print("ALL PASS" if ok and not bad else "SOME FAILED")
