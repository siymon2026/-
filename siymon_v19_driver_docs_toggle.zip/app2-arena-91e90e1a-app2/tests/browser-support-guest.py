"""Admin <-> customers WITHOUT an account, customer photos to support, RIB copy.
Run: PORT=4031 node tests/loyalty-admin-mock-server.js &  then  python3 tests/browser-support-guest.py"""
import asyncio, base64, json, urllib.request
from playwright.async_api import async_playwright
BASE = "http://127.0.0.1:4031"
errs = []
JPG = """() => { const c=document.createElement('canvas'); c.width=900; c.height=600; const x=c.getContext('2d'); x.fillStyle='#36c'; x.fillRect(0,0,900,600); return c.toDataURL('image/jpeg',0.9).split(',')[1]; }"""
async def ev(pg, js, arg=None):
    """evaluate, retrying when the page reloads itself once (service worker / perms refresh)"""
    for i in range(4):
        try:
            await pg.wait_for_load_state("load")
            return await (pg.evaluate(js, arg) if arg is not None else pg.evaluate(js))
        except Exception as e:
            if "context was destroyed" not in str(e) or i == 3: raise
            await pg.wait_for_timeout(800)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        # ---------------- admin: starts a chat with a customer who has NO account ----------------
        ctx = await b.new_context(viewport={"width": 1280, "height": 900}, permissions=["clipboard-read", "clipboard-write"])
        await ctx.add_init_script("localStorage.setItem('siymon_admin_token_v2','tok-system')")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("admin: " + str(e)))
        await pg.goto(BASE + "/admin/"); await pg.wait_for_timeout(1200)
        await ev(pg, "document.getElementById('supportBtn').click()")
        await pg.wait_for_selector("#supportModal.show")
        for _ in range(4):   # the admin page can finish wiring right after it opens: retry the toggle until the picker is really open
            await pg.locator("#scNewBtn").click()
            try:
                await pg.wait_for_selector("#scNewList .sc-item", timeout=2500); break
            except Exception:
                if await pg.locator("#scNewList .sc-item").count(): break
        await pg.wait_for_selector("#scNewList .sc-item")
        items = await pg.locator("#scNewList .sc-item").all_inner_texts()
        assert any("بدون حساب" in t for t in items), items          # the guest is offered, tagged
        assert any("سارة" in t for t in items), items                # and the registered customer too
        await pg.locator("#scNewList .sc-item", has_text="بدون حساب").click()
        await pg.fill("#supportMsgInput", "مرحبا، طلبك في الطريق"); await pg.locator("#supportSendBtn").click()
        await pg.wait_for_selector("#supportChatBox .chat-msg.me")
        # admin sends a photo too
        png = await ev(pg, JPG)
        await pg.set_input_files("#scFile", files=[{"name": "a.jpg", "mimeType": "image/jpeg", "buffer": base64.b64decode(png)}])
        await pg.wait_for_selector("#supportChatBox img.sc-img", timeout=5000)
        await ctx.close()

        # ---------------- the guest opens the tracking link of their order ----------------
        ctx = await b.new_context(viewport={"width": 390, "height": 844})
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("track: " + str(e)))
        await pg.goto(BASE + "/track/#G1.tok-g1"); await pg.wait_for_selector("#tkSupport:not([hidden])", timeout=6000)
        assert await pg.locator("#tkSupport img").count() == 1, "the admin's photo is visible"
        assert "مرحبا، طلبك في الطريق" in await pg.locator("#tkSupport").inner_text()
        await pg.locator("#tkSupport input[type=text]").fill("شكراً، متى يصل؟"); await pg.locator("#tkSupport button", has_text="إرسال").click()
        await pg.wait_for_function("document.querySelector('#tkSupport').innerText.includes('متى يصل')")
        png = await ev(pg, JPG)
        await pg.set_input_files("#tkSupport input[type=file]", files=[{"name": "p.jpg", "mimeType": "image/jpeg", "buffer": base64.b64decode(png)}])
        await pg.wait_for_function("document.querySelectorAll('#tkSupport img').length === 2", timeout=5000)
        await pg.screenshot(path="/tmp/shots/guest_track.png")
        await ctx.close()
        # a wrong token sees nothing
        ctx = await b.new_context(); pg = await ctx.new_page()
        await pg.goto(BASE + "/track/#G1.wrong"); await pg.wait_for_timeout(800)
        assert await pg.locator("#tkSupport").is_hidden()
        await ctx.close()

        # ---------------- a registered customer sends a photo from /chat/ ----------------
        ctx = await b.new_context(viewport={"width": 390, "height": 844})
        await ctx.add_init_script("localStorage.setItem('siymon_customer_token_v1','tok-cust')")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("chat: " + str(e)))
        await pg.goto(BASE + "/chat/"); await pg.wait_for_selector("#chatAttachBtn:not([hidden])", timeout=6000)
        png = await ev(pg, JPG)
        await pg.set_input_files("#chatFile", files=[{"name": "s.jpg", "mimeType": "image/jpeg", "buffer": base64.b64decode(png)}])
        await pg.wait_for_selector("#chatBox img.cc-img", timeout=6000)
        await pg.screenshot(path="/tmp/shots/cust_chat_photo.png")
        # not an image -> readable error, nothing added
        await pg.set_input_files("#chatFile", files=[{"name": "x.txt", "mimeType": "text/plain", "buffer": b"hello"}])
        await pg.wait_for_timeout(700)
        assert "❌" in await pg.locator("#chatHint").inner_text()
        assert await pg.locator("#chatBox img.cc-img").count() == 1
        await ctx.close()

        # ---------------- wallet: RIB / IBAN with copy buttons ----------------
        ctx = await b.new_context(viewport={"width": 390, "height": 844}, permissions=["clipboard-read", "clipboard-write"])
        await ctx.add_init_script("localStorage.setItem('siymon_customer_token_v1','tok-cust')")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("wallet: " + str(e)))
        await pg.goto(BASE + "/wallet/"); await pg.wait_for_selector("#wTopBtn", timeout=8000); await pg.locator("#wTopBtn").click(); await pg.wait_for_selector("#wMethodInfo .w-copy", timeout=8000)
        row = pg.locator("#wMethodInfo .w-acct-row", has_text="RIB")
        await row.locator(".w-copy").click()
        copied = await pg.evaluate("navigator.clipboard.readText()")
        assert copied == "230780123456789012345678", copied           # digits only, ready to paste in a banking app
        await pg.screenshot(path="/tmp/shots/wallet_rib.png")
        await ctx.close()

        # ---------------- store owner shares the pickup location ----------------
        ctx = await b.new_context(viewport={"width": 1280, "height": 800}, permissions=["geolocation"], geolocation={"latitude": 33.2631, "longitude": -7.5871, "accuracy": 15})
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("restaurant: " + str(e)))
        await pg.goto(BASE + "/restaurant/#admintoken=tok-rest"); await pg.wait_for_selector("button[data-action=shareloc]", timeout=8000)
        assert "موقع" in await pg.locator("button[data-action=shareloc]").inner_text()
        await ctx.set_geolocation({"latitude": 33.2631, "longitude": -7.5871, "accuracy": 4000})
        await pg.locator("button[data-action=shareloc]").click(); await pg.wait_for_timeout(1200)
        assert json.loads(urllib.request.urlopen(BASE + "/__order-pin?id=R1").read())["storePin"] is None, "an imprecise location is refused, never shared"
        await ctx.set_geolocation({"latitude": 33.2631, "longitude": -7.5871, "accuracy": 15})
        await pg.locator("button[data-action=shareloc]").click()
        await pg.wait_for_function("document.querySelector('button[data-action=shareloc]').innerText.includes('✓')", timeout=8000)
        pin = json.loads(urllib.request.urlopen(BASE + "/__order-pin?id=R1").read())["storePin"]
        assert pin and abs(pin["lat"] - 33.2631) < 1e-4 and pin["accuracy"] == 15, pin
        await pg.screenshot(path="/tmp/shots/restaurant_pin.png")
        await ctx.close()
        await b.close()
asyncio.run(main())
assert not errs, errs
print("ok: guest support + photos + RIB copy")
