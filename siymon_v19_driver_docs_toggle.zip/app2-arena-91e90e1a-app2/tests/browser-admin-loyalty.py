"""Admin loyalty page: edit tiers / ladder / alert days, validation, save round-trip.
Run: PORT=4031 node tests/loyalty-admin-mock-server.js &  then  python3 tests/browser-admin-loyalty.py"""
import asyncio, json
from playwright.async_api import async_playwright
errs = []
async def ev(pg, js, arg=None):
    """evaluate, retrying when the page reloads itself once (service worker / perms refresh)"""
    for i in range(4):
        try:
            await pg.wait_for_load_state("load")
            return await (pg.evaluate(js, arg) if arg is not None else pg.evaluate(js))
        except Exception as e:
            if "context was destroyed" not in str(e) or i == 3: raise
            await pg.wait_for_timeout(800)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); ctx = await b.new_context(viewport={"width": 1280, "height": 900})
        await ctx.add_init_script("localStorage.setItem('siymon_admin_token_v2','tok-system')")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("dialog", lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto("http://127.0.0.1:4031/admin/"); await pg.wait_for_timeout(1200)
        await pg.locator("#sbLoyalty").click(); await pg.wait_for_selector(".lx-hero")
        assert await pg.locator(".lx-bar .lx-btn.primary").is_disabled(), "save starts disabled"
        # redeem tab: alert days
        await pg.locator(".lx-tab[data-k=redeem]").click()
        await pg.locator(".lx-pane:not([hidden]) .lx-card").nth(1).locator("input[type=number]").nth(1).fill("14")
        # levels tab
        await pg.locator(".lx-tab[data-k=levels]").click()
        assert await pg.locator(".lx-tier").count() == 3
        await pg.locator(".lx-tier").nth(1).locator("input[type=number]").fill("400"); await pg.locator(".lx-tier").nth(1).locator("input[type=number]").dispatch_event("change")
        await pg.locator(".lx-tier").nth(2).locator("input[type=text]").first.fill("ماسي")
        await pg.get_by_role("button", name="+ إضافة رتبة").click()
        assert await pg.locator(".lx-tier").count() == 4
        # invalid: new tier has empty Arabic name -> save blocked with a message
        assert await pg.locator(".lx-bar .lx-btn.primary").is_disabled(), "empty name must block save"
        assert "⚠" in await pg.locator(".lx-issues").inner_text()
        await pg.locator(".lx-tier").nth(3).locator("input[type=text]").first.fill("أسطوري")
        await pg.locator(".lx-tier").nth(3).locator("input[type=number]").fill("4000")
        # ladder: add 15, remove 100
        await pg.locator(".lx-addrow input").fill("15"); await pg.locator(".lx-addrow button").click()
        await pg.locator(".lx-chip").last.locator(".lx-icon-btn").click()
        assert await pg.locator(".lx-chip").count() == 5
        assert await pg.locator(".lx-bar .lx-btn.primary").is_enabled()
        await pg.locator(".lx-bar .lx-btn.primary").click(); await pg.wait_for_timeout(900)
        # reload shows the saved values
        await pg.locator(".lx-tab[data-k=levels]").click()
        names = await pg.locator(".lx-tier").evaluate_all("els=>els.map(e=>e.querySelector('input[type=text]').value)")
        assert names == ["برونزي", "فضي", "ماسي", "أسطوري"], names
        steps = await pg.locator(".lx-chip b").all_inner_texts()
        assert [s.strip() for s in steps] == ["5", "10", "15", "20", "50"], steps
        await pg.locator(".lx-tab[data-k=redeem]").click()
        assert await pg.locator(".lx-pane:not([hidden]) .lx-card").nth(1).locator("input[type=number]").nth(1).input_value() == "14"
        await b.close()
asyncio.run(main())
assert not errs, errs
print("ok: admin loyalty settings flow")

# ---------------------------------------------------------------- reward products tab
async def shop():
    import urllib.request
    async with async_playwright() as p:
        b = await p.chromium.launch(); ctx = await b.new_context(viewport={"width": 1280, "height": 900})
        await ctx.add_init_script("localStorage.setItem('siymon_admin_token_v2','tok-system')")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("dialog", lambda d: asyncio.ensure_future(d.accept("غير متوفر")))
        await pg.goto("http://127.0.0.1:4031/admin/"); await pg.wait_for_timeout(1200)
        await pg.locator("#sbLoyalty").click(); await pg.wait_for_selector(".lx-hero")
        await pg.locator(".lx-tab[data-k=shop]").click(); await pg.wait_for_selector(".lx-shop")
        assert await pg.locator(".lx-bar").is_hidden(), "settings save bar hidden on the products tab"
        assert await pg.locator(".lx-empty").first.is_visible()
        # add a product
        await pg.get_by_role("button", name="+ منتج جديد").click()
        form = pg.locator(".lx-prodform")
        await form.locator("input[type=text]").first.fill("قهوة مجانية")
        await form.locator("input[type=number]").nth(0).fill("200"); await form.locator("input[type=number]").nth(1).fill("3")
        await form.get_by_role("button", name="إضافة المنتج").click(); await pg.wait_for_selector(".lx-prod")
        assert "قهوة مجانية" in await pg.locator(".lx-prod").first.inner_text()
        assert "3" in await pg.locator(".lx-prod small").first.inner_text()
        # invalid points are refused client-side
        await pg.get_by_role("button", name="+ منتج جديد").click()
        form = pg.locator(".lx-prodform")
        await form.locator("input[type=text]").first.fill("بدون سعر"); await form.locator("input[type=number]").nth(0).fill("0")
        await form.get_by_role("button", name="إضافة المنتج").click(); await pg.wait_for_timeout(300)
        assert await pg.locator(".lx-prod").count() == 1
        await form.get_by_role("button", name="إلغاء").click()
        # edit price
        await pg.locator(".lx-prod").first.get_by_role("button", name="تعديل").click()
        form = pg.locator(".lx-prodform"); await form.locator("input[type=number]").nth(0).fill("250")
        await form.get_by_role("button", name="حفظ", exact=True).click(); await pg.wait_for_timeout(500)
        assert "250" in await pg.locator(".lx-prod .lx-pts").first.inner_text()
        # a customer redeems (seeded through the real lib) -> pending request appears -> cancel refunds
        pid = (await pg.evaluate("fetch('/api/admin/loyalty/rewards',{headers:{Authorization:'Bearer tok-system'}}).then(r=>r.json()).then(j=>j.products[0].id)"))
        def post(path, body): return json.loads(urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:4031"+path, data=json.dumps(body).encode(), method="POST", headers={"content-type":"application/json"})).read())
        assert post("/__seed-redemption", {"productId": pid})["available"] == 750
        await pg.locator(".lx-tab[data-k=levels]").click(); await pg.locator(".lx-tab[data-k=shop]").click(); await pg.wait_for_timeout(500)
        assert await pg.locator(".lx-red").count() == 1
        await pg.get_by_role("button", name="إلغاء واسترجاع النقاط").click(); await pg.wait_for_timeout(600)
        assert json.loads(urllib.request.urlopen("http://127.0.0.1:4031/__balance").read())["available"] == 1000, "points refunded"
        assert await pg.locator(".lx-red").count() == 0, "pending list now empty"
        # second redemption -> fulfil
        post("/__seed-redemption", {"productId": pid})
        await pg.locator(".lx-tab[data-k=levels]").click(); await pg.locator(".lx-tab[data-k=shop]").click(); await pg.wait_for_timeout(500)
        await pg.get_by_role("button", name="تم التسليم").click(); await pg.wait_for_timeout(600)
        assert await pg.locator(".lx-red").count() == 0
        await pg.locator(".lx-seg-b[data-f=all]").click()
        assert await pg.locator(".lx-red").count() == 2
        # delete the product
        await pg.locator(".lx-prod").first.get_by_role("button", name="حذف").click(); await pg.wait_for_timeout(500)
        assert await pg.locator(".lx-prod").count() == 0
        await b.close()
asyncio.run(shop())
assert not errs, errs
print("ok: admin reward products flow")
