"""Rewards page, phone viewport. Needs: node tests/rewards-mock-server.js (PORT=4455).
Checks: render, tier + ladder + activity, redeem sheet (limits, retry-safe id, success), RTL/LTR, offline cache, no console errors."""
import json, os, sys
from playwright.sync_api import sync_playwright

BASE = os.environ.get("BASE", "http://127.0.0.1:4455")
OUT = os.environ.get("OUT", "/tmp")
fails = []
def check(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: fails.append(m)

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True, locale="ar")
    ctx.add_init_script("localStorage.setItem('siymon_customer_token_v1','tok-test-1234567890');")
    pg = ctx.new_page()
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.on("console", lambda m: errs.append(m.text) if m.type == "error" and "favicon" not in m.text and "404" not in m.text else None)
    pg.goto(BASE + "/rewards/"); pg.wait_for_selector("#rPass .r-tier")
    pg.wait_for_timeout(1300)
    check(pg.inner_text("#rPass .r-tier").strip() != "", "tier badge rendered")
    n = int(pg.inner_text("#rPtsNum").replace(" ", ""))
    check(n == 665, f"available points counted up to 665 (got {n})")
    check(pg.locator(".r-rung").count() >= 3, "ladder has rungs")
    check(pg.locator("#rActivity .r-row").count() >= 4, "activity rows")
    check(pg.evaluate("document.documentElement.scrollWidth <= innerWidth"), "no horizontal overflow")
    pg.screenshot(path=f"{OUT}/rw-1-home-ar.png")
    pg.evaluate("window.scrollTo(0, 700)"); pg.wait_for_timeout(300)
    pg.screenshot(path=f"{OUT}/rw-2-scrolled-ar.png", full_page=False)
    pg.evaluate("window.scrollTo(0, 0)")
    # filters
    pg.click("#rActivity .r-seg [data-f=out]"); check(pg.locator("#rActivity .r-row").count() == 0 and "r-empty" in pg.inner_html("#rActivity"), "filter 'used' empty before redeeming")
    pg.click("#rActivity .r-seg [data-f=all]")
    # redeem sheet
    pg.click("#rBtnConvert"); pg.wait_for_selector("#rGo"); pg.wait_for_timeout(500)
    check(pg.input_value("#rPts") == "100", "redeem starts at the minimum (100)")
    pg.screenshot(path=f"{OUT}/rw-3-redeem-ar.png")
    pg.click("#rChips .r-chip:last-child"); check(pg.input_value("#rPts") == "665", "max chip = all available")
    pg.fill("#rPts", "50"); pg.dispatch_event("#rPts", "input")
    check(pg.is_disabled("#rGo") and pg.inner_text("#rErr").strip() != "", "below minimum disables confirm and explains")
    pg.fill("#rPts", "300"); pg.dispatch_event("#rPts", "input")
    check("3.00" in pg.inner_text("#rWorthBig"), "300 pts previews 3.00 MAD")
    pg.click("#rGo"); pg.wait_for_selector(".r-check"); pg.wait_for_timeout(700)
    check("3.00" in pg.inner_text(".r-done .amt"), "success shows +3.00")
    pg.screenshot(path=f"{OUT}/rw-4-done-ar.png")
    pg.click("#rRedeemBody [data-close]"); pg.wait_for_timeout(600)
    check(pg.locator("#rRedeem").is_hidden(), "sheet closes")
    pg.wait_for_timeout(1000)
    n2 = int(pg.inner_text("#rPtsNum").replace(" ", ""))
    check(n2 == 365, f"balance refreshed to 365 (got {n2})")
    check(pg.locator("#rActivity .r-row.in").count() >= 4 and pg.locator("#rActivity .r-row", has_text="300").count() >= 1, "redeem appears in activity")
    # how sheet
    pg.click("#rBtnHow"); pg.wait_for_selector(".r-tiers"); pg.wait_for_timeout(500)
    pg.screenshot(path=f"{OUT}/rw-5-how-ar.png")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(600)
    # English / LTR
    pg.click("[data-lang=en]"); pg.wait_for_timeout(900)
    check(pg.evaluate("document.documentElement.dir") == "ltr", "LTR in English")
    check(pg.evaluate("document.documentElement.scrollWidth <= innerWidth"), "no overflow in English")
    pg.screenshot(path=f"{OUT}/rw-6-home-en.png")
    # network lost: the cached numbers stay on screen with a banner (cold start from cache too)
    pg2 = ctx.new_page()
    pg2.route("**/api/**", lambda r: r.abort())
    pg2.goto(BASE + "/rewards/"); pg2.wait_for_selector("#rPass .r-tier", timeout=8000); pg2.wait_for_timeout(800)
    check(not pg2.locator("#rOffline").is_hidden(), "offline banner shown with cached data (cold start)")
    check(int(pg2.inner_text("#rPtsNum").replace(" ", "")) == 365, "cached balance shown while offline")
    pg2.screenshot(path=f"{OUT}/rw-7-offline-en.png")
    check(not errs, "no console/page errors: " + "; ".join(errs[:3]))
    b.close()
print("\nFAILED: %d" % len(fails)); sys.exit(1 if fails else 0)
