"use strict";
const test = require("node:test");
const assert = require("node:assert");
const ai = require("../lib/app-icons");

test("yearly ranges incl. wrap over New Year", () => {
  assert.ok(ai.inRange("03-15", "03-01", "04-10"));
  assert.ok(!ai.inRange("05-01", "03-01", "04-10"));
  assert.ok(ai.inRange("12-25", "12-20", "01-05"));
  assert.ok(ai.inRange("01-02", "12-20", "01-05"));
  assert.ok(!ai.inRange("06-01", "12-20", "01-05"));
  assert.ok(!ai.inRange("06-01", "", ""));
});
test("resolveActive: manual / auto / default", () => {
  const cfg = ai.normalize({ customer: { mode: "manual", activeId: "ramadan1", items: [{ id: "ramadan1", name: "Ramadan", from: "03-01", to: "03-30" }, { id: "winter1", name: "Winter", from: "12-20", to: "01-05" }] } }).customer;
  assert.equal(ai.resolveActive(cfg).id, "ramadan1");
  cfg.mode = "auto";
  assert.equal(ai.resolveActive(cfg, new Date("2026-03-10T12:00:00Z")).id, "ramadan1");
  assert.equal(ai.resolveActive(cfg, new Date("2026-12-31T12:00:00Z")).id, "winter1");
  assert.equal(ai.resolveActive(cfg, new Date("2026-07-10T12:00:00Z")), null);
  cfg.mode = "manual"; cfg.activeId = "default";
  assert.equal(ai.resolveActive(cfg), null);
});
test("normalize drops bad ids and unknown activeId", () => {
  const n = ai.normalize({ driver: { activeId: "ghost", items: [{ id: "../x" }, { id: "good1234" }] } });
  assert.equal(n.driver.items.length, 1);
  assert.equal(n.driver.activeId, "default");
  assert.equal(n.customer.mode, "manual");
  assert.equal(ai.cleanMd("13-01").ok, false);
  assert.equal(ai.cleanMd("").value, "");
});
