"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const P = require("../lib/payment-methods");
const pay = require("../lib/payments");
const OT = require("../lib/order-transfer");
const promo = require("../lib/promo");
const stores = require("../lib/stores");
const topups = require("../lib/topups");

const REAL = { holderName: "SIYMON SARL", rib: "230000000000000000000001" };
const withAccount = (rec, ctxs, extra = {}) =>
  P.applyUpdate(rec, { enabled: true, contexts: ctxs, details: { default: REAL }, ...extra }).value;

function registry() {
  // CIH: orders + both wallets; Cash Plus: wallets only; COD: orders only
  let l = P.withDefaults([]);
  l = l.map((m) => {
    if (m.id === "cih") return withAccount(m, { checkout: true, customerTopup: true, driverTopup: true });
    if (m.id === "cashplus") return withAccount(m, { checkout: false, customerTopup: true, driverTopup: true });
    return m;
  });
  return l;
}
const byId = (l, id) => l.find((m) => m.id === id);

/* ---------------- registry: three independent uses ---------------- */

test("a manual transfer is OFF for orders until the supervisor opts in (also for legacy stored records)", () => {
  const fresh = byId(P.withDefaults([]), "cih");
  assert.equal(fresh.contexts.checkout, false);
  // legacy record stored before this feature: checkout=true was only a meaningless default
  const legacy = { ...fresh, enabled: true, contexts: { checkout: true, customerTopup: true, driverTopup: true }, checkoutOptIn: undefined, details: { default: REAL, customer: null, driver: null } };
  delete legacy.checkoutOptIn;
  const loaded = byId(P.withDefaults([legacy]), "cih");
  assert.equal(loaded.contexts.checkout, false, "must not silently become a way to pay orders");
  assert.equal(P.availability(loaded, "checkout").available, false);
  assert.equal(P.availability(loaded, "customerTopup").available, true, "top-ups keep working");
});

test("CIH on for orders + both wallets, Cash Plus wallets only, COD orders only, wallet-only kinds never at checkout", () => {
  const l = registry();
  assert.equal(P.availability(byId(l, "cih"), "checkout").available, true);
  assert.equal(P.availability(byId(l, "cih"), "customerTopup").available, true);
  assert.equal(P.availability(byId(l, "cih"), "driverTopup").available, true);
  assert.equal(P.availability(byId(l, "cashplus"), "checkout").available, false);
  assert.equal(P.availability(byId(l, "cashplus"), "checkout").reason, "context_off");
  assert.equal(P.availability(byId(l, "cashplus"), "driverTopup").available, true);
  assert.equal(P.availability(byId(l, "cod"), "checkout").available, true);
  assert.equal(P.availability(byId(l, "cod"), "customerTopup").available, false);
  // server decision used by POST /api/orders
  assert.deepEqual(pay.resolveOrderPayment("cih", l), { ok: true, method: "cih", kind: "transfer" });
  assert.equal(pay.resolveOrderPayment("cashplus", l).ok, false);
  assert.equal(pay.resolveOrderPayment("stripe", l).ok, false);
});

test("a transfer cannot be offered for orders without a real receiving account", () => {
  const rec = byId(P.withDefaults([]), "barid");
  const r = P.applyUpdate(rec, { enabled: true, contexts: { checkout: true } });
  assert.equal(r.ok, false);
  assert.equal(r.code, "ACCOUNT_REQUIRED");
  assert.equal(r.context, "checkout");
});

test("ONE central record, but the receiving account may differ per use (order account overrides default)", () => {
  let rec = withAccount(byId(P.withDefaults([]), "cih"), { checkout: true, customerTopup: true });
  const ORDER_ACC = { holderName: "SIYMON ORDERS", rib: "230000000000000000000002" };
  rec = P.applyUpdate(rec, { details: { order: ORDER_ACC } }).value;
  assert.equal(P.detailsFor(rec, P.audienceOf("checkout")).holderName, "SIYMON ORDERS");
  assert.equal(P.detailsFor(rec, P.audienceOf("customerTopup")).holderName, "SIYMON SARL");
  assert.equal(P.detailsFor(rec, P.audienceOf("driverTopup")).holderName, "SIYMON SARL");
  // account shown at checkout is the order account
  const v = P.publicView(rec, "checkout", { includeAccount: true });
  assert.equal(v.account.holderName, "SIYMON ORDERS");
  const v2 = P.publicView(rec, "checkout", {});
  assert.equal(v2.account, undefined, "account hidden unless asked");
});

test("disabling a method switches it off for every use at once; per-use flags are independent", () => {
  let l = registry();
  l = l.map((m) => (m.id === "cih" ? P.applyUpdate(m, { contexts: { checkout: false } }).value : m));
  assert.equal(P.availability(byId(l, "cih"), "checkout").available, false);
  assert.equal(P.availability(byId(l, "cih"), "customerTopup").available, true);
  l = l.map((m) => (m.id === "cih" ? P.applyUpdate(m, { enabled: false }).value : m));
  for (const c of P.CONTEXTS) assert.equal(P.availability(byId(l, "cih"), c).available, false);
});

/* ---------------- order transfer lifecycle ---------------- */

const T0 = new Date("2026-10-30T10:00:00Z");
function newOrder(over = {}) {
  const order = {
    id: "o1", customerId: "c1", status: "new", subtotal: 100, deliveryFee: 15, total: 115, currency: "MAD",
    customer: { name: "A", phone: "0600000000" },
    payment: { method: "cih", walletAmount: 0, amountDueOnDelivery: 115, status: "transfer_unpaid", reference: null },
    ...over,
  };
  order.payment.transfer = OT.initial({ methodId: "cih", amount: OT.amountToTransfer({ subtotal: 100, discount: 0 }), at: T0.toISOString(), autoAcceptOnApproval: over.auto === true });
  delete order.auto;
  return order;
}
const cih = () => byId(registry(), "cih");
const ctx = (order, extra = {}) => ({ order, customerId: "c1", reference: "CIH-2026-0001", hasReceipt: true, receiptHash: "h1", method: cih(), orders: [order], topupList: [], now: T0, ...extra });

test("amount is computed from the goods (subtotal - discount), never from the client; delivery fee stays on delivery", () => {
  assert.equal(OT.amountToTransfer({ subtotal: 100, discount: 0 }), 100);
  assert.equal(OT.amountToTransfer({ subtotal: 100, discount: 30 }), 70);
  assert.equal(OT.amountToTransfer({ subtotal: 20, discount: 50 }), 0);
});

test("uploading a receipt only makes the order PAYMENT_PENDING, never paid", () => {
  const o = newOrder();
  assert.equal(OT.statusOf(o), "UNPAID");
  assert.equal(OT.blocksProcessing(o), true);
  const v = OT.validateProof(ctx(o));
  assert.equal(v.ok, true);
  OT.submit(o, v.attempt, { receiptFile: "order_o1_1.jpg" });
  assert.equal(OT.statusOf(o), "PAYMENT_PENDING");
  assert.equal(OT.blocksProcessing(o), true, "still blocked");
  assert.equal(o.payment.transferAmount, undefined, "nothing credited");
  assert.equal(o.payment.amountDueOnDelivery, 115, "driver still collects everything");
  assert.equal(promo.goodsDue(o), 100);
});

test("only a supervisor approval makes it paid; then goods are prepaid and only the delivery fee is due", () => {
  const o = newOrder();
  OT.submit(o, OT.validateProof(ctx(o)).attempt, { receiptFile: "f.jpg" });
  const r = OT.decide(o, { to: "approved", by: "adm1", confirmedReference: "BANK-777", now: T0 });
  assert.equal(r.ok, true);
  assert.equal(OT.statusOf(o), "PAYMENT_APPROVED");
  assert.equal(OT.blocksProcessing(o), false);
  assert.equal(o.payment.transferAmount, 100);
  assert.equal(o.payment.amountDueOnDelivery, 15);
  assert.equal(promo.goodsDue(o), 0, "driver is not charged for goods the platform already holds");
  assert.equal(o.status, "new", "a restaurant order still waits for the normal admin acceptance");
  // second decision refused
  assert.equal(OT.decide(o, { to: "approved", by: "adm1" }).code, "NOT_PENDING");
  assert.equal(OT.decide(o, { to: "rejected", by: "adm1", reason: "no" }).code, "NOT_PENDING");
});

test("direct-flow stores (non restaurant) are auto-accepted only AFTER approval", () => {
  const o = newOrder({ auto: true });
  assert.equal(stores.initialOrderStatus({ flow: "direct" }), "admin_accepted");
  assert.equal(o.status, "new", "created waiting");
  OT.submit(o, OT.validateProof(ctx(o)).attempt);
  const r = OT.decide(o, { to: "approved", by: "adm1", now: T0 });
  assert.equal(r.autoAccepted, true);
  assert.equal(o.status, "admin_accepted");
  assert.ok(o.adminAcceptedAt);
  assert.equal(o.events[o.events.length - 1].to, "admin_accepted");
});

test("rejection needs a reason, keeps the order blocked and lets the customer try again with NEW proof", () => {
  const o = newOrder();
  OT.submit(o, OT.validateProof(ctx(o)).attempt, { receiptFile: "a.jpg" });
  assert.equal(OT.decide(o, { to: "rejected", by: "adm1" }).code, "REASON_REQUIRED");
  assert.equal(OT.decide(o, { to: "rejected", by: "adm1", reason: "amount did not arrive" }).ok, true);
  assert.equal(OT.statusOf(o), "PAYMENT_REJECTED");
  assert.equal(OT.blocksProcessing(o), true);
  assert.equal(OT.customerView(o).canSubmit, true);
  assert.equal(OT.customerView(o).decisionNote, "amount did not arrive");
  // same reference again is refused (it was already submitted), a new one is accepted
  assert.equal(OT.validateProof(ctx(o)).code, "DUPLICATE_REFERENCE");
  const again = OT.validateProof(ctx(o, { reference: "CIH-2026-0002", receiptHash: "h2" }));
  assert.equal(again.ok, true);
  OT.submit(o, again.attempt, { receiptFile: "b.jpg" });
  assert.equal(OT.statusOf(o), "PAYMENT_PENDING");
  assert.equal(o.payment.transfer.attempts.length, 2);
});

test("the same reference / the same receipt image cannot back two orders (or an order and a top-up)", () => {
  const a = newOrder();
  OT.submit(a, OT.validateProof(ctx(a)).attempt);
  const b = newOrder({ id: "o2" });
  // reference compared ignoring case/punctuation
  const dupRef = OT.validateProof({ ...ctx(b), reference: "cih 2026 0001", receiptHash: "other", orders: [a, b] });
  assert.equal(dupRef.code, "DUPLICATE_REFERENCE");
  const dupImg = OT.validateProof({ ...ctx(b), reference: "ZZZ-9999", receiptHash: "h1", orders: [a, b] });
  assert.equal(dupImg.code, "DUPLICATE_RECEIPT");
  // top-ups share the namespace
  const asTopup = [{ id: "t1", status: "pending", reference: "TOP-5555", refKey: topups.refKey("TOP-5555"), receiptHash: "h-top" }];
  assert.equal(OT.validateProof({ ...ctx(b), reference: "top5555", orders: [b], topupList: asTopup }).code, "DUPLICATE_REFERENCE");
  assert.equal(OT.validateProof({ ...ctx(b), reference: "NEW-1234", receiptHash: "h-top", orders: [b], topupList: asTopup }).code, "DUPLICATE_RECEIPT");
  // and the other direction: a top-up with an order's reference is refused by the top-up rules
  const methods = registry();
  const r = topups.validateRequest({ walletType: "customer", ownerId: "c9", methodId: "cih", amount: 100, reference: "CIH-2026-0001", hasReceipt: true, methods, topups: [], orders: [a] });
  assert.equal(r.code, "DUPLICATE_REFERENCE");
});

test("ownership, lifecycle and input checks", () => {
  const o = newOrder();
  assert.equal(OT.validateProof({ ...ctx(o), customerId: "someone-else" }).code, "NOT_FOUND");
  assert.equal(OT.validateProof({ ...ctx(o), reference: "ab" }).code, "REFERENCE_REQUIRED");
  assert.equal(OT.validateProof({ ...ctx(o), hasReceipt: false }).code, "RECEIPT_REQUIRED");
  const noTransfer = { id: "o9", customerId: "c1", status: "new", payment: {} };
  assert.equal(OT.validateProof({ ...ctx(noTransfer), order: noTransfer }).code, "NOT_A_TRANSFER_ORDER");
  const canceled = newOrder({ status: "canceled" });
  assert.equal(OT.validateProof(ctx(canceled)).code, "ORDER_CLOSED");
  assert.equal(OT.decide(canceled, { to: "approved", by: "a" }).code, "ORDER_CLOSED");
});

test("double tap while pending returns the same pending proof; a different proof is refused", () => {
  const o = newOrder();
  OT.submit(o, OT.validateProof(ctx(o)).attempt);
  const same = OT.validateProof({ ...ctx(o), orders: [] });
  assert.equal(same.ok, true);
  assert.equal(same.duplicate, true);
  assert.equal(OT.validateProof({ ...ctx(o), reference: "OTHER-1234", receiptHash: "x" }).code, "ALREADY_PENDING");
});

test("approved order refuses new proof; attempts are capped", () => {
  const o = newOrder();
  OT.submit(o, OT.validateProof(ctx(o)).attempt);
  OT.decide(o, { to: "approved", by: "a" });
  assert.equal(OT.validateProof(ctx(o, { reference: "NEWREF-1" })).code, "ALREADY_APPROVED");
  const p = newOrder();
  for (let i = 0; i < OT.MAX_ATTEMPTS; i++) {
    const v = OT.validateProof(ctx(p, { reference: `REF-${1000 + i}`, receiptHash: `hh${i}` }));
    assert.equal(v.ok, true, "attempt " + i);
    OT.submit(p, v.attempt);
    OT.decide(p, { to: "rejected", by: "a", reason: "not found" });
  }
  assert.equal(OT.validateProof(ctx(p, { reference: "REF-9999", receiptHash: "zz" })).code, "TOO_MANY_ATTEMPTS");
  assert.equal(OT.customerView(p).canSubmit, false);
});

test("canceled orders that may hold the customer's money are flagged for a manual refund, once", () => {
  const unpaid = newOrder({ status: "canceled" });
  assert.equal(OT.onCanceled(unpaid).changed, false, "nothing was sent");
  const approved = newOrder();
  OT.submit(approved, OT.validateProof(ctx(approved)).attempt);
  OT.decide(approved, { to: "approved", by: "a" });
  approved.status = "canceled";
  assert.equal(OT.onCanceled(approved, T0).changed, true);
  assert.equal(approved.payment.transfer.refund.state, "required");
  assert.equal(approved.payment.transfer.refund.amount, 100);
  assert.equal(OT.onCanceled(approved, T0).changed, false, "idempotent");
  assert.equal(OT.markRefunded(approved, { by: "a", reference: "x" }).code, "REFERENCE_REQUIRED");
  assert.equal(OT.markRefunded(approved, { by: "a", reference: "VIR-001" }).ok, true);
  assert.equal(OT.markRefunded(approved, { by: "a", reference: "VIR-001" }).duplicate, true);
  const pending = newOrder();
  OT.submit(pending, OT.validateProof(ctx(pending)).attempt);
  pending.status = "canceled";
  assert.equal(OT.onCanceled(pending).changed, true);
  assert.equal(pending.payment.transfer.refund.reason, "claimed_then_canceled");
});

test("views never leak review internals to the customer, drivers or stores", () => {
  const o = newOrder();
  OT.submit(o, OT.validateProof(ctx(o)).attempt, { receiptFile: "secret_name.jpg" });
  OT.decide(o, { to: "approved", by: "adm-77", confirmedReference: "BANK" });
  const cv = JSON.stringify(OT.customerView(o));
  for (const bad of ["secret_name", "adm-77", "receiptHash", "h1", "refKey"]) assert.ok(!cv.includes(bad), bad);
  const pub = JSON.stringify(OT.publicOrder(o).payment);
  for (const bad of ["secret_name", "adm-77", "receiptHash", "attempts", "refKey", "CIH-2026"]) assert.ok(!pub.includes(bad), bad);
  const st = JSON.stringify(stores.orderForStore(o, "owner").payment);
  for (const bad of ["secret_name", "adm-77", "receiptHash", "attempts", "CIH-2026"]) assert.ok(!st.includes(bad), bad);
  assert.equal(JSON.parse(st).transfer.status, "PAYMENT_APPROVED");
  assert.equal(o.payment.transfer.attempts.length, 1, "originals untouched");
});

test("receiptHashOf: stable for the same image, different otherwise, null for non data URLs", () => {
  const a = "data:image/png;base64,AAAA";
  assert.equal(OT.receiptHashOf(a), OT.receiptHashOf("data:image/png;base64,AA AA"));
  assert.notEqual(OT.receiptHashOf(a), OT.receiptHashOf("data:image/png;base64,AAAB"));
  assert.equal(OT.receiptHashOf("nope"), null);
});

/* ---------------- server wiring (static): no fake paths ---------------- */

test("server: transfer orders wait unpaid, are gated before acceptance and the only approval route is the admin PATCH", () => {
  const fs = require("fs");
  const src = fs.readFileSync(require("path").join(__dirname, "..", "server.js"), "utf8");
  assert.match(src, /const orderStatus = isTransfer \? "new" : storeAutoStatus;/);
  assert.match(src, /orderTransferLib\.blocksProcessing\(order\)/);
  assert.match(src, /code: "PAYMENT_NOT_APPROVED"/);
  assert.match(src, /app\.patch\("\/api\/admin\/order-payments\/:id"/);
  // approval is decided ONLY through decide(); the customer route can only call submit()
  assert.equal((src.match(/orderTransferLib\.decide\(/g) || []).length, 1);
  assert.equal((src.match(/orderTransferLib\.submit\(/g) || []).length, 1);
  const proofRoute = src.slice(src.indexOf('app.post("/api/customer/orders/:id/payment-proof"'), src.indexOf("// Rating the store (POST"));
  assert.ok(!/PAYMENT_APPROVED/.test(proofRoute.replace(/PAYMENT_PENDING only[^\n]*/, "")), "customer route cannot approve");
  // guests cannot pay by transfer, mixing with the wallet is refused
  assert.match(src, /TRANSFER_LOGIN_REQUIRED/);
  assert.match(src, /MIXED_PAYMENT_NOT_SUPPORTED/);
});

test("amountToTransfer includes the delivery fee", () => {
  assert.equal(OT.amountToTransfer({ subtotal: 100, discount: 30, deliveryFee: 15 }), 85);
  assert.equal(OT.amountToTransfer({ subtotal: 20, discount: 50, deliveryFee: 10 }), 10);
});
