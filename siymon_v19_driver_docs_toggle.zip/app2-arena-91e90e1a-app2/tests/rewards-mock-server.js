"use strict";
/* Static server + a mock of GET /api/customer/wallet and the redeem route, for tests/browser-rewards.py.
   The loyalty block is built with the REAL lib/loyalty + lib/loyalty-app so the page is tested against real shapes. */
const http = require("http");
const fs = require("fs");
const path = require("path");
const loyalty = require("../lib/loyalty");
const loyaltyApp = require("../lib/loyalty-app");

const PUBLIC = path.join(__dirname, "..", "public");
const PORT = Number(process.env.PORT || 4455);
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".webmanifest": "application/manifest+json" };

const settings = loyalty.settingsOf({
  enabled: true,
  earn: { enabled: true, unitAmount: 10, pointsPerUnit: 1 },
  redeem: { enabled: true, minPoints: 100, pointsPerCurrencyUnit: 100 },
  expiry: { enabled: true, days: 365 },
  campaigns: [{ id: "c1", name: "Double points weekend", points: 50, note: "Order on Friday or Saturday", active: true }],
});
const account = { customerId: "C1", entries: [] };
const iso = (d) => new Date(Date.now() - d * 86400000).toISOString();
const seed = process.env.SEED || "mid";
const plan = seed === "empty" ? [] : seed === "top" ? [[1, 900], [4, 800], [20, 600]] : [[0.2, 120], [3, 210], [12, 95], [40, 180], [330, 60]];
plan.forEach(([d, p], i) => loyalty.credit(account, { ref: "loyalty:earn:O" + i, kind: "earn", points: p, orderId: "O" + i, at: iso(d), expiresDays: 365, holdDays: i === 0 && seed === "pend" ? 2 : 0 }));
let wallet = 12.5;
const redeemSeen = new Map();

function view() {
  const now = new Date().toISOString();
  const bal = loyalty.balances(account, now);
  const per = settings.redeem.pointsPerCurrencyUnit;
  return {
    ok: true, currency: "MAD", walletBalance: wallet, available: wallet,
    loyalty: {
      program: loyalty.publicView(settings, "ar"), balances: bal, valueMAD: loyalty.floor2(bal.available / per),
      canRedeem: bal.available >= settings.redeem.minPoints, minPoints: settings.redeem.minPoints, pointsPerCurrencyUnit: per,
      maxPointsPerTx: settings.redeem.maxPointsPerTx, app: loyaltyApp.appView(account, settings, bal, now), entries: loyalty.statement(account, { limit: 100 }),
    },
  };
}
const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  if (url.pathname === "/api/customer/wallet") {
    if (process.env.FAIL === "1") { res.writeHead(500); return res.end("{}"); }
    res.writeHead(200, { "Content-Type": "application/json" }); return res.end(JSON.stringify(view()));
  }
  if (url.pathname === "/api/customer/wallet/loyalty/redeem" && req.method === "POST") {
    let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => {
      const body = JSON.parse(b || "{}"), id = body.requestId;
      if (redeemSeen.has(id)) { res.writeHead(200, { "Content-Type": "application/json" }); return res.end(JSON.stringify({ ...redeemSeen.get(id), duplicate: true })); }
      const q = loyalty.redeemQuote(account, body.points, settings, { now: new Date().toISOString() });
      if (!q.ok) { res.writeHead(q.status, { "Content-Type": "application/json" }); return res.end(JSON.stringify({ ok: false, code: q.code, error: q.error, available: q.available })); }
      loyalty.debit(account, { ref: loyalty.redeemRef(id), kind: "redeem", points: q.points, at: new Date().toISOString() });
      wallet = Math.round((wallet + q.amount) * 100) / 100;
      const out = { ok: true, points: q.points, amount: q.amount, walletBalance: wallet, currency: "MAD" };
      redeemSeen.set(id, out); res.writeHead(200, { "Content-Type": "application/json" }); res.end(JSON.stringify(out));
    });
    return;
  }
  let rel = decodeURIComponent(url.pathname);
  if (rel.endsWith("/")) rel += "index.html";
  const file = path.join(PUBLIC, rel);
  if (!file.startsWith(PUBLIC) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end("nf"); }
  res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
});
server.listen(PORT, () => console.log("rewards mock on " + PORT));
