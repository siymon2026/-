"""Every image a store or an admin uploads is converted to WebP (and shrunk) in the browser before it is sent.
Run: PORT=4031 node tests/loyalty-admin-mock-server.js &  then  python3 tests/browser-webp-upload.py"""
import asyncio, base64, json, urllib.request
from playwright.async_api import async_playwright
BASE = "http://127.0.0.1:4031"
errs = []
MAKE = """async (dims) => {            // a real PNG with a transparent corner, dims = [w, h]
  const c = document.createElement('canvas'); c.width = dims[0]; c.height = dims[1]; const x = c.getContext('2d');
  x.fillStyle = '#c33'; x.fillRect(0, 0, dims[0], dims[1]); x.clearRect(0, 0, 40, 40);
  const blob = await new Promise(r => c.toBlob(r, 'image/png'));
  const buf = new Uint8Array(await blob.arrayBuffer()); let s = ''; for (const b of buf) s += String.fromCharCode(b); return btoa(s); }"""
CONVERT = """async (b64) => {
  const bytes = Uint8Array.from(atob(b64), ch => ch.charCodeAt(0));
  const f = new File([bytes], 'photo.png', { type: 'image/png' });
  const url = await fileToDataUrl(f);
  const img = new Image(); await new Promise((ok, no) => { img.onload = ok; img.onerror = no; img.src = url; });
  return { head: url.slice(0, 22), w: img.naturalWidth, h: img.naturalHeight, bytes: url.length, orig: b64.length }; }"""
async def ev(pg, js, arg=None):
    """evaluate, retrying when the page reloads itself once (service worker / perms refresh)"""
    for i in range(4):
        try:
            await pg.wait_for_load_state("load")
            return await (pg.evaluate(js, arg) if arg is not None else pg.evaluate(js))
        except Exception as e:
            if "context was destroyed" not in str(e) or i == 3: raise
            await pg.wait_for_timeout(800)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        # ---------------- admin: the shared converter used by banners / meals / stores / notifications ----------------
        ctx = await b.new_context(viewport={"width": 1280, "height": 900})
        await ctx.add_init_script("localStorage.setItem('siymon_admin_token_v2','tok-system')")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("admin: " + str(e)))
        await pg.goto(BASE + "/admin/"); await pg.wait_for_timeout(1200)
        big = await ev(pg, MAKE, [4000, 3000])
        r = await ev(pg, CONVERT, big)
        assert r["head"].startswith("data:image/webp"), r
        assert max(r["w"], r["h"]) == 1600 and r["w"] == 1600 and r["h"] == 1200, r   # shrunk, ratio kept
        assert r["bytes"] < r["orig"], r                                             # and smaller than the original PNG
        small = await ev(pg, MAKE, [300, 200])
        r2 = await ev(pg, CONVERT, small)
        assert r2["head"].startswith("data:image/webp") and (r2["w"], r2["h"]) == (300, 200), r2   # never enlarged
        # ---------------- admin UI: reward product photo goes out as WebP ----------------
        await pg.locator("#sbLoyalty").click(); await pg.wait_for_selector(".lx-hero")
        await pg.locator(".lx-tab[data-k=shop]").click(); await pg.wait_for_selector(".lx-shop")
        await pg.get_by_role("button", name="+ منتج جديد").click()
        await pg.set_input_files(".lx-prodform input[type=file]", files=[{"name": "p.png", "mimeType": "image/png", "buffer": base64.b64decode(small)}])
        await pg.wait_for_selector(".lx-prodform .lx-img img", timeout=5000)
        up = json.loads(urllib.request.urlopen(BASE + "/__last-upload").read())
        assert up["head"].startswith("data:image/webp"), up
        await ctx.close()
        # ---------------- the store portal ----------------
        ctx = await b.new_context(viewport={"width": 1280, "height": 800})
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("restaurant: " + str(e)))
        await pg.goto(BASE + "/restaurant/#admintoken=tok-rest"); await pg.wait_for_selector("#restName", timeout=8000)
        r3 = await ev(pg, CONVERT, big)
        assert r3["head"].startswith("data:image/webp") and r3["w"] == 1600, r3
        await ctx.close()
        # ---------------- an undecodable file never breaks the upload (original is sent as before) ----------------
        ctx = await b.new_context(); await ctx.add_init_script("localStorage.setItem('siymon_admin_token_v2','tok-system')")
        pg = await ctx.new_page(); await pg.goto(BASE + "/admin/"); await pg.wait_for_timeout(1000)
        out = await ev(pg, """async () => { const f = new File([new Uint8Array([1,2,3,4])], 'x.png', {type:'image/png'}); return (await fileToDataUrl(f)).slice(0, 15); }""")
        assert out.startswith("data:image/png") or out.startswith("data:applicatio"), out
        await b.close()
asyncio.run(main())
assert not errs, errs
print("ok: store/admin images are converted to WebP before upload")
