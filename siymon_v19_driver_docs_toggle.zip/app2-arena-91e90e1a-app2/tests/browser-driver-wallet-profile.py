"""Driver: the wallet lives INSIDE the profile (no wallet tab in the bottom bar), on phone sizes.
Run: python3 tests/browser-driver-wallet-profile.py   (starts tests/offline-driver-server.js on 4032)"""
import subprocess, time
from playwright.sync_api import sync_playwright
PORT = "4032"; B = "http://localhost:" + PORT
srv = subprocess.Popen(["node", "tests/offline-driver-server.js"], env={"PORT": PORT, "PATH": "/usr/bin:/usr/local/bin"}); time.sleep(1.2)
ok = True; errs = []
def check(n, c, x=""):
    global ok; print(("PASS " if c else "FAIL ") + n + ("" if c else " -> " + str(x))); ok = ok and bool(c)
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        for w, h in ((360, 800), (375, 812), (390, 844), (412, 915)):
            ctx = b.new_context(viewport={"width": w, "height": h}, locale="ar", service_workers="block")
            ctx.add_init_script("localStorage.setItem('SIYMON_DRIVER_TOKEN','dtok'); localStorage.setItem('SIYMON_DRIVER_SOUND_PROMPTED','1')")
            pg = ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
            pg.goto(B + "/driver/"); pg.wait_for_timeout(1800)
            t = f"[{w}]"
            check(t + " no wallet tab in the bottom bar", pg.locator(".bottom-nav .nav-item[data-page=wallet]").count() == 0)
            check(t + " 4 tabs only", pg.locator(".bottom-nav .nav-item").count() == 4, pg.locator(".bottom-nav .nav-item").count())
            pg.click(".nav-item[data-page=profile]"); pg.wait_for_timeout(500)
            link = pg.locator("#profileWalletLink")
            check(t + " profile has the 'محفظتي' entry with the balance", link.is_visible() and "محفظتي" in link.inner_text() and "100" in link.inner_text(), link.inner_text())
            box = link.bounding_box()
            check(t + " entry is a big touch target inside the screen", box["height"] >= 44 and box["x"] >= 0 and box["x"] + box["width"] <= w, box)
            link.click(); pg.wait_for_timeout(600)
            check(t + " wallet page opens (balance + history sections)", pg.locator("#pageWallet").is_visible() and pg.locator("#walletBalance").is_visible())
            check(t + " profile tab stays highlighted while in the wallet", pg.locator(".nav-item[data-page=profile].active").count() == 1)
            over = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            check(t + " no sideways scroll", over <= 0, over)
            pg.click("#walletBackBtn"); pg.wait_for_timeout(400)
            check(t + " back returns to the profile", pg.locator("#pageProfile").is_visible() and not pg.locator("#pageWallet").is_visible())
            ctx.close()
        b.close()
finally:
    srv.terminate()
bad = [e for e in errs if "404" not in e]
print("JS ERRORS:", bad[:5]); print("ALL PASS" if ok and not bad else "SOME FAILED")
