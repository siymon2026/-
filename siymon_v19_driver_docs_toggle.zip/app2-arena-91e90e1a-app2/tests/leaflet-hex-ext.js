/* Extension of tests/leaflet-stub.js for the hexagon layer: layer groups that can remove layers, map.hasLayer/getZoom/removeControl,
   L.control, polygon.setStyle/popups. Popups are rendered into #stub-popup so the test can read what an admin would see. Tests only. */
(function () {
  var L = window.L, polys = [], markers = [];
  var GP = Object.getPrototypeOf(L.layerGroup());
  GP.removeLayer = function (l) { var k = (this._items || []).indexOf(l); if (k >= 0) this._items.splice(k, 1); return this; };
  var origMap = L.map;
  L.map = function (id) {
    var m = origMap(id);
    m._z = 15; m._ctl = [];
    m.hasLayer = function (l) { return (m._items || []).indexOf(l) >= 0; };
    m.getZoom = function () { return m._z; };
    m.removeLayer = function (l) { var k = (m._items || []).indexOf(l); if (k >= 0) m._items.splice(k, 1); };
    m.removeControl = function (c) { if (c._el && c._el.parentNode) c._el.parentNode.removeChild(c._el); };
    return m;
  };
  L.control = function (o) {
    var c = { options: o, addTo: function (m) { c._el = c.onAdd(m); c._el.setAttribute("data-stub-ctl", "1"); (m.el || document.body).appendChild(c._el); return c; } };
    return c;
  };
  if (!L.DomEvent) L.DomEvent = {};
  L.DomEvent.disableClickPropagation = L.DomEvent.disableClickPropagation || function () {};
  L.DomEvent.disableScrollPropagation = L.DomEvent.disableScrollPropagation || function () {};
  var origPoly = L.polygon;
  L.polygon = function (p, o) {
    var pg = origPoly(p, o);
    pg.setStyle = function (s) { pg.options = s; return pg; };
    pg.bindPopup = function (content) { pg._popup = content; return pg; };
    pg.unbindPopup = function () { pg._popup = null; pg._open = false; return pg; };
    pg.openPopup = function () {
      var box = document.getElementById("stub-popup");
      if (!box) { box = document.createElement("div"); box.id = "stub-popup"; document.body.appendChild(box); }
      box.replaceChildren(pg._popup); pg._open = true; return pg;
    };
    pg.isPopupOpen = function () { return !!pg._open; };
    polys.push(pg);
    return pg;
  };
  var origMarker = L.marker;
  L.marker = function (p, o) { var m = origMarker(p, o); markers.push(m); return m; };
  window.__hex = {
    cells: function () { return polys.filter(function (p) { return p._cell; }); },
    live: function () { return polys.filter(function (p) { return p._cell && window.L && true; }).length; },
    click: function (id) { var p = polys.filter(function (x) { return x._cell && x._cell.id === id; }).pop(); p.fire("click", {}); return !!p; },
    popupText: function () { var b = document.getElementById("stub-popup"); return b ? b.innerText : ""; },
    labels: function () { return markers.filter(function (m) { return m.options && m.options.icon && m.options.icon.className === "hx-lbl"; }).map(function (m) { return m.options.icon.html; }); },
  };
})();
