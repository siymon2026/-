"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const hx = require("../lib/hexcell");

const near = (a, b, tol, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg || ""} ${a} vs ${b}`);
const BERRECHID = { lat: 33.265, lng: -7.59 };

test("a cell is a regular hexagon whose corner-to-corner diameter is 500 m", () => {
  const id = hx.cellOf(BERRECHID.lat, BERRECHID.lng);
  const c = hx.centerOf(id), b = hx.boundary(id);
  assert.equal(b.length, 6);
  for (const p of b) near(hx.distanceM(c, { lat: p[0], lng: p[1] }), 250, 2, "centre -> corner");
  for (let i = 0; i < 3; i++) { // opposite corners
    const p = b[i], q = b[i + 3];
    near(hx.distanceM({ lat: p[0], lng: p[1] }, { lat: q[0], lng: q[1] }), 500, 4, "diameter");
  }
  for (let i = 0; i < 6; i++) { // edge = 250 m
    const p = b[i], q = b[(i + 1) % 6];
    near(hx.distanceM({ lat: p[0], lng: p[1] }, { lat: q[0], lng: q[1] }), 250, 2, "edge");
  }
});

test("neighbouring cells are 433 m apart (flat side to flat side) and there are exactly 6", () => {
  const id = hx.cellOf(BERRECHID.lat, BERRECHID.lng);
  const ns = hx.neighbors(id);
  assert.equal(new Set(ns).size, 6);
  for (const n of ns) near(hx.distanceM(hx.centerOf(id), hx.centerOf(n)), 433, 3, "neighbour distance");
});

test("cellOf and centerOf agree, and a cell contains exactly the points inside its hexagon", () => {
  let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 400; i++) {
    const lat = BERRECHID.lat + (rnd() - 0.5) * 0.08, lng = BERRECHID.lng + (rnd() - 0.5) * 0.08;
    const id = hx.cellOf(lat, lng);
    assert.ok(/^hx:-?\d+:-?\d+$/.test(id));
    assert.equal(hx.cellOf(hx.centerOf(id).lat, hx.centerOf(id).lng), id);
    // the point is closer to its own centre than 250 m (circumradius), and not nearer to a neighbour's centre
    const d0 = hx.distanceM({ lat, lng }, hx.centerOf(id));
    assert.ok(d0 <= 251, "within the circumradius");
    for (const n of hx.neighbors(id)) assert.ok(d0 <= hx.distanceM({ lat, lng }, hx.centerOf(n)) + 1.5, "nearest centre wins");
  }
});

test("rings: 1 -> 7 cells, 2 -> 19, 3 -> 37; steps between cells", () => {
  const id = hx.cellOf(BERRECHID.lat, BERRECHID.lng);
  assert.deepEqual([0, 1, 2, 3].map((k) => hx.disk(id, k).length), [1, 7, 19, 37]);
  assert.ok(hx.disk(id, 2).includes(id));
  const far = hx.disk(id, 3).filter((c) => hx.stepsBetween(id, c) === 3);
  assert.equal(far.length, 18);
  assert.equal(hx.stepsBetween(id, id), 0);
  assert.equal(hx.stepsBetween(id, "nope"), Infinity);
});

test("bad ids and coordinates are rejected, never thrown on", () => {
  for (const bad of [null, undefined, "", "hx:1", "hx:a:b", "h3:xyz", "hx:1:2:3", "hx:99999999:1"]) {
    assert.equal(hx.isCell(bad), false, String(bad));
    assert.equal(hx.centerOf(bad), null);
    assert.deepEqual(hx.boundary(bad), []);
    assert.deepEqual(hx.neighbors(bad), []);
  }
  for (const [la, ln] of [[NaN, 1], [91, 0], [0, 181], ["x", 1], [null, null]]) assert.equal(hx.cellOf(la, ln), null);
});

test("a polygon is covered by the cells that overlap it — nobody inside is left out", () => {
  // a ~3 km square around Berrechid
  const d = 0.0135, poly = [[BERRECHID.lat - d, BERRECHID.lng - d], [BERRECHID.lat - d, BERRECHID.lng + d], [BERRECHID.lat + d, BERRECHID.lng + d], [BERRECHID.lat + d, BERRECHID.lng - d]];
  const cover = new Set(hx.coverPolygon(poly));
  assert.ok(cover.size > 40 && cover.size < 120, `cells: ${cover.size}`);
  let seed = 11; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 500; i++) {
    const lat = BERRECHID.lat + (rnd() * 2 - 1) * d, lng = BERRECHID.lng + (rnd() * 2 - 1) * d;
    assert.ok(cover.has(hx.cellOf(lat, lng)), "every point inside the polygon falls in a covered cell");
  }
  // and far points are not covered
  assert.equal(cover.has(hx.cellOf(BERRECHID.lat + 0.2, BERRECHID.lng)), false);
  // the cover is only slightly bigger than the area (no huge overshoot): area ratio < 1.6
  const cellArea = (3 * Math.sqrt(3) / 2) * 250 * 250;
  const polyArea = (2 * d * 111194.9) * (2 * d * 111194.9 * Math.cos(BERRECHID.lat * Math.PI / 180));
  assert.ok((cover.size * cellArea) / polyArea < 1.6, "reasonable overshoot");
  assert.ok((cover.size * cellArea) / polyArea >= 1, "covers at least the whole area");
});

test("cover is deterministic, sorted, and tolerant of garbage", () => {
  const poly = [[33.26, -7.6], [33.26, -7.58], [33.27, -7.58], [33.27, -7.6]];
  const a = hx.coverPolygon(poly), b = hx.coverPolygon(poly);
  assert.deepEqual(a, b);
  assert.deepEqual([...a].sort(), a);
  for (const bad of [null, [], [[1, 2]], "x", [[NaN, 1], [2, 3], [4, 5]]]) assert.deepEqual(hx.coverPolygon(bad), []);
});
