"use strict";
/** Supervisor-editable tiers / reward ladder / expiry alert window. */
const test = require("node:test");
const assert = require("node:assert/strict");
const loyalty = require("../lib/loyalty");
const app = require("../lib/loyalty-app");

const NOW = "2026-10-31T10:00:00.000Z";
const day = (n) => new Date(Date.parse(NOW) - n * 86400000).toISOString();
const norm = (body, prev) => loyalty.normalizeSettings(body, prev || loyalty.defaults());
const acct = (plan) => {
  const a = { customerId: "C1", entries: [] };
  plan.forEach(([d, p], i) => loyalty.credit(a, { ref: "loyalty:earn:O" + i, kind: "earn", points: p, orderId: "O" + i, at: day(d), expiresDays: 365 }));
  return a;
};
const tiers = (list, extra = {}) => ({ tiers: Object.assign({ list }, extra) });
const T = (id, from, ar = id) => ({ id, from, names: { ar } });

test("defaults keep the previous hard-coded numbers", () => {
  const s = loyalty.settingsOf({});
  assert.deepEqual(s.tiers.list.map((t) => [t.id, t.from]), [["bronze", 0], ["silver", 500], ["gold", 1500]]);
  assert.equal(s.tiers.windowMonths, 12);
  assert.deepEqual(s.ladder.steps, [5, 10, 20, 50, 100]);
  assert.equal(s.expiry.alertDays, 30);
});

test("old stored settings without the new blocks still load with defaults", () => {
  const s = loyalty.settingsOf({ enabled: true, earn: { unitAmount: 5 }, expiry: { enabled: true, days: 90 }, version: 4 });
  assert.equal(s.version, 4);
  assert.equal(s.tiers.list.length, 3);
  assert.equal(s.expiry.alertDays, 30);
});

test("tier thresholds and names can be changed and round-trip through storage", () => {
  const r = norm(tiers([T("bronze", 0, "عادي"), T("vip", 300, "مميز")], { windowMonths: 6 }));
  assert.ok(r.ok);
  const back = loyalty.settingsOf(r.value);
  assert.deepEqual(back.tiers.list.map((t) => t.id), ["bronze", "vip"]);
  assert.equal(back.tiers.windowMonths, 6);
  assert.equal(back.tiers.list[1].names.en, "مميز"); // missing languages fall back to Arabic
});

test("tier validation is strict", () => {
  for (const [list, why] of [
    [[T("a", 10), T("b", 20)], "first level must start at 0"],
    [[T("a", 0), T("b", 0)], "strictly increasing"],
    [[T("a", 0), T("b", 500), T("c", 400)], "strictly increasing"],
    [[T("a", 0)], "2 to 6"],
    [Array.from({ length: 7 }, (_, i) => T("t" + i, i * 10)), "2 to 6"],
    [[T("a", 0), T("a", 10)], "unique"],
    [[T("a", 0), { id: "b", from: 10, names: { ar: "" } }], "Arabic name"],
    [[T("a", 0), T("b", 1.5)], "integer"],
    [[T("a", 0), { id: "b", from: 10, names: { ar: "x" }, color: "red" }], "unknown"],
  ]) {
    const r = norm(tiers(list));
    assert.equal(r.ok, false, why);
    assert.match(r.error, new RegExp(why));
  }
  assert.equal(norm({ tiers: { windowMonths: 0 } }).ok, false);
  assert.equal(norm({ tiers: { windowMonths: 61 } }).ok, false);
  assert.equal(norm({ tiers: { windowMonths: 1.5 } }).ok, false);
  assert.equal(norm({ tiers: { bogus: 1 } }).code, "UNKNOWN_SETTING");
  assert.equal(norm({ tiers: { enabled: "yes" } }).ok, false);
});

test("a failed tier update never changes the stored settings", () => {
  const prev = loyalty.defaults();
  const snap = JSON.stringify(prev);
  assert.equal(norm(tiers([T("a", 5), T("b", 9)]), prev).ok, false);
  assert.equal(JSON.stringify(prev), snap);
});

test("ladder steps: sorted, unique, bounded", () => {
  const r = norm({ ladder: { steps: [50, 10, 25] } });
  assert.deepEqual(r.value.ladder.steps, [10, 25, 50]);
  assert.equal(norm({ ladder: { steps: [] } }).ok, false);
  assert.equal(norm({ ladder: { steps: [5, 5] } }).ok, false);
  assert.equal(norm({ ladder: { steps: [0] } }).ok, false);
  assert.equal(norm({ ladder: { steps: [-3] } }).ok, false);
  assert.equal(norm({ ladder: { steps: Array.from({ length: 9 }, (_, i) => i + 1) } }).ok, false);
  assert.equal(norm({ ladder: { steps: ["a"] } }).ok, false);
  assert.equal(norm({ ladder: { nope: 1 } }).code, "UNKNOWN_SETTING");
});

test("expiry alert window is bounded and cannot exceed the validity", () => {
  assert.equal(norm({ expiry: { alertDays: 14 } }).value.expiry.alertDays, 14);
  assert.equal(norm({ expiry: { alertDays: 0 } }).ok, false);
  assert.equal(norm({ expiry: { alertDays: 366 } }).ok, false);
  assert.equal(norm({ expiry: { alertDays: 2.5 } }).ok, false);
  assert.equal(norm({ expiry: { days: 20, alertDays: 30 } }).ok, false);
  assert.equal(norm({ expiry: { days: 20, alertDays: 20 } }).ok, true);
});

test("customer tier follows the configured levels", () => {
  const s = loyalty.settingsOf(norm(tiers([T("bronze", 0, "عادي"), T("vip", 300, "مميز"), T("elite", 900, "نخبة")])).value);
  const a = acct([[10, 350]]);
  const t = app.tierState(a, Date.parse(NOW), s);
  assert.equal(t.id, "vip");
  assert.equal(t.toNext, 550);
  assert.equal(t.next.id, "elite");
  assert.equal(t.names.ar, "مميز");
  assert.deepEqual(t.tiers.map((x) => x.id), ["bronze", "vip", "elite"]);
});

test("window length is configurable (3 months drops older points)", () => {
  const a = acct([[20, 200], [150, 400]]);
  const s3 = loyalty.settingsOf(norm({ tiers: { windowMonths: 3 } }).value);
  const s12 = loyalty.settingsOf({});
  assert.equal(app.tierState(a, Date.parse(NOW), s3).earnedInWindow, 200);
  assert.equal(app.tierState(a, Date.parse(NOW), s12).earnedInWindow, 600);
  assert.equal(app.tierState(a, Date.parse(NOW), s3).windowMonths, 3);
});

test("tiers can be switched off", () => {
  const s = loyalty.settingsOf(norm({ tiers: { enabled: false } }).value);
  const v = app.appView(acct([[5, 2000]]), s, { available: 2000 }, NOW);
  assert.equal(v.tier.enabled, false);
  assert.deepEqual(v.tier.tiers, []);
  assert.equal(v.tier.next, null);
});

test("ladder uses the configured money steps", () => {
  const s = loyalty.settingsOf(norm({ ladder: { steps: [2, 7, 30] } }).value);
  const l = app.ladder(300, s);
  assert.deepEqual(l.steps.map((x) => x.value), [2, 7, 30]);
  assert.equal(l.steps.find((x) => x.value === 2).unlocked, true);
  assert.equal(l.next.value, 7);
});

test("expiring window follows alertDays", () => {
  const s = loyalty.settingsOf(norm({ expiry: { enabled: true, days: 365, alertDays: 10 } }).value);
  const a = { customerId: "C", entries: [] };
  loyalty.credit(a, { ref: "r1", kind: "earn", points: 100, at: day(0), expiresDays: 8 });
  loyalty.credit(a, { ref: "r2", kind: "earn", points: 50, at: day(0), expiresDays: 25 });
  const v10 = app.appView(a, s, { available: 150 }, NOW);
  assert.equal(v10.expiring.days, 10);
  assert.equal(v10.expiring.total, 100);
  const s30 = loyalty.settingsOf(norm({ expiry: { enabled: true, days: 365, alertDays: 30 } }).value);
  assert.equal(app.appView(a, s30, { available: 150 }, NOW).expiring.total, 150);
});

test("publicView exposes the levels, ladder and alert window per language", () => {
  const s = norm({ tiers: { list: [{ id: "bronze", from: 0, names: { ar: "أ", fr: "A", en: "A1" } }, { id: "x", from: 50, names: { ar: "ب", fr: "B", en: "B1" } }] }, expiry: { alertDays: 7 } }).value;
  const pv = loyalty.publicView(s, "fr");
  assert.deepEqual(pv.tiers.list.map((t) => t.name), ["A", "B"]);
  assert.equal(pv.expiry.alertDays, 7);
  assert.deepEqual(pv.ladder.steps, [5, 10, 20, 50, 100]);
});
