"""Customer side: reward products on /rewards/ and profile photo on /account/.
Run: PORT=4031 node tests/loyalty-admin-mock-server.js &  then  python3 tests/browser-customer-rewards.py"""
import asyncio, base64, io, json, urllib.request
from playwright.async_api import async_playwright
BASE = "http://127.0.0.1:4031"
errs = []
def post(path, body, headers=None):
    h = {"content-type": "application/json", "Authorization": "Bearer tok-system"}; h.update(headers or {})
    return json.loads(urllib.request.urlopen(urllib.request.Request(BASE+path, data=json.dumps(body).encode(), method="POST", headers=h)).read())
async def ev(pg, js, arg=None):
    """evaluate, retrying when the page reloads itself once (service worker / perms refresh)"""
    for i in range(4):
        try:
            await pg.wait_for_load_state("load")
            return await (pg.evaluate(js, arg) if arg is not None else pg.evaluate(js))
        except Exception as e:
            if "context was destroyed" not in str(e) or i == 3: raise
            await pg.wait_for_timeout(800)

async def main():
    # two products through the real admin route of the mock
    cheap = post("/api/admin/loyalty/rewards/products", {"names": {"ar": "قهوة مجانية"}, "points": 200, "stock": 2})["product"]
    dear = post("/api/admin/loyalty/rewards/products", {"names": {"ar": "وجبة عائلية"}, "points": 5000})["product"]
    async with async_playwright() as p:
        b = await p.chromium.launch(); ctx = await b.new_context(viewport={"width": 390, "height": 844})
        await ctx.add_init_script("localStorage.setItem('siymon_customer_token_v1','tok-cust')")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("rewards: " + str(e)))
        before = json.loads(urllib.request.urlopen(BASE + "/__balance").read())["available"]
        await pg.goto(BASE + "/rewards/"); await pg.wait_for_selector(".r-prod", timeout=8000)
        assert await pg.locator(".r-prod").count() == 2
        assert await pg.locator(".r-prod.is-locked").count() == 1, "unaffordable product is marked locked"
        await pg.screenshot(path="/tmp/shots/cust_shop.png")
        # tapping the locked one explains what is missing, no redeem button
        await pg.locator(".r-prod.is-locked").click(); await pg.wait_for_selector("#rReward.is-on")
        assert await pg.locator("#rRwGo").count() == 0
        await pg.locator("#rReward [data-close]").click(); await pg.wait_for_timeout(500)
        # redeem the affordable one
        await pg.locator(".r-prod:not(.is-locked)").click(); await pg.wait_for_selector("#rRwGo")
        await pg.locator("#rRwGo").click(); await pg.wait_for_selector(".r-done", timeout=5000)
        await pg.locator("#rReward [data-close]").click(); await pg.wait_for_timeout(900)
        assert await pg.locator(".r-rd.pending").count() == 1, "pending redemption listed"
        bal = json.loads(urllib.request.urlopen(BASE + "/__balance").read())["available"]
        assert bal == before - 200, (before, bal)
        await pg.screenshot(path="/tmp/shots/cust_shop_after.png")
        await ctx.close()

        # ---- profile photo
        ctx = await b.new_context(viewport={"width": 390, "height": 844})
        await ctx.add_init_script("localStorage.setItem('siymon_customer_token_v1','tok-cust')")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("account: " + str(e)))
        await pg.goto(BASE + "/account/"); await pg.wait_for_selector("#acBody:not(.hidden)")
        assert await pg.locator("#acAv img").count() == 0 and (await pg.locator("#acAv").inner_text()).strip() == "س"
        # make a real 800x400 JPEG in the browser and feed it to the file input
        png = await pg.evaluate("""() => { const c=document.createElement('canvas'); c.width=800; c.height=400; const x=c.getContext('2d'); x.fillStyle='#c33'; x.fillRect(0,0,800,400); x.fillStyle='#fff'; x.fillRect(300,100,200,200); return c.toDataURL('image/jpeg',0.9).split(',')[1]; }""")
        await pg.set_input_files("#acFile", files=[{"name": "me.jpg", "mimeType": "image/jpeg", "buffer": base64.b64decode(png)}])
        await pg.wait_for_selector("#acAv img", timeout=5000)
        assert (await pg.locator("#acAvMsg").inner_text()).strip(), "success message shown"
        dims = await pg.evaluate("() => { const i=document.querySelector('#acAv img'); return new Promise(r=>{ if(i.complete) r([i.naturalWidth,i.naturalHeight]); else i.onload=()=>r([i.naturalWidth,i.naturalHeight]); }); }")
        assert dims == [512, 512], dims  # centre-cropped square, downsized
        assert await pg.locator("#acAvDel").is_visible()
        await pg.screenshot(path="/tmp/shots/cust_avatar.png")
        # not an image -> friendly error, avatar unchanged
        await pg.set_input_files("#acFile", files=[{"name": "x.txt", "mimeType": "text/plain", "buffer": b"hello"}])
        await pg.wait_for_timeout(600)
        assert await pg.locator("#acAv img").count() == 1
        # remove
        await pg.locator("#acAvDel").click(); await pg.wait_for_timeout(500)
        assert await pg.locator("#acAv img").count() == 0 and await pg.locator("#acAvDel").is_hidden()
        await b.close()
asyncio.run(main())
assert not errs, errs
print("ok: customer rewards + avatar")
