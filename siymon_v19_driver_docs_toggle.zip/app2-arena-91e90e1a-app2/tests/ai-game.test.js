"use strict";
/** Siymon AI <-> Grid Battle integration: admin switches, read-only tools, privacy, prompt. */
const test = require("node:test");
const assert = require("node:assert");
const http = require("node:http");
const engine = require("../lib/ai/engine");
const aiSettings = require("../lib/ai/settings");
const storeLib = require("../lib/ai/store");
const limitsLib = require("../lib/ai/limits");
const tools = require("../lib/ai/tools");
const prompt = require("../lib/ai/prompt");
const dataLib = require("../lib/ai/data");
const { registerGridRoutes } = require("../lib/grid-battle");

/* ---- a real game store + facade, no HTTP ---- */
function mkGame() {
  let disk = null;
  const noop = (_q, _s, n) => n && n();
  const app = { get() {}, post() {}, put() {} };
  const names = { c1: { firstName: "Ahmed", lastName: "Benali" }, c2: { firstName: "Sara", lastName: "Khan" } };
  const rt = registerGridRoutes(app, { requireCustomer: noop, requireAdmin: noop, readJson: () => (disk ? JSON.parse(JSON.stringify(disk)) : null), writeJson: (_f, d) => { disk = JSON.parse(JSON.stringify(d)); }, file: "g", getCustomer: (id) => names[id], logger: { error() {} } });
  rt.hub.stop();
  return rt;
}
function playOne(rt) {
  rt.store.applyMatch({ matchId: "m1", kind: "quick", players: [{ id: "c1", name: "Ahmed B." }, { id: "c2", name: "Sara K." }], wins: [2, 1], winner: 0, reason: "score", rated: true, now: Date.now() });
}
function facade(rt) {
  const base = { searchProducts: async () => ({ items: [] }), orders: async () => [], wallet: async () => ({}), paymentMethods: async () => [], appSettings: async () => ({}), restaurants: async () => [], productDetails: async () => null, profile: async () => ({}), loyalty: async () => ({}), firstName: async () => "Ahmed" };
  return { ...base, gameInfo: async () => rt.assistantApi.info(), gameLeaderboard: async (n) => rt.assistantApi.leaderboard(n), gameStats: async (id) => rt.assistantApi.stats(id) };
}

/* ---- settings ---- */
test("settings: the game block defaults on, is clamped, and the public view only says whether the assistant may appear in the game", () => {
  const d = aiSettings.normalize({});
  assert.deepStrictEqual(d.game, { enabled: true, stats: true, leaderboard: true, tips: true, inGame: true });
  const off = aiSettings.normalize({ game: { enabled: false, stats: false, inGame: true, junk: 1 } });
  assert.strictEqual(off.game.enabled, false); assert.strictEqual(off.game.stats, false); assert.strictEqual(off.game.junk, undefined);
  assert.strictEqual(aiSettings.normalize({ game: "x" }).game.enabled, true, "garbage falls back to defaults");
  const pub = aiSettings.publicView(aiSettings.normalize({ enabled: true, game: { enabled: false, inGame: true } }), { keyConfigured: true, loggedIn: true });
  assert.deepStrictEqual(pub.game, { enabled: false, inGame: false }, "inGame requires the integration to be on");
  assert.strictEqual(JSON.stringify(pub).includes("leaderboard"), false, "stats/leaderboard switches stay server-side");
});

/* ---- tool declarations and enforcement ---- */
test("tools: guests get the public game tools, signed-in players also get their stats; switches remove them", () => {
  const names = (a, g) => tools.declarations(a, g).map((d) => d.name).filter((n) => /game/.test(n));
  assert.deepStrictEqual(names(false), ["get_game_info", "get_game_leaderboard"]);
  assert.deepStrictEqual(names(true), ["get_game_info", "get_game_leaderboard", "get_game_stats"]);
  assert.deepStrictEqual(names(true, { enabled: false, stats: true, leaderboard: true, tips: true }), []);
  assert.deepStrictEqual(names(true, { enabled: true, stats: false, leaderboard: false, tips: true }), ["get_game_info"]);
});
test("tools: a switched-off tool is refused at run time even if the model calls it anyway", async () => {
  const rt = mkGame(); playOne(rt); const data = facade(rt);
  const off = { enabled: false, stats: true, leaderboard: true, tips: true };
  for (const n of ["get_game_info", "get_game_leaderboard"]) assert.strictEqual((await tools.runTool(n, {}, { customerId: "c1", lang: "en", game: off }, data)).data.error, "feature_disabled");
  assert.strictEqual((await tools.runTool("navigate_to_app_page", { page: "grid" }, { customerId: "c1", lang: "en", game: off }, data)).data.error, "feature_disabled");
  const noStats = { enabled: true, stats: false, leaderboard: true, tips: true };
  assert.strictEqual((await tools.runTool("get_game_stats", {}, { customerId: "c1", lang: "en", game: noStats }, data)).data.error, "feature_disabled");
  assert.strictEqual((await tools.runTool("get_game_stats", {}, { customerId: null, lang: "en" }, data)).data.error, "login_required", "guests cannot read stats");
});

/* ---- data returned to the model ---- */
test("game data: own stats only, no opponent names or ids; leaderboard has shortened names and no ids; tips follow the switch", async () => {
  const rt = mkGame(); playOne(rt); const data = facade(rt);
  const me = await tools.runTool("get_game_stats", { customerId: "c2" /* hostile argument */ }, { customerId: "c1", lang: "en" }, data);
  assert.strictEqual(me.data.wins, 1); assert.strictEqual(me.data.rating, 1016); assert.strictEqual(me.data.rank, 1);
  const raw = JSON.stringify(me.data);
  assert.ok(!raw.includes("Sara") && !raw.includes("c2") && !raw.includes("Khan"), "opponent identity never reaches the model");
  assert.strictEqual(me.ui.nav.href, "/grid/");
  const lb = await tools.runTool("get_game_leaderboard", { limit: 99 }, { customerId: null, lang: "en" }, data);
  assert.strictEqual(lb.data.players.length, 2); assert.strictEqual(lb.data.players[0].name, "Ahmed B.");
  assert.ok(!JSON.stringify(lb.data).includes('"id"') && !JSON.stringify(lb.data).includes("c1"));
  const info = await tools.runTool("get_game_info", {}, { customerId: null, lang: "en", game: { enabled: true, tips: true } }, data);
  assert.ok(info.data.tips.length > 0 && info.data.ranking.tiers.length === 5 && info.data.modes.online.quickMatch.ranked === true && info.data.modes.solo.ranked === false);
  const noTips = await tools.runTool("get_game_info", {}, { customerId: null, lang: "en", game: { enabled: true, tips: false } }, data);
  assert.strictEqual(noTips.data.tips, undefined);
  assert.strictEqual(info.data.rewards.enabled, false, "rewards are off by default: nothing is promised");
});
test("assistant API is read only: reading never changes a rating, points or a result", async () => {
  const rt = mkGame(); playOne(rt); const before = JSON.stringify(rt.store.doc);
  rt.assistantApi.info(); rt.assistantApi.leaderboard(5); rt.assistantApi.stats("c1"); rt.assistantApi.stats("nobody");
  assert.strictEqual(JSON.stringify(rt.store.doc), before);
  assert.strictEqual(typeof rt.assistantApi.applyMatch, "undefined");
});

/* ---- prompt ---- */
test("prompt: the game section appears only when the integration is on, and forbids promises", () => {
  const on = prompt.buildSystem({ settings: aiSettings.normalize({ enabled: true }), loggedIn: true, lang: "ar", page: "grid", now: "x" });
  assert.ok(on.includes("GRID BATTLE") && on.includes("Grid Battle game page") && /Do not promise prizes/.test(on));
  const off = prompt.buildSystem({ settings: aiSettings.normalize({ enabled: true, game: { enabled: false } }), loggedIn: true, lang: "ar", page: "home", now: "x" });
  assert.strictEqual(off.includes("GRID BATTLE"), false);
});

/* ---- end to end with a fake model provider ---- */
function fakeProvider(script) {
  const seen = [];
  const srv = http.createServer((req, res) => {
    let body = ""; req.on("data", (c) => (body += c)); req.on("end", () => {
      seen.push(JSON.parse(body || "{}"));
      const turn = script.shift() || [{ text: "fin" }];
      res.writeHead(200, { "content-type": "text/event-stream" });
      res.write(`data: ${JSON.stringify({ candidates: [{ content: { parts: turn } }], usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 5 } })}\n\n`);
      res.end();
    });
  });
  return new Promise((r) => srv.listen(0, "127.0.0.1", () => r({ srv, seen, url: `http://127.0.0.1:${srv.address().port}` })));
}
async function ask(rt, over, owner, message) {
  const p = await fakeProvider([[{ functionCall: { name: "get_game_stats", args: {} } }], [{ text: "Your rating is 1016, Bronze." }]]);
  const files = {};
  const store = storeLib.create({ readJson: (f, d) => (files[f] !== undefined ? files[f] : d), writeJson: (f, v) => { files[f] = JSON.parse(JSON.stringify(v)); }, convFile: "c", statsFile: "s" });
  const settings = aiSettings.normalize({ enabled: true, ...over }); settings.baseUrl = p.url;
  const events = [];
  await engine.chat({ settings, store, limits: limitsLib.create(), data: facade(rt), env: { GEMINI_API_KEY: "test-key-123456" }, owner, ip: "9.9.9.9", message, page: "grid", lang: "en", send: (e) => events.push(e) });
  p.srv.close();
  return { p, events };
}
test("end to end: a signed-in player asks for their stats, the model reads them through the tool, the reply streams", async () => {
  const rt = mkGame(); playOne(rt);
  const { p, events } = await ask(rt, {}, { customerId: "c1" }, "what is my rating in the game?");
  assert.ok(p.seen[0].tools[0].functionDeclarations.some((d) => d.name === "get_game_stats"));
  assert.ok(p.seen[0].systemInstruction.parts[0].text.includes("GRID BATTLE"));
  const fr = p.seen[1].contents.at(-1).parts[0].functionResponse;
  assert.strictEqual(fr.name, "get_game_stats"); assert.ok(JSON.stringify(fr).includes("1016")); assert.ok(!JSON.stringify(fr).includes("Sara"));
  assert.ok(events.some((e) => e.type === "nav" && e.nav.href === "/grid/"));
  assert.strictEqual((events.find((e) => e.type === "final") || {}).text, "Your rating is 1016, Bronze.");
});
test("end to end: with the integration off the model is not even offered the game tools or the game rules", async () => {
  const rt = mkGame(); playOne(rt);
  const { p } = await ask(rt, { game: { enabled: false } }, { customerId: "c1" }, "what is my rating in the game?");
  const decl = p.seen[0].tools[0].functionDeclarations.map((d) => d.name);
  assert.ok(!decl.some((n) => /game/.test(n)));
  assert.ok(!p.seen[0].systemInstruction.parts[0].text.includes("GRID BATTLE"));
  const fr = p.seen[1].contents.at(-1).parts[0].functionResponse;   // the scripted model still tries: it is refused
  assert.ok(JSON.stringify(fr).includes("feature_disabled"));
});
test("end to end: a guest asking for stats is told to sign in (no data)", async () => {
  const rt = mkGame(); playOne(rt);
  const { p } = await ask(rt, {}, { guestKey: "abcdef0123456789" }, "my rating?");
  assert.ok(!p.seen[0].tools[0].functionDeclarations.some((d) => d.name === "get_game_stats"));
  assert.ok(JSON.stringify(p.seen[1].contents.at(-1).parts[0].functionResponse).includes("login_required"));
});
