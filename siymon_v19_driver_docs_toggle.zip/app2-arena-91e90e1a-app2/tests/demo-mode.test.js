"use strict";
const test = require("node:test");
const assert = require("node:assert");
const demo = require("../lib/demo-mode");

function harness() {
  const files = {
    customers: { customers: [{ id: "real_c", firstName: "Real", walletBalance: 10 }] },
    drivers: { drivers: [{ id: "real_d", name: "Real driver" }] },
    orders: { orders: [{ id: "real_o", customerId: "real_c", restaurantId: "real_s", status: "delivered" }] },
    topups: { topups: [] }, loyalty: { accounts: [{ customerId: "real_c", entries: [] }] },
  };
  let rs = { restaurants: [{ id: "real_s", name: { ar: "حقيقي" } }] }, menu = { items: [{ id: "real_m", restaurantId: "real_s" }] }, ru = { users: [{ id: "u1", restaurantId: "real_s" }] };
  const kv = {};
  const d = {
    stateFile: "state", dataFile: (n) => n,
    readJson: (f, fb) => (f === "customers.json" ? files.customers : f === "drivers.json" ? files.drivers : kv[f] !== undefined ? kv[f] : fb),
    writeJson: (f, v) => { kv[f] = JSON.parse(JSON.stringify(v)); },
    financeTx: (fn) => { const st = { ...files, touch() {}, customers: files.customers, drivers: files.drivers, orders: files.orders, topups: files.topups, loyalty: files.loyalty }; const r = fn(st); return r; },
    loadRestaurants: () => rs, saveRestaurants: (v) => { rs = v; }, loadMenu: () => menu, saveMenu: (v) => { menu = v; },
    loadRestaurantUsers: () => ru, saveRestaurantUsers: (v) => { ru = v; }, loadOrders: () => files.orders,
    hashPassword: (p) => "h:" + p, newVerify: () => ({ salt: "x" }),
  };
  return { d, files, get: () => ({ rs, menu, ru }) };
}

test("enable creates tagged demo data, disable removes exactly it", () => {
  const h = harness();
  const m = demo.create(h.d);
  const on = m.enable({ by: "a1" });
  assert.equal(on.ok, true);
  assert.equal(on.status.counts.customers, 3);
  assert.equal(on.status.counts.drivers, 3);
  assert.equal(on.status.counts.stores, 3);
  assert.ok(on.status.counts.orders >= 3);
  assert.equal(on.status.accounts.password, demo.DEMO_PASSWORD);
  assert.equal(m.enable().ok, false); // already on

  // a demo customer places an order during the demo, and a real order exists too
  h.files.orders.orders.unshift({ id: "x1", customerId: on.status.accounts.customers[0].id, restaurantId: "real_s" });
  const off = m.disable();
  assert.equal(off.ok, true);
  assert.equal(off.status.enabled, false);
  assert.deepEqual(h.files.customers.customers.map((c) => c.id), ["real_c"]);
  assert.deepEqual(h.files.drivers.drivers.map((c) => c.id), ["real_d"]);
  assert.deepEqual(h.files.orders.orders.map((o) => o.id), ["real_o"]);
  assert.deepEqual(h.get().rs.restaurants.map((r) => r.id), ["real_s"]);
  assert.deepEqual(h.get().menu.items.map((r) => r.id), ["real_m"]);
  assert.deepEqual(h.get().ru.users.map((r) => r.id), ["u1"]);
  assert.equal(h.files.loyalty.accounts.length, 1);
  assert.equal(m.enable().ok, true); // can be re-enabled
});
